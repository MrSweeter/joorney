var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringTaskEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var pinMessage = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringTaskEffect: starringTaskEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus,
	pinMessage: pinMessage
};

function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
isFirefox() ? browser.tabs : chrome.tabs;
isFirefox() ? browser.contextMenus : chrome.contextMenus;
const Runtime = isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
isFirefox() ? browser.webNavigation : chrome.webNavigation;
isFirefox() ? browser.cookies : chrome.cookies;
isFirefox() ? browser.action : chrome.action;
isFirefox() ? browser.commands : chrome.commands;
isFirefox() ? browser.windows : chrome.windows;
isFirefox() ? browser.management : chrome.management;
isFirefox() ? browser.omnibox : chrome.omnibox;
isFirefox() ? browser.webRequest : chrome.webRequest;

async function sendRuntimeMessage(action, message = {}) {
    try {
        return await Runtime.sendMessage({ action: action, ...message });
    } catch (err) {
        Console.trace('catch runtime', err);
    }
}

const Console = {
    info(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
    },
    log(obj) {
        console.log(obj);
    },
    error(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
    },
    warn(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
    },
    success(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
    },
    trace(label, obj) {
        console.trace(label, obj);
    },
    critical(obj) {
        console.error(obj);
    },

    _getFormatOperator(obj) {
        switch (typeof obj) {
            case 'string':
                return '%s';
            case 'number':
                return '%s';
            case 'object':
                return '%O';
            default:
                return '%s';
        }
    },
};

const MESSAGE_ACTION = {
    TO_BACKGROUND: {
        GET_FEATURES_LIST: 'GET_FEATURES_LIST',
        GET_FINAL_RUNBOT_URL: 'GET_FINAL_RUNBOT_URL',
        UPDATE_EXT_STATUS: 'UPDATE_EXT_STATUS',
        TRIGGER_FEATURE: 'TRIGGER_FEATURE',
        RECREATE_MENU: 'RECREATE_MENU',
        TAB_LOADED: 'TAB_LOADED',
    },
    TO_CONTENT: {
        TAB_NAVIGATION: 'TAB_NAVIGATION',
        POPUP_HAS_CHANGE: 'POPU¨_HAS_CHANGE',
        REQUEST_ODOO_INFO: 'REQUEST_ODOO_INFO',
        CM_OPEN_MENU: 'CM_OPEN_MENU',
        CM_OPEN_RUNBOT: 'CM_OPEN_RUNBOT',
        WEB_REQUEST_COMPLETE: 'WEB_REQUEST_COMPLETE',
    },
};

function __variableDynamicImportRuntime4__(path) {
  switch (path) {
    case './src/features/adminDebugLoginRunbot/option.js': return Promise.resolve().then(function () { return option$f; });
    case './src/features/assignMeTask/option.js': return Promise.resolve().then(function () { return option$e; });
    case './src/features/autoOpenRunbot/option.js': return Promise.resolve().then(function () { return option$d; });
    case './src/features/awesomeLoadingLarge/option.js': return Promise.resolve().then(function () { return option$c; });
    case './src/features/awesomeLoadingSmall/option.js': return Promise.resolve().then(function () { return option$b; });
    case './src/features/awesomeStyle/option.js': return Promise.resolve().then(function () { return option$a; });
    case './src/features/contextOdooMenus/option.js': return Promise.resolve().then(function () { return option$9; });
    case './src/features/impersonateLoginRunbot/option.js': return Promise.resolve().then(function () { return option$8; });
    case './src/features/newServerActionCode/option.js': return Promise.resolve().then(function () { return option$7; });
    case './src/features/pinMessage/option.js': return Promise.resolve().then(function () { return option$6; });
    case './src/features/saveKnowledge/option.js': return Promise.resolve().then(function () { return option$5; });
    case './src/features/showMyBadge/option.js': return Promise.resolve().then(function () { return option$4; });
    case './src/features/starringTaskEffect/option.js': return Promise.resolve().then(function () { return option$3; });
    case './src/features/themeSwitch/option.js': return Promise.resolve().then(function () { return option$2; });
    case './src/features/tooltipMetadata/option.js': return Promise.resolve().then(function () { return option$1; });
    case './src/features/unfocusApp/option.js': return Promise.resolve().then(function () { return option; });
    default: return new Promise(function(resolve, reject) {
      (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
        reject.bind(null, new Error("Unknown variable dynamic import: " + path))
      );
    })
   }
 }

const baseSettings = {
    configurationVersion: 1,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['17.0'],

    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
};
Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

function importFeatureOptionFile(featureID) {
    return __variableDynamicImportRuntime4__(`./src/features/${featureID}/option.js`).then((f) => new f.default());
}

async function getCurrentSettings(features) {
    const defaultSettings = features.reduce((acc, obj) => {
        return Object.assign(acc, obj.defaultSettings);
    }, {});

    const settings = await StorageSync.get({
        ...baseSettings,
        ...defaultSettings,
    });
    return settings;
}

function disableFeatureInput(feature) {
    const inputs = Array.from(document.getElementsByClassName(`joorney_origins_filter_feature_input_${feature}`));
    for (const i of inputs) {
        i.disabled = true;
        i.classList.add('feature-disabled');
    }

    document.getElementById(`joorney_origins_filter_feature_header_${feature}`).style.opacity = 0.5;
}

function enableFeatureInput(feature) {
    const inputs = Array.from(document.getElementsByClassName(`joorney_origins_filter_feature_input_${feature}`));

    for (const i of inputs) {
        i.disabled = false;
        i.classList.remove('feature-disabled');
    }

    document.getElementById(`joorney_origins_filter_feature_header_${feature}`).style.opacity = 1;
}

//#region Drag and Drop
function setupDragAndDrop() {
    const whitelistFeature = document.getElementById('joorney-whitelist-feature');
    whitelistFeature.ondrop = (e) => {
        dropElement(e, true, true);
    };
    whitelistFeature.ondragover = allowDropInArea;

    const blacklistFeature = document.getElementById('joorney-blacklist-feature');
    blacklistFeature.ondrop = (e) => {
        dropElement(e, true, false);
    };
    blacklistFeature.ondragover = allowDropInArea;

    const disableFeature = document.getElementById('joorney-disable-feature');
    disableFeature.ondrop = (e) => {
        dropElement(e, false, undefined);
    };
    disableFeature.ondragover = allowDropInArea;
}

function allowDropInArea(e) {
    e.preventDefault();
}

function startDrag(e) {
    e.dataTransfer.setData('text/feature', e.currentTarget.getAttribute('data-feature'));
    e.dataTransfer.setData('text/id', e.currentTarget.id);
}

async function dropElement(e, enable, isWhitelist) {
    e.preventDefault();
    const dataFeature = e.dataTransfer.getData('text/feature');
    const dataID = e.dataTransfer.getData('text/id');
    const container = e.currentTarget;
    await StorageSync.set({
        [`${dataFeature}Enabled`]: enable,
        [`${dataFeature}WhitelistMode`]: isWhitelist,
    });
    if (enable) enableFeatureInput(dataFeature);
    else disableFeatureInput(dataFeature);
    const element = document.getElementById(dataID);
    if (container.id === element.parentElement.id) return;
    container.appendChild(document.getElementById(dataID));
    updateInputColor(dataFeature, enable, isWhitelist);
}
//#endregion

//#region Element dragging
const dragStart = (e) => e.currentTarget.classList.add('feature-dragging');
const dragEnd = (e) => e.currentTarget.classList.remove('feature-dragging');
for (const card of document.querySelectorAll('.draggable-feature')) {
    card.addEventListener('dragstart', dragStart);
    card.addEventListener('dragend', dragEnd);
}

/*const dragEnter = (e) => e.currentTarget.classList.add('drop');
const dragLeave = (e) => e.currentTarget.classList.remove('drop');
for (const column of document.querySelectorAll('.joorney-state-feature')) {
    column.addEventListener('dragenter', dragEnter);
    column.addEventListener('dragleave', dragLeave);
};*/
//#endregion

//#region Update Origins
async function updateFeatureOriginInputs(featureID, isEnable, isWhitelist) {
    updateInputColor(featureID, isEnable, isWhitelist);

    if (isEnable) enableFeatureInput(featureID);
    else disableFeatureInput(featureID);
}

function updateInputColor(feature, isEnable, isWhitelist) {
    for (const el of document.getElementsByClassName(`joorney_origins_filter_feature_input_${feature}`)) {
        el.classList.remove('joorney_f_whitelist');
        el.classList.remove('joorney_f_blacklist');
        el.classList.remove('joorney_f_disable');
        let toAdd = 'joorney_f_disable';
        if (isEnable) {
            if (isWhitelist) {
                toAdd = 'joorney_f_whitelist';
            } else {
                toAdd = 'joorney_f_blacklist';
            }
        }
        el.classList.add(toAdd);
    }
}
//#endregion

function stringToHTML(str) {
    const template = document.createElement('template');
    template.innerHTML = str.trim();
    return template.content.firstChild;
}

function generateLimitedFeatureOptionButtonItem(feature) {
    return stringToHTML(`
		<label
			title="[Limited Feature] ${feature.display_name ?? feature.id}"
			for="joorney_${feature.id}_limited_feature"
		>
			<input id="joorney_${feature.id}_limited_feature" class="input-hide" type="checkbox" />
			<div class="limited-feature-wrapper d-flex">
				<i class="joorney-font-icon-size fa-regular me-2"></i>
				<p>${feature.display_name ?? feature.id}</p>
			</div>
		</label>
	`);
}

function generateFeatureOptionListItem(feature) {
    const icon = feature.icon.join('\n');

    return stringToHTML(`
		<label
			id="joorney_${feature.id}_feature"
			title="[Feature] ${feature.display_name ?? feature.id}"
			data-feature="${feature.id}"
			class="draggable-feature" draggable="true"
		>
			<div class="feature-wrapper d-flex">
				<div class="icon-wrapper pe-1">
					${icon}
				</div>
				<p>${feature.display_name ?? feature.id}</p>
			</div>
		</label>
	`);
}

function generateFeatureOptionTableHeadItem(feature) {
    const icon = feature.icon.join('\n');

    return stringToHTML(`
		<th title="[Feature Origin] ${feature.display_name ?? feature.id}" class="icon-wrapper-head">
			<div class="icon-wrapper" id="joorney_origins_filter_feature_header_${feature.id}">
				${icon}
			</div>
		</th>
	`);
}

const regexSchemePrefix = 'regex://';

//#region CRUD
async function createOriginsFilterOrigin() {
    const origin = document.getElementById('joorney_origins_filter_new_origin');
    let originString = origin.value.trim();
    if (!originString) {
        renderOriginsFilterError('Missing origin');
        return;
    }

    const origins = await readOriginsFilterOrigins();

    if (originString.startsWith(regexSchemePrefix)) {
        let regexString = originString.replace(regexSchemePrefix, '');
        try {
            regexString = regexSchemePrefix + new RegExp(regexString).source;
            origins[regexString] = {};
            await renderOriginsObject(origins);
            origin.value = '';
        } catch (ex) {
            renderOriginsFilterError(ex);
        }
        return;
    }

    originString = originString.trim().toLowerCase().replace(/\s/g, '');

    if (origins[originString]) {
        renderOriginsFilterError('Origin already added');
        return;
    }

    try {
        originString = new URL(originString).origin;
        origins[originString] = {};
        await renderOriginsObject(origins);
        origin.value = '';
    } catch (ex) {
        renderOriginsFilterError(ex);
    }
}

async function readOriginsFilterOrigins() {
    const { originsFilterOrigins } = await StorageSync.get(baseSettings);
    return originsFilterOrigins;
}

async function deleteOriginsFilterOrigin(origin) {
    if (confirm(`Are you sure you want to remove origin: ${origin}?`)) {
        const origins = await readOriginsFilterOrigins();
        delete origins[origin];
        await renderOriginsObject(origins);
    }
}
//#endregion

//#region Event
function onKeydownHost(event) {
    if (event.key === 'Enter') createOriginsFilterOrigin();
}
async function load() {
    const originsFilterNewOrigin = document.getElementById('joorney_origins_filter_new_origin');
    originsFilterNewOrigin.onkeydown = onKeydownHost;

    document.getElementById('joorney_origins_filter_new_origin_save').onclick = createOriginsFilterOrigin;

    await restore();
}

async function restore() {
    const configuration = await StorageSync.get(baseSettings);

    await renderOriginsObject(configuration.originsFilterOrigins);
}
//#endregion

//#region UI
function renderOriginsFilterError(errorMessage) {
    const container = document.getElementById('joorney_origins_filter_error_footer');
    container.textContent = errorMessage;
    container.style.display = errorMessage ? 'table-cell' : 'none';
}

function updateColSpan(count) {
    const footers = document.querySelectorAll('tfoot tr td:first-child');
    footers[0].colSpan = `${count + 2}`;
    footers[1].colSpan = `${count + 1}`;
    footers[2].colSpan = `${count + 2}`;
}

async function renderOriginsObject(origins) {
    const originsArray = [];
    for (const o of Object.keys(origins)) originsArray.push({ ...origins[o], origin: o });

    await StorageSync.set({ originsFilterOrigins: origins });

    const response = await sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.GET_FEATURES_LIST);
    const features = response.features.filter((f) => !f.limited);

    const tableHeader = document.querySelector('#joorney_origins_filter_table thead tr');
    tableHeader.innerHTML = '';
    tableHeader.appendChild(
        stringToHTML(`<th class="joorney-origins_filter-origin-input" title="Odoo Database Origin">Origins</th>`)
    );
    for (const f of features) tableHeader.appendChild(generateFeatureOptionTableHeadItem(f));
    tableHeader.appendChild(stringToHTML(`<th class="py-0 joorney-valign-middle action-head"></th>`));

    const container = document.getElementById('joorney_origins_filter_table_body');
    container.innerHTML = '';
    for (const [id, o] of originsArray.entries())
        container.appendChild(
            renderOrigin(
                id,
                o,
                features.map((f) => f.id)
            )
        );
    renderOriginsFilterError();
    updateColSpan(features.length);

    const defaultConfiguration = await getCurrentSettings(features);

    for (const feature of features) {
        const enabled = defaultConfiguration[`${feature.id}Enabled`];
        const isWhitelist = defaultConfiguration[`${feature.id}WhitelistMode`];

        updateFeatureOriginInputs(feature.id, enabled, isWhitelist);
    }
}

function setupOriginFeature(container, idx, feature, origin) {
    const checkInput = container.getElementsByClassName(`joorney_origins_filter_origin_${idx}_${feature}`)[0];
    checkInput.onchange = (e) => updateOriginFeature(idx, origin, feature, e.currentTarget.checked);
}

async function updateOriginFeature(idx, origin, feature, checked) {
    // Disable row on update to avoid spamming/inconsistency if StorageSync.set take time
    const rowInputs = Array.from(
        document.getElementsByClassName(`joorney_origins_filter_feature_input_${idx} `)
    ).filter((i) => !i.className.includes('feature-disabled'));
    for (const i of rowInputs) i.disabled = true;

    const origins = await readOriginsFilterOrigins();
    origins[origin][feature] = checked;
    await StorageSync.set({ originsFilterOrigins: origins });

    for (const i of rowInputs) i.disabled = false;
}

function renderOrigin(idx, origin, features) {
    const originTemplate = document.createElement('template');

    const featuresUI = features
        .map((f) =>
            `
			<td>
				<input
					class="
					    joorney_origins_filter_feature_input_${idx}
                        joorney_origins_filter_feature_input_${f}
                        joorney_origins_filter_origin_${idx}_${f}
                        m-0 form-check-input
                    "
                    ${!document.getElementById(`joorney_${f}_feature`)?.checked ? 'disabled' : ''}
					type="checkbox"
					${origin[f] === true ? 'checked' : ''}
				/>
			</td>
		`.trim()
        )
        .join('\n');

    originTemplate.innerHTML = `
		<tr>
			<td class="p-1 joorney-valign-middle">
				<input
					id="joorney_origins_filter_origin_${idx}"
					class="joorney-bg-white form-control border border-0 joorney_origins_filter_origin_input"
					type="text"
					disabled
					value="${origin.origin}"
				/>
			</td>
			${featuresUI}
			<td class="p-1 joorney-valign-middle">
				<button
					class="joorney_origins_filter_origin_delete_${idx} btn btn-outline-danger border-0 btn-floating"
					title="Delete origin"
				>
					<i class="joorney-font-icon-size fa fa-trash"></i>
				</button>
			</td>
		</tr>
	`.trim();

    const originElement = originTemplate.content.firstChild;

    for (const f of features) setupOriginFeature(originElement, idx, f, origin.origin);

    const deleteButton = originElement.getElementsByClassName(`joorney_origins_filter_origin_delete_${idx}`)[0];
    deleteButton.onclick = () => deleteOriginsFilterOrigin(origin.origin);

    return originElement;
}
//#endregion

async function loadPage(features, _currentSettings) {
    await load();

    loadFeatures(features);

    setupDragAndDrop();
}

async function loadFeatures(features) {
    for (const feature of features) {
        importFeatureOptionFile(feature.id).then((featureModule) => featureModule.load());
    }
}

function featureIDToPascalCase(id) {
    return id.charAt(0).toUpperCase() + id.slice(1);
}

var adminDebugLoginConfiguration = {
    id: 'adminDebugLoginRunbot',
    display_name: '[Runbot] Admin Debug Login',
    icon: ['<i class="fa-solid fa-rocket"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        adminDebugLoginRunbotEnabled: false,
        adminDebugLoginRunbotLimitedOrigins: ['https://runbot.odoo.com', 'regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
    },
    limited: true,
};

var configuration$d = {
    id: 'assignMeTask',
    display_name: 'Assign Me Task',
    icon: ['<i class="fa-solid fa-user-plus"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        assignMeTaskEnabled: false,
        assignMeTaskWhitelistMode: false,
    },
    supported_version: ['16.3+'],
};

const openRunbotWithVersionMenuItem = {
    id: 'joorney_autoOpenRunbot_open_with_version',
    title: 'Open runbot with version %version%',
    active: true,
    favorite: true,
    order: 100,
};

var autoOpenRunbotConfiguration = {
    id: 'autoOpenRunbot',
    display_name: '[Runbot] Auto Open',
    icon: [
        '<!--<i class="fa-solid fa-door-open"></i>-->',
        '<!--<i class="fa-solid fa-dungeon"></i>-->',
        '<i class="fa-solid fa-fighter-jet"></i>',
    ],
    trigger: {
        load: true,
        navigate: true,
        context: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        autoOpenRunbotEnabled: false,
        autoOpenRunbotLimitedOrigins: ['https://runbot.odoo.com'],
        autoOpenRunbotContextMenu: {
            [openRunbotWithVersionMenuItem.id]: openRunbotWithVersionMenuItem,
        },
    },
    limited: true,
};

var configuration$c = {
    id: 'awesomeLoadingLarge',
    display_name: 'Awesome Loading Large',
    icon: ['<i class="fa-solid fa-circle-notch"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingSmall',
    defaultSettings: {
        awesomeLoadingLargeEnabled: false,
        awesomeLoadingLargeWhitelistMode: false,
        awesomeLoadingLargeImage: 'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['16:17'],
};

var configuration$b = {
    id: 'awesomeLoadingSmall',
    display_name: 'Awesome Loading Small',
    icon: ['<i class="fa-solid fa-spinner"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingLarge',
    defaultSettings: {
        awesomeLoadingSmallEnabled: false,
        awesomeLoadingSmallWhitelistMode: false,
        awesomeLoadingSmallImage: '',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['15+'],
};

var configuration$a = {
    id: 'awesomeStyle',
    display_name: 'Awesome Style',
    icon: ['<i class="fa-brands fa-css3-alt"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: true,
    },
    defaultSettings: {
        awesomeStyleEnabled: false,
        awesomeStyleWhitelistMode: false,
        awesomeStyleCSS: '',
    },
    supported_version: ['15+'],
};

var configuration$9 = {
    id: 'contextOdooMenus',
    display_name: 'Context OdooMenus',
    icon: ['<i class="fa-solid fa-location-arrow"></i>'],
    trigger: {
        background: false,
        load: false,
        navigate: false,
        context: true,
    },
    customization: {
        option: true,
        popup: false,
    },
    defaultSettings: {
        contextOdooMenusEnabled: false,
        contextOdooMenusWhitelistMode: false,
        contextOdooMenusContextMenu: {},
    },
    supported_version: ['15+'],
};

var configuration$8 = {
    id: 'impersonateLoginRunbot',
    display_name: '[Runbot] Impersonate Login',
    icon: ['<!--<i class="fa-solid fa-people-arrows"></i>-->', '<i class="fa-solid fa-masks-theater"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        impersonateLoginRunbotEnabled: false,
        impersonateLoginRunbotLimitedOrigins: ['regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
    },
    limited: true,
};

var configuration$7 = {
    id: 'newServerActionCode',
    display_name: 'New Server Action Code',
    icon: ['<i class="fa-solid fa-code"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        newServerActionCodeEnabled: false,
        newServerActionCodeWhitelistMode: false,
    },
    supported_version: ['15+'],
};

var configuration$6 = {
    id: 'pinMessage',
    display_name: 'Pin Message',
    icon: ['<i class="fa-solid fa-thumbtack"></i>'],
    trigger: {
        background: false,
        load: true,
        navigate: true,
        context: false,
        onrequest: [
            'https://*/*/mail.message/toggle_message_starred',
            'https://*/mail/message/update_content',
            'https://*/mail/thread/messages',
        ],
    },
    customization: {
        option: false,
        popup: true,
    },
    defaultSettings: {
        pinMessageEnabled: false,
        pinMessageWhitelistMode: false,
        pinMessageContextMenu: {},
        pinMessageSelfAuthorEnabled: true,
        pinMessageDefaultShown: false,
    },
    supported_version: ['17+'],
};

var configuration$5 = {
    id: 'saveKnowledge',
    display_name: 'Save Knowledge',
    icon: ['<i class="fa-regular fa-bookmark"></i>', '<i class="fa-solid fa-floppy-disk double-fa"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        saveKnowledgeEnabled: false,
        saveKnowledgeWhitelistMode: false,
    },
    supported_version: ['16:17'],
};

var configuration$4 = {
    id: 'showMyBadge',
    display_name: 'Show My Badge',
    icon: ['<i class="fa-solid fa-certificate"></i>'],
    trigger: {
        background: false,
        load: true,
        navigate: true,
    },
    customization: {
        option: false,
        popup: false,
    },
    defaultSettings: {
        showMyBadgeEnabled: false,
        showMyBadgeWhitelistMode: false,
    },
    supported_version: ['17+'],
};

var configuration$3 = {
    id: 'starringTaskEffect',
    display_name: 'Starring Task Effect',
    icon: ['<i class="fa-solid fa-star"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        starringTaskEffectEnabled: false,
        starringTaskEffectWhitelistMode: false,
    },
    supported_version: ['16+'],
};

var configuration$2 = {
    id: 'themeSwitch',
    display_name: 'Theme Switch',
    icon: [
        '<i class="fa-solid fa-sun"></i>',
        '<i class="fa-solid fa-circle double-fa-mask double-fa-bicolor"></i>',
        '<i class="fa-solid fa-moon double-fa"></i>',
    ],
    trigger: {
        background: true,
        load: false,
        navigate: false,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: "themeSwitchMode: 'system', 'autoDark', 'autoLight', 'dynamicLocation', 'dynamicTime'",
    defaultSettings: {
        themeSwitchEnabled: false,
        themeSwitchWhitelistMode: false,
        themeSwitchMode: 'system',
        themeSwitchLocationLatitude: '51.477928',
        themeSwitchLocationLongitude: '-0.001545',
        themeSwitchDarkStartTime: '20:30',
        themeSwitchDarkStopTime: '07:30',
    },
    supported_version: ['16+'],
};

var configuration$1 = {
    id: 'tooltipMetadata',
    display_name: 'Tooltip Metadata',
    icon: ['<i class="fa-solid fa-file-lines"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        tooltipMetadataEnabled: false,
        tooltipMetadataWhitelistMode: false,
    },
    supported_version: ['15+'],
};

var configuration = {
    id: 'unfocusApp',
    display_name: 'Unfocus App',
    icon: ['<i class="fa-solid fa-ghost"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    defaultSettings: {
        unfocusAppEnabled: false,
        unfocusAppWhitelistMode: false,
        unfocusAppReorderEnabled: false,
        unfocusAppShareEnabled: false,
        unfocusAppLightImageURL: 'https://i.imgur.com/AkTvOga.png',
        unfocusAppDarkImageURL: 'https://i.imgur.com/YzShNtH.png',
        unfocusAppOrigins: {},
    },
    supported_version: ['15+'],
};

class OptionFeature {
    constructor(configuration) {
        this.configuration = configuration;
        this.defaultSettings = configuration.defaultSettings;
    }

    async load() {
        this.appendHTMLFeatureElement();

        this.handlePopupMessage();

        return this.restore();
    }

    appendHTMLFeatureElement() {
        const disabledContainer = document.getElementById('joorney-disable-feature');
        disabledContainer.appendChild(generateFeatureOptionListItem(this.configuration));
    }

    handlePopupMessage() {
        if (!this.configuration.customization.popup) return;
        Runtime.onMessage.addListener((msg) => {
            if (msg.action !== MESSAGE_ACTION.TO_CONTENT.POPUP_HAS_CHANGE) return;
            this.onPopupMessage(msg);
        });
    }

    onPopupMessage(msg) {
        const enableFeature = msg[`enable${featureIDToPascalCase(this.configuration.id)}`];
        if (enableFeature === true || enableFeature === false) {
            this.restore();
        }
    }

    async restore() {
        const defaultConfiguration = await this.getDefaultConfiguration();
        this.moveElementToHTMLContainer(defaultConfiguration);
    }

    async getDefaultConfiguration() {
        const configuration = await StorageSync.get({
            [`${this.configuration.id}Enabled`]: false,
            [`${this.configuration.id}WhitelistMode`]: true,
        });
        return configuration;
    }

    moveElementToHTMLContainer(defaultConfiguration) {
        const enabled = defaultConfiguration[`${this.configuration.id}Enabled`];
        const isWhitelist = defaultConfiguration[`${this.configuration.id}WhitelistMode`];

        const featureElement = document.getElementById(`joorney_${this.configuration.id}_feature`);
        let container = document.getElementById('joorney-disable-feature');
        if (enabled) {
            if (isWhitelist) {
                container = document.getElementById('joorney-whitelist-feature');
            } else {
                container = document.getElementById('joorney-blacklist-feature');
            }
        }

        container.appendChild(featureElement);
        updateFeatureOriginInputs(this.configuration.id, enabled, isWhitelist);

        featureElement.ondragstart = startDrag;
    }
}

class LimitedShareOptionFeature extends OptionFeature {
    appendHTMLFeatureElement() {
        const limitedContainer = document.getElementById('joorney-limited-feature');
        limitedContainer.appendChild(generateLimitedFeatureOptionButtonItem(this.configuration));
    }

    moveElementToHTMLContainer(defaultConfiguration) {
        const enabled = defaultConfiguration[`${this.configuration.id}Enabled`];

        const featureInput = document.getElementById(`joorney_${this.configuration.id}_limited_feature`);
        featureInput.checked = enabled;

        featureInput.onchange = async (e) => {
            const checked = e.target.checked;
            await StorageSync.set({ [`${this.configuration.id}Enabled`]: checked });
        };
    }
}

class AdminDebugLoginRunbotOptionFeature extends LimitedShareOptionFeature {
    constructor() {
        super(adminDebugLoginConfiguration);
    }
}

var option$f = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AdminDebugLoginRunbotOptionFeature
});

class AssignMeTaskOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$d);
    }
}

var option$e = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AssignMeTaskOptionFeature
});

class AutoOpenRunbotOptionFeature extends LimitedShareOptionFeature {
    constructor() {
        super(autoOpenRunbotConfiguration);
    }
}

var option$d = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AutoOpenRunbotOptionFeature
});

class AwesomeLoadingLargeOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$c);
    }
}

var option$c = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeLoadingLargeOptionFeature
});

class AwesomeLoadingSmallOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$b);
    }
}

var option$b = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeLoadingSmallOptionFeature
});

class AwesomeStyleOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$a);
    }
}

var option$a = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeStyleOptionFeature
});

class ContextOdooMenusOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$9);
    }
}

var option$9 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ContextOdooMenusOptionFeature
});

class ImpersonateLoginRunbotOptionFeature extends LimitedShareOptionFeature {
    constructor() {
        super(configuration$8);
    }
}

var option$8 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ImpersonateLoginRunbotOptionFeature
});

class NewServerActionCodeOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$7);
    }
}

var option$7 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: NewServerActionCodeOptionFeature
});

class PinMessageOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$6);
    }
}

var option$6 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: PinMessageOptionFeature
});

class SaveKnowledgeOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$5);
    }
}

var option$5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: SaveKnowledgeOptionFeature
});

class ShowMyBadgeOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$4);
    }
}

var option$4 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ShowMyBadgeOptionFeature
});

class StarringTaskEffectOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$3);
    }
}

var option$3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: StarringTaskEffectOptionFeature
});

class ThemeSwitchOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$2);
    }
}

var option$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ThemeSwitchOptionFeature
});

class TooltipMetadataOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$1);
    }
}

var option$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: TooltipMetadataOptionFeature
});

class UnfocusAppOptionFeature extends OptionFeature {
    constructor() {
        super(configuration);
    }
}

var option = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: UnfocusAppOptionFeature
});

export { loadPage };
