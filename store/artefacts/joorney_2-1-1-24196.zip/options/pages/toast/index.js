var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringTaskEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringTaskEffect: starringTaskEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus
};

function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
isFirefox() ? browser.tabs : chrome.tabs;
isFirefox() ? browser.contextMenus : chrome.contextMenus;
isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
isFirefox() ? browser.webNavigation : chrome.webNavigation;
isFirefox() ? browser.cookies : chrome.cookies;
isFirefox() ? browser.action : chrome.action;
isFirefox() ? browser.commands : chrome.commands;
isFirefox() ? browser.windows : chrome.windows;
isFirefox() ? browser.management : chrome.management;
isFirefox() ? browser.omnibox : chrome.omnibox;

const Console = {
    info(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
    },
    log(obj) {
        console.log(obj);
    },
    error(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
    },
    warn(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
    },
    success(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
    },
    trace(label, obj) {
        console.trace(label, obj);
    },
    critical(obj) {
        console.error(obj);
    },

    _getFormatOperator(obj) {
        switch (typeof obj) {
            case 'string':
                return '%s';
            case 'number':
                return '%s';
            case 'object':
                return '%O';
            default:
                return '%s';
        }
    },
};

const baseSettings = {
    configurationVersion: 1,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['17.0'],

    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
};
Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

function stringToHTML(str) {
    const template = document.createElement('template');
    template.innerHTML = str.trim();
    return template.content.firstChild;
}

async function sleep(timeMS) {
    return await new Promise((r) => setTimeout(r, timeMS));
}

const html = String.raw;
const css = String.raw;

const toastFadeInOutDurationMillis = 500;
const toastDelayMillis = 100;
const toastDurationMillis = 3000;

const ToastContainerElementID = 'joorney-toast-container';
const ToastItemElementClass = 'joorney-toasty';

const iconForType = {
    success: 'fa fa-check-circle',
    danger: 'fa fa-exclamation-circle',
    warning: 'fa fa-exclamation-triangle',
    info: 'fa fa-info-circle',
};

const ToastStyle = css`
    #${ToastContainerElementID} {
        display: flex;
        flex-direction: column;
        padding: 16px;
        position: fixed;
        top: 10px;
        width: 100%;
        z-index: 9999;
        pointer-events: none;
        font-family: Roboto, sans-serif;
    }

    .${ToastItemElementClass} {
        display: none;
        opacity: 0;
        align-self: end;
        padding: 16px;
        margin-bottom: 10px;
        border-radius: 4px;
        min-width: 300px;
        max-width: 600px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        position: relative;
        overflow: hidden;
        pointer-events: auto;
    }

    .${ToastItemElementClass}-success .toast-progress {
        background-color: #4caf50;
    }

    .${ToastItemElementClass}-danger .toast-progress {
        background-color: #f44336;
    }

    .${ToastItemElementClass}-info .toast-progress {
        background-color: #2196f3;
    }

    .${ToastItemElementClass}-warning .toast-progress {
        background-color: #ff9800;
    }

    .toast-icon {
        margin-right: 10px;
        font-size: 24px;
    }

    .toast-content {
        flex-grow: 1;
        align-content: center;
    }

    .toast-title {
        font-weight: bold;
        margin-bottom: 5px;
    }

    .toast-text {
        max-width: 500px;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .toast-feature span {
        background-color: rgba(128, 128, 128, .25);
    }

    .toast-close {
        cursor: pointer;
        position: absolute;
        top: 8px;
        right: 8px;
        font-size: 16px;
        background: transparent;
        border: none;
    }

    .toast-progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 5px;
        animation: progressBar ${toastDurationMillis}ms linear forwards;
        animation-delay: ${toastDelayMillis + toastFadeInOutDurationMillis}ms;
    }

    @keyframes progressBar {
        from { width: 100%; }
        to { width: 0%; }
    }
  `.trim();

const ToastContainer = html`
    <div id="${ToastContainerElementID}">
        <style>${ToastStyle}</style>
    </div>
`.trim();

function buildContainer() {
    const container = stringToHTML(ToastContainer);
    return container;
}

function buildToastItem(feature, title, message, type, large) {
    const toastID = `toast-${Date.now()}`;
    const textHeight = !large ? 'height: 20px; white-space: nowrap;' : '';
    const item = stringToHTML(html`
        <div id="${toastID}" class="${ToastItemElementClass} ${ToastItemElementClass}-${type} alert-${type}">
            <div class="toast-icon"><i class="${iconForType[type]}"></i></div>
            <div class="toast-content">
                <div>
                    <strong>Joorney: </strong>
                    <span class="toast-feature">
                        <span class="badge rounded-pill">${feature}</span>
                    </span>
                </span>
                <div class="toast-title">${title}</div>
                <div
                    class="toast-text"
                    style="${textHeight}"
                >${message}</div>
            </div>
            <button id="close-${toastID}" class="toast-close"><i class="fa-solid fa-xmark"></i></button>
            <div class="toast-progress"></div>
        </div>
    `);
    return item;
}

const existingToast = {};
const maximumNotification = 3;

const ToastManager = {
    async load() {
        const container = buildContainer();
        const existElement = document.getElementById(container.id);
        if (existElement) existElement.remove();

        document.documentElement.appendChild(container);
        this.toastMode = (await StorageSync.get(baseSettings))?.toastMode ?? 'ui';
        this.toastType = JSON.parse((await StorageSync.get(baseSettings))?.toastType);
    },

    isDisabled() {
        return this.toastMode === 'disabled';
    },

    isLogConsole() {
        return this.toastMode === 'log';
    },

    isLargeMode() {
        return this.toastMode === 'large-ui';
    },

    info(feature, title, message, force = false) {
        return this._notify(feature, title, message, 'info', force);
    },

    warn(feature, title, message, force = false) {
        return this._notify(feature, title, message, 'warning', force);
    },

    error(feature, title, message, force = false) {
        return this._notify(feature, title, message, 'danger', force);
    },

    success(feature, title, message, force = false) {
        return this._notify(feature, title, message, 'success', force);
    },

    async _notify(feature, title, message, type, force) {
        if (this.isDisabled()) return false;
        if (!this.toastType[type]) return false;

        const existing = Object.entries(existingToast).find((entry) => entry[1].msg === message);
        if (existing) {
            if (existing[1].id) clearTimeout(existing[1].id);
            this._updateui(existing, feature);
            return true;
        }

        const isLogConsole = this.isLogConsole();
        if (isLogConsole) {
            this._log(feature, title, message, type);
            return true;
        }

        if (!force && Object.keys(existingToast).length >= maximumNotification) {
            this._log(feature, title, message, type, false);
            this._ui(
                'notification',
                '',
                `You have reached the notification limit (${maximumNotification}). Notification logged to console.`,
                'warning'
            );
            return true;
        }

        if (this.isLargeMode()) {
            this._ui(feature, title, message, type, true);
            return true;
        }

        this._log(feature, title, message, type, false);
        this._ui(feature, title, message, type, false);

        return true;
    },

    _ui(feature, title, message, type, large) {
        const container = document.getElementById(ToastContainerElementID);
        if (!container) return;
        const item = buildToastItem(feature, title, message, type, large);
        container.appendChild(item);
        const toastID = item.id;
        existingToast[toastID] = { msg: message, id: this._show(toastID) };
    },

    _log(feature, title, message, type, antispam = true) {
        const itemID = `log-${Date.now()}`;
        if (antispam) existingToast[itemID] = message;
        switch (type) {
            case 'info':
                Console.info(`(${feature})\n${title}\n${message}`);
                break;
            case 'danger':
                Console.error(`(${feature})\n${title}\n${message}`);
                break;
            case 'warning':
                Console.warn(`(${feature})\n${title}\n${message}`);
                break;
            case 'success':
                Console.success(`(${feature})\n${title}\n${message}`);
                break;
            default:
                Console.log(`[${type}] (${feature})\n${title}\n${message}`);
        }
        if (antispam) {
            setTimeout(() => {
                delete existingToast[itemID];
            }, toastDelayMillis * 1000);
        }
    },

    _show(toastID) {
        const toast = document.getElementById(toastID);
        if (!toast) return;

        toast.style.display = 'flex';
        toast.style.transform = 'translateX(200%)';
        toast.style.transition = `transform ${toastFadeInOutDurationMillis}ms ease-in-out, opacity ${toastFadeInOutDurationMillis}ms ease-in-out`;
        setTimeout(() => {
            toast.style.transform = 'translateX(0%)';
            toast.style.opacity = 1;
        }, toastDelayMillis);

        document.getElementById(`close-${toastID}`).onclick = () => this._hide(toastID);
        toast.onclick = () => this._hide(toastID);

        return setTimeout(
            () => {
                this._hide(toastID);
            },
            toastDelayMillis + toastFadeInOutDurationMillis + toastDurationMillis
        );
    },

    _hide(toastID) {
        const toast = document.getElementById(toastID);
        if (!toast) return;
        toast.style.transform = 'translateX(200%)';
        toast.style.opacity = 0;
        setTimeout(() => {
            toast.remove();
            delete existingToast[toastID];
        }, toastDelayMillis + toastFadeInOutDurationMillis);
    },

    _updateui(existing, feature) {
        const features = document.getElementById(existing[0]).getElementsByClassName('toast-feature')[0];
        const featureBadge = stringToHTML(`
                <span class="badge rounded-pill">${feature}</span>
            `);
        features.appendChild(featureBadge);

        const toast = document.getElementById(existing[0]);
        if (!toast) return true;
        const progress = toast.getElementsByClassName('toast-progress')[0];
        if (!progress) return true;

        progress.style.animation = 'none';
        progress.offsetWidth; // force re-render
        progress.style.animation = '';
        existingToast[existing[0]].id = setTimeout(() => {
            this._hide(existing[0]);
        }, toastDurationMillis + toastFadeInOutDurationMillis);
    },
};

async function loadPage(features, currentSettings) {
    ToastManager.load();

    handleToastMode(currentSettings.toastMode);
    handleToastType(JSON.parse(currentSettings.toastType));
}

let joorneyCurrentToastMode = undefined;

function handleToastMode(mode) {
    const radioButtons = document.querySelectorAll('.joorney-toast-mode-control input[type="radio"]');
    for (const radio of radioButtons) {
        radio.checked = mode === radio.value;
        if (radio.checked) joorneyCurrentToastMode = mode;
        radio.onchange = (e) => {
            joorneyCurrentToastMode = e.target.value;
            StorageSync.set({ toastMode: joorneyCurrentToastMode });
            ToastManager.load();
        };
    }

    document.getElementById('joorney-toast-mode-showme').onclick = () => showMockToast();
}

function handleToastType(types) {
    const checkboxes = document.querySelectorAll('.joorney-toast-mode-control input[type="checkbox"]');
    for (const checkbox of checkboxes) {
        checkbox.checked = types[checkbox.dataset.toastType];
        checkbox.onchange = (e) => {
            StorageSync.set({
                toastType: JSON.stringify({ ...types, [e.target.dataset.toastType]: e.target.checked }),
            });
            ToastManager.load();
        };
    }
}

async function showMockToast() {
    if (!joorneyCurrentToastMode) return;
    const types = await StorageSync.get('toastType');
    const toastType = JSON.parse(types.toastType);

    if (
        ToastManager.info(
            'options-demo-info',
            'Update Available',
            `A new software update is available for download.

        This update includes several new features and performance improvements.
        It is recommended to install the update as soon as possible.

        Make sure your device is connected to the internet and has sufficient battery life.
        Click on the update button to start the process.
        <br /><br /><small>Generated by ChatGPT.</small>`,
            true
        )
    )
        await sleep(500);
    if (
        ToastManager.warn(
            'options-demo-warn',
            'Password Expiring',
            `Your profile has been successfully updated.
            All changes have been saved and are now active.
            You can review your updated profile information in the settings section.
            If you encounter any issues, please contact support.
            Thank you for keeping your information current.
            <br /><br /><small>Generated by ChatGPT.</small>`,
            true
        )
    )
        await sleep(500);

    if (
        ToastManager.error(
            'options-demo-error',
            'Connection Lost',
            `Your password will expire in 3 days.
            Please update it to ensure continued access to your account.
            It is recommended to choose a strong and unique password that you haven't used before.
            If you do not update your password, you may be locked out of your account.
             Go to the settings page to change your password.
            <br /><br /><small>Generated by ChatGPT.</small>`,
            true
        )
    )
        await sleep(500);

    if (toastType.success) {
        ToastManager.success(
            'options-demo-success',
            'Profile Updated',
            `Unable to connect to the server.
            Please check your internet connection and try again.
            If the problem persists, it might be due to server maintenance or network issues on our end.
            We apologize for the inconvenience.
            You can retry the connection or contact support for further assistance.
            <br /><br /><small>Generated by ChatGPT.</small>`,
            true
        );
    }
}

export { loadPage };
