var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringPriorityEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var pinMessage = true;
var ambient = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringPriorityEffect: starringPriorityEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus,
	pinMessage: pinMessage,
	ambient: ambient
};

function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
isFirefox() ? browser.tabs : chrome.tabs;
isFirefox() ? browser.contextMenus : chrome.contextMenus;
const Runtime = isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
isFirefox() ? browser.webNavigation : chrome.webNavigation;
isFirefox() ? browser.cookies : chrome.cookies;
isFirefox() ? browser.action : chrome.action;
isFirefox() ? browser.commands : chrome.commands;
isFirefox() ? browser.windows : chrome.windows;
isFirefox() ? browser.management : chrome.management;
isFirefox() ? browser.omnibox : chrome.omnibox;
isFirefox() ? browser.webRequest : chrome.webRequest;

async function sendRuntimeMessage(action, message = {}) {
    try {
        return await Runtime.sendMessage({ action: action, ...message });
    } catch (err) {
        Console.trace('catch runtime', err);
    }
}

const Console = {
    info(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
    },
    log(obj) {
        console.log(obj);
    },
    error(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
    },
    warn(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
    },
    success(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
    },
    trace(label, obj) {
        console.trace(label, obj);
    },
    critical(obj) {
        console.error(obj);
    },

    _getFormatOperator(obj) {
        switch (typeof obj) {
            case 'string':
                return '%s';
            case 'number':
                return '%s';
            case 'object':
                return '%O';
            default:
                return '%s';
        }
    },
};

const MESSAGE_ACTION = {
    TO_BACKGROUND: {
        GET_FEATURES_LIST: 'GET_FEATURES_LIST',
        GET_FINAL_RUNBOT_URL: 'GET_FINAL_RUNBOT_URL',
        UPDATE_EXT_STATUS: 'UPDATE_EXT_STATUS',
        TRIGGER_FEATURE: 'TRIGGER_FEATURE',
        RECREATE_MENU: 'RECREATE_MENU',
        TAB_LOADED: 'TAB_LOADED',
    },
    TO_CONTENT: {
        TAB_NAVIGATION: 'TAB_NAVIGATION',
        POPUP_HAS_CHANGE: 'POPU¨_HAS_CHANGE',
        REQUEST_ODOO_INFO: 'REQUEST_ODOO_INFO',
        CM_OPEN_MENU: 'CM_OPEN_MENU',
        CM_OPEN_RUNBOT: 'CM_OPEN_RUNBOT',
        WEB_REQUEST_COMPLETE: 'WEB_REQUEST_COMPLETE',
    },
};

function __variableDynamicImportRuntime7__(path) {
  switch (path) {
    case './options/migration/migrator/migrate_0.js': return Promise.resolve().then(function () { return migrate_0; });
    case './options/migration/migrator/migrate_1.js': return Promise.resolve().then(function () { return migrate_1; });
    default: return new Promise(function(resolve, reject) {
      (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
        reject.bind(null, new Error("Unknown variable dynamic import: " + path))
      );
    })
   }
 }

const baseSettings = {
    configurationVersion: 2,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['19.0'],
    supportedDevVersions: [],

    // Experimental
    developerMode: false,
    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
    cacheEncodingBase64: true,
};
Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

function importMigratorFile(fromVersion) {
    return __variableDynamicImportRuntime7__(`./options/migration/migrator/migrate_${fromVersion}.js`).then((f) => f.default);
}

async function getFeaturesAndCurrentSettings() {
    const response = await sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.GET_FEATURES_LIST);
    const features = response.features;

    const configuration = await getCurrentSettings(features);
    return { features: features, currentSettings: configuration };
}

async function getCurrentSettings(features) {
    const defaultSettings = features.reduce((acc, obj) => {
        return Object.assign(acc, obj.defaultSettings);
    }, {});

    const settings = await StorageSync.get({
        ...baseSettings,
        ...defaultSettings,
    });
    return settings;
}

function setupInput() {
    const importInput = document.getElementById('joorney_import_storage_sync_file');
    importInput.onchange = (e) => {
        const reader = new FileReader();
        reader.onload = async (eventRead) => {
            const resJson = JSON.parse(eventRead.target.result);
            analyzeConfiguration(resJson);
        };
        reader.readAsText(e.target.files[0]);
    };

    const migrateCurrent = document.getElementById('migrate_current');
    migrateCurrent.onclick = async () => {
        const { currentSettings } = await getFeaturesAndCurrentSettings();
        analyzeConfiguration(currentSettings);
    };
}

function analyzeConfiguration(jsonFile) {
    const migrateVersion = jsonFile.configurationVersion ?? 0;
    const currentVersion = baseSettings.configurationVersion;

    const resume = document.getElementById('migration_resume');

    if (migrateVersion > currentVersion) {
        document.getElementById('error_message').innerHTML = 'Configuration cannot be migrate to a lower version';
        if (!resume.classList.contains('d-none')) resume.classList.add('d-none');
        return;
    }
    if (migrateVersion === currentVersion) {
        document.getElementById('error_message').innerHTML = 'Configuration cannot be migrate to the same version';
        if (!resume.classList.contains('d-none')) resume.classList.add('d-none');
        return;
    }
    document.getElementById('error_message').innerHTML = '';

    let migrateListString = `<h3><span class="badge badge-success py-1 px-3">${migrateVersion}</span></h3><i class="fa-solid fa-arrow-right-long mx-3"></i>`;
    for (let i = migrateVersion; i < currentVersion - 1; i++) {
        migrateListString += `<h3><span class="badge badge-info py-1 px-3">${i + 1}</span></h3>
        <i class="fa-solid fa-arrow-right-long mx-3"></i>`;
    }
    migrateListString += `<h3><span class="badge badge-success py-1 px-3">${currentVersion}</span></h3>`;
    document.getElementById('migration_list').innerHTML = migrateListString;

    const runButton = document.getElementById('run_migration');
    runButton.innerHTML = 'Execute migration';
    runButton.onclick = async (e) => {
        e.preventDefault();
        document.getElementById('joorney_import_storage_sync_file').value = null;
        const button = e.currentTarget;
        button.disabled = true;
        button.innerHTML = '<i class="fa-solid fa-spin fa-spinner"></i>';
        const finalConfiguration = await runMigration(jsonFile, migrateVersion, currentVersion);

        await StorageSync.set(finalConfiguration);

        button.innerHTML = 'Download new configuration';
        runButton.onclick = () => {
            downloadNewMigration(finalConfiguration);
        };
        button.disabled = false;
    };

    resume.classList.remove('d-none');
}

async function runMigration(configuration, fromVersion, toVersion) {
    let data = configuration;
    for (let i = fromVersion; i < toVersion; i++) {
        data = await runOneMigration(data, i);
    }
    return data;
}

async function runOneMigration(configuration, version) {
    const migrator = await importMigratorFile(version);
    return migrator(configuration);
}

function downloadNewMigration(data) {
    const dataStr = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(data))}`;
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute('href', dataStr);
    const fileName = `joorney_storage_sync_${new Date().toLocaleDateString()}.json`;
    downloadAnchorNode.setAttribute('download', fileName);
    document.body.appendChild(downloadAnchorNode); // required for firefox
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
}

async function onDOMContentLoaded() {
    setupInput();
}

document.removeEventListener('DOMContentLoaded', onDOMContentLoaded);
document.addEventListener('DOMContentLoaded', onDOMContentLoaded);

function run$1(configuration) {
    if (!configuration) return {};
    const result = configuration;

    const isWhitelist = !result.originsFilterIsBlacklist;

    result.assignMeTaskWhitelistMode = isWhitelist;
    result.saveKnowledgeWhitelistMode = isWhitelist;
    result.awesomeLoadingLargeWhitelistMode = isWhitelist;
    result.awesomeLoadingSmallWhitelistMode = isWhitelist;
    result.awesomeStyleWhitelistMode = isWhitelist;
    result.starringTaskEffectWhitelistMode = isWhitelist;
    result.unfocusAppWhitelistMode = isWhitelist;
    result.themeSwitchWhitelistMode = isWhitelist;

    result.originsFilterIsBlacklist = undefined;

    result.configurationVersion = 1;
    return result;
}

var migrate_0 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: run$1
});

function run(configuration) {
    if (!configuration) return {};
    const result = configuration;

    result.starringPriorityEffectEnabled = result.starringTaskEffectEnabled;
    result.starringPriorityEffectWhitelistMode = result.starringTaskEffectWhitelistMode;
    result.starringTaskEffectEnabled = undefined;
    result.starringTaskEffectWhitelistMode = undefined;

    const origins = result.originsFilterOrigins || {};

    for (const origin in origins) {
        if (Object.keys(origins[origin]).includes('starringTaskEffect')) {
            origins[origin].starringPriorityEffect = origins[origin].starringTaskEffect;
            origins[origin].starringTaskEffect = undefined;
        }
    }

    result.configurationVersion = 2;
    return result;
}

var migrate_1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: run
});
