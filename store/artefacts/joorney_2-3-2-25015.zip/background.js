function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
const Tabs = isFirefox() ? browser.tabs : chrome.tabs;
const ContextMenus = isFirefox() ? browser.contextMenus : chrome.contextMenus;
const Runtime = isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
const StorageLocal = isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
const WebNavigation = isFirefox() ? browser.webNavigation : chrome.webNavigation;
const Cookies = isFirefox() ? browser.cookies : chrome.cookies;
const Action = isFirefox() ? browser.action : chrome.action;
const Commands = isFirefox() ? browser.commands : chrome.commands;
const Windows = isFirefox() ? browser.windows : chrome.windows;
const Management = isFirefox() ? browser.management : chrome.management;
const OmniBox = isFirefox() ? browser.omnibox : chrome.omnibox;
const WebRequest = isFirefox() ? browser.webRequest : chrome.webRequest;

async function sendTabMessage(tabID, action, message = {}) {
    try {
        return await Tabs.sendMessage(tabID, { action: action, ...message });
    } catch (err) {
        Console.trace('catch tabs', err);
    }
}

const Console = {
    info(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
    },
    log(obj) {
        console.log(obj);
    },
    error(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
    },
    warn(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
    },
    success(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
    },
    trace(label, obj) {
        console.trace(label, obj);
    },
    critical(obj) {
        console.error(obj);
    },

    _getFormatOperator(obj) {
        switch (typeof obj) {
            case 'string':
                return '%s';
            case 'number':
                return '%s';
            case 'object':
                return '%O';
            default:
                return '%s';
        }
    },
};

async function isDevMode() {
    const installType = await getInstallType();
    return installType === 'development';
}

async function getInstallType() {
    const extension = await Management.getSelf();
    return extension.installType;
}

var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringTaskEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var pinMessage = true;
var ambient = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringTaskEffect: starringTaskEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus,
	pinMessage: pinMessage,
	ambient: ambient
};

const MESSAGE_ACTION = {
    TO_BACKGROUND: {
        GET_FEATURES_LIST: 'GET_FEATURES_LIST',
        GET_FINAL_RUNBOT_URL: 'GET_FINAL_RUNBOT_URL',
        UPDATE_EXT_STATUS: 'UPDATE_EXT_STATUS',
        TRIGGER_FEATURE: 'TRIGGER_FEATURE',
        RECREATE_MENU: 'RECREATE_MENU',
        TAB_LOADED: 'TAB_LOADED',
    },
    TO_CONTENT: {
        TAB_NAVIGATION: 'TAB_NAVIGATION',
        POPUP_HAS_CHANGE: 'POPU¨_HAS_CHANGE',
        REQUEST_ODOO_INFO: 'REQUEST_ODOO_INFO',
        CM_OPEN_MENU: 'CM_OPEN_MENU',
        CM_OPEN_RUNBOT: 'CM_OPEN_RUNBOT',
        WEB_REQUEST_COMPLETE: 'WEB_REQUEST_COMPLETE',
    },
};

function __variableDynamicImportRuntime3__(path) {
  switch (path) {
    case './src/features/themeSwitch/background.js': return Promise.resolve().then(function () { return background; });
    default: return new Promise(function(resolve, reject) {
      (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
        reject.bind(null, new Error("Unknown variable dynamic import: " + path))
      );
    })
   }
 }

function __variableDynamicImportRuntime0__(path) {
  switch (path) {
    case './src/features/adminDebugLoginRunbot/configuration.js': return Promise.resolve().then(function () { return configuration$u; });
    case './src/features/ambient/configuration.js': return Promise.resolve().then(function () { return configuration$t; });
    case './src/features/assignMeTask/configuration.js': return Promise.resolve().then(function () { return configuration$r; });
    case './src/features/autoOpenRunbot/configuration.js': return Promise.resolve().then(function () { return configuration$v; });
    case './src/features/awesomeLoadingLarge/configuration.js': return Promise.resolve().then(function () { return configuration$p; });
    case './src/features/awesomeLoadingSmall/configuration.js': return Promise.resolve().then(function () { return configuration$n; });
    case './src/features/awesomeStyle/configuration.js': return Promise.resolve().then(function () { return configuration$l; });
    case './src/features/contextOdooMenus/configuration.js': return Promise.resolve().then(function () { return configuration$j; });
    case './src/features/impersonateLoginRunbot/configuration.js': return Promise.resolve().then(function () { return configuration$h; });
    case './src/features/newServerActionCode/configuration.js': return Promise.resolve().then(function () { return configuration$f; });
    case './src/features/pinMessage/configuration.js': return Promise.resolve().then(function () { return configuration$d; });
    case './src/features/saveKnowledge/configuration.js': return Promise.resolve().then(function () { return configuration$b; });
    case './src/features/showMyBadge/configuration.js': return Promise.resolve().then(function () { return configuration$9; });
    case './src/features/starringTaskEffect/configuration.js': return Promise.resolve().then(function () { return configuration$7; });
    case './src/features/themeSwitch/configuration.js': return Promise.resolve().then(function () { return configuration$5; });
    case './src/features/tooltipMetadata/configuration.js': return Promise.resolve().then(function () { return configuration$3; });
    case './src/features/unfocusApp/configuration.js': return Promise.resolve().then(function () { return configuration$1; });
    default: return new Promise(function(resolve, reject) {
      (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
        reject.bind(null, new Error("Unknown variable dynamic import: " + path))
      );
    })
   }
 }

const baseSettings = {
    configurationVersion: 1,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['18.0'],

    // Experimental
    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
    cacheEncodingBase64: true,
};
const activeFeaturesList = Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

let features = [];
async function loadFeaturesConfiguration() {
    features = await Promise.all(activeFeaturesList.map((f) => importFeatureConfigurationFile(f)));
    Console.info(features);
}

function importFeatureConfigurationFile(featureID) {
    return __variableDynamicImportRuntime0__(`./src/features/${featureID}/configuration.js`).then((f) => f.default);
}

function importFeatureBackgroundFile(featureID) {
    return __variableDynamicImportRuntime3__(`./src/features/${featureID}/background.js`).then((f) => new f.default());
}

async function getCurrentSettings(features) {
    const defaultSettings = features.reduce((acc, obj) => {
        return Object.assign(acc, obj.defaultSettings);
    }, {});

    const settings = await StorageSync.get({
        ...baseSettings,
        ...defaultSettings,
    });
    return settings;
}

function sanitizeURL(url) {
    return sanitizedHrefToUrl(url);
}

function sanitizedHrefToUrl(hrefArg) {
    const href = typeof hrefArg === 'object' ? hrefArg.href : hrefArg;
    const url = new URL(href.replace(/#/g, href.includes('?') ? '&' : '?'));
    return url;
}

async function sleep(timeMS) {
    return await new Promise((r) => setTimeout(r, timeMS));
}

function yyyymmdd_hhmmssToDate(datetimeStr) {
    const [dateStr, timeStr] = datetimeStr.split(' ');
    return new Date(`${dateStr}T${timeStr}Z`).toISOString();
}

function toOdooBackendDateGMT0(date) {
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const hours = String(date.getUTCHours()).padStart(2, '0');
    const minutes = String(date.getUTCMinutes()).padStart(2, '0');
    const seconds = String(date.getUTCSeconds()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

function hasUnknownKey(sourceObj, targetObj) {
    for (const key in sourceObj) {
        if (!(key in targetObj)) {
            return true;
        }
    }
    return false;
}

// Private
const LOCAL_DEFAULT = {
    journey_announces: {},
    offs: [],
    ambient_dates: {},
    joorney_sunrise: 0,
    joorney_sunset: 23 * 60 + 59,
    joorney_date: '',
    joorneyLocalCacheCall: {},
};

async function setLocal(obj) {
    if (hasUnknownKey(obj, LOCAL_DEFAULT)) {
        Console.warn(`Unknown local key in: ${JSON.stringify(obj)}`);
    }
    await StorageLocal.set(obj);
}

// Announce
async function getAnnounceCloseStatus(hash) {
    const { journey_announces } = await StorageLocal.get({ journey_announces: LOCAL_DEFAULT.journey_announces });
    return journey_announces[hash] ?? false;
}

// Off website
async function getWebsiteOff() {
    const { offs } = await StorageLocal.get({ offs: LOCAL_DEFAULT.offs });
    return new Set(offs);
}

async function updateWebsiteOff(origin, disabled) {
    const offs = await getWebsiteOff();
    if (disabled) offs.add(origin);
    else offs.delete(origin);
    await StorageLocal.set({ offs: Array.from(offs) });
}

// Cache
async function getLocalCache() {
    const { joorneyLocalCacheCall } = await StorageLocal.get({
        joorneyLocalCacheCall: LOCAL_DEFAULT.joorneyLocalCacheCall,
    });
    return joorneyLocalCacheCall;
}
async function setLocalCache(cacheData) {
    await setLocal({ joorneyLocalCacheCall: cacheData });
}

// Ambient
async function getAmbientDates() {
    const { ambient_dates } = await StorageLocal.get({ ambient_dates: LOCAL_DEFAULT.ambient_dates });
    return ambient_dates;
}
async function setAmbientDates(datesData) {
    await setLocal({ ambient_dates: datesData });
}

// ThemeSwitch
async function getSunSchedule() {
    const cached = await StorageLocal.get({
        joorney_sunrise: LOCAL_DEFAULT.joorney_sunrise,
        joorney_sunset: LOCAL_DEFAULT.joorney_sunset,
        joorney_date: LOCAL_DEFAULT.joorney_date,
    });
    return cached;
}

async function setSunSchedule(scheduleData) {
    await setLocal(scheduleData);
}

/**
 * Caches the result of a function call for a specified amount of time.
 * If the cached result exists and hasn't expired, it is returned;
 * otherwise, the function is executed and the result is cached.
 *
 * @async
 * @function cache
 * @param {number} cachingTime - The amount of time (in minutes) to cache the result. If 0 or less, the result will not be cached.
 * @param {Function} call - The asynchronous function to call if there is no cached data.
 * @param {string} callID - A unique identifier for the cached data.
 * @param {...any} params - Additional parameters passed to both the `readCacheCall` and `saveCacheCall` functions.
 * @returns {Promise<{fromCache: boolean, data: any}>} - An object containing two properties:
 *          - `fromCache` (boolean): Whether the data was retrieved from the cache.
 *          - `data` (any): The cached data or the result of the function call.
 */
async function cache(cachingTime, call, callID, ...params) {
    let data = undefined;
    let fromCache = true;
    if (cachingTime > 0) {
        data = await readCacheCall(callID, ...params);
    }
    if (!data) {
        data = await call();
        fromCache = false;

        if (cachingTime > 0) await saveCacheCall(cachingTime, callID, data, ...params);
    }
    return { fromCache, data };
}

async function checkHostsExpiration() {
    let cache = await getLocalCache();
    cache = await _checkHostsExpiration(cache, Date.now());
    if (cache.changed) setLocalCache(cache.cache);
}

async function clearHost(host) {
    const cache = await getLocalCache();
    delete cache[host === Runtime.id ? `joorney://${Runtime.id}` : host];
    await setLocalCache(cache);
}

function getHost() {
    if (typeof window === 'undefined' || window.location.host === Runtime.id) return `joorney://${Runtime.id}`;
    return window.location.host;
}

// Clear host if last change is 12h hours old
async function _checkHostsExpiration(cache, now) {
    let hasChange = false;
    for (const [k, v] of Object.entries(cache)) {
        if (now - (v.lastChange ?? 0) > 12 * 60 * 60 * 1000) {
            delete cache[k];
            hasChange = true;
        }
    }
    return { changed: hasChange, cache: cache };
}

async function saveCacheCall(expireAfterMinute, call, result, ...params) {
    const { cacheEncodingBase64 } = await StorageSync.get({ cacheEncodingBase64: true });
    const hash = jbtoa(JSON.stringify(params), cacheEncodingBase64);
    const host = getHost();

    let cache = await getLocalCache();

    const now = Date.now();

    cache[host] ??= {};
    cache[host][call] ??= {};
    cache[host][call][hash] = {
        date: now,
        dateStr: new Date(now).toISOString(),
        expireAfterMinute: expireAfterMinute ?? 0,
        data: jbtoa(JSON.stringify(result), cacheEncodingBase64),
    };
    cache[host].lastChange = now;

    cache = await _checkHostsExpiration(cache, now);
    await setLocalCache(cache.cache);
}

async function readCacheCall(call, ...params) {
    const { cacheEncodingBase64 } = await StorageSync.get({ cacheEncodingBase64: true });
    const hash = jbtoa(JSON.stringify(params), cacheEncodingBase64);
    const host = getHost();
    let cache = await getLocalCache();
    cache = cache?.[host]?.[call]?.[hash];
    if (!cache) return undefined;
    const { date, expireAfterMinute, data } = cache;

    const now = Date.now();
    if (now - date > expireAfterMinute * 60 * 1000) return undefined;
    const decodeData = jatob(data, cacheEncodingBase64);
    return decodeData ? JSON.parse(decodeData) : undefined;
}

// TODO[IMP] Encryption/Decryption instead of Encoding/Decoding
function jbtoa(str, cacheEncodingBase64) {
    if (!cacheEncodingBase64) return str;
    try {
        return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (_, p1) => String.fromCharCode(`0x${p1}`)));
    } catch (e) {
        Console.error(e);
        return undefined;
    }
}

function jatob(data, cacheEncodingBase64) {
    if (!cacheEncodingBase64) return data;
    try {
        return decodeURIComponent(
            atob(data)
                .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
                .join('')
        );
    } catch (e) {
        Console.error(e);
        return undefined;
    }
}

const openRunbotWithVersionMenuItem = {
    id: 'joorney_autoOpenRunbot_open_with_version',
    title: 'Open runbot with version %version%',
    active: true,
    favorite: true,
    order: 100,
};

var autoOpenRunbotConfiguration = {
    id: 'autoOpenRunbot',
    display_name: '[Runbot] Auto Open',
    icon: '<i class="fa-solid fa-fighter-jet"></i>',
    trigger: {
        load: true,
        navigate: true,
        context: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        autoOpenRunbotEnabled: false,
        autoOpenRunbotLimitedOrigins: ['https://runbot.odoo.com'],
        autoOpenRunbotContextMenu: {
            [openRunbotWithVersionMenuItem.id]: openRunbotWithVersionMenuItem,
        },
    },
    limited: true,
};

var configuration$v = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: autoOpenRunbotConfiguration,
    openRunbotWithVersionMenuItem: openRunbotWithVersionMenuItem
});

// import { getVersionInfo } from '../api/odoo.js';

let SUPPORTED_VERSION = ['16.0']; // Minimal supported version for extension versioning

function updateSupportedVersion(versionsArg) {
    let versions = versionsArg;
    if (!versions || versions.length === 0) versions = ['18.0']; // Use current Odoo long-term version
    SUPPORTED_VERSION = versions.map((v) => sanitizeVersion(v));
}
function sanitizeVersion(version) {
    return `${version}`.replaceAll(/saas[~|-]/g, '');
}

const regexSchemePrefix = 'regex://';

async function isAuthorizedFeature(feature, url) {
    const key = `${feature}Enabled`;
    const configuration = await StorageSync.get({
        [key]: false,
    });
    if (!configuration[key]) return false;

    const authorizedFeature = await authorizeFeature(feature, url.origin);
    return authorizedFeature;
}

async function isAuthorizedLimitedFeature(featureName, url) {
    const key = `${featureName}Enabled`;
    const configKey = `${featureName}LimitedOrigins`;
    const configuration = await StorageSync.get({
        [key]: false,
        [configKey]: [],
    });
    if (!configuration[key]) return false;
    const origin = url.origin;

    const offs = await getWebsiteOff();
    if (offs.has(origin)) return false;

    // Check URL
    if (configuration[configKey].includes(origin)) {
        return true;
    }

    // Check Regex
    const activeRegex = configuration[configKey]
        .filter((o) => o.startsWith(regexSchemePrefix))
        .map((o) => new RegExp(o.replace(regexSchemePrefix, '')));
    const validRegex = activeRegex.some((r) => r.test(origin));

    return validRegex;
}

async function authorizeFeature(featureName, origin) {
    const offs = await getWebsiteOff();
    if (offs.has(origin)) return false;

    const configuration = await StorageSync.get({
        originsFilterOrigins: {},
        [`${featureName}Enabled`]: false,
        [`${featureName}WhitelistMode`]: true,
    });

    if (!configuration[`${featureName}Enabled`]) return false;

    const activeOrigins = getActiveFeatureOrigins(configuration.originsFilterOrigins, featureName);
    const activeRegex = activeOrigins
        .filter((o) => o.startsWith(regexSchemePrefix))
        .map((o) => new RegExp(o.replace(regexSchemePrefix, '')));

    const originExist = activeOrigins.includes(origin) || activeRegex.some((r) => r.test(origin));

    const isWhitelistMode = configuration[`${featureName}WhitelistMode`];
    if (isWhitelistMode) {
        return originExist;
    }

    if (!isWhitelistMode) {
        return !originExist;
    }

    return false;
}

function getActiveFeatureOrigins(originsFilterOrigins, featureName) {
    const enabledOrigins = Object.entries(originsFilterOrigins)
        .filter((origin) => origin[1][featureName] === true)
        .map((origin) => origin[0]);
    return enabledOrigins;
}

const separatorMenuItem = {
    id: 'joorney_cm_separator_options',
    contexts: ['all'],
    type: 'separator',
};

const optionMenuItem = {
    id: 'joorney_cm_open_options',
    title: 'Open options',
    contexts: ['all'],
};

const clearLocalCacheMenuItem = {
    id: 'joorney_cm_clear_cache_host',
    title: 'Clear cache for this host',
    contexts: ['all'],
};

const CONTEXT_MENU_DYNAMIC_ITEM_IDS = [];

async function disableDynamicItems() {
    return Promise.all(CONTEXT_MENU_DYNAMIC_ITEM_IDS.map((id) => ContextMenus.update(id, { visible: false })));
}

async function createContextMenu() {
    await ContextMenus.removeAll();
    CONTEXT_MENU_DYNAMIC_ITEM_IDS.length = 0;

    const items = [];
    const dynamicItems = await getItems();

    for (const item of dynamicItems.filter((i) => !i.parentId)) {
        items.push(
            createContextMenuItem({
                id: item.id,
                title: item.title ?? item.path ?? 'Unknown item',
                contexts: item.contexts ?? ['all'],
                visible: false,
            })
        );
        CONTEXT_MENU_DYNAMIC_ITEM_IDS.push(item.id);
    }

    for (const item of dynamicItems.filter((i) => i.parentId)) {
        items.push(
            createContextMenuItem({
                id: item.id,
                title: item.title ?? item.path ?? 'Unknown item',
                contexts: item.contexts ?? ['all'],
                visible: false,
                parentId: item.parentId,
            })
        );
        CONTEXT_MENU_DYNAMIC_ITEM_IDS.push(item.id);
    }

    if (dynamicItems.length > 0) items.push(createContextMenuItem(separatorMenuItem));
    items.push(createContextMenuItem(clearLocalCacheMenuItem));
    items.push(createContextMenuItem(optionMenuItem));

    await Promise.all(items);
}

async function updateContext(tabId) {
    disableDynamicItems();

    try {
        const tab = await Tabs.get(tabId);
        if (!tab.active) return;
        if (!tab.url.startsWith('http')) return;
        const odooInfo = await sendTabMessage(tab.id, MESSAGE_ACTION.TO_CONTENT.REQUEST_ODOO_INFO);
        if (!odooInfo || !odooInfo.isOdoo) return;
        updateContextMenu(tab, odooInfo.isOdoo, odooInfo.version);
    } catch (error) {
        // Error: No tab with id (from Tabs.get) is expected
        if (`${error}`.includes(tabId)) Console.log(`background.js - updateContext: ${error}`);
        else Console.error(error);
    }
}

async function updateContextMenu(tab, isOdoo, version) {
    const dynamicItems = await getItems(tab);

    const itemsUpdate = [];
    for (const item of dynamicItems) {
        itemsUpdate.push(
            ContextMenus.update(item.id, {
                visible: isOdoo === true && item.active,
                title: formatTitle(item.title ?? item.path ?? 'Unknown item', { version }),
                parentId: null,
            })
        );
    }
    await Promise.all(itemsUpdate);
}

async function onContextMenuItemClick(info, tab) {
    const itemId = info.menuItemId;

    switch (itemId) {
        case optionMenuItem.id: {
            Runtime.openOptionsPage();
            return;
        }
        case clearLocalCacheMenuItem.id: {
            clearHost(new URL(tab.url).host);
            return;
        }
        case openRunbotWithVersionMenuItem.id: {
            sendTabMessage(tab.id, MESSAGE_ACTION.TO_CONTENT.CM_OPEN_RUNBOT);
            return;
        }
    }

    const items = await getItems(tab, false);
    const item = items[itemId];
    if (item?.path) {
        sendTabMessage(tab.id, MESSAGE_ACTION.TO_CONTENT.CM_OPEN_MENU, { menupath: item.path });
    }
}

function formatTitle(title, args) {
    const placeholders = ['%version%'];
    let finalTitle = title;
    for (const p of placeholders) {
        finalTitle = finalTitle.replaceAll(p, args[p.replaceAll('%', '')]);
    }
    return finalTitle;
}

async function createContextMenuItem(createProperties) {
    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/menus/create
    // https://developer.chrome.com/docs/extensions/reference/api/contextMenus#method-create
    // TODO switch to await when Promise flow is release
    return new Promise((resolve) => {
        ContextMenus.create(createProperties, resolve);
    }).catch(() => {});
}

async function getItems(tab = undefined, toArray = true) {
    const featureItems = await getFeaturesItems(tab);

    if (!toArray) return featureItems;

    const items = Object.values(featureItems).sort((a, b) => {
        if (a.parentId && !b.parentId) return 1;
        if (!a.parentId && b.parentId) return -1;
        return a.order - b.order;
    });
    return items;
}

async function getFeaturesItems(tab) {
    let url = undefined;
    if (tab) {
        if (!tab.url) return {};
        url = sanitizeURL(tab.url);
        if (!url.origin || !url.origin.startsWith('http')) return;
    }

    const contextFeatures = features.filter((f) => f.trigger.context);
    const allFavorite = contextFeatures.length === 1;

    const result = {};
    for (const feature of contextFeatures) {
        // If more limited feature, maybe need to rethink this part
        const isActive = feature.limited
            ? await isAuthorizedLimitedFeature(
                  feature.id,
                  new URL(feature.defaultSettings[`${feature.id}LimitedOrigins`][0])
              )
            : url !== undefined && (await isAuthorizedFeature(feature.id, url));

        const defaultSettings = await StorageSync.get(feature.defaultSettings);

        const id = `joorney_cm_${feature.id}`;
        const menus = defaultSettings[`${feature.id}ContextMenu`];
        if (!menus) continue;

        if (Object.keys(menus).length <= 0) continue;
        const menusArray = Object.values(menus);
        const activeMenuCount = menusArray.filter((m) => m.active).length;
        const activeFavoriteCount = menusArray.filter((m) => m.favorite).length;

        const parentActive = !allFavorite && activeFavoriteCount !== activeMenuCount && activeMenuCount > 1;
        result[id] = {
            id: id,
            title: feature.display_name,
            contexts: ['all'],
            order: Number.MAX_SAFE_INTEGER,
            active: isActive && parentActive,
        };

        for (const menu of menusArray) {
            result[menu.id] = {
                ...menu,
                parentId: parentActive ? (menu.favorite ? undefined : id) : undefined,
                active: isActive && menu.active,
            };
        }
    }
    return result;
}

//#region External Public Odoo API
async function getFutureEventWithName(domainName, host) {
    const { data } = await cache(
        30 * 24 * 60,
        async () => {
            const url = `https://${host}/web/dataset/call_kw/event.event/search_read`;
            const today = toOdooBackendDateGMT0(new Date());
            const payload = {
                method: 'call',
                jsonrpc: '2.0',
                params: {
                    args: [],
                    kwargs: {
                        context: { active_test: true, lang: 'en_US' },
                        domain: [domainName, ['date_end', '>=', today]],
                        limit: 1,
                        fields: ['date_begin', 'date_end', 'name', 'display_name'],
                    },
                    model: 'event.event',
                    method: 'search_read',
                },
            };
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });
            return await response.json();
        },
        'getFutureEventWithName',
        domainName,
        host
    );
    if (!data) return undefined;
    if (data.error) return undefined;
    if (!data.result || data.result.length !== 1) return undefined;
    return data.result[0];
}
//#endregion

// Based on: https://github.com/catdad/canvas-confetti/blob/master/src/confetti.js


function shapeFromText(textData, flips = { vertical: false, horizontal: false }) {
    let text;
    let scalar = 1;
    let color = '#000000';
    let // see https://nolanlawson.com/2022/04/08/the-struggle-of-using-native-emoji-on-the-web/
        fontFamily =
            '"Twemoji Mozilla", "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "system emoji", sans-serif';

    if (typeof textData === 'string') {
        text = textData;
    } else {
        text = textData.text;
        scalar = 'scalar' in textData ? textData.scalar : scalar;
        fontFamily = 'fontFamily' in textData ? textData.fontFamily : fontFamily;
        color = 'color' in textData ? textData.color : color;
    }

    // all other confetti are 10 pixels,
    // so this pixel size is the de-facto 100% scale confetti
    const fontSize = 10 * scalar;
    const font = `${fontSize}px ${fontFamily}`;

    let canvas = new OffscreenCanvas(1, 1);
    let ctx = canvas.getContext('2d');

    ctx.font = font;
    const size = ctx.measureText(text);
    const width = Math.floor(size.width);
    const height = Math.floor(size.fontBoundingBoxAscent + size.fontBoundingBoxDescent);

    canvas = new OffscreenCanvas(width, height);
    ctx = canvas.getContext('2d');
    ctx.font = font;
    ctx.fillStyle = color;

    ctx.fillText(text, 0, fontSize);

    const scale = 1 / scalar;

    return {
        type: 'bitmap',
        // TODO these probably need to be transfered for workers
        bitmap: canvas.transferToImageBitmap(),
        matrix: [
            scale * (flips?.horizontal ? -1 : 1),
            0,
            0,
            scale * (flips?.vertical ? -1 : 1),
            (-width * scale) / 2,
            (-height * scale) / 2,
        ],
    };
}

// note: you CAN only use a path for confetti.shapeFrompath(), but for
// performance reasons it is best to use it once in development and save
// the result to avoid the performance penalty at runtime
// https://svg-path-visualizer.netlify.app/

/*
// From bubble emoji: https://images.emojiterra.com/google/noto-emoji/unicode-15.1/color/svg/1fae7.svg
// Large
shapeFromPath(
	'M68.48 46.02C65.29 45.09 65.41 48.52 62.05 53.99C59.81 57.63 55.09 62.36 47.41 64.25C42.89 65.36 40.86 66.31 40.73 67.97C40.5 70.8 44.35 71.56 49.94 70.1C64.76 66.25 75.25 47.99 68.48 46.02Z M34.9902 10.2501C39.3802 11.7601 40.5402 15.6801 39.1902 19.0301C37.9502 22.1101 33.2902 23.5001 30.3702 25.0901C25.9202 27.5001 22.6902 30.6301 20.2802 35.0801C17.9502 39.3801 11.6702 41.1201 10.8102 34.8701C10.1402 29.9801 13.1802 23.0201 16.0302 19.4501C18.5502 16.3001 22.0102 13.4901 25.6302 11.6901C28.1802 10.4301 32.2202 9.30006 34.9902 10.2501Z M55.4199 12.46C57.2199 13.98 57.4299 16.77 54.9399 17.64C53.8299 17.95 52.6699 17.45 51.5199 17.37C49.1799 17.21 48.2099 18.04 46.2099 17.19C43.2299 15.91 41.9999 13.33 43.4199 11.21C44.1199 10.17 45.4499 9.63996 46.6299 9.40996C49.8299 8.78996 53.1699 10.2 55.4199 12.46Z M39.88 79.75C17.89 79.75 0 61.86 0 39.87C0 17.88 17.89 0 39.88 0C61.87 0 79.76 17.89 79.76 39.88C79.76 61.87 61.86 79.75 39.88 79.75ZM40.5 4.22C20.44 4.22 4.13 20.53 4.13 40.59C4.13 60.65 20.45 76.96 40.5 76.96C60.55 76.96 76.87 60.64 76.87 40.59C76.87 20.54 60.55 4.22 40.5 4.22Z'
)
// Medium
shapeFromPath(
	'M40.6301 28.96C38.1901 28.13 38.7701 31.89 33.9501 35.28C28.8101 38.9 25.7001 38.03 25.5201 40.08C25.3301 42.27 30.6801 42.26 36.2501 38.11C41.0801 34.53 43.1001 29.8 40.6301 28.96Z M24.2696 47.52C11.2296 47.52 0.619629 36.91 0.619629 23.87C0.619629 10.83 11.2296 0.219971 24.2696 0.219971C37.3096 0.219971 47.9196 10.83 47.9196 23.87C47.9196 36.91 37.3096 47.52 24.2696 47.52ZM24.8696 3.10997C13.3496 3.10997 3.97963 12.48 3.97963 24C3.97963 35.52 13.3496 44.89 24.8696 44.89C36.3896 44.89 45.7596 35.52 45.7596 24C45.7596 12.48 36.3896 3.10997 24.8696 3.10997Z M19.0198 7.31001C23.4198 7.01001 24.9398 10.15 23.8498 12.64C22.4498 15.84 19.1898 14.7 16.3198 17.81C14.3398 19.96 10.1098 22.29 9.51979 17.54C8.99979 13.34 13.6498 7.68001 19.0198 7.31001Z M31.7194 13C34.3694 12.99 34.6894 10.01 33.2694 8.41996C31.6294 5.96996 26.1394 6.22996 27.4394 10.27C28.0094 12.05 29.0494 13.01 31.7194 13Z'
)
// Small
shapeFromPath(
	'M31.6804 20.37C32.2604 17.3 31.5304 10.85 28.4204 12.91C27.1704 13.74 29.1404 17.29 28.5404 20.34C27.7404 24.43 26.2204 26.57 22.6404 29.12C21.8204 29.7 22.2604 30.78 23.8104 30.22C27.9004 28.75 30.6804 25.71 31.6804 20.37Z M16.5102 6.67002C17.2202 8.15002 14.9602 10.03 14.0802 11.2C11.7902 14.25 12.9802 16.62 11.2702 19.4C9.98017 21.49 5.89016 22.93 5.12016 17.82C4.64016 14.62 6.64016 11 8.00016 9.52002C12.5102 4.62002 15.9202 5.45002 16.5102 6.67002Z M18.37 36.74C8.24 36.74 0 28.5 0 18.37C0 8.24 8.24 0 18.37 0C28.5 0 36.74 8.24 36.74 18.37C36.74 28.5 28.49 36.74 18.37 36.74ZM18.02 2.6C9.32 2.6 2.24001 9.68 2.24001 18.38C2.24001 27.08 9.32 34.16 18.02 34.16C26.72 34.16 33.8 27.08 33.8 18.38C33.8 9.68 26.73 2.6 18.02 2.6Z'
)
*/
const bubbles = {
    large: {
        type: 'path',
        path: 'M68.48 46.02C65.29 45.09 65.41 48.52 62.05 53.99C59.81 57.63 55.09 62.36 47.41 64.25C42.89 65.36 40.86 66.31 40.73 67.97C40.5 70.8 44.35 71.56 49.94 70.1C64.76 66.25 75.25 47.99 68.48 46.02Z M34.9902 10.2501C39.3802 11.7601 40.5402 15.6801 39.1902 19.0301C37.9502 22.1101 33.2902 23.5001 30.3702 25.0901C25.9202 27.5001 22.6902 30.6301 20.2802 35.0801C17.9502 39.3801 11.6702 41.1201 10.8102 34.8701C10.1402 29.9801 13.1802 23.0201 16.0302 19.4501C18.5502 16.3001 22.0102 13.4901 25.6302 11.6901C28.1802 10.4301 32.2202 9.30006 34.9902 10.2501Z M55.4199 12.46C57.2199 13.98 57.4299 16.77 54.9399 17.64C53.8299 17.95 52.6699 17.45 51.5199 17.37C49.1799 17.21 48.2099 18.04 46.2099 17.19C43.2299 15.91 41.9999 13.33 43.4199 11.21C44.1199 10.17 45.4499 9.63996 46.6299 9.40996C49.8299 8.78996 53.1699 10.2 55.4199 12.46Z M39.88 79.75C17.89 79.75 0 61.86 0 39.87C0 17.88 17.89 0 39.88 0C61.87 0 79.76 17.89 79.76 39.88C79.76 61.87 61.86 79.75 39.88 79.75ZM40.5 4.22C20.44 4.22 4.13 20.53 4.13 40.59C4.13 60.65 20.45 76.96 40.5 76.96C60.55 76.96 76.87 60.64 76.87 40.59C76.87 20.54 60.55 4.22 40.5 4.22Z',
        matrix: [0.1282051282051282, 0, 0, 0.1282051282051282, -5, -5.128205128205128],
    },
    medium: {
        type: 'path',
        path: 'M40.6301 28.96C38.1901 28.13 38.7701 31.89 33.9501 35.28C28.8101 38.9 25.7001 38.03 25.5201 40.08C25.3301 42.27 30.6801 42.26 36.2501 38.11C41.0801 34.53 43.1001 29.8 40.6301 28.96Z M24.2696 47.52C11.2296 47.52 0.619629 36.91 0.619629 23.87C0.619629 10.83 11.2296 0.219971 24.2696 0.219971C37.3096 0.219971 47.9196 10.83 47.9196 23.87C47.9196 36.91 37.3096 47.52 24.2696 47.52ZM24.8696 3.10997C13.3496 3.10997 3.97963 12.48 3.97963 24C3.97963 35.52 13.3496 44.89 24.8696 44.89C36.3896 44.89 45.7596 35.52 45.7596 24C45.7596 12.48 36.3896 3.10997 24.8696 3.10997Z M19.0198 7.31001C23.4198 7.01001 24.9398 10.15 23.8498 12.64C22.4498 15.84 19.1898 14.7 16.3198 17.81C14.3398 19.96 10.1098 22.29 9.51979 17.54C8.99979 13.34 13.6498 7.68001 19.0198 7.31001Z M31.7194 13C34.3694 12.99 34.6894 10.01 33.2694 8.41996C31.6294 5.96996 26.1394 6.22996 27.4394 10.27C28.0094 12.05 29.0494 13.01 31.7194 13Z',
        matrix: [0.22727272727272727, 0, 0, 0.22727272727272727, -5.454545454545454, -5.454545454545454],
    },
    small: {
        type: 'path',
        path: 'M31.6804 20.37C32.2604 17.3 31.5304 10.85 28.4204 12.91C27.1704 13.74 29.1404 17.29 28.5404 20.34C27.7404 24.43 26.2204 26.57 22.6404 29.12C21.8204 29.7 22.2604 30.78 23.8104 30.22C27.9004 28.75 30.6804 25.71 31.6804 20.37Z M16.5102 6.67002C17.2202 8.15002 14.9602 10.03 14.0802 11.2C11.7902 14.25 12.9802 16.62 11.2702 19.4C9.98017 21.49 5.89016 22.93 5.12016 17.82C4.64016 14.62 6.64016 11 8.00016 9.52002C12.5102 4.62002 15.9202 5.45002 16.5102 6.67002Z M18.37 36.74C8.24 36.74 0 28.5 0 18.37C0 8.24 8.24 0 18.37 0C28.5 0 36.74 8.24 36.74 18.37C36.74 28.5 28.49 36.74 18.37 36.74ZM18.02 2.6C9.32 2.6 2.24001 9.68 2.24001 18.38C2.24001 27.08 9.32 34.16 18.02 34.16C26.72 34.16 33.8 27.08 33.8 18.38C33.8 9.68 26.73 2.6 18.02 2.6Z',
        matrix: [0.29411764705882354, 0, 0, 0.29411764705882354, -5.588235294117648, -5.588235294117648],
    },
};

//#region Abstract Loader
const lockedState = ['circle', 'square', 'star'];
const emojisLoader = ({
    emojis,
    alpha,
    size,
    gravity,
    drift,
    xRange,
    yRange,
    color = '#ffffff',
    flat = true,
    flipHorizontal = false,
    flipVertical = false,
}) => {
    const emojisBitmap = emojis.map((emoji) =>
        lockedState.includes(emoji)
            ? emoji
            : shapeFromText(
                  { text: emoji, scalar: size?.max ?? 1, color: color },
                  { vertical: flipVertical, horizontal: flipHorizontal }
              )
    );

    return shapesLoader({
        shapes: emojisBitmap,
        alpha,
        size,
        gravity,
        drift,
        xRange,
        yRange,
        colors: [color],
        flat,
    });
};

const shapesLoader = ({
    shapes,
    alpha = { max: 1, double: true },
    size = { min: 1, max: 1, dynamic: false },
    gravity = { min: 0.4, max: 0.6, dynamic: false },
    drift = { min: -0.4, max: 0.4, dynamic: false },
    xRange = { min: 0, max: 1 },
    yRange = { min: 0, max: 1 }, // Top = 0, Bottom = 1
    colors = ['#ffffff'],
    flat = true,
}) => {
    const scalarComputed = size.dynamic ? () => Math.round(randomInRange(size.min, size.max)) : size.max;
    const gravityComputed = gravity.dynamic ? () => randomInRange(gravity.min, gravity.max) : gravity.max;
    const driftComputed = drift.dynamic ? () => randomInRange(drift.min, drift.max) : drift.max;

    return (ticks) => ({
        flat,
        particleCount: 1,
        startVelocity: 0,
        ticks,
        origin: {
            x: randomInRange(xRange.min, xRange.max),
            y: randomInRange(yRange.min, yRange.max),
        },
        colors,
        shapes,
        gravity: gravityComputed,
        scalar: scalarComputed,
        drift: driftComputed,
        alpha,
    });
};

const fireworkLoader = (colors, mixColor, smallAndLarge, doubleBurst) => {
    return (_ticks) => {
        const loads = [
            {
                startVelocity: 30,
                spread: 360,
                ticks: 60,
                zIndex: 0,
                particleCount: 50,
                origin: { x: randomInRange(0.1, 0.5), y: Math.random() - 0.2 },
                colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
            },
            {
                startVelocity: 30,
                spread: 360,
                ticks: 60,
                zIndex: 0,
                particleCount: 50,
                origin: { x: randomInRange(0.5, 0.9), y: Math.random() - 0.2 },
                colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
            },
        ];
        if (smallAndLarge) {
            loads.concat(
                loads.map((l) => {
                    l.particleCount *= 2;
                    return l;
                })
            );
        }

        const firework = loads[Math.round(randomInRange(0, loads.length - 1))];
        if (doubleBurst) {
            const fireworkInside = {
                ...firework,
                startVelocity: 15,
                colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
            };
            return [firework, fireworkInside];
        }
        return firework;
    };
};
const schoolPrideLoader = (colors) => {
    return (_ticks) => {
        return [
            {
                particleCount: 2,
                angle: 60,
                spread: 55,
                origin: { x: 0 },
                colors: colors,
            },
            {
                particleCount: 2,
                angle: 120,
                spread: 55,
                origin: { x: 1 },
                colors: colors,
            },
        ];
    };
};
const floatingLoader = (emojis) => {
    return emojisLoader({
        emojis: emojis,
        alpha: { max: 0.2, double: true },
        size: { min: 8, max: 20, dynamic: true },
        gravity: { min: -0.6, max: -0.4, dynamic: true },
        drift: { min: -0.4, max: 0.4, dynamic: true },
        yRange: { min: 0.5, max: 1 },
    });
};

const ambients = {
    compute: {
        name: 'Computed Events',
        ambients: [
            {
                name: `Odoo Experience ${new Date().getFullYear()}`,
                id: 'odoo-experience-oxp-cpt',
                computeDates: async () => {
                    return await getOdooEventDate(['name', '=', `Odoo Experience ${new Date().getFullYear()}`]);
                },
                type: 'long',
                duration: 3000,
                load: schoolPrideLoader(['#FBB130', '#714b67', '#050a30']),
            },
            {
                name: 'Future Community Days',
                id: 'odoo-community-days-cpt',
                computeDates: async () => {
                    return await getOdooEventDate(['name', '=like', '%Community Days%']);
                },
                type: 'long',
                duration: 3000,
                load: schoolPrideLoader(['#714B67', '#FFFFFF', '#017E84']),
            },
        ],
    },
    event: {
        name: 'Events',
        ambients: [
            // {
            //     name: 'Developer Test',
            //     id: 'joorney-test-ambient-evt',
            //     date: new Date().toISOString(),
            //     type: 'count',
            //     count: 20,
            //     delay: 250,
            //     load: fireworkLoader(['#FFFFFF', '#000000'], true, false, false),
            // },
            {
                name: 'Happy Birthday Odoo!',
                id: 'odoo-birthday-evt',
                // date: '2005-02-22T12:00:00Z', // TinyERP
                // date: '2009-04-14T12:00:00Z', // OpenERP
                date: '2014-05-15T12:00:00Z',
                type: 'count',
                count: 20,
                delay: 250,
                load: fireworkLoader(['#E46E78', '#21B799', '#5B899E', '#E4A900'], true, false, false),
            },
            {
                name: 'New Year, Countdown',
                id: 'new-year-evt',
                date_from: `${new Date().getFullYear()}-12-31T23:59:30`,
                date_to: `${new Date().getFullYear() + 1}-01-01T00:00:30`,
                type: 'count',
                count: 480,
                delay: 250,
                load: fireworkLoader(
                    [
                        // Palette 1
                        '#C63347',
                        '#F28E63',
                        '#FC7F81',
                        '#FAEFC4',
                        '#F9AE9B',
                        '#792BB2',
                        '#2E42CB',
                        '#F75781',
                        '#E365E4',
                        '#FA5348',
                        // Palette 2
                        '#FFD07E',
                        '#FA9B49',
                        '#90CA80',
                        '#62ABCC',
                        '#7984DE',
                        '#DE6C90',
                    ],
                    false,
                    true,
                    true
                ),
            },
        ],
    },
    yearly: {
        name: 'Every year, one day',
        ambients: [
            {
                name: 'New Year',
                id: 'new-year-yly',
                day: 1,
                month: 1,
                type: 'long',
                duration: 10000,
                load: schoolPrideLoader(['#BF7218', '#FADE98', '#F1A738', '#f9eb82', '#180D1C', '#514414']),
            },
            {
                name: "Valentine's Day",
                id: 'valentine-yly',
                day: 14,
                month: 2,
                type: 'count',
                count: 30,
                delay: 1000,
                load: floatingLoader(['♥️', '🌹']),
            },
            {
                name: "Lucky Day (St. Patrick's)",
                id: 'patrick-yly',
                day: 17,
                month: 3,
                type: 'onetime',
                load: (_ticks) => {
                    const emojisBitmap = ['🍻', '🪙', '🍀', '🌈'].map((emoji) =>
                        shapeFromText({ text: emoji, scalar: 4 })
                    );
                    return [
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 26,
                            startVelocity: 55,
                            particleCount: 50,
                            scalar: 2,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 60,
                            particleCount: 40,
                            scalar: 2,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 100,
                            decay: 0.91,
                            scalar: 1.6,
                            particleCount: 70,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 120,
                            startVelocity: 25,
                            decay: 0.92,
                            scalar: 2.4,
                            particleCount: 20,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 120,
                            scalar: 2,
                            startVelocity: 45,
                            particleCount: 20,
                        },
                    ];
                },
            },
            {
                name: "April Fool's",
                id: 'aprilfool-yly',
                day: 1,
                month: 4,
                type: 'count',
                count: 15,
                delay: 1000,
                load: (ticks) => {
                    const left = emojisLoader({
                        emojis: ['🐟', '🐠', '🐡'],
                        alpha: { max: 0.5, double: true },
                        size: { min: 4, max: 10, dynamic: true },
                        gravity: { min: -0.1, max: 0.1, dynamic: true },
                        drift: { min: -1, max: -0.3, dynamic: true },
                    })(ticks);
                    const right = emojisLoader({
                        emojis: ['🐟', '🐠', '🐡'],
                        alpha: { max: 0.5, double: true },
                        size: { min: 4, max: 10, dynamic: true },
                        gravity: { min: -0.1, max: 0.1, dynamic: true },
                        drift: { min: 0.3, max: 1, dynamic: true },
                        flipHorizontal: true,
                    })(ticks);
                    const bubble = shapesLoader({
                        shapes: [bubbles.large, bubbles.medium, bubbles.small],
                        alpha: { max: 0.2, double: true },
                        size: { min: 2, max: 5, dynamic: true },
                        gravity: { min: -0.4, max: -0.2, dynamic: true },
                        drift: { min: -0.4, max: 0.4, dynamic: true },
                        yRange: { min: 0.5, max: 1 },
                        colors: ['#89cff0', 'e7feff', '#a1caf1', '#39a78e'],
                    })(ticks);
                    return [left, right, bubble];
                },
            },
            {
                name: 'Halloween Night',
                id: 'halloween-yly',
                day: 31,
                month: 10,
                type: 'count',
                count: 30,
                delay: 1000,
                load: floatingLoader(['🎃']),
            },
            {
                name: "New Year's Eve",
                id: 'new-year-eve-yly',
                day: 31,
                month: 12,
                type: 'count',
                count: 30,
                delay: 1000,
                load: floatingLoader(['🥂']),
            },
        ],
    },
    // season: {
    //     winter: {},
    //     spring: {},
    //     summer: {},
    //     fall: {},
    // },
    // weather: {
    //     rain: {},
    //     snow: {},
    //     sun: {},
    // },
};

// Utils
function randomInRange(min, max) {
    return Math.random() * (max - min) + min;
}

async function getOdooEventDate(domainName) {
    const event = await getFutureEventWithName(domainName, 'www.odoo.com');
    if (!event) return undefined;

    return {
        event_name: event.display_name,
        event_date_from: yyyymmdd_hhmmssToDate(event.date_begin),
        event_date_to: yyyymmdd_hhmmssToDate(event.date_end),
    };
}

//#region SEASON
// export const fallSeasonLoader = emojisLoader({
//     emojis: ['🍂'],
//     alpha: { max: 0.5 },
//     size: { min: 1, max: 2, dynamic: true },
//     gravity: { min: 0.4, max: 0.9, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.75 },
//     flat: false,
// });

// export const winterSeasonLoader = emojisLoader({
//     emojis: ['❄️', 'circle'],
//     alpha: { max: 1 },
//     size: { min: 0.4, max: 1, dynamic: true },
//     gravity: { min: 0.4, max: 0.6, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.5 },
//     color: '#ffffff',
//     flat: false,
// });

// export const summerSeasonLoader = emojisLoader({
//     emojis: ['☀️'],
//     alpha: { max: 0.5 },
//     size: { min: 1, max: 2, dynamic: true },
//     gravity: { min: 0.4, max: 0.9, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.75 },
//     flat: false,
// });

// export const springSeasonLoader = emojisLoader({
//     emojis: ['🌸'],
//     alpha: { max: 1 },
//     size: { min: 0.4, max: 1, dynamic: true },
//     gravity: { min: 0.4, max: 0.6, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.5 },
//     color: '#ffffff',
//     flat: false,
// });
//#endregion

//#region WEATHER
// export const rainWeatherLoader = emojisLoader({
//     emojis: ['💧'],
//     alpha: { max: 1 },
//     size: { min: 0.1, max: 0.6, dynamic: true },
//     gravity: { min: 4, max: 5, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: -0.1, max: 0 },
//     color: '#4a6583',
//     flat: true,
// });

// export const snowWeatherLoader = emojisLoader({
//     emojis: ['circle'],
//     alpha: { max: 1 },
//     size: { min: 0.1, max: 0.6, dynamic: true },
//     gravity: { min: 0.4, max: 0.6, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: -0.1, max: 0.5 },
//     color: '#ffffff',
//     flat: false,
// });
//#endregion

class AmbientManager {
    static async computeEvents() {
        const ambient_dates = {};

        for (const c of ambients.compute.ambients) {
            const dates = await c.computeDates();
            if (!dates) continue;
            ambient_dates[c.id] = {
                date_from: dates.event_date_from,
                date_to: dates.event_date_to,
                name: dates.event_name,
            };
        }

        await setAmbientDates(ambient_dates);
    }

    async getAmbientForDate(date) {
        let ambient = undefined;
        const { ambientStatus } = await StorageSync.get({ ambientStatus: {} });

        if (!ambient) ambient = await this.getComputedEventForDate(ambientStatus, date);
        if (!ambient) ambient = this.getEventAmbientForDate(ambientStatus, date);
        if (!ambient) ambient = this.getYearlyAmbientForDate(ambientStatus, date);
        if (!ambient) ambient = this.getSeasonAmbientForDate(ambientStatus, date);
        if (!ambient) ambient = await this.getWeatherAmbientForDate(ambientStatus, date);

        return ambient;
    }

    getEventForDate(date, events) {
        let from = undefined;
        let to = undefined;

        for (const event of events) {
            if (event.date_from && event.date_to) {
                from = new Date(event.date_from);
                to = new Date(event.date_to);
                if (this.isDateBetween(date, from, to)) return event;
                continue;
            }
            if (event.date) {
                from = new Date(event.date);
                if (this.isSameDay(date, from)) return event;
            }
        }

        return undefined;
    }

    getEventAmbientForDate(ambientStatus, date) {
        const activeAmbients = ambients.event.ambients.filter((a) => ambientStatus[a] ?? true);
        return this.getEventForDate(date, activeAmbients);
    }

    async getComputedEventForDate(ambientStatus, date) {
        const computes = ambients.compute.ambients.filter((a) => ambientStatus[a.id] ?? true);
        const ambient_dates = await getAmbientDates();
        for (const c of computes) {
            const dates = ambient_dates[c.id];
            if (dates) Object.assign(c, dates);
        }
        return this.getEventForDate(date, computes);
    }

    getYearlyAmbientForDate(ambientStatus, date) {
        const mm = date.getMonth() + 1; // Months start at 0!
        const dd = date.getDate();

        return ambients.yearly.ambients.find((a) => (ambientStatus[a] ?? true) && a.day === dd && a.month === mm);
    }

    getSeasonAmbientForDate(_ambientStatus, _date) {
        return undefined;
    }

    async getWeatherAmbientForDate(_ambientStatus, _date) {
        return undefined;
    }

    isDateBetween(targetDate, startDate, endDate) {
        return targetDate >= startDate && targetDate <= endDate;
    }

    isSameDay(date1, date2) {
        // return date1.toDateString() === date2.toDateString();
        return (
            date1.getFullYear() === date2.getFullYear() &&
            date1.getMonth() === date2.getMonth() &&
            date1.getDate() === date2.getDate()
        );
    }
}

async function getAnnounceData() {
    const devMode = await isDevMode();
    if (devMode) {
        const d = await Promise.resolve().then(function () { return announce$1; });
        return d.default;
    }
    const source = 'https://raw.githubusercontent.com/MrSweeter/joorney/master/store/announce.json';
    try {
        const { data } = await cache(
            1 * 24 * 60,
            async () => {
                const response = await fetch(source);
                if (!response.ok) return {};
                return await response.json();
            },
            'getAnnounceData'
        );
        return data;
    } catch (error) {
        Console.critical('There was a problem with the fetch announce operation:', error);
    }
    return {};
}

async function getOdooData() {
    const devMode = await isDevMode();
    if (devMode) {
        const d = await Promise.resolve().then(function () { return odoo$1; });
        return d.default;
    }
    const source = 'https://raw.githubusercontent.com/MrSweeter/joorney/master/store/odoo.json';
    try {
        const { data } = await cache(
            1 * 24 * 60,
            async () => {
                const response = await fetch(source);
                if (!response.ok) return {};
                return await response.json();
            },
            'getOdooData'
        );
        return data;
    } catch (error) {
        Console.critical('There was a problem with the fetch odoo-version operation:', error);
    }
    return {};
}

const fetchVersion = 'https://raw.githubusercontent.com/MrSweeter/joorney/master/manifest.json';

async function checkVersion() {
    const installType = await getInstallType();

    const odooData = await getOdooData();
    updateSupportedVersion(odooData?.availableOdooVersions);

    if (!['development', 'other'].includes(installType)) return;
    const res = await fetch(fetchVersion);
    const manifest = await res.json();
    const remoteVersion = removeBuildFromVersion(manifest.version);
    const currentVersion = removeBuildFromVersion(Runtime.getManifest().version);

    let badgeText = { text: '' };

    if (
        remoteVersion.localeCompare(currentVersion, undefined, {
            numeric: true,
            sensitivity: 'base',
        }) > 0
    ) {
        badgeText = { text: remoteVersion };
    }

    await Action.setBadgeText(badgeText);
    await Action.setBadgeBackgroundColor({
        color: '#FF0000',
    });
}

function removeBuildFromVersion(version) {
    return version.split('.').slice(0, 3).join('.');
}

/*
- 2.1.0: Initial/Public release
- 2.2.0: [Feature] Pin Message
- 2.3.0: [Feature] Ambient
*/
const openOption4Version = ['2.1.0', '2.2.0', '2.3.0'];
async function openOption(force = false, previousVersionFull = false) {
    const previousVersion = previousVersionFull ? removeBuildFromVersion(previousVersionFull) : null;
    const currentVersion = removeBuildFromVersion(Runtime.getManifest().version);
    const announce = await getAnnounce();
    if (force || announce || (currentVersion !== previousVersion && openOption4Version.includes(currentVersion))) {
        Runtime.openOptionsPage();
    }
}

async function getAnnounce() {
    const currentVersion = Runtime.getManifest().version_name;
    const announces = await getAnnounceData();
    const announce = announces[currentVersion];
    if (!announce || !announce.hash) return undefined;
    if (announce.closeable !== false) {
        const status = await getAnnounceCloseStatus(announce.hash);
        if (status) return undefined;
    }
    return { ...announce, version: removeBuildFromVersion(currentVersion), closeable: announce.closeable === true };
}

// Only use this function during the initial install phase. After
// installation the user may have intentionally unassigned commands.
function checkCommandShortcuts() {
    Commands.getAll((commands) => {

        for (const { name, shortcut } of commands) {
        }
    });
}

function handleCommands() {
    Commands.onCommand.addListener((command, tab) => {
        switch (command) {
            case 'enable-disable-temporary':
                if (!tab) return;
                enableDisableTabExtension(tab);
                break;
        }
    });
}

async function updateTabState(request) {
    const tabs = await Tabs.query({ active: true, currentWindow: true });
    if (!tabs) return;
    const tab = tabs[0];
    enableDisableTabExtension(tab, request.forceSwitchToOFF);
}

async function enableDisableTabExtension(tab, forceOff = undefined) {
    const tabId = tab.id;
    const origin = new URL(tab.url).origin;

    let isOFF = (await Action.getBadgeText({ tabId: tabId })) === 'OFF';
    if (forceOff) {
        isOFF = false;
    }

    const badgeText = { tabId: tabId, text: isOFF ? '' : 'OFF' };

    if (isOFF) {
        Action.enable(tabId);
    } else {
        Action.disable(tabId);
    }
    await Action.setBadgeText(badgeText);
    await Action.setBadgeBackgroundColor({
        tabId: tabId,
        color: '#FF0000',
    });

    updateWebsiteOff(origin, !isOFF);

    if (forceOff === undefined) {
        Tabs.reload(tabId);
    }
}

async function getFinalRunbotURL(request) {
    try {
        const response = await fetch(request.href, {
            method: 'HEAD',
        });
        return { url: response.url };
    } catch (ex) {
        Console.warn(ex);
        return { url: null, error: ex.toString() };
    }
}

async function handleMessage(message, sender) {
    if (message.action) return handleAction(message, sender);
    return undefined;
}

async function handleAction(message, sender) {
    let callback = undefined;

    switch (message.action) {
        case MESSAGE_ACTION.TO_BACKGROUND.GET_FEATURES_LIST: {
            callback = Promise.resolve({ features: features });
            break;
        }
        case MESSAGE_ACTION.TO_BACKGROUND.GET_FINAL_RUNBOT_URL: {
            callback = getFinalRunbotURL(message);
            break;
        }
        case MESSAGE_ACTION.TO_BACKGROUND.UPDATE_EXT_STATUS: {
            callback = updateTabState(message);
            break;
        }
        case MESSAGE_ACTION.TO_BACKGROUND.RECREATE_MENU: {
            callback = createContextMenu();
            break;
        }
        case MESSAGE_ACTION.TO_BACKGROUND.TRIGGER_FEATURE: {
            if (!message.feature) return undefined;
            callback = handleFeature(message.feature, sender.tab, message.args);
            break;
        }
        case MESSAGE_ACTION.TO_BACKGROUND.TAB_LOADED: {
            callback = updateContext(sender.tab.id);
            break;
        }
    }

    return callback;
}

async function handleFeature(feature, tab, args) {
    if (!features.some((f) => f.id === feature)) return undefined;

    return importFeatureBackgroundFile(feature).then((featureModule) => {
        featureModule.load(tab, args);
    });
}

const html = String.raw;
const css = String.raw;

const toastFadeInOutDurationMillis = 500;
const toastDelayMillis = 100;
const toastDurationMillis = 3000;

const ToastContainerElementID = 'joorney-toast-container';
const ToastItemElementClass = 'joorney-toasty';

const ToastStyle = css`
    #${ToastContainerElementID} {
        display: flex;
        flex-direction: column;
        padding: 16px;
        position: fixed;
        top: 32px;
        width: 100%;
        z-index: 9999;
        pointer-events: none;
        font-family: Roboto, sans-serif;
    }

    .${ToastItemElementClass} {
        display: none;
        opacity: 0;
        align-self: end;
        padding: 16px;
        margin-bottom: 10px;
        border-radius: 4px;
        min-width: 300px;
        max-width: 600px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        position: relative;
        overflow: hidden;
        pointer-events: auto;
    }

    .${ToastItemElementClass}-success .toast-progress {
        background-color: #4caf50;
    }

    .${ToastItemElementClass}-danger .toast-progress {
        background-color: #f44336;
    }

    .${ToastItemElementClass}-info .toast-progress {
        background-color: #2196f3;
    }

    .${ToastItemElementClass}-warning .toast-progress {
        background-color: #ff9800;
    }

    .toast-icon {
        margin-right: 10px;
        font-size: 24px;
    }

    .toast-content {
        flex-grow: 1;
        align-content: center;
    }

    .toast-title {
        font-weight: bold;
        margin-bottom: 5px;
    }

    .toast-text {
        max-width: 500px;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .toast-feature span {
        background-color: rgba(128, 128, 128, .25);
    }

    .toast-close {
        cursor: pointer;
        position: absolute;
        top: 8px;
        right: 8px;
        font-size: 16px;
        background: transparent;
        border: none;
    }

    .toast-progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 5px;
        animation: progressBar ${toastDurationMillis}ms linear forwards;
        animation-delay: ${toastDelayMillis + toastFadeInOutDurationMillis}ms;
    }

    @keyframes progressBar {
        from { width: 100%; }
        to { width: 0%; }
    }
  `.trim();

html`
    <div id="${ToastContainerElementID}">
        <style>${ToastStyle}</style>
    </div>
`.trim();

const openVersionKey = 'joorney-runbot';

function getRunbotOpenUrl(version) {
    return `https://runbot.odoo.com?${openVersionKey}=${version}`;
}

function initOmni() {
    OmniBox.onInputStarted.removeListener(onStarted);
    OmniBox.onInputStarted.addListener(onStarted);
}

const STATIC_LINK = {
    CHROMEWEBSTORE: {
        suggestionStart: ['chrome', 'store'],
        keyword: 'chromewebstore',
        description: 'Open Chrome Web Store',
        url: `https://chromewebstore.google.com/detail/${Runtime.id}`,
    },
    GITHUB: {
        suggestionStart: ['git'],
        keyword: 'githubrepository',
        description: 'Open GitHub repository',
        url: 'https://github.com/MrSweeter/joorney',
    },
    WEBSITE: {
        suggestionStart: ['web'],
        keyword: 'websitepage',
        description: 'Open Github Page',
        url: 'https://mrsweeter.github.io/joorney/?style=odoo',
    },
};

async function onStarted() {
    const { autoOpenRunbotEnabled } = await StorageSync.get({ autoOpenRunbotEnabled: false });
    if (!autoOpenRunbotEnabled) {
        await OmniBox.setDefaultSuggestion({
            description:
                'The functionality to open a runbot from URL is currently disabled. Open options to enabled "Auto Open Runbot"!',
        });
    } else {
        await OmniBox.setDefaultSuggestion({ description: 'Open <match>%s</match> <dim>(if found)</dim>' });
        OmniBox.onInputChanged.removeListener(onChange);
        OmniBox.onInputChanged.addListener(onChange);

        OmniBox.onInputEntered.removeListener(onEntered);
        OmniBox.onInputEntered.addListener(onEntered);
    }
}

function onChange(text, suggest) {
    const suggestions = getSuggestions(text);
    suggest(suggestions);
}

function onEntered(text) {
    const url = getURLFromKeyword(text);
    if (url) {
        openURL(url);
    }
}

async function openURL(url) {
    const { omniboxFocusCurrentTab } = await StorageSync.get({ omniboxFocusCurrentTab: false });
    if (omniboxFocusCurrentTab) {
        Tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs.length > 0) {
                Tabs.update(tabs[0].id, { url });
            }
        });
    } else {
        Tabs.create({ url });
    }
}

function getSuggestions(keyword) {
    for (const link of Object.values(STATIC_LINK)) {
        if (link.suggestionStart?.some((start) => keyword.startsWith(start))) {
            return [{ content: link.keyword, description: link.description }];
        }
    }

    const prefix = 'rb';
    if (!keyword.startsWith(prefix)) return [];

    const suggestions = SUPPORTED_VERSION.map((v) => ({ value: v, keyword: `${prefix}:${v}` }))
        .filter((v) => v.keyword.startsWith(keyword))
        .map((version) => ({
            content: version.keyword,
            description: `Open Runbot for version '${version.value}'`,
        }));
    suggestions.push({
        content: 'rb:master',
        description: `Open Runbot for version 'master'`,
    });
    return suggestions;
}

function getURLFromKeyword(keyword) {
    const link = Object.values(STATIC_LINK).find((link) => link.keyword === keyword);
    if (link) return link.url;

    const pattern = /^rb:(.+)$/;
    const match = keyword.match(pattern);

    if (match) {
        const version = match[1];
        return getRunbotOpenUrl(version);
    }

    return null;
}

function listenRequest() {
    const urls = features.flatMap((f) => f.trigger.onrequest || []);

    WebRequest.onCompleted.addListener(requestComplete, { urls: urls }, []);
}

async function requestComplete(details) {
    if (!details.tabId || details.tabId < 0) return;
    try {
        const tab = await Tabs.get(details.tabId);
        if (!tab.active) return;
        if (!tab.url.startsWith('http')) return;

        await sendTabMessage(tab.id, MESSAGE_ACTION.TO_CONTENT.WEB_REQUEST_COMPLETE, { status: details.statusCode });
    } catch (error) {
        // Error: No tab with id (from Tabs.get) is expected
        if (`${error}`.includes(details.tabId)) Console.log(`background.js - requestComplete: ${error}`);
        else Console.error(error);
    }
}

// [ODOO] < 17.2 On page # path change
WebNavigation.onReferenceFragmentUpdated.addListener((e) => {
    if (e.url.startsWith('http')) {
        sendTabMessage(e.tabId, MESSAGE_ACTION.TO_CONTENT.TAB_NAVIGATION, {
            url: e.url,
            navigator: true,
            fragment: true,
        });
    }
});

// [ODOO] 17.2+
WebNavigation.onHistoryStateUpdated.addListener((e) => {
    if (e.url.startsWith('http')) {
        sendTabMessage(e.tabId, MESSAGE_ACTION.TO_CONTENT.TAB_NAVIGATION, {
            url: e.url,
            navigator: true,
            history: true,
        });
    }
});

Runtime.onInstalled.addListener(async (details) => {
    const isInstall = details.reason === Runtime.OnInstalledReason.INSTALL;
    if (isInstall) {
        const settingsOrDefault = getCurrentSettings(features);
        await StorageSync.set(settingsOrDefault);
        checkCommandShortcuts();
    }
    await sleep(1000);
    await openOption(isInstall, details.previousVersion);
});

Tabs.onActivated.addListener((activeInfo) => {
    updateContext(activeInfo.tabId);
});

// Handled by message "TAB_LOADED"
// Tabs.onUpdated.addListener((tabId, changeInfo, _tab) => {
//     if (changeInfo.status === 'complete') {
//         updateContext(tabId);
//     }
// });

Windows.onFocusChanged.addListener(async (windowId) => {
    const tabs = await Tabs.query({ active: true, windowId: windowId });
    if (tabs.length > 0) updateContext(tabs[0].id);
});

// Triggers when a message is received (from the content script)
Runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleMessage(message, sender)
        .then(async (r) => {
            sendResponse(r);
        })
        .catch((ex) => {
            Console.warn(ex);
            sendResponse();
        });
    return true;
});

ContextMenus.onClicked.addListener(onContextMenuItemClick);

async function main() {
    // Add some delay to avoid initialization side effect
    await sleep(1000);

    checkVersion();
    handleCommands();
    checkHostsExpiration();

    await loadFeaturesConfiguration();

    initOmni();

    createContextMenu();

    listenRequest();

    await AmbientManager.computeEvents();
}

main();

var adminDebugLoginConfiguration = {
    id: 'adminDebugLoginRunbot',
    display_name: '[Runbot] Admin Debug Login',
    icon: '<i class="fa-solid fa-rocket"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        adminDebugLoginRunbotEnabled: false,
        adminDebugLoginRunbotLimitedOrigins: ['https://runbot.odoo.com', 'regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
    },
    limited: true,
};

var configuration$u = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: adminDebugLoginConfiguration
});

var configuration$s = {
    id: 'ambient',
    display_name: 'Ambient',
    icon: '<i class="fa-solid fa-mountain-sun"></i>', // '<i class="fa-solid fa-panorama"></i>'
    trigger: {
        background: false,
        load: true,
        navigate: false,
    },
    customization: {
        option: false,
        popup: false,
    },
    defaultSettings: {
        ambientEnabled: false,
        ambientWhitelistMode: false,
        ambientStatus: {},
    },
    supported_version: ['17+'],
};

var configuration$t = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$s
});

var configuration$q = {
    id: 'assignMeTask',
    display_name: 'Assign Me Task',
    icon: '<i class="fa-solid fa-user-plus"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        assignMeTaskEnabled: false,
        assignMeTaskWhitelistMode: false,
    },
    supported_version: ['16.3+'],
};

var configuration$r = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$q
});

var configuration$o = {
    id: 'awesomeLoadingLarge',
    display_name: 'Awesome Loading Large',
    icon: '<i class="fa-solid fa-circle-notch"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingSmall',
    defaultSettings: {
        awesomeLoadingLargeEnabled: false,
        awesomeLoadingLargeWhitelistMode: false,
        awesomeLoadingLargeImage: 'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['16:17'],
};

var configuration$p = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$o
});

var configuration$m = {
    id: 'awesomeLoadingSmall',
    display_name: 'Awesome Loading Small',
    icon: '<i class="fa-solid fa-spinner"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingLarge',
    defaultSettings: {
        awesomeLoadingSmallEnabled: false,
        awesomeLoadingSmallWhitelistMode: false,
        awesomeLoadingSmallImage: '',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['16+'],
};

var configuration$n = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$m
});

var configuration$k = {
    id: 'awesomeStyle',
    display_name: 'Awesome Style',
    icon: '<i class="fa-brands fa-css3-alt"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: true,
    },
    defaultSettings: {
        awesomeStyleEnabled: false,
        awesomeStyleWhitelistMode: false,
        awesomeStyleCSS: '',
    },
    supported_version: ['16+'],
};

var configuration$l = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$k
});

var configuration$i = {
    id: 'contextOdooMenus',
    display_name: 'Context OdooMenus',
    icon: '<i class="fa-solid fa-location-arrow"></i>',
    trigger: {
        background: false,
        load: false,
        navigate: false,
        context: true,
    },
    customization: {
        option: true,
        popup: false,
    },
    defaultSettings: {
        contextOdooMenusEnabled: false,
        contextOdooMenusWhitelistMode: false,
        contextOdooMenusContextMenu: {},
    },
    supported_version: ['16+'],
};

var configuration$j = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$i
});

var configuration$g = {
    id: 'impersonateLoginRunbot',
    display_name: '[Runbot] Impersonate Login',
    icon: '<i class="fa-solid fa-masks-theater"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        impersonateLoginRunbotEnabled: false,
        impersonateLoginRunbotLimitedOrigins: ['regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
    },
    limited: true,
};

var configuration$h = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$g
});

var configuration$e = {
    id: 'newServerActionCode',
    display_name: 'New Server Action Code',
    icon: '<i class="fa-solid fa-code"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        newServerActionCodeEnabled: false,
        newServerActionCodeWhitelistMode: false,
    },
    supported_version: ['16+'],
};

var configuration$f = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$e
});

var configuration$c = {
    id: 'pinMessage',
    display_name: 'Pin Message',
    icon: '<i class="fa-solid fa-thumbtack"></i>',
    trigger: {
        background: false,
        load: true,
        navigate: true,
        context: false,
        onrequest: [
            'https://*/*/mail.message/toggle_message_starred',
            'https://*/mail/message/update_content',
            'https://*/mail/thread/messages',
        ],
    },
    customization: {
        option: false,
        popup: true,
    },
    defaultSettings: {
        pinMessageEnabled: false,
        pinMessageWhitelistMode: false,
        pinMessageContextMenu: {},
        pinMessageSelfAuthorEnabled: true,
        pinMessageDefaultShown: false,
    },
    supported_version: ['17+'],
};

var configuration$d = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$c
});

var configuration$a = {
    id: 'saveKnowledge',
    display_name: 'Save Knowledge',
    icon: '<i class="fa-solid fa-bookmark"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        saveKnowledgeEnabled: false,
        saveKnowledgeWhitelistMode: false,
    },
    supported_version: ['16:17'],
};

var configuration$b = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$a
});

var configuration$8 = {
    id: 'showMyBadge',
    display_name: 'Show My Badge',
    icon: '<i class="fa-solid fa-certificate"></i>',
    trigger: {
        background: false,
        load: true,
        navigate: true,
    },
    customization: {
        option: false,
        popup: false,
    },
    defaultSettings: {
        showMyBadgeEnabled: false,
        showMyBadgeWhitelistMode: false,
    },
    supported_version: ['17+'],
};

var configuration$9 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$8
});

var configuration$6 = {
    id: 'starringTaskEffect',
    display_name: 'Starring Task Effect',
    icon: '<i class="fa-solid fa-star"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        starringTaskEffectEnabled: false,
        starringTaskEffectWhitelistMode: false,
    },
    supported_version: ['16+'],
};

var configuration$7 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$6
});

var configuration$4 = {
    id: 'themeSwitch',
    display_name: 'Theme Switch',
    icon: '<i class="fa-solid fa-sun"></i>',
    trigger: {
        background: true,
        load: false,
        navigate: false,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: "themeSwitchMode: 'system', 'autoDark', 'autoLight', 'dynamicLocation', 'dynamicTime'",
    defaultSettings: {
        themeSwitchEnabled: false,
        themeSwitchWhitelistMode: false,
        themeSwitchMode: 'system',
        themeSwitchLocationLatitude: '51.477928',
        themeSwitchLocationLongitude: '-0.001545',
        themeSwitchDarkStartTime: '20:30',
        themeSwitchDarkStopTime: '07:30',
    },
    supported_version: ['16+'],
};

var configuration$5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$4
});

var configuration$2 = {
    id: 'tooltipMetadata',
    display_name: 'Tooltip Metadata',
    icon: '<i class="fa-solid fa-file-lines"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        tooltipMetadataEnabled: false,
        tooltipMetadataWhitelistMode: false,
    },
    supported_version: ['16+'],
};

var configuration$3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$2
});

var configuration = {
    id: 'unfocusApp',
    display_name: 'Unfocus App',
    icon: '<i class="fa-solid fa-ghost"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    defaultSettings: {
        unfocusAppEnabled: false,
        unfocusAppWhitelistMode: false,
        unfocusAppReorderEnabled: false,
        unfocusAppShareEnabled: false,
        unfocusAppLightImageURL: 'https://i.imgur.com/AkTvOga.png',
        unfocusAppDarkImageURL: 'https://i.imgur.com/YzShNtH.png',
        unfocusAppOrigins: {},
    },
    supported_version: ['16+'],
};

var configuration$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration
});

async function getSunRiseSunSet(latitude, longitude) {
    let today = new Date();
    today = `${today.getMonth() + 1}-${today.getDate()}-${today.getFullYear()}`;
    const cached = await getSunSchedule();

    if (cached.joorney_sunrise && cached.joorney_sunset && cached.joorney_date === today) {
        return cached;
    }

    // Timezone related to coordinates
    const response = await fetch(`https://api.sunrisesunset.io/json?lat=${latitude}&lng=${longitude}`);

    const json = await response.json();

    let sunrise = json.results.sunrise.split(':');
    sunrise =
        Number.parseInt(sunrise[0]) * 60 + Number.parseInt(sunrise[1]) + (sunrise[2].endsWith('PM') ? 12 * 60 : 0);

    let sunset = json.results.sunset.split(':');
    sunset = Number.parseInt(sunset[0]) * 60 + Number.parseInt(sunset[1]) + (sunset[2].endsWith('PM') ? 12 * 60 : 0);

    const data = {
        joorney_sunrise: sunrise,
        joorney_sunset: sunset,
        joorney_date: today,
    };

    await setSunSchedule(data);
    return data;
}

class BackgroundFeature {
    constructor(configuration) {
        this.configuration = configuration;
        this.defaultSettings = configuration.defaultSettings;
    }

    async load(tab, args = undefined) {
        // TODO[IMP] Maybe useless as background trigger has been moved to content script side, cf themeSwitch
        if (!tab.url) return;
        const url = sanitizeURL(tab.url);
        const origin = url.origin;
        if (!origin || !origin.startsWith('http')) return;

        if (!(await isAuthorizedFeature(this.configuration.id, url))) return;

        this.loadFeature(tab, url, args);
    }

    async loadFeature(_tab, _url, _args) {}
}

async function setThemeModeCookie(expectedMode, origin, useConfiguredCookie) {
    if (!origin.startsWith('http')) return;
    await Cookies.set({
        name: 'color_scheme',
        value: expectedMode,
        url: origin,
    });
    if (useConfiguredCookie) {
        await Cookies.set({
            name: 'configured_color_scheme',
            value: expectedMode,
            url: origin,
        });
    }
}

async function getThemeModeCookie(origin, useConfiguredCookie) {
    if (!origin.startsWith('http')) return 'light';

    if (!Cookies) return getCookiesFromDocument(useConfiguredCookie);

    const cookies = await Promise.all([
        Cookies.get({
            name: 'configured_color_scheme',
            url: origin,
        }),
        Cookies.get({
            name: 'color_scheme',
            url: origin,
        }),
    ]);
    if (useConfiguredCookie) return cookies[0]?.value || cookies[1]?.value || 'light';
    return cookies[1]?.value || 'light';
}

function getCookiesFromDocument(useConfiguredCookie) {
    if (!document) return 'light';

    const decodedCookie = decodeURIComponent(document.cookie);

    const cookieName =
        decodedCookie.includes('configured_color_scheme') && useConfiguredCookie
            ? 'configured_color_scheme'
            : decodedCookie.includes('color_scheme')
              ? 'color_scheme'
              : null;

    if (!cookieName) return 'light';

    const cookies = decodedCookie.split(';');

    const cookie = cookies.find((c) => c.trim().indexOf(cookieName) === 0).substring(cookieName.length + 2);

    return cookie || 'light';
}

class ThemeSwitchBackgroundFeature extends BackgroundFeature {
    constructor() {
        super(configuration$4);
    }

    async loadFeature(tab, url, args) {
        const {
            themeSwitchMode /* "system", "autoDark", "autoLight", "dynamicLocation", "dynamicTime" */,
            themeSwitchLocationLatitude,
            themeSwitchLocationLongitude,
            themeSwitchDarkStartTime,
            themeSwitchDarkStopTime,
        } = await StorageSync.get(this.configuration.defaultSettings);

        let expectedMode = false;
        const today = new Date();
        const time = today.getHours() * 60 + today.getMinutes();

        switch (themeSwitchMode) {
            case 'system': {
                if (!args.theme) break;
                if (!['dark', 'light'].includes(args.theme)) {
                    console.debug(
                        `Invalid theme provided: ${args.theme}\nYou can open a bug report on https://github.com/MrSweeter/joorney/issues/new/choose`
                    );
                    return;
                }
                expectedMode = args.theme;
                break;
            }
            case 'autoDark':
                expectedMode = 'dark';
                break;
            case 'autoLight':
                expectedMode = 'light';
                break;
            case 'dynamicLocation': {
                const sunData = await getSunRiseSunSet(themeSwitchLocationLatitude, themeSwitchLocationLongitude);

                expectedMode = time > sunData.joorney_sunrise && time < sunData.joorney_sunset ? 'light' : 'dark';
                break;
            }
            case 'dynamicTime': {
                let start = themeSwitchDarkStartTime.split(':');
                start = Number.parseInt(start[0]) * 60 + Number.parseInt(start[1]);
                let stop = themeSwitchDarkStopTime.split(':');
                stop = Number.parseInt(stop[0]) * 60 + Number.parseInt(stop[1]);

                if (start < stop) expectedMode = time > start && time < stop ? 'dark' : 'light';
                else expectedMode = time > start || time < stop ? 'dark' : 'light';
            }
        }

        if (!expectedMode) return;

        // [ODOO] < 17.2
        if (`${url}`.includes('action=studio')) return;
        // [ODOO] < 17.4
        const useConfiguredCookie = args.version < 17.4;
        const origin = url.origin;
        const currentMode = await getThemeModeCookie(origin, useConfiguredCookie);

        if (currentMode !== expectedMode) {
            await setThemeModeCookie(expectedMode, origin, useConfiguredCookie);
            Tabs.reload(tab.id);
        }
    }
}

var background = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ThemeSwitchBackgroundFeature
});

var announce = {
	"2.2.1": {
	title: "Introducing the Announcement Banner",
	description: "Stay updated with the latest news and updates in the extension through our new announcement banner!",
	closeable: false,
	hash: "2.2.1.1"
},
	"2.3.0.15": {
	title: "New Feature - Ambient Effects",
	description: "Introduce ambient effects on the Odoo Home/Apps menu to highlight special events and important days.",
	closeable: true,
	hash: "2.3.0.15.1"
},
	"2.3.0.16": {
	title: "Odoo 18",
	description: "Odoo Experience 2024 has kicked off (or is over)! Buckle up and get ready to dive into the wild world of Odoo 18!",
	closeable: true,
	menu: "page-version",
	hash: "2.3.0.16.1"
},
	"2.3.2.16": {
	title: "Odoo 18.1",
	description: "",
	closeable: true,
	menu: "page-version",
	hash: "2.3.2.16.1"
}
};

var announce$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: announce
});

var availableOdooVersions = [
	"16.0",
	"saas-16.1",
	"saas-16.2",
	"saas-16.3",
	"saas-16.4",
	"17.0",
	"saas-17.1",
	"saas-17.2",
	"saas-17.3",
	"saas-17.4",
	"18.0",
	"saas-18.1",
	"saas-18.2"
];
var odoo = {
	availableOdooVersions: availableOdooVersions
};

var odoo$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    availableOdooVersions: availableOdooVersions,
    default: odoo
});
