var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringPriorityEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var pinMessage = true;
var ambient = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringPriorityEffect: starringPriorityEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus,
	pinMessage: pinMessage,
	ambient: ambient
};

function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
const Tabs = isFirefox() ? browser.tabs : chrome.tabs;
isFirefox() ? browser.contextMenus : chrome.contextMenus;
const Runtime = isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
isFirefox() ? browser.webNavigation : chrome.webNavigation;
isFirefox() ? browser.cookies : chrome.cookies;
isFirefox() ? browser.action : chrome.action;
isFirefox() ? browser.commands : chrome.commands;
isFirefox() ? browser.windows : chrome.windows;
isFirefox() ? browser.management : chrome.management;
isFirefox() ? browser.omnibox : chrome.omnibox;
isFirefox() ? browser.webRequest : chrome.webRequest;

async function sendRuntimeMessage(action, message = {}) {
    try {
        return await Runtime.sendMessage({ action: action, ...message });
    } catch (err) {
        Console.trace('catch runtime', err);
    }
}

async function sendTabMessage(tabID, action, message = {}) {
    try {
        return await Tabs.sendMessage(tabID, { action: action, ...message });
    } catch (err) {
        Console.trace('catch tabs', err);
    }
}

const Console = {
    info(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
    },
    log(obj) {
        console.log(obj);
    },
    error(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
    },
    warn(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
    },
    success(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
    },
    trace(label, obj) {
        console.trace(label, obj);
    },
    critical(obj) {
        console.error(obj);
    },

    _getFormatOperator(obj) {
        switch (typeof obj) {
            case 'string':
                return '%s';
            case 'number':
                return '%s';
            case 'object':
                return '%O';
            default:
                return '%s';
        }
    },
};

const MESSAGE_ACTION = {
    TO_BACKGROUND: {
        GET_FEATURES_LIST: 'GET_FEATURES_LIST',
        GET_FINAL_RUNBOT_URL: 'GET_FINAL_RUNBOT_URL',
        UPDATE_EXT_STATUS: 'UPDATE_EXT_STATUS',
        TRIGGER_FEATURE: 'TRIGGER_FEATURE',
        RECREATE_MENU: 'RECREATE_MENU',
        TAB_LOADED: 'TAB_LOADED',
    },
    TO_CONTENT: {
        TAB_NAVIGATION: 'TAB_NAVIGATION',
        POPUP_HAS_CHANGE: 'POPU¨_HAS_CHANGE',
        REQUEST_ODOO_INFO: 'REQUEST_ODOO_INFO',
        CM_OPEN_MENU: 'CM_OPEN_MENU',
        CM_OPEN_RUNBOT: 'CM_OPEN_RUNBOT',
        WEB_REQUEST_COMPLETE: 'WEB_REQUEST_COMPLETE',
    },
};

function __variableDynamicImportRuntime6__(path) {
  switch (path) {
    case './src/features/adminDebugLoginRunbot/popup.js': return Promise.resolve().then(function () { return popup$g; });
    case './src/features/ambient/popup.js': return Promise.resolve().then(function () { return popup$f; });
    case './src/features/assignMeTask/popup.js': return Promise.resolve().then(function () { return popup$e; });
    case './src/features/autoOpenRunbot/popup.js': return Promise.resolve().then(function () { return popup$d; });
    case './src/features/awesomeLoadingLarge/popup.js': return Promise.resolve().then(function () { return popup$c; });
    case './src/features/awesomeLoadingSmall/popup.js': return Promise.resolve().then(function () { return popup$b; });
    case './src/features/awesomeStyle/popup.js': return Promise.resolve().then(function () { return popup$a; });
    case './src/features/contextOdooMenus/popup.js': return Promise.resolve().then(function () { return popup$9; });
    case './src/features/impersonateLoginRunbot/popup.js': return Promise.resolve().then(function () { return popup$8; });
    case './src/features/newServerActionCode/popup.js': return Promise.resolve().then(function () { return popup$7; });
    case './src/features/pinMessage/popup.js': return Promise.resolve().then(function () { return popup$6; });
    case './src/features/saveKnowledge/popup.js': return Promise.resolve().then(function () { return popup$5; });
    case './src/features/showMyBadge/popup.js': return Promise.resolve().then(function () { return popup$4; });
    case './src/features/starringPriorityEffect/popup.js': return Promise.resolve().then(function () { return popup$3; });
    case './src/features/themeSwitch/popup.js': return Promise.resolve().then(function () { return popup$2; });
    case './src/features/tooltipMetadata/popup.js': return Promise.resolve().then(function () { return popup$1; });
    case './src/features/unfocusApp/popup.js': return Promise.resolve().then(function () { return popup; });
    default: return new Promise(function(resolve, reject) {
      (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
        reject.bind(null, new Error("Unknown variable dynamic import: " + path))
      );
    })
   }
 }

const baseSettings = {
    configurationVersion: 2,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['18.0'],
    supportedDevVersions: [],

    // Experimental
    developerMode: false,
    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
    cacheEncodingBase64: true,
};
Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

function importFeaturePopupFile(featureID) {
    return __variableDynamicImportRuntime6__(`./src/features/${featureID}/popup.js`).then((f) => new f.default());
}

async function getFeaturesAndCurrentSettings() {
    const response = await sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.GET_FEATURES_LIST);
    const features = response.features;

    const configuration = await getCurrentSettings(features);
    return { features: features, currentSettings: configuration };
}

async function getCurrentSettings(features) {
    const defaultSettings = features.reduce((acc, obj) => {
        return Object.assign(acc, obj.defaultSettings);
    }, {});

    const settings = await StorageSync.get({
        ...baseSettings,
        ...defaultSettings,
    });
    return settings;
}

function stringToHTML(str) {
    const template = document.createElement('template');
    template.innerHTML = str.trim();
    return template.content.firstChild;
}

function generateFeaturePopupToggleItem(feature) {
    return stringToHTML(`
		<label
			title="[Feature] ${feature.display_name ?? feature.id}"
			for="${feature.id}Feature"
			class="m-2 d-flex justify-content-center align-items-center"
		>
			<input id="${feature.id}Feature" type="checkbox" />
			<div class="icon-wrapper ${feature.limited ? 'limited-feature' : ''}">
				${feature.icon}
			</div>
		</label>
	`);
}

function generateTabFeaturePopupToggleItem(feature) {
    return stringToHTML(`
		<label
			title="[Feature Origin] ${feature.display_name ?? feature.id}"
			for="${feature.id}FeatureTab"
			class=""
		>
			<input id="${feature.id}FeatureTab" type="checkbox" />
			<div class="icon-wrapper-tab">
				${feature.icon}
			</div>
		</label>
	`);
}

const regexSchemePrefix = 'regex://';

async function reloadTabFeatures() {
    const { features, currentSettings } = await getFeaturesAndCurrentSettings();

    loadTabFeatures(features, currentSettings);
}

async function loadTabFeatures(features, configuration) {
    const tabs = await Tabs.query({ active: true, currentWindow: true });
    const currentTab = tabs[0];

    const originString = new URL(currentTab.url).origin;

    const origins = configuration.originsFilterOrigins;

    setupSaveOriginButton(features, configuration, currentTab.id, origins, originString);
}

function setupSaveOriginButton(features, configuration, currentTabID, origins, originStringArg) {
    const saveOriginButton = document.getElementById('saveOriginButton');
    const tabFeaturesList = document.getElementById('tabFeaturesList');

    let originString = originStringArg;
    const originKeys = Object.keys(origins);
    if (!originKeys.includes(originString)) {
        const regexes = originKeys
            .filter((o) => o.startsWith(regexSchemePrefix))
            .map((o) => new RegExp(o.replace(regexSchemePrefix, '')));
        const validRegex = regexes.find((r) => r.test(originString));
        if (validRegex) {
            originString = regexSchemePrefix + validRegex.source;
        }
    }

    const currentTabText = document.getElementById('currentTabUrl');
    currentTabText.innerHTML = originString;

    if (originKeys.includes(originString)) {
        setupFeatures(features, configuration, currentTabID, origins, originString);
        saveOriginButton.style.display = 'none';
        tabFeaturesList.style.display = 'flex';
        return;
    }
    saveOriginButton.style.display = 'flex';
    tabFeaturesList.style.display = 'none';
    saveOriginButton.onclick = async () => {
        origins[originString] = {};
        await StorageSync.set({ originsFilterOrigins: origins });
        reloadTabFeatures();
    };
    saveOriginButton.disabled = false;
}

function setupFeatures(featuresArg, configuration, currentTabID, origins, originString) {
    const tabConfiguration = origins[originString];
    const features = featuresArg.filter((f) => !f.limited).map((f) => f.id);

    for (const f of features) {
        const featureInput = document.getElementById(`${f}FeatureTab`);
        featureInput.checked = tabConfiguration[f];
        featureInput.disabled = !configuration[`${f}Enabled`];
        featureInput.classList.remove('blacklist');
        featureInput.classList.remove('whitelist');
        featureInput.classList.add(configuration[`${f}WhitelistMode`] ? 'whitelist' : 'blacklist');
    }

    const saveButton = document.getElementById('saveButton');
    saveButton.onclick = async () => {
        const originConfiguration = {};
        for (const f of features) {
            const featureInput = document.getElementById(`${f}FeatureTab`);
            originConfiguration[f] = featureInput.checked;
        }
        origins[originString] = originConfiguration;
        await StorageSync.set({ originsFilterOrigins: origins });
        Tabs.reload(currentTabID);
    };
    saveButton.disabled = false;
}

window.onload = async () => {
    const tabs = await Tabs.query({ active: true, currentWindow: true });
    const currentTab = tabs[0];
    if (!currentTab.url.startsWith('http')) return;

    document.getElementById('joorney-invalid-website').remove();
    document.getElementById('joorney-popup-configuration').classList.remove('d-none');

    renderFeatures();

    const popupIcon = document.getElementById('popupIcon');
    popupIcon.onclick = () => Runtime.openOptionsPage();
};

async function renderFeatures() {
    const { features, currentSettings } = await getFeaturesAndCurrentSettings();

    const toggleContainer = document.getElementById('joorney-popup-feature-toggle');
    toggleContainer.innerHTML = '';
    const tabFeatureContainer = document.getElementById('tabFeaturesContainer');
    tabFeatureContainer.innerHTML = '';

    for (const f of features) {
        toggleContainer.appendChild(generateFeaturePopupToggleItem(f));
        if (!f.limited) tabFeatureContainer.appendChild(generateTabFeaturePopupToggleItem(f));
    }

    loadFeatures(features, currentSettings);
}

async function loadFeatures(features, currentSettings) {
    for (const feature of features) {
        importFeaturePopupFile(feature.id).then((featureModule) => {
            featureModule.load(currentSettings);
        });
    }

    reloadTabFeatures();
}

function featureIDToPascalCase(id) {
    return id.charAt(0).toUpperCase() + id.slice(1);
}

class PopupFeature {
    constructor(configuration) {
        this.configuration = configuration;
        this.defaultSettings = configuration.defaultSettings;
        this.updateFeature = this.updateFeature.bind(this);
    }

    load() {
        this.restore();
    }

    async restore() {
        const defaultConfiguration = await this.getDefaultConfiguration();
        const feature = document.getElementById(`${this.configuration.id}Feature`);
        feature.onchange = this.updateFeature;

        feature.checked = defaultConfiguration[`${this.configuration.id}Enabled`];
    }

    async getDefaultConfiguration() {
        const configuration = await StorageSync.get({
            [`${this.configuration.id}Enabled`]: false,
        });
        return configuration;
    }

    updateFeature(e) {
        const checked = e.target.checked;
        StorageSync.set({ [`${this.configuration.id}Enabled`]: checked });
        this.notifyOptionPage({
            [`enable${featureIDToPascalCase(this.configuration.id)}`]: checked,
        });
    }

    getNotificationMessage(data) {
        return {
            [`enable${featureIDToPascalCase(this.configuration.id)}`]: data.checked,
        };
    }

    notifyTabs(data) {
        // The wildcard * for scheme only matches http or https
        // Same url pattern than content_scripts in manifest
        Tabs.query({ url: '*://*/*' }).then(async (tabs) => {
            const message = this.getNotificationMessage(data);
            if (Object.keys(message).length) {
                for (const t of tabs) {
                    sendTabMessage(t.id, MESSAGE_ACTION.TO_CONTENT.POPUP_HAS_CHANGE, { ...message, url: t.url });
                }
            }
        });
    }

    async notifyOptionPage(message) {
        reloadTabFeatures();
        // No query for the chrome-extension scheme
        Tabs.query({}).then((tabs) => {
            for (const tab of tabs.filter((t) => t.url.startsWith(`chrome-extension://${Runtime.id}`))) {
                sendTabMessage(tab.id, MESSAGE_ACTION.TO_CONTENT.POPUP_HAS_CHANGE, message);
            }
        });
    }
}

class PopupCustomizableFeature extends PopupFeature {
    constructor(configuration) {
        super(configuration);
        if (!configuration.customization.popup) throw new Error(`Invalid state for feature: ${this.configuration.id}`);
    }

    load(currentSettings) {
        super.load();
        const container = document.querySelector(`div[data-feature-customization="${this.configuration.id}"]`);
        if (!container) throw new Error(`Invalid state for feature: ${this.configuration.id}`);
        container.classList.remove('d-none');
        document.getElementById(`joorney-popup-feature-${this.configuration.id}-label`).innerHTML =
            this.configuration.display_name;

        this.render(currentSettings[`${this.configuration.id}Enabled`]);
    }

    updateFeature(e) {
        super.updateFeature(e);
        const checked = e.target.checked;
        this.render(checked);
        this.notifyTabs({ checked: checked });
    }

    render(_enabled) {}
}

var adminDebugLoginConfiguration = {
    id: 'adminDebugLoginRunbot',
    display_name: '[Runbot] Admin Debug Login',
    icon: '<i class="fa-solid fa-rocket"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        adminDebugLoginRunbotEnabled: false,
        adminDebugLoginRunbotLimitedOrigins: ['https://runbot.odoo.com', 'regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
    },
    limited: true,
};

class AdminDebugLoginRunbotPopupFeature extends PopupFeature {
    constructor() {
        super(adminDebugLoginConfiguration);
    }
}

var popup$g = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AdminDebugLoginRunbotPopupFeature
});

var configuration$e = {
    id: 'ambient',
    display_name: 'Ambient',
    icon: '<i class="fa-solid fa-mountain-sun"></i>', // '<i class="fa-solid fa-panorama"></i>'
    trigger: {
        background: false,
        load: true,
        navigate: false,
    },
    customization: {
        option: false,
        popup: false,
    },
    defaultSettings: {
        ambientEnabled: false,
        ambientWhitelistMode: false,
        ambientStatus: {},
    },
    supported_version: ['17+'],
};

class AmbientPopupFeature extends PopupFeature {
    constructor() {
        super(configuration$e);
    }
}

var popup$f = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AmbientPopupFeature
});

var configuration$d = {
    id: 'assignMeTask',
    display_name: 'Assign Me Task',
    icon: '<i class="fa-solid fa-user-plus"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        assignMeTaskEnabled: false,
        assignMeTaskWhitelistMode: false,
    },
    supported_version: ['16.3+'],
};

class AssignMeTaskPopupFeature extends PopupFeature {
    constructor() {
        super(configuration$d);
    }
}

var popup$e = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AssignMeTaskPopupFeature
});

const openRunbotWithVersionMenuItem = {
    id: 'joorney_autoOpenRunbot_open_with_version',
    title: 'Open runbot with version %version%',
    active: true,
    favorite: true,
    order: 100,
};

var autoOpenRunbotConfiguration = {
    id: 'autoOpenRunbot',
    display_name: '[Runbot] Auto Open',
    icon: '<i class="fa-solid fa-fighter-jet"></i>',
    trigger: {
        load: true,
        navigate: true,
        context: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        autoOpenRunbotEnabled: false,
        autoOpenRunbotLimitedOrigins: ['https://runbot.odoo.com'],
        autoOpenRunbotContextMenu: {
            [openRunbotWithVersionMenuItem.id]: openRunbotWithVersionMenuItem,
        },
    },
    limited: true,
};

class AutoOpenRunbotPopupFeature extends PopupFeature {
    constructor() {
        super(autoOpenRunbotConfiguration);
    }
}

var popup$d = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AutoOpenRunbotPopupFeature
});

class AwesomeLoadingSharePopupFeature extends PopupCustomizableFeature {
    constructor(configuration) {
        super(configuration);
        this.htmlID = '';
        this.previewHtmlID = '';
    }

    async render(enabled) {
        const awesomeLoadingImage = document.getElementById(this.htmlID);
        const awesomeLoadingImagePreview = document.getElementById(this.previewHtmlID);

        const { images, selected } = await this.getImagesConfiguration();

        awesomeLoadingImage.innerHTML = '<option value="" selected>Default</option>';
        awesomeLoadingImage.disabled = !enabled;
        awesomeLoadingImagePreview.src = selected;
        awesomeLoadingImagePreview.style.opacity = enabled ? 1 : 0.25;

        for (const img of images) {
            const opt = document.createElement('option');
            opt.innerHTML = img;
            opt.value = img;
            opt.selected = selected === img;
            awesomeLoadingImage.appendChild(opt);
        }

        if (images.length <= 0) {
            awesomeLoadingImage.disabled = true;
            awesomeLoadingImage.style.opacity = 0.25;

            const optionButton = document.createElement('div');
            optionButton.style.cursor = 'pointer';
            optionButton.innerHTML = '<i class="fa-solid fa-up-right-from-square"></i>';
            optionButton.onclick = () => Runtime.openOptionsPage();

            awesomeLoadingImage.parentNode.appendChild(optionButton);
        }

        awesomeLoadingImage.onchange = async (e) => {
            const value = e.target.value;
            await this.saveSelectedImage(value);
            const preview = document.getElementById(this.previewHtmlID);
            preview.src = value;
            this.notifyTabs({ image: value });
        };

        this.notifyTabs({ image: enabled ? selected : false });
    }

    getNotificationMessage(_data) {
        return {};
    }

    async getImagesConfiguration() {
        return { images: [], selected: '' };
    }

    async saveSelectedImage(_value) {}
}

var configuration$c = {
    id: 'awesomeLoadingLarge',
    display_name: 'Awesome Loading Large',
    icon: '<i class="fa-solid fa-circle-notch"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingSmall',
    defaultSettings: {
        awesomeLoadingLargeEnabled: false,
        awesomeLoadingLargeWhitelistMode: false,
        awesomeLoadingLargeImage: 'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['16:17'],
};

class AwesomeLoadingLargePopupFeature extends AwesomeLoadingSharePopupFeature {
    constructor() {
        super(configuration$c);
        this.htmlID = 'updateAwesomeLoadingLargeImage';
        this.previewHtmlID = 'awesomeLoadingLargeImagePreview';
    }

    getNotificationMessage(data) {
        return { awesomeLoadingLargeImage: data.image };
    }

    async getImagesConfiguration() {
        const configuration = await StorageSync.get({
            awesomeLoadingLargeImage: '',
            awesomeLoadingImages: [],
        });
        return {
            images: configuration.awesomeLoadingImages,
            selected: configuration.awesomeLoadingLargeImage,
        };
    }

    async saveSelectedImage(value) {
        await StorageSync.set({ awesomeLoadingLargeImage: value });
    }
}

var popup$c = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeLoadingLargePopupFeature
});

var configuration$b = {
    id: 'awesomeLoadingSmall',
    display_name: 'Awesome Loading Small',
    icon: '<i class="fa-solid fa-spinner"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingLarge',
    defaultSettings: {
        awesomeLoadingSmallEnabled: false,
        awesomeLoadingSmallWhitelistMode: false,
        awesomeLoadingSmallImage: '',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['16+'],
};

class AwesomeLoadingSmallPopupFeature extends AwesomeLoadingSharePopupFeature {
    constructor() {
        super(configuration$b);
        this.htmlID = 'updateAwesomeLoadingSmallImage';
        this.previewHtmlID = 'awesomeLoadingSmallImagePreview';
    }

    getNotificationMessage(data) {
        return { awesomeLoadingSmallImage: data.image };
    }

    async getImagesConfiguration() {
        const configuration = await StorageSync.get({
            awesomeLoadingSmallImage: '',
            awesomeLoadingImages: [],
        });
        return {
            images: configuration.awesomeLoadingImages,
            selected: configuration.awesomeLoadingSmallImage,
        };
    }

    async saveSelectedImage(value) {
        await StorageSync.set({ awesomeLoadingSmallImage: value });
    }
}

var popup$b = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeLoadingSmallPopupFeature
});

var configuration$a = {
    id: 'awesomeStyle',
    display_name: 'Awesome Style',
    icon: '<i class="fa-brands fa-css3-alt"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: true,
    },
    defaultSettings: {
        awesomeStyleEnabled: false,
        awesomeStyleWhitelistMode: false,
        awesomeStyleCSS: '',
    },
    supported_version: ['16+'],
};

class AwesomeStylePopupFeature extends PopupFeature {
    constructor() {
        super(configuration$a);
    }

    updateFeature(e) {
        super.updateFeature(e);
        this.notifyTabs({ checked: e.target.checked });
    }
}

var popup$a = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeStylePopupFeature
});

var configuration$9 = {
    id: 'contextOdooMenus',
    display_name: 'Context OdooMenus',
    icon: '<i class="fa-solid fa-location-arrow"></i>',
    trigger: {
        background: false,
        load: false,
        navigate: false,
        context: true,
    },
    customization: {
        option: true,
        popup: false,
    },
    defaultSettings: {
        contextOdooMenusEnabled: false,
        contextOdooMenusWhitelistMode: false,
        contextOdooMenusContextMenu: {},
    },
    supported_version: ['16+'],
};

class ContextOdooMenusPopupFeature extends PopupFeature {
    constructor() {
        super(configuration$9);
    }
}

var popup$9 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ContextOdooMenusPopupFeature
});

var configuration$8 = {
    id: 'impersonateLoginRunbot',
    display_name: '[Runbot] Impersonate Login',
    icon: '<i class="fa-solid fa-masks-theater"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        impersonateLoginRunbotEnabled: false,
        impersonateLoginRunbotLimitedOrigins: ['regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
    },
    limited: true,
};

class ImpersonateLoginRunbotPopupFeature extends PopupFeature {
    constructor() {
        super(configuration$8);
    }
}

var popup$8 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ImpersonateLoginRunbotPopupFeature
});

var configuration$7 = {
    id: 'newServerActionCode',
    display_name: 'New Server Action Code',
    icon: '<i class="fa-solid fa-code"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        newServerActionCodeEnabled: false,
        newServerActionCodeWhitelistMode: false,
    },
    supported_version: ['16+'],
};

class NewServerActionCodePopupFeature extends PopupFeature {
    constructor() {
        super(configuration$7);
    }
}

var popup$7 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: NewServerActionCodePopupFeature
});

var configuration$6 = {
    id: 'pinMessage',
    display_name: 'Pin Message',
    icon: '<i class="fa-solid fa-thumbtack"></i>',
    trigger: {
        background: false,
        load: true,
        navigate: true,
        context: false,
        onrequest: [
            'https://*/*/mail.message/toggle_message_starred',
            'https://*/mail/message/update_content',
            'https://*/mail/thread/messages',
        ],
    },
    customization: {
        option: false,
        popup: true,
    },
    defaultSettings: {
        pinMessageEnabled: false,
        pinMessageWhitelistMode: false,
        pinMessageContextMenu: {},
        pinMessageSelfAuthorEnabled: true,
        pinMessageDefaultShown: false,
    },
    supported_version: ['17+'],
};

class PinMessagePopupFeature extends PopupCustomizableFeature {
    constructor() {
        super(configuration$6);
    }

    async render(enabled) {
        const { pinMessageSelfAuthorEnabled, pinMessageDefaultShown } = await StorageSync.get({
            pinMessageSelfAuthorEnabled: this.defaultSettings.pinMessageSelfAuthorEnabled,
            pinMessageDefaultShown: this.defaultSettings.pinMessageDefaultShown,
        });

        const selfAuthorSwitcher = document.getElementById('joorney_pin_message_self_author_switcher');
        const selfAuthorInput = document.getElementById('joorney_pin_message_self_author_input');
        this.updateRenderPinMessageSelfAuthorSwitcher(
            selfAuthorSwitcher,
            selfAuthorInput,
            pinMessageSelfAuthorEnabled,
            enabled,
            this.onPinMessageSelfAuthorChange
        );

        const defaultShownSwitcher = document.getElementById('joorney_pin_message_default_shown_switcher');
        const defaultShownInput = document.getElementById('joorney_pin_message_default_shown_input');
        this.updateRenderPinMessageSelfAuthorSwitcher(
            defaultShownSwitcher,
            defaultShownInput,
            pinMessageDefaultShown,
            enabled,
            this.onPinMessageDefaultShownChange
        );
    }

    updateRenderPinMessageSelfAuthorSwitcher(switcher, input, optionActive, featureActive, onchange) {
        input.checked = optionActive;
        input.setAttribute('indeterminate', !featureActive);
        input.onchange = onchange;

        switcher.disabled = !featureActive;
        input.disabled = !featureActive;
        switcher.style.opacity = featureActive ? 1 : 0.5;
    }

    updateRenderPinMessageDefaultShownSwitcher(switcher, input, optionActive, featureActive, onchange) {
        input.checked = optionActive;
        input.setAttribute('indeterminate', !featureActive);
        input.onchange = onchange;

        switcher.disabled = !featureActive;
        input.disabled = !featureActive;
        switcher.style.opacity = featureActive ? 1 : 0.5;
    }

    onPinMessageSelfAuthorChange(event) {
        const pinMessageFeature = document.getElementById('pinMessageFeature');
        const enabled = pinMessageFeature.checked;
        if (enabled)
            StorageSync.set({
                pinMessageSelfAuthorEnabled: event.currentTarget.checked,
            });
        else event.preventDefault();
    }

    onPinMessageDefaultShownChange(event) {
        const pinMessageFeature = document.getElementById('pinMessageFeature');
        const enabled = pinMessageFeature.checked;
        if (enabled)
            StorageSync.set({
                pinMessageDefaultShown: event.currentTarget.checked,
            });
        else event.preventDefault();
    }
}

var popup$6 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: PinMessagePopupFeature
});

var configuration$5 = {
    id: 'saveKnowledge',
    display_name: 'Save Knowledge',
    icon: '<i class="fa-solid fa-bookmark"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        saveKnowledgeEnabled: false,
        saveKnowledgeWhitelistMode: false,
    },
    supported_version: ['16:17'],
};

class SaveKnowledgePopupFeature extends PopupFeature {
    constructor() {
        super(configuration$5);
    }
}

var popup$5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: SaveKnowledgePopupFeature
});

var configuration$4 = {
    id: 'showMyBadge',
    display_name: 'Show My Badge',
    icon: '<i class="fa-solid fa-certificate"></i>',
    trigger: {
        background: false,
        load: true,
        navigate: true,
    },
    customization: {
        option: false,
        popup: false,
    },
    defaultSettings: {
        showMyBadgeEnabled: false,
        showMyBadgeWhitelistMode: false,
    },
    supported_version: ['17+'],
};

class ShowMyBadgePopupFeature extends PopupFeature {
    constructor() {
        super(configuration$4);
    }
}

var popup$4 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ShowMyBadgePopupFeature
});

var configuration$3 = {
    id: 'starringPriorityEffect',
    display_name: 'Starring Effect',
    icon: '<i class="fa-solid fa-star"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        starringPriorityEffectEnabled: false,
        starringPriorityEffectWhitelistMode: false,
    },
    supported_version: ['16+'],
};

class StarringPriorityEffectPopupFeature extends PopupFeature {
    constructor() {
        super(configuration$3);
    }
}

var popup$3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: StarringPriorityEffectPopupFeature
});

var configuration$2 = {
    id: 'themeSwitch',
    display_name: 'Theme Switch',
    icon: '<i class="fa-solid fa-sun"></i>',
    trigger: {
        background: true,
        load: false,
        navigate: false,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: "themeSwitchMode: 'system', 'autoDark', 'autoLight', 'dynamicLocation', 'dynamicTime'",
    defaultSettings: {
        themeSwitchEnabled: false,
        themeSwitchWhitelistMode: false,
        themeSwitchMode: 'system',
        themeSwitchLocationLatitude: '51.477928',
        themeSwitchLocationLongitude: '-0.001545',
        themeSwitchDarkStartTime: '20:30',
        themeSwitchDarkStopTime: '07:30',
    },
    supported_version: ['16+'],
};

class ThemeSwitchPopupFeature extends PopupCustomizableFeature {
    constructor() {
        super(configuration$2);
    }

    async render(enabled) {
        const themeModeSwitcher = document.getElementById('joorney_theme_switch_mode_switcher');

        const { themeSwitchMode } = await StorageSync.get({
            themeSwitchMode: 'autoDark',
        });

        themeModeSwitcher.value = themeSwitchMode;
        themeModeSwitcher.onchange = this.onThemeSwitchModeChange;

        themeModeSwitcher.disabled = !enabled;
        themeModeSwitcher.style.opacity = enabled ? 1 : 0.5;
    }

    onThemeSwitchModeChange(event) {
        const themeSwitchFeature = document.getElementById('themeSwitchFeature');
        const enabled = themeSwitchFeature.checked;
        if (enabled)
            StorageSync.set({
                themeSwitchMode: event.currentTarget.value,
            });
        else event.preventDefault();
    }
}

var popup$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ThemeSwitchPopupFeature
});

var configuration$1 = {
    id: 'tooltipMetadata',
    display_name: 'Tooltip Metadata',
    icon: '<i class="fa-solid fa-file-lines"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        tooltipMetadataEnabled: false,
        tooltipMetadataWhitelistMode: false,
    },
    supported_version: ['16+'],
};

class TooltipMetadataPopupFeature extends PopupFeature {
    constructor() {
        super(configuration$1);
    }
}

var popup$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: TooltipMetadataPopupFeature
});

var configuration = {
    id: 'unfocusApp',
    display_name: 'Unfocus App',
    icon: '<i class="fa-solid fa-ghost"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    defaultSettings: {
        unfocusAppEnabled: false,
        unfocusAppWhitelistMode: false,
        unfocusAppReorderEnabled: false,
        unfocusAppShareEnabled: false,
        unfocusAppLightImageURL: 'https://i.imgur.com/AkTvOga.png',
        unfocusAppDarkImageURL: 'https://i.imgur.com/YzShNtH.png',
        unfocusAppOrigins: {},
    },
    supported_version: ['16+'],
};

class UnfocusAppPopupFeature extends PopupCustomizableFeature {
    constructor() {
        super(configuration);
    }

    async render(enabled) {
        const { unfocusAppReorderEnabled, unfocusAppShareEnabled } = await StorageSync.get({
            unfocusAppReorderEnabled: this.defaultSettings.unfocusAppReorderEnabled,
            unfocusAppShareEnabled: this.defaultSettings.unfocusAppShareEnabled,
        });

        const appOrderSwitcher = document.getElementById('joorney_unfocus_app_order_switcher');
        const appOrderInput = document.getElementById('joorney_unfocus_app_order_input');
        this.updateRenderUnfocusAppSwitcher(
            appOrderSwitcher,
            appOrderInput,
            unfocusAppReorderEnabled,
            enabled,
            this.onUnfocusAppReorderModeChange
        );

        const appShareSwitcher = document.getElementById('joorney_unfocus_app_share_switcher');
        const appShareInput = document.getElementById('joorney_unfocus_app_share_input');

        this.updateRenderUnfocusAppSwitcher(
            appShareSwitcher,
            appShareInput,
            unfocusAppShareEnabled,
            enabled,
            this.onUnfocusAppShareModeChange
        );
    }

    updateRenderUnfocusAppSwitcher(switcher, input, optionActive, featureActive, onchange) {
        input.checked = optionActive;
        input.setAttribute('indeterminate', !featureActive);
        input.onchange = onchange;

        switcher.disabled = !featureActive;
        input.disabled = !featureActive;
        switcher.style.opacity = featureActive ? 1 : 0.5;
    }

    onUnfocusAppReorderModeChange(event) {
        const unfocusAppFeature = document.getElementById('unfocusAppFeature');
        const enabled = unfocusAppFeature.checked;
        if (enabled)
            StorageSync.set({
                unfocusAppReorderEnabled: event.currentTarget.checked,
            });
        else event.preventDefault();
    }

    onUnfocusAppShareModeChange(event) {
        const unfocusAppFeature = document.getElementById('unfocusAppFeature');
        const enabled = unfocusAppFeature.checked;
        if (enabled)
            StorageSync.set({
                unfocusAppShareEnabled: event.currentTarget.checked,
            });
        else event.preventDefault();
    }
}

var popup = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: UnfocusAppPopupFeature
});
