function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
isFirefox() ? browser.tabs : chrome.tabs;
isFirefox() ? browser.contextMenus : chrome.contextMenus;
const Runtime = isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
const StorageLocal = isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
isFirefox() ? browser.webNavigation : chrome.webNavigation;
isFirefox() ? browser.cookies : chrome.cookies;
isFirefox() ? browser.action : chrome.action;
isFirefox() ? browser.commands : chrome.commands;
isFirefox() ? browser.windows : chrome.windows;
isFirefox() ? browser.management : chrome.management;
isFirefox() ? browser.omnibox : chrome.omnibox;
isFirefox() ? browser.webRequest : chrome.webRequest;

const Console = {
    info(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
    },
    log(obj) {
        console.log(obj);
    },
    error(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
    },
    warn(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
    },
    success(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
    },
    trace(label, obj) {
        console.trace(label, obj);
    },
    critical(obj) {
        console.error(obj);
    },

    _getFormatOperator(obj) {
        switch (typeof obj) {
            case 'string':
                return '%s';
            case 'number':
                return '%s';
            case 'object':
                return '%O';
            default:
                return '%s';
        }
    },
};

function createTitleFromJSON(obj) {
    return escapeForHTMLTitle(JSON.stringify(obj));
}

function escapeForHTMLTitle(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
        .replace(/\n/g, '&#10;');
}

function yyyymmdd_hhmmssToDate(datetimeStr) {
    const [dateStr, timeStr] = datetimeStr.split(' ');
    return new Date(`${dateStr}T${timeStr}Z`).toISOString();
}

function toLocaleDateStringFormatted(date) {
    return date.toLocaleDateString([], { year: '2-digit', month: '2-digit', day: '2-digit' });
}

function toLocaleTimeStringFormatted(date) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function toLocaleDateTimeStringFormatted(date) {
    return `${toLocaleDateStringFormatted(date)} ${toLocaleTimeStringFormatted(date)}`;
}

function toOdooBackendDateGMT0(date) {
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const hours = String(date.getUTCHours()).padStart(2, '0');
    const minutes = String(date.getUTCMinutes()).padStart(2, '0');
    const seconds = String(date.getUTCSeconds()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

function hasUnknownKey(sourceObj, targetObj) {
    for (const key in sourceObj) {
        if (!(key in targetObj)) {
            return true;
        }
    }
    return false;
}

// Private
const LOCAL_DEFAULT = {
    journey_announces: {},
    offs: [],
    ambient_dates: {},
    joorney_sunrise: 0,
    joorney_sunset: 23 * 60 + 59,
    joorney_date: '',
    joorneyLocalCacheCall: {},
};

async function setLocal(obj) {
    if (hasUnknownKey(obj, LOCAL_DEFAULT)) {
        Console.warn(`Unknown local key in: ${JSON.stringify(obj)}`);
    }
    await StorageLocal.set(obj);
}

// Cache
async function getLocalCache() {
    const { joorneyLocalCacheCall } = await StorageLocal.get({
        joorneyLocalCacheCall: LOCAL_DEFAULT.joorneyLocalCacheCall,
    });
    return joorneyLocalCacheCall;
}
async function setLocalCache(cacheData) {
    await setLocal({ joorneyLocalCacheCall: cacheData });
}

// Ambient
async function getAmbientDates() {
    const { ambient_dates } = await StorageLocal.get({ ambient_dates: LOCAL_DEFAULT.ambient_dates });
    return ambient_dates;
}
async function setAmbientDates(datesData) {
    await setLocal({ ambient_dates: datesData });
}

var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringPriorityEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var pinMessage = true;
var ambient = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringPriorityEffect: starringPriorityEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus,
	pinMessage: pinMessage,
	ambient: ambient
};

({
    configurationVersion: 2,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['18.0'],
    supportedDevVersions: [],

    // Experimental
    developerMode: false,
    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
    cacheEncodingBase64: true,
});
Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

/**
 * Caches the result of a function call for a specified amount of time.
 * If the cached result exists and hasn't expired, it is returned;
 * otherwise, the function is executed and the result is cached.
 *
 * @async
 * @function cache
 * @param {number} cachingTime - The amount of time (in minutes) to cache the result. If 0 or less, the result will not be cached.
 * @param {Function} call - The asynchronous function to call if there is no cached data.
 * @param {string} callID - A unique identifier for the cached data.
 * @param {...any} params - Additional parameters passed to both the `readCacheCall` and `saveCacheCall` functions.
 * @returns {Promise<{fromCache: boolean, data: any}>} - An object containing two properties:
 *          - `fromCache` (boolean): Whether the data was retrieved from the cache.
 *          - `data` (any): The cached data or the result of the function call.
 */
async function cache(cachingTime, call, callID, ...params) {
    let data = undefined;
    let fromCache = true;
    {
        data = await readCacheCall(callID, ...params);
    }
    if (!data) {
        data = await call();
        fromCache = false;

        await saveCacheCall(cachingTime, callID, data, ...params);
    }
    return { fromCache, data };
}

function getHost() {
    if (typeof window === 'undefined' || window.location.host === Runtime.id) return `joorney://${Runtime.id}`;
    return window.location.host;
}

// Clear host if last change is 12h hours old
async function _checkHostsExpiration(cache, now) {
    let hasChange = false;
    for (const [k, v] of Object.entries(cache)) {
        if (now - (v.lastChange ?? 0) > 12 * 60 * 60 * 1000) {
            delete cache[k];
            hasChange = true;
        }
    }
    return { changed: hasChange, cache: cache };
}

async function saveCacheCall(expireAfterMinute, call, result, ...params) {
    const { cacheEncodingBase64 } = await StorageSync.get({ cacheEncodingBase64: true });
    const hash = jbtoa(JSON.stringify(params), cacheEncodingBase64);
    const host = getHost();

    let cache = await getLocalCache();

    const now = Date.now();

    cache[host] ??= {};
    cache[host][call] ??= {};
    cache[host][call][hash] = {
        date: now,
        dateStr: new Date(now).toISOString(),
        expireAfterMinute: expireAfterMinute ?? 0,
        data: jbtoa(JSON.stringify(result), cacheEncodingBase64),
    };
    cache[host].lastChange = now;

    cache = await _checkHostsExpiration(cache, now);
    await setLocalCache(cache.cache);
}

async function readCacheCall(call, ...params) {
    const { cacheEncodingBase64 } = await StorageSync.get({ cacheEncodingBase64: true });
    const hash = jbtoa(JSON.stringify(params), cacheEncodingBase64);
    const host = getHost();
    let cache = await getLocalCache();
    cache = cache?.[host]?.[call]?.[hash];
    if (!cache) return undefined;
    const { date, expireAfterMinute, data } = cache;

    const now = Date.now();
    if (now - date > expireAfterMinute * 60 * 1000) return undefined;
    const decodeData = jatob(data, cacheEncodingBase64);
    return decodeData ? JSON.parse(decodeData) : undefined;
}

// TODO[IMP] Encryption/Decryption instead of Encoding/Decoding
function jbtoa(str, cacheEncodingBase64) {
    if (!cacheEncodingBase64) return str;
    try {
        return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (_, p1) => String.fromCharCode(`0x${p1}`)));
    } catch (e) {
        Console.error(e);
        return undefined;
    }
}

function jatob(data, cacheEncodingBase64) {
    if (!cacheEncodingBase64) return data;
    try {
        return decodeURIComponent(
            atob(data)
                .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
                .join('')
        );
    } catch (e) {
        Console.error(e);
        return undefined;
    }
}

//#region External Public Odoo API
async function getFutureEventWithName(domainName, host) {
    const { data } = await cache(
        30 * 24 * 60,
        async () => {
            const url = `https://${host}/web/dataset/call_kw/event.event/search_read`;
            const today = toOdooBackendDateGMT0(new Date());
            const payload = {
                method: 'call',
                jsonrpc: '2.0',
                params: {
                    args: [],
                    kwargs: {
                        context: { active_test: true, lang: 'en_US' },
                        domain: [domainName, ['date_end', '>=', today]],
                        limit: 1,
                        fields: ['date_begin', 'date_end', 'name', 'display_name'],
                    },
                    model: 'event.event',
                    method: 'search_read',
                },
            };
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });
            return await response.json();
        },
        'getFutureEventWithName',
        domainName,
        host
    );
    if (!data) return undefined;
    if (data.error) return undefined;
    if (!data.result || data.result.length !== 1) return undefined;
    return data.result[0];
}
//#endregion

// Based on: https://github.com/catdad/canvas-confetti/blob/master/src/confetti.js

const global = globalThis;

class Confetti {
    constructor(canvas = null, globalOpts = { resize: true, disableForReducedMotion: true }) {
        this.cannon = new ConfettiCannon(canvas, globalOpts);
    }

    fire(options) {
        this.cannon.fire(options);
    }

    reset() {
        this.cannon.reset();
    }
}

class ConfettiCannon {
    constructor(canvas, globalOpts) {
        this.isLibCanvas = !canvas;
        this.allowResize = !!prop(globalOpts || {}, 'resize');
        this.disableForReducedMotion = prop(globalOpts, 'disableForReducedMotion', Boolean);
        this.resizer = this.isLibCanvas ? this.setCanvasWindowSize : this.setCanvasRectSize;
        this.initialized = false;
        this.preferLessMotion = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion)').matches;
        this.animationObj = undefined;
        this.canvas = canvas;

        this.animator = new ConfettiAnimator();
    }

    //#region Canvas
    loadCanvas(zIndex) {
        if (this.isLibCanvas && this.animationObj) {
            // use existing canvas from in-progress animation
            this.canvas = this.animationObj.canvas;
        } else if (this.isLibCanvas && !this.canvas) {
            // create and initialize a new canvas
            this.canvas = this.getCanvas(zIndex);
            document.body.appendChild(this.canvas);
        }

        if (this.allowResize && !this.initialized) {
            // initialize the size of a user-supplied canvas
            this.resizer(this.canvas);
        }

        return this.canvas;
    }

    getCanvas(zIndex) {
        const canvas = document.createElement('canvas');

        canvas.style.position = 'fixed';
        canvas.style.top = '0px';
        canvas.style.left = '0px';
        canvas.style.pointerEvents = 'none';
        canvas.style.zIndex = zIndex;

        return canvas;
    }

    setCanvasRectSize(canvas) {
        const rect = canvas.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
    }

    setCanvasWindowSize(canvas) {
        canvas.width = document.documentElement.clientWidth;
        canvas.height = document.documentElement.clientHeight;
    }
    //#endregion

    fire(options) {
        if (this.disableForReducedMotion && this.preferLessMotion) {
            return promise((resolve) => resolve());
        }

        this.loadCanvas(prop(options, 'zIndex', Number));

        const size = {
            width: this.canvas.width,
            height: this.canvas.height,
        };

        this.initialized = true;

        function onResize() {
            // don't actually query the size here, since this
            // can execute frequently and rapidly
            size.width = size.height = null;
        }

        if (this.allowResize) global.addEventListener('resize', onResize, false);

        const fireDone = () => {
            this.animationObj = null;

            if (this.allowResize) global.removeEventListener('resize', onResize);

            if (this.isLibCanvas && this.canvas) {
                document.body.removeChild(this.canvas);
                this.canvas = null;
                this.initialized = false;
            }
        };

        return this.fireLocal(options, size, fireDone);
    }

    reset() {
        if (this.animationObj) this.animationObj.reset();
    }

    fireLocal(options, size, done) {
        const particleCount = prop(options, 'particleCount', onlyPositiveInt);
        const angle = prop(options, 'angle', Number);
        const spread = prop(options, 'spread', Number);
        const startVelocity = prop(options, 'startVelocity', Number);
        const decay = prop(options, 'decay', Number);
        const gravity = prop(options, 'gravity');
        const drift = prop(options, 'drift');
        const colors = prop(options, 'colors', colorsToRgb);
        const ticks = prop(options, 'ticks', Number);
        const shapes = prop(options, 'shapes');
        const scalar = prop(options, 'scalar');
        const flat = !!prop(options, 'flat');
        const origin = getOrigin(options);
        const alpha = getAlpha(options);

        let temp = particleCount;
        const fettis = [];

        const startX = this.canvas.width * origin.x;
        const startY = this.canvas.height * origin.y;

        while (temp--) {
            fettis.push(
                Fetti.randomPhysics({
                    x: startX,
                    y: startY,
                    angle: angle,
                    spread: spread,
                    startVelocity: startVelocity,
                    color:
                        colors.length <= particleCount
                            ? colors[temp % colors.length]
                            : colors[Math.round(randomInRange$1(0, colors.length - 1))],
                    shape: shapes[randomInt(0, shapes.length)],
                    ticks: ticks,
                    decay: decay,
                    gravity: gravity,
                    drift: drift,
                    scalar: scalar,
                    flat: flat,
                    alpha: alpha,
                })
            );
        }

        // if we have a previous canvas already animating, add to it
        if (this.animationObj) return this.animationObj.addFettis(fettis);

        this.animationObj = this.animator.animate(this.canvas, fettis, this.resizer, size, done);
        return this.animationObj.promise;
    }
}

class ConfettiAnimator {
    constructor() {
        this.TIME = Math.floor(1000 / 60);
        this.frames = {};
        this.lastFrameTime = 0;

        if (typeof requestAnimationFrame === 'function' && typeof cancelAnimationFrame === 'function') {
            this.frame = (cb) => this.frameFct(cb);
            this.cancel = (id) => this.cancelFct(id);
        } else {
            this.frame = (cb) => setTimeout(cb, this.TIME);
            this.cancel = (timer) => clearTimeout(timer);
        }
    }

    onFrame(time, id, cb) {
        if (this.lastFrameTime === time || this.lastFrameTime + this.TIME - 1 < time) {
            this.lastFrameTime = time;
            delete this.frames[id];
            cb();
            return;
        }
        this.frames[id] = requestAnimationFrame((time) => this.onFrame(time, id, cb));
    }

    frameFct(cb) {
        const id = Math.random();
        this.frames[id] = requestAnimationFrame((time) => this.onFrame(time, id, cb));
        return id;
    }

    cancelFct(id) {
        if (frames[id]) cancelAnimationFrame(frames[id]);
    }

    animate(canvas, fettis, resizer, size, done) {
        let animatingFettis = fettis.slice();
        const context = canvas.getContext('2d');
        let animationFrame;
        let destroy;

        const self = this;
        function getAnimatePromise() {
            return promise((resolve) => {
                function onDone() {
                    animationFrame = destroy = null;
                    context.clearRect(0, 0, size.width, size.height);

                    done();
                    resolve();
                }

                function update() {
                    if (!size.width && !size.height) {
                        resizer(canvas);
                        size.width = canvas.width;
                        size.height = canvas.height;
                    }

                    context.clearRect(0, 0, size.width, size.height);

                    animatingFettis = animatingFettis.filter((fetti) => fetti.updateFetti(context));

                    if (animatingFettis.length) {
                        animationFrame = self.frame(update);
                    } else {
                        onDone();
                    }
                }

                animationFrame = self.frame(update);
                destroy = onDone;
            });
        }

        const prom = getAnimatePromise();

        return {
            canvas: canvas,
            promise: prom,
            addFettis: (fettis) => {
                animatingFettis = animatingFettis.concat(fettis);
                return prom;
            },
            reset: () => {
                if (animationFrame) this.cancel(animationFrame);
                if (destroy) destroy();
            },
        };
    }
}

class Fetti {
    static randomPhysics(opts) {
        const radAngle = opts.angle * (Math.PI / 180);
        const radSpread = opts.spread * (Math.PI / 180);
        let scalar = opts.scalar;
        if (typeof scalar === 'function') {
            scalar = scalar() ?? 1;
        }
        let gravity = opts.gravity;
        if (typeof gravity === 'function') {
            gravity = gravity() ?? 1;
        }
        let drift = opts.drift;
        if (typeof drift === 'function') {
            drift = drift() ?? 1;
        }

        return new Fetti(
            opts.x,
            opts.y,
            Math.random() * 10,
            Math.min(0.11, Math.random() * 0.1 + 0.05),
            opts.startVelocity * 0.5 + Math.random() * opts.startVelocity,
            -radAngle + (0.5 * radSpread - Math.random() * radSpread),
            (Math.random() * (0.75 - 0.25) + 0.25) * Math.PI,
            opts.color,
            opts.shape,
            0,
            opts.ticks,
            opts.decay,
            drift,
            Math.random() + 2,
            0,
            0,
            0,
            0,
            gravity * 3,
            0.6,
            scalar,
            opts.flat,
            opts.alpha
        );
    }

    constructor(
        x,
        y,
        wobble,
        wobbleSpeed,
        velocity,
        angle2D,
        tiltAngle,
        color,
        shape,
        tick,
        totalTicks,
        decay,
        drift,
        random,
        tiltSin,
        tiltCos,
        wobbleX,
        wobbleY,
        gravity,
        ovalScalar,
        scalar,
        flat,
        alpha
    ) {
        this.x = x;
        this.y = y;
        this.wobble = wobble;
        this.wobbleSpeed = wobbleSpeed;
        this.velocity = velocity;
        this.angle2D = angle2D;
        this.tiltAngle = tiltAngle;
        this.color = color;
        this.shape = shape;
        this.tick = tick;
        this.totalTicks = totalTicks;
        this.decay = decay;
        this.drift = drift;
        this.random = random;
        this.tiltSin = tiltSin;
        this.tiltCos = tiltCos;
        this.wobbleX = wobbleX;
        this.wobbleY = wobbleY;
        this.gravity = gravity;
        this.ovalScalar = ovalScalar;
        this.scalar = scalar;
        this.flat = flat;
        this.alpha = alpha;
    }

    ellipse(context, x, y, radiusX, radiusY, rotation, startAngle, endAngle, antiClockwise) {
        context.save();
        context.translate(x, y);
        context.rotate(rotation);
        context.scale(radiusX, radiusY);
        context.arc(0, 0, 1, startAngle, endAngle, antiClockwise);
        context.restore();
    }

    updateFettiBitmap(context, x1, x2, y1, y2, alpha) {
        const rotation = (Math.PI / 10) * this.wobble;
        const scaleX = Math.abs(x2 - x1) * 0.1;
        const scaleY = Math.abs(y2 - y1) * 0.1;
        const width = this.shape.bitmap.width * this.scalar;
        const height = this.shape.bitmap.height * this.scalar;

        const matrix = new DOMMatrix([
            Math.cos(rotation) * scaleX,
            Math.sin(rotation) * scaleX,
            -Math.sin(rotation) * scaleY,
            Math.cos(rotation) * scaleY,
            this.x,
            this.y,
        ]);

        // apply the transform matrix from the confetti shape
        matrix.multiplySelf(new DOMMatrix(this.shape.matrix));

        const pattern = context.createPattern(this.shape.bitmap, 'no-repeat');
        pattern.setTransform(matrix);

        context.globalAlpha = alpha;
        context.fillStyle = pattern;
        context.fillRect(this.x - width / 2, this.y - height / 2, width, height);
        context.globalAlpha = 1;
    }

    updateFettiCircle(context, x1, x2, y1, y2) {
        context.ellipse
            ? context.ellipse(
                  this.x,
                  this.y,
                  Math.abs(x2 - x1) * this.ovalScalar,
                  Math.abs(y2 - y1) * this.ovalScalar,
                  (Math.PI / 10) * this.wobble,
                  0,
                  2 * Math.PI
              )
            : this.ellipse(
                  context,
                  this.x,
                  this.y,
                  Math.abs(x2 - x1) * this.ovalScalar,
                  Math.abs(y2 - y1) * this.ovalScalar,
                  (Math.PI / 10) * this.wobble,
                  0,
                  2 * Math.PI
              );
    }

    updateFettiStar(context) {
        let rot = (Math.PI / 2) * 3;
        const innerRadius = 4 * this.scalar;
        const outerRadius = 8 * this.scalar;
        let x = this.x;
        let y = this.y;
        let spikes = 5;
        const step = Math.PI / spikes;

        while (spikes--) {
            x = this.x + Math.cos(rot) * outerRadius;
            y = this.y + Math.sin(rot) * outerRadius;
            context.lineTo(x, y);
            rot += step;

            x = this.x + Math.cos(rot) * innerRadius;
            y = this.y + Math.sin(rot) * innerRadius;
            context.lineTo(x, y);
            rot += step;
        }
    }

    updateFetti(context) {
        this.x += Math.cos(this.angle2D) * this.velocity + this.drift;
        this.y += Math.sin(this.angle2D) * this.velocity + this.gravity;
        this.velocity *= this.decay;

        if (this.flat) {
            this.wobble = 0;
            this.wobbleX = this.x + 10 * this.scalar;
            this.wobbleY = this.y + 10 * this.scalar;

            this.tiltSin = 0;
            this.tiltCos = 0;
            this.random = 1;
        } else {
            this.wobble += this.wobbleSpeed;
            this.wobbleX = this.x + 10 * this.scalar * Math.cos(this.wobble);
            this.wobbleY = this.y + 10 * this.scalar * Math.sin(this.wobble);

            this.tiltAngle += 0.1;
            this.tiltSin = Math.sin(this.tiltAngle);
            this.tiltCos = Math.cos(this.tiltAngle);
            this.random = Math.random() + 2;
        }

        const progress = this.tick++ / this.totalTicks;

        const x1 = this.x + this.random * this.tiltCos;
        const y1 = this.y + this.random * this.tiltSin;
        const x2 = this.wobbleX + this.random * this.tiltCos;
        const y2 = this.wobbleY + this.random * this.tiltSin;

        let alpha = 1 - progress;
        if (this.alpha.invert) {
            alpha = progress;
        } else if (this.alpha.double) {
            alpha = progress < 0.5 ? progress / 0.5 : progress > 0.5 ? 1 - (progress / 0.5 - 1) : 1;
        }
        if (this.alpha.max) {
            alpha *= this.alpha.max;
        }

        context.fillStyle = `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${alpha})`;
        context.beginPath();

        if (this.shape.type === 'path' && typeof this.shape.path === 'string' && Array.isArray(this.shape.matrix)) {
            context.fill(
                this.transformPath2D(
                    this.shape.path,
                    this.shape.matrix,
                    this.x,
                    this.y,
                    Math.abs(x2 - x1) * 0.1,
                    Math.abs(y2 - y1) * 0.1,
                    (Math.PI / 10) * this.wobble
                )
            );
        } else if (this.shape.type === 'bitmap') {
            this.updateFettiBitmap(context, x1, x2, y1, y2, alpha);
        } else if (this.shape === 'circle') {
            this.updateFettiCircle(context, x1, x2, y1, y2);
        } else if (this.shape === 'star') {
            this.updateFettiStar(context);
        } else {
            context.moveTo(Math.floor(this.x), Math.floor(this.y));
            context.lineTo(Math.floor(this.wobbleX), Math.floor(y1));
            context.lineTo(Math.floor(x2), Math.floor(y2));
            context.lineTo(Math.floor(x1), Math.floor(this.wobbleY));
        }

        context.closePath();
        context.fill();

        return this.tick < this.totalTicks;
    }

    transformPath2D(pathString, pathMatrix, x, y, scaleX, scaleY, rotation) {
        const path2d = new Path2D(pathString);

        const t1 = new Path2D();
        t1.addPath(path2d, new DOMMatrix(pathMatrix));

        const t2 = new Path2D();
        // see https://developer.mozilla.org/en-US/docs/Web/API/DOMMatrix/DOMMatrix
        t2.addPath(
            t1,
            new DOMMatrix([
                Math.cos(rotation) * scaleX,
                Math.sin(rotation) * scaleX,
                -Math.sin(rotation) * scaleY,
                Math.cos(rotation) * scaleY,
                x,
                y,
            ])
        );

        return t2;
    }
}

//#region Options
const defaults = {
    particleCount: 50,
    angle: 90,
    spread: 45,
    startVelocity: 45,
    decay: 0.9,
    gravity: 1,
    drift: 0,
    ticks: 200,
    x: 0.5,
    y: 0.5,
    shapes: ['square', 'circle'],
    zIndex: 100,
    colors: ['#26ccff', '#a25afd', '#ff5e7e', '#88ff5a', '#fcff42', '#ffa62d', '#ff36ff'],
    // probably should be true, but back-compat
    disableForReducedMotion: false,
    scalar: 1,
};

function getOrigin(options) {
    const origin = prop(options, 'origin', Object);
    origin.x = prop(origin, 'x', Number);
    origin.y = prop(origin, 'y', Number);

    return origin;
}

function getAlpha(options) {
    const alpha = prop(options, 'alpha', Object);
    alpha.max = prop(alpha, 'max', Number);
    alpha.double = prop(alpha, 'double', Boolean);
    alpha.invert = prop(alpha, 'invert', Boolean);

    return alpha;
}

function convert(val, transform) {
    return transform ? transform(val) : val;
}

function isOk(val) {
    return !(val === null || val === undefined);
}

function prop(options, name, transform) {
    return convert(options && isOk(options[name]) ? options[name] : defaults[name], transform);
}
//#endregion

//#region Utils
function promise(func) {
    return new Promise(func);
}

function onlyPositiveInt(number) {
    return number < 0 ? 0 : Math.floor(number);
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function toDecimal(str) {
    return Number.parseInt(str, 16);
}

function colorsToRgb(colors) {
    return colors.map(hexToRgb);
}

function hexToRgb(str) {
    let val = String(str).replace(/[^0-9a-f]/gi, '');

    if (val.length < 6) {
        val = val[0] + val[0] + val[1] + val[1] + val[2] + val[2];
    }

    return {
        r: toDecimal(val.substring(0, 2)),
        g: toDecimal(val.substring(2, 4)),
        b: toDecimal(val.substring(4, 6)),
    };
}

function shapeFromText(textData, flips = { vertical: false, horizontal: false }) {
    let text;
    let scalar = 1;
    let color = '#000000';
    let // see https://nolanlawson.com/2022/04/08/the-struggle-of-using-native-emoji-on-the-web/
        fontFamily =
            '"Twemoji Mozilla", "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "system emoji", sans-serif';

    if (typeof textData === 'string') {
        text = textData;
    } else {
        text = textData.text;
        scalar = 'scalar' in textData ? textData.scalar : scalar;
        fontFamily = 'fontFamily' in textData ? textData.fontFamily : fontFamily;
        color = 'color' in textData ? textData.color : color;
    }

    // all other confetti are 10 pixels,
    // so this pixel size is the de-facto 100% scale confetti
    const fontSize = 10 * scalar;
    const font = `${fontSize}px ${fontFamily}`;

    let canvas = new OffscreenCanvas(1, 1);
    let ctx = canvas.getContext('2d');

    ctx.font = font;
    const size = ctx.measureText(text);
    const width = Math.floor(size.width);
    const height = Math.floor(size.fontBoundingBoxAscent + size.fontBoundingBoxDescent);

    canvas = new OffscreenCanvas(width, height);
    ctx = canvas.getContext('2d');
    ctx.font = font;
    ctx.fillStyle = color;

    ctx.fillText(text, 0, fontSize);

    const scale = 1 / scalar;

    return {
        type: 'bitmap',
        // TODO these probably need to be transfered for workers
        bitmap: canvas.transferToImageBitmap(),
        matrix: [
            scale * (flips?.horizontal ? -1 : 1),
            0,
            0,
            scale * (flips?.vertical ? -1 : 1),
            (-width * scale) / 2,
            (-height * scale) / 2,
        ],
    };
}

//#endregion

function randomInRange$1(min, max) {
    return Math.random() * (max - min) + min;
}

// note: you CAN only use a path for confetti.shapeFrompath(), but for
// performance reasons it is best to use it once in development and save
// the result to avoid the performance penalty at runtime
// https://svg-path-visualizer.netlify.app/

/*
// From bubble emoji: https://images.emojiterra.com/google/noto-emoji/unicode-15.1/color/svg/1fae7.svg
// Large
shapeFromPath(
	'M68.48 46.02C65.29 45.09 65.41 48.52 62.05 53.99C59.81 57.63 55.09 62.36 47.41 64.25C42.89 65.36 40.86 66.31 40.73 67.97C40.5 70.8 44.35 71.56 49.94 70.1C64.76 66.25 75.25 47.99 68.48 46.02Z M34.9902 10.2501C39.3802 11.7601 40.5402 15.6801 39.1902 19.0301C37.9502 22.1101 33.2902 23.5001 30.3702 25.0901C25.9202 27.5001 22.6902 30.6301 20.2802 35.0801C17.9502 39.3801 11.6702 41.1201 10.8102 34.8701C10.1402 29.9801 13.1802 23.0201 16.0302 19.4501C18.5502 16.3001 22.0102 13.4901 25.6302 11.6901C28.1802 10.4301 32.2202 9.30006 34.9902 10.2501Z M55.4199 12.46C57.2199 13.98 57.4299 16.77 54.9399 17.64C53.8299 17.95 52.6699 17.45 51.5199 17.37C49.1799 17.21 48.2099 18.04 46.2099 17.19C43.2299 15.91 41.9999 13.33 43.4199 11.21C44.1199 10.17 45.4499 9.63996 46.6299 9.40996C49.8299 8.78996 53.1699 10.2 55.4199 12.46Z M39.88 79.75C17.89 79.75 0 61.86 0 39.87C0 17.88 17.89 0 39.88 0C61.87 0 79.76 17.89 79.76 39.88C79.76 61.87 61.86 79.75 39.88 79.75ZM40.5 4.22C20.44 4.22 4.13 20.53 4.13 40.59C4.13 60.65 20.45 76.96 40.5 76.96C60.55 76.96 76.87 60.64 76.87 40.59C76.87 20.54 60.55 4.22 40.5 4.22Z'
)
// Medium
shapeFromPath(
	'M40.6301 28.96C38.1901 28.13 38.7701 31.89 33.9501 35.28C28.8101 38.9 25.7001 38.03 25.5201 40.08C25.3301 42.27 30.6801 42.26 36.2501 38.11C41.0801 34.53 43.1001 29.8 40.6301 28.96Z M24.2696 47.52C11.2296 47.52 0.619629 36.91 0.619629 23.87C0.619629 10.83 11.2296 0.219971 24.2696 0.219971C37.3096 0.219971 47.9196 10.83 47.9196 23.87C47.9196 36.91 37.3096 47.52 24.2696 47.52ZM24.8696 3.10997C13.3496 3.10997 3.97963 12.48 3.97963 24C3.97963 35.52 13.3496 44.89 24.8696 44.89C36.3896 44.89 45.7596 35.52 45.7596 24C45.7596 12.48 36.3896 3.10997 24.8696 3.10997Z M19.0198 7.31001C23.4198 7.01001 24.9398 10.15 23.8498 12.64C22.4498 15.84 19.1898 14.7 16.3198 17.81C14.3398 19.96 10.1098 22.29 9.51979 17.54C8.99979 13.34 13.6498 7.68001 19.0198 7.31001Z M31.7194 13C34.3694 12.99 34.6894 10.01 33.2694 8.41996C31.6294 5.96996 26.1394 6.22996 27.4394 10.27C28.0094 12.05 29.0494 13.01 31.7194 13Z'
)
// Small
shapeFromPath(
	'M31.6804 20.37C32.2604 17.3 31.5304 10.85 28.4204 12.91C27.1704 13.74 29.1404 17.29 28.5404 20.34C27.7404 24.43 26.2204 26.57 22.6404 29.12C21.8204 29.7 22.2604 30.78 23.8104 30.22C27.9004 28.75 30.6804 25.71 31.6804 20.37Z M16.5102 6.67002C17.2202 8.15002 14.9602 10.03 14.0802 11.2C11.7902 14.25 12.9802 16.62 11.2702 19.4C9.98017 21.49 5.89016 22.93 5.12016 17.82C4.64016 14.62 6.64016 11 8.00016 9.52002C12.5102 4.62002 15.9202 5.45002 16.5102 6.67002Z M18.37 36.74C8.24 36.74 0 28.5 0 18.37C0 8.24 8.24 0 18.37 0C28.5 0 36.74 8.24 36.74 18.37C36.74 28.5 28.49 36.74 18.37 36.74ZM18.02 2.6C9.32 2.6 2.24001 9.68 2.24001 18.38C2.24001 27.08 9.32 34.16 18.02 34.16C26.72 34.16 33.8 27.08 33.8 18.38C33.8 9.68 26.73 2.6 18.02 2.6Z'
)
*/
const bubbles = {
    large: {
        type: 'path',
        path: 'M68.48 46.02C65.29 45.09 65.41 48.52 62.05 53.99C59.81 57.63 55.09 62.36 47.41 64.25C42.89 65.36 40.86 66.31 40.73 67.97C40.5 70.8 44.35 71.56 49.94 70.1C64.76 66.25 75.25 47.99 68.48 46.02Z M34.9902 10.2501C39.3802 11.7601 40.5402 15.6801 39.1902 19.0301C37.9502 22.1101 33.2902 23.5001 30.3702 25.0901C25.9202 27.5001 22.6902 30.6301 20.2802 35.0801C17.9502 39.3801 11.6702 41.1201 10.8102 34.8701C10.1402 29.9801 13.1802 23.0201 16.0302 19.4501C18.5502 16.3001 22.0102 13.4901 25.6302 11.6901C28.1802 10.4301 32.2202 9.30006 34.9902 10.2501Z M55.4199 12.46C57.2199 13.98 57.4299 16.77 54.9399 17.64C53.8299 17.95 52.6699 17.45 51.5199 17.37C49.1799 17.21 48.2099 18.04 46.2099 17.19C43.2299 15.91 41.9999 13.33 43.4199 11.21C44.1199 10.17 45.4499 9.63996 46.6299 9.40996C49.8299 8.78996 53.1699 10.2 55.4199 12.46Z M39.88 79.75C17.89 79.75 0 61.86 0 39.87C0 17.88 17.89 0 39.88 0C61.87 0 79.76 17.89 79.76 39.88C79.76 61.87 61.86 79.75 39.88 79.75ZM40.5 4.22C20.44 4.22 4.13 20.53 4.13 40.59C4.13 60.65 20.45 76.96 40.5 76.96C60.55 76.96 76.87 60.64 76.87 40.59C76.87 20.54 60.55 4.22 40.5 4.22Z',
        matrix: [0.1282051282051282, 0, 0, 0.1282051282051282, -5, -5.128205128205128],
    },
    medium: {
        type: 'path',
        path: 'M40.6301 28.96C38.1901 28.13 38.7701 31.89 33.9501 35.28C28.8101 38.9 25.7001 38.03 25.5201 40.08C25.3301 42.27 30.6801 42.26 36.2501 38.11C41.0801 34.53 43.1001 29.8 40.6301 28.96Z M24.2696 47.52C11.2296 47.52 0.619629 36.91 0.619629 23.87C0.619629 10.83 11.2296 0.219971 24.2696 0.219971C37.3096 0.219971 47.9196 10.83 47.9196 23.87C47.9196 36.91 37.3096 47.52 24.2696 47.52ZM24.8696 3.10997C13.3496 3.10997 3.97963 12.48 3.97963 24C3.97963 35.52 13.3496 44.89 24.8696 44.89C36.3896 44.89 45.7596 35.52 45.7596 24C45.7596 12.48 36.3896 3.10997 24.8696 3.10997Z M19.0198 7.31001C23.4198 7.01001 24.9398 10.15 23.8498 12.64C22.4498 15.84 19.1898 14.7 16.3198 17.81C14.3398 19.96 10.1098 22.29 9.51979 17.54C8.99979 13.34 13.6498 7.68001 19.0198 7.31001Z M31.7194 13C34.3694 12.99 34.6894 10.01 33.2694 8.41996C31.6294 5.96996 26.1394 6.22996 27.4394 10.27C28.0094 12.05 29.0494 13.01 31.7194 13Z',
        matrix: [0.22727272727272727, 0, 0, 0.22727272727272727, -5.454545454545454, -5.454545454545454],
    },
    small: {
        type: 'path',
        path: 'M31.6804 20.37C32.2604 17.3 31.5304 10.85 28.4204 12.91C27.1704 13.74 29.1404 17.29 28.5404 20.34C27.7404 24.43 26.2204 26.57 22.6404 29.12C21.8204 29.7 22.2604 30.78 23.8104 30.22C27.9004 28.75 30.6804 25.71 31.6804 20.37Z M16.5102 6.67002C17.2202 8.15002 14.9602 10.03 14.0802 11.2C11.7902 14.25 12.9802 16.62 11.2702 19.4C9.98017 21.49 5.89016 22.93 5.12016 17.82C4.64016 14.62 6.64016 11 8.00016 9.52002C12.5102 4.62002 15.9202 5.45002 16.5102 6.67002Z M18.37 36.74C8.24 36.74 0 28.5 0 18.37C0 8.24 8.24 0 18.37 0C28.5 0 36.74 8.24 36.74 18.37C36.74 28.5 28.49 36.74 18.37 36.74ZM18.02 2.6C9.32 2.6 2.24001 9.68 2.24001 18.38C2.24001 27.08 9.32 34.16 18.02 34.16C26.72 34.16 33.8 27.08 33.8 18.38C33.8 9.68 26.73 2.6 18.02 2.6Z',
        matrix: [0.29411764705882354, 0, 0, 0.29411764705882354, -5.588235294117648, -5.588235294117648],
    },
};

//#region Abstract Loader
const lockedState = ['circle', 'square', 'star'];
const emojisLoader = ({
    emojis,
    alpha,
    size,
    gravity,
    drift,
    xRange,
    yRange,
    color = '#ffffff',
    flat = true,
    flipHorizontal = false,
    flipVertical = false,
}) => {
    const emojisBitmap = emojis.map((emoji) =>
        lockedState.includes(emoji)
            ? emoji
            : shapeFromText(
                  { text: emoji, scalar: size?.max ?? 1, color: color },
                  { vertical: flipVertical, horizontal: flipHorizontal }
              )
    );

    return shapesLoader({
        shapes: emojisBitmap,
        alpha,
        size,
        gravity,
        drift,
        xRange,
        yRange,
        colors: [color],
        flat,
    });
};

const shapesLoader = ({
    shapes,
    alpha = { max: 1, double: true },
    size = { min: 1, max: 1, dynamic: false },
    gravity = { min: 0.4, max: 0.6, dynamic: false },
    drift = { min: -0.4, max: 0.4, dynamic: false },
    xRange = { min: 0, max: 1 },
    yRange = { min: 0, max: 1 }, // Top = 0, Bottom = 1
    colors = ['#ffffff'],
    flat = true,
}) => {
    const scalarComputed = size.dynamic ? () => Math.round(randomInRange(size.min, size.max)) : size.max;
    const gravityComputed = gravity.dynamic ? () => randomInRange(gravity.min, gravity.max) : gravity.max;
    const driftComputed = drift.dynamic ? () => randomInRange(drift.min, drift.max) : drift.max;

    return (ticks) => ({
        flat,
        particleCount: 1,
        startVelocity: 0,
        ticks,
        origin: {
            x: randomInRange(xRange.min, xRange.max),
            y: randomInRange(yRange.min, yRange.max),
        },
        colors,
        shapes,
        gravity: gravityComputed,
        scalar: scalarComputed,
        drift: driftComputed,
        alpha,
    });
};

const fireworkLoader = (colors, mixColor, smallAndLarge, doubleBurst) => {
    return (_ticks) => {
        const loads = [
            {
                startVelocity: 30,
                spread: 360,
                ticks: 60,
                zIndex: 0,
                particleCount: 50,
                origin: { x: randomInRange(0.1, 0.5), y: Math.random() - 0.2 },
                colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
            },
            {
                startVelocity: 30,
                spread: 360,
                ticks: 60,
                zIndex: 0,
                particleCount: 50,
                origin: { x: randomInRange(0.5, 0.9), y: Math.random() - 0.2 },
                colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
            },
        ];
        if (smallAndLarge) {
            loads.concat(
                loads.map((l) => {
                    l.particleCount *= 2;
                    return l;
                })
            );
        }

        const firework = loads[Math.round(randomInRange(0, loads.length - 1))];
        if (doubleBurst) {
            const fireworkInside = {
                ...firework,
                startVelocity: 15,
                colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
            };
            return [firework, fireworkInside];
        }
        return firework;
    };
};
const schoolPrideLoader = (colors) => {
    return (_ticks) => {
        return [
            {
                particleCount: 2,
                angle: 60,
                spread: 55,
                origin: { x: 0 },
                colors: colors,
            },
            {
                particleCount: 2,
                angle: 120,
                spread: 55,
                origin: { x: 1 },
                colors: colors,
            },
        ];
    };
};
const floatingLoader = (emojis) => {
    return emojisLoader({
        emojis: emojis,
        alpha: { max: 0.2, double: true },
        size: { min: 8, max: 20, dynamic: true },
        gravity: { min: -0.6, max: -0.4, dynamic: true },
        drift: { min: -0.4, max: 0.4, dynamic: true },
        yRange: { min: 0.5, max: 1 },
    });
};
//#endregion

function estimateAmbientDuration(ambient) {
    if (!ambient) return 1000;
    switch (ambient.type) {
        case 'long':
            return ambient.duration;
        case 'count':
            return ambient.count * ambient.delay;
        case 'onetime':
            return 1;
    }
    return 0;
}

const ambients = {
    compute: {
        name: 'Computed Events',
        ambients: [
            {
                name: `Odoo Experience ${new Date().getFullYear()}`,
                id: 'odoo-experience-oxp-cpt',
                computeDates: async () => {
                    return await getOdooEventDate(['name', '=', `Odoo Experience ${new Date().getFullYear()}`]);
                },
                type: 'long',
                duration: 3000,
                load: schoolPrideLoader(['#FBB130', '#714b67', '#050a30']),
            },
            {
                name: 'Future Community Days',
                id: 'odoo-community-days-cpt',
                computeDates: async () => {
                    return await getOdooEventDate(['name', '=like', '%Community Days%']);
                },
                type: 'long',
                duration: 3000,
                load: schoolPrideLoader(['#714B67', '#FFFFFF', '#017E84']),
            },
        ],
    },
    event: {
        name: 'Events',
        ambients: [
            // {
            //     name: 'Developer Test',
            //     id: 'joorney-test-ambient-evt',
            //     date: new Date().toISOString(),
            //     type: 'count',
            //     count: 20,
            //     delay: 250,
            //     load: fireworkLoader(['#FFFFFF', '#000000'], true, false, false),
            // },
            {
                name: 'Happy Birthday Odoo!',
                id: 'odoo-birthday-evt',
                // date: '2005-02-22T12:00:00Z', // TinyERP
                // date: '2009-04-14T12:00:00Z', // OpenERP
                date: '2014-05-15T12:00:00Z',
                type: 'count',
                count: 20,
                delay: 250,
                load: fireworkLoader(['#E46E78', '#21B799', '#5B899E', '#E4A900'], true, false, false),
            },
            {
                name: 'New Year, Countdown',
                id: 'new-year-evt',
                date_from: `${new Date().getFullYear()}-12-31T23:59:30`,
                date_to: `${new Date().getFullYear() + 1}-01-01T00:00:30`,
                type: 'count',
                count: 480,
                delay: 250,
                load: fireworkLoader(
                    [
                        // Palette 1
                        '#C63347',
                        '#F28E63',
                        '#FC7F81',
                        '#FAEFC4',
                        '#F9AE9B',
                        '#792BB2',
                        '#2E42CB',
                        '#F75781',
                        '#E365E4',
                        '#FA5348',
                        // Palette 2
                        '#FFD07E',
                        '#FA9B49',
                        '#90CA80',
                        '#62ABCC',
                        '#7984DE',
                        '#DE6C90',
                    ],
                    false,
                    true,
                    true
                ),
            },
        ],
    },
    yearly: {
        name: 'Every year, one day',
        ambients: [
            {
                name: 'New Year',
                id: 'new-year-yly',
                day: 1,
                month: 1,
                type: 'long',
                duration: 10000,
                load: schoolPrideLoader(['#BF7218', '#FADE98', '#F1A738', '#f9eb82', '#180D1C', '#514414']),
            },
            {
                name: "Valentine's Day",
                id: 'valentine-yly',
                day: 14,
                month: 2,
                type: 'count',
                count: 30,
                delay: 1000,
                load: floatingLoader(['♥️', '🌹']),
            },
            {
                name: "Lucky Day (St. Patrick's)",
                id: 'patrick-yly',
                day: 17,
                month: 3,
                type: 'onetime',
                load: (_ticks) => {
                    const emojisBitmap = ['🍻', '🪙', '🍀', '🌈'].map((emoji) =>
                        shapeFromText({ text: emoji, scalar: 4 })
                    );
                    return [
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 26,
                            startVelocity: 55,
                            particleCount: 50,
                            scalar: 2,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 60,
                            particleCount: 40,
                            scalar: 2,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 100,
                            decay: 0.91,
                            scalar: 1.6,
                            particleCount: 70,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 120,
                            startVelocity: 25,
                            decay: 0.92,
                            scalar: 2.4,
                            particleCount: 20,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 120,
                            scalar: 2,
                            startVelocity: 45,
                            particleCount: 20,
                        },
                    ];
                },
            },
            {
                name: "April Fool's",
                id: 'aprilfool-yly',
                day: 1,
                month: 4,
                type: 'count',
                count: 15,
                delay: 1000,
                load: (ticks) => {
                    const left = emojisLoader({
                        emojis: ['🐟', '🐠', '🐡'],
                        alpha: { max: 0.5, double: true },
                        size: { min: 4, max: 10, dynamic: true },
                        gravity: { min: -0.1, max: 0.1, dynamic: true },
                        drift: { min: -1, max: -0.3, dynamic: true },
                    })(ticks);
                    const right = emojisLoader({
                        emojis: ['🐟', '🐠', '🐡'],
                        alpha: { max: 0.5, double: true },
                        size: { min: 4, max: 10, dynamic: true },
                        gravity: { min: -0.1, max: 0.1, dynamic: true },
                        drift: { min: 0.3, max: 1, dynamic: true },
                        flipHorizontal: true,
                    })(ticks);
                    const bubble = shapesLoader({
                        shapes: [bubbles.large, bubbles.medium, bubbles.small],
                        alpha: { max: 0.2, double: true },
                        size: { min: 2, max: 5, dynamic: true },
                        gravity: { min: -0.4, max: -0.2, dynamic: true },
                        drift: { min: -0.4, max: 0.4, dynamic: true },
                        yRange: { min: 0.5, max: 1 },
                        colors: ['#89cff0', 'e7feff', '#a1caf1', '#39a78e'],
                    })(ticks);
                    return [left, right, bubble];
                },
            },
            {
                name: 'Halloween Night',
                id: 'halloween-yly',
                day: 31,
                month: 10,
                type: 'count',
                count: 30,
                delay: 1000,
                load: floatingLoader(['🎃']),
            },
            {
                name: "New Year's Eve",
                id: 'new-year-eve-yly',
                day: 31,
                month: 12,
                type: 'count',
                count: 30,
                delay: 1000,
                load: floatingLoader(['🥂']),
            },
        ],
    },
    // season: {
    //     winter: {},
    //     spring: {},
    //     summer: {},
    //     fall: {},
    // },
    // weather: {
    //     rain: {},
    //     snow: {},
    //     sun: {},
    // },
};

// Utils
function randomInRange(min, max) {
    return Math.random() * (max - min) + min;
}

async function getOdooEventDate(domainName) {
    const event = await getFutureEventWithName(domainName, 'www.odoo.com');
    if (!event) return undefined;

    return {
        event_name: event.display_name,
        event_date_from: yyyymmdd_hhmmssToDate(event.date_begin),
        event_date_to: yyyymmdd_hhmmssToDate(event.date_end),
    };
}

//#region SEASON
// export const fallSeasonLoader = emojisLoader({
//     emojis: ['🍂'],
//     alpha: { max: 0.5 },
//     size: { min: 1, max: 2, dynamic: true },
//     gravity: { min: 0.4, max: 0.9, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.75 },
//     flat: false,
// });

// export const winterSeasonLoader = emojisLoader({
//     emojis: ['❄️', 'circle'],
//     alpha: { max: 1 },
//     size: { min: 0.4, max: 1, dynamic: true },
//     gravity: { min: 0.4, max: 0.6, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.5 },
//     color: '#ffffff',
//     flat: false,
// });

// export const summerSeasonLoader = emojisLoader({
//     emojis: ['☀️'],
//     alpha: { max: 0.5 },
//     size: { min: 1, max: 2, dynamic: true },
//     gravity: { min: 0.4, max: 0.9, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.75 },
//     flat: false,
// });

// export const springSeasonLoader = emojisLoader({
//     emojis: ['🌸'],
//     alpha: { max: 1 },
//     size: { min: 0.4, max: 1, dynamic: true },
//     gravity: { min: 0.4, max: 0.6, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.5 },
//     color: '#ffffff',
//     flat: false,
// });
//#endregion

//#region WEATHER
// export const rainWeatherLoader = emojisLoader({
//     emojis: ['💧'],
//     alpha: { max: 1 },
//     size: { min: 0.1, max: 0.6, dynamic: true },
//     gravity: { min: 4, max: 5, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: -0.1, max: 0 },
//     color: '#4a6583',
//     flat: true,
// });

// export const snowWeatherLoader = emojisLoader({
//     emojis: ['circle'],
//     alpha: { max: 1 },
//     size: { min: 0.1, max: 0.6, dynamic: true },
//     gravity: { min: 0.4, max: 0.6, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: -0.1, max: 0.5 },
//     color: '#ffffff',
//     flat: false,
// });
//#endregion

class AmbientLoader {
    constructor(ambientConfetti) {
        this.ambientConfetti = ambientConfetti;
        this.stopped = true;
    }

    async stop(delay) {
        this.stopped = true;
        await this.ambientConfetti.reset();
        await new Promise((r) => setTimeout(r, delay + 10));
    }

    async load(ambientData) {
        if (!ambientData) return;
        switch (ambientData.type) {
            case 'long':
                this.loadAmbient(ambientData.load, ambientData.duration);
                break;
            case 'count':
                this.loadAmbientCount(ambientData.load, ambientData.count, ambientData.delay);
                break;
            case 'onetime':
                this.loadOneTimeAmbient(ambientData.load);
                break;
        }
    }

    async loadAmbientCount(ambientLoader, count, delay) {
        await this.stop(0);
        this.stopped = false;
        this.loadAmbient(ambientLoader, count * delay, count);
    }

    async loadOneTimeAmbient(ambientLoader) {
        await this.stop(0);
        this.stopped = false;
        const ambients = await ambientLoader();
        this.playAmbients(ambients);
    }

    async loadAmbient(
        ambientLoader,
        duration,
        countArg = undefined,
        animationStartArg = Date.now(),
        animationEnd = animationStartArg + duration,
        delay = countArg ? duration / Number.parseFloat(countArg) : 1
    ) {
        await this.stop(delay);
        this.stopped = false;
        this._loadAmbient(ambientLoader, duration, countArg, animationStartArg, animationEnd, delay);
    }

    async _loadAmbient(ambientLoader, duration, countArg, animationStartArg, animationEnd, delay) {
        const now = Date.now();
        const timeLeft = animationEnd - now;
        const ticks = Math.max(200, 500 * (timeLeft / duration));
        const ambients = await ambientLoader(ticks);

        let count = countArg;
        let animationStart = animationStartArg;

        if (count) {
            const ellapsed = now - animationStart;

            if (ellapsed >= delay) {
                this.playAmbients(ambients);
                count--;
                animationStart = now;
            }
        } else if (count === undefined) {
            this.playAmbients(ambients);
        }

        if (timeLeft > 0 && !this.stopped) {
            requestAnimationFrame(() =>
                this._loadAmbient(ambientLoader, duration, count, animationStart, animationEnd, delay)
            );
        }
    }

    playAmbients(ambientsArg) {
        const ambients = Array.isArray(ambientsArg) ? ambientsArg : [ambientsArg];
        for (const ambient of ambients) {
            this.ambientConfetti.fire(ambient);
        }
    }
}

class AmbientManager {
    static async computeEvents() {
        const ambient_dates = {};

        for (const c of ambients.compute.ambients) {
            const dates = await c.computeDates();
            if (!dates) continue;
            ambient_dates[c.id] = {
                date_from: dates.event_date_from,
                date_to: dates.event_date_to,
                name: dates.event_name,
            };
        }

        await setAmbientDates(ambient_dates);
    }

    async getAmbientForDate(date) {
        let ambient = undefined;
        const { ambientStatus } = await StorageSync.get({ ambientStatus: {} });

        if (!ambient) ambient = await this.getComputedEventForDate(date);
        if (!ambient) ambient = this.getEventAmbientForDate(date);
        if (!ambient) ambient = this.getYearlyAmbientForDate(date);
        if (!ambient) ambient = this.getSeasonAmbientForDate(date);
        if (!ambient) ambient = await this.getWeatherAmbientForDate(date);

        if (ambient && this.isEnable(ambientStatus, ambient.id)) return ambient;
        return false;
    }

    getEventForDate(date, events) {
        let from = undefined;
        let to = undefined;

        for (const event of events) {
            if (event.date_from && event.date_to) {
                from = new Date(event.date_from);
                to = new Date(event.date_to);
                if (this.isDateBetween(date, from, to)) return event;
                continue;
            }
            if (event.date) {
                from = new Date(event.date);
                if (this.isSameDay(date, from)) return event;
            }
        }

        return undefined;
    }

    getEventAmbientForDate(date) {
        const activeAmbients = ambients.event.ambients;
        return this.getEventForDate(date, activeAmbients);
    }

    async getComputedEventForDate(date) {
        const computes = ambients.compute.ambients;
        const ambient_dates = await getAmbientDates();
        for (const c of computes) {
            const dates = ambient_dates[c.id];
            if (dates) Object.assign(c, dates);
        }
        return this.getEventForDate(date, computes);
    }

    getYearlyAmbientForDate(date) {
        const mm = date.getMonth() + 1; // Months start at 0!
        const dd = date.getDate();

        return ambients.yearly.ambients.find((a) => a.day === dd && a.month === mm);
    }

    getSeasonAmbientForDate(_date) {
        return undefined;
    }

    async getWeatherAmbientForDate(_date) {
        return undefined;
    }

    isDateBetween(targetDate, startDate, endDate) {
        return targetDate >= startDate && targetDate <= endDate;
    }

    isSameDay(date1, date2) {
        // return date1.toDateString() === date2.toDateString();
        return (
            date1.getFullYear() === date2.getFullYear() &&
            date1.getMonth() === date2.getMonth() &&
            date1.getDate() === date2.getDate()
        );
    }

    isEnable(ambientStatus, ambientName) {
        if (Object.keys(ambientStatus).includes(ambientName)) return ambientStatus[ambientName];
        return true;
    }
}

function stringToHTML(str) {
    const template = document.createElement('template');
    template.innerHTML = str.trim();
    return template.content.firstChild;
}

function setCancellableTimeout(callback, ms) {
    const timeoutID = setTimeout(callback, ms);
    return {
        clear: () => clearTimeout(timeoutID),
        trigger: () => {
            clearTimeout(timeoutID);
            callback();
        },
    };
}

let ambientConfetti = undefined;
let ambientManager = undefined;
let ambientLoader = undefined;
const ambientsData = {};

async function loadPage(_features, _currentSettings) {
    setupSlider();

    const canva = document.getElementById('previewAmbient');
    ambientConfetti = new Confetti(canva);
    ambientManager = new AmbientManager(ambientConfetti);
    ambientLoader = new AmbientLoader(ambientConfetti);

    loadAmbientList();
}

async function loadAmbientList() {
    const container = document.getElementById('joorney-ambient-list');
    container.innerHTML = '';

    const ambient_dates = await getAmbientDates();
    const todayAmbient = await ambientManager.getAmbientForDate(new Date());

    for (const [id, category] of Object.entries(ambients)) {
        container.appendChild(
            stringToHTML(`
            <div class="d-flex justify-content-between bg-body-tertiary p-2 border-bottom" data-ambient-category-id="${id}">
                <h6 class="m-0"><span class="ambient-category-toggle me-1 opacity-25" style="cursor: pointer;"><i class="fa-fw fa-solid fa-chevron-down"></i></span>${category.name}</h6>
                <p class="m-0">
                    <small class="text-decoration-underline ambient-category-all-toggle" style="cursor: pointer;">All</small>
                    &nbsp;/&nbsp;
                    <small class="text-decoration-underline ambient-category-none-toggle" style="cursor: pointer;">None</small>
                </p>
            </div>
            `)
        );

        for (const v of category.ambients) {
            ambientsData[v.id] = v;

            let name = v.name;
            let description = '';
            if (v.date) {
                description = toLocaleDateStringFormatted(new Date(v.date));
            } else if (v.date_from && v.date_to) {
                const from = new Date(v.date_from);
                const to = new Date(v.date_to);
                description = `${toLocaleDateTimeStringFormatted(from)} - ${toLocaleDateTimeStringFormatted(to)}`;
            } else if (v.month && v.day) {
                const d = new Date();
                d.setMonth(v.month - 1);
                d.setDate(v.day);
                description = toLocaleDateStringFormatted(d);
            } else if (ambient_dates[v.id]) {
                const from = new Date(ambient_dates[v.id].date_from);
                const to = new Date(ambient_dates[v.id].date_to);
                name = ambient_dates[v.id].name;
                description = `${toLocaleDateTimeStringFormatted(from)} - ${toLocaleDateTimeStringFormatted(to)}`;
            }

            container.appendChild(
                stringToHTML(`
                <li class="list-collapsible show list-group-item d-flex justify-content-between align-items-center" data-ambient-id="${v.id}" title='${createTitleFromJSON(v)}'>
                    <div class="d-flex align-items-center">
                        <button class="joorney-play-ambient btn me-3"><i class="fa-fw fa-solid fa-play"></i></button>
                        <label class="form-check-label">
                            <p class="m-0" >${name}${todayAmbient?.id === v.id ? ' <span title="This effect is currently active for today" class="badge badge-success rounded-pill">active</span>' : ''}</p>
                            ${description ? `<span class="small text-muted">${description}</span>` : ''}
                        </label>
                    </div>
                    <!--<span class="badge rounded-pill badge-success">Active</span>-->
                    <div class="vc-toggle-container">
                        <label class="vc-switch" style="--vc-width: 75px;">
                            <input type="checkbox" class="vc-switch-input" checked />
                            <span class="vc-switch-label" data-on="Enable" data-off="Disable"></span>
                            <span class="vc-handle"></span>
                        </label>
                    </div>
                </li>
            `)
            );
        }
    }

    for (const el of container.getElementsByClassName('joorney-play-ambient')) {
        el.onclick = playAmbient;
    }
    for (const el of container.getElementsByClassName('ambient-category-all-toggle')) {
        el.onclick = (e) => onSwitchCategory(e, true);
    }
    for (const el of container.getElementsByClassName('ambient-category-none-toggle')) {
        el.onclick = (e) => onSwitchCategory(e, false);
    }
    for (const header of container.getElementsByClassName('ambient-category-toggle')) {
        const icon = header.querySelector('i');
        icon.style.transition = 'transform .25s';
        header.onclick = () => {
            icon.style.transform = icon.style.transform === '' ? 'rotate(-90deg)' : '';

            let sibling = header.parentElement.parentElement.nextElementSibling;
            while (sibling && sibling.tagName.toLowerCase() !== 'div') {
                if (sibling.tagName.toLowerCase() === 'li') {
                    sibling.classList.toggle('show');
                }
                sibling = sibling.nextElementSibling;
            }
        };
    }

    const { ambientStatus } = await StorageSync.get({ ambientStatus: {} });
    updateAmbientState(ambientStatus);
}

function updateAmbientState(ambientStatus) {
    const container = document.getElementById('joorney-ambient-list');
    for (const el of container.getElementsByClassName('vc-switch-input')) {
        const dataElement = el.parentElement.parentElement.parentElement;
        const ambientId = dataElement.dataset.ambientId;
        el.checked = ambientStatus[ambientId] ?? true;
        el.onchange = onSwitch;
    }
}

async function onSwitchCategory(event, enable) {
    const dataElement = event.currentTarget.parentElement.parentElement;
    const ambientsList = ambients[dataElement.dataset.ambientCategoryId].ambients ?? [];
    if (!ambientsList || ambientsList.lenght <= 0) return;

    const { ambientStatus } = await StorageSync.get({ ambientStatus: {} });
    for (const a of ambientsList) {
        ambientStatus[a.id] = enable;
    }
    await StorageSync.set({ ambientStatus });
    updateAmbientState(ambientStatus);
}

async function onSwitch(event) {
    const input = event.currentTarget;
    const dataElement = input.parentElement.parentElement.parentElement;
    const { ambientStatus } = await StorageSync.get({ ambientStatus: {} });
    ambientStatus[dataElement.dataset.ambientId] = input.checked;
    await StorageSync.set({ ambientStatus });
}

function playAmbient(event) {
    disableAllButtons();

    const button = event.currentTarget;
    const dataElement = button.parentElement.parentElement;
    const ambient = ambientsData[dataElement.dataset.ambientId];
    if (!ambient) {
        enableAllButtons();
        return;
    }
    const estimatedDuration = estimateAmbientDuration(ambient);

    document.getElementById('joorney-playing-ambient-info').innerText =
        `Ambient: "${ambient.name}" - Duration: ${estimatedDuration}ms`;

    ambientLoader?.load(ambient);
    const timeout = setCancellableTimeout(() => {
        stopAmbient();
    }, estimatedDuration + 1000);

    const iconClass = button.querySelector('i').classList;
    iconClass.remove('fa-pause');
    iconClass.add('fa-stop');
    button.onclick = () => {
        timeout.trigger();
    };

    button.removeAttribute('disabled');
}

function stopAmbient() {
    ambientLoader.stop();
    document.getElementById('joorney-playing-ambient-info').innerText = '';
    enableAllButtons();
}

function disableAllButtons() {
    for (const btn of document.getElementsByClassName('joorney-play-ambient')) {
        btn.onclick = null;
        btn.setAttribute('disabled', true);
        const iconClass = btn.querySelector('i').classList;
        iconClass.add('fa-pause');
        iconClass.remove('fa-play');
        iconClass.remove('fa-stop');
    }
}

function enableAllButtons() {
    for (const btn of document.getElementsByClassName('joorney-play-ambient')) {
        btn.onclick = playAmbient;
        btn.removeAttribute('disabled');
        const iconClass = btn.querySelector('i').classList;
        iconClass.add('fa-play');
        iconClass.remove('fa-pause');
        iconClass.remove('fa-stop');
    }
}

function setupSlider() {
    const slider = document.querySelector('.images-comparison .slider');
    const leftImageElement = document.querySelector('.images-comparison .left-image');
    const sliderLineElement = document.querySelector('.images-comparison .slider-line');
    const sliderIconElement = document.querySelector('.images-comparison .slider-icon');

    slider.addEventListener('input', (e) => {
        const sliderValue = `${e.target.value}%`;

        leftImageElement.style.width = sliderValue;
        sliderLineElement.style.left = sliderValue;
        sliderIconElement.style.left = sliderValue;
    });
}

export { loadPage };
