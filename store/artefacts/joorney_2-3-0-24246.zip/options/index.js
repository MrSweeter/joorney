var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringTaskEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var pinMessage = true;
var ambient = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringTaskEffect: starringTaskEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus,
	pinMessage: pinMessage,
	ambient: ambient
};

function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
const Tabs = isFirefox() ? browser.tabs : chrome.tabs;
isFirefox() ? browser.contextMenus : chrome.contextMenus;
const Runtime = isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
const StorageLocal = isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
isFirefox() ? browser.webNavigation : chrome.webNavigation;
isFirefox() ? browser.cookies : chrome.cookies;
isFirefox() ? browser.action : chrome.action;
isFirefox() ? browser.commands : chrome.commands;
isFirefox() ? browser.windows : chrome.windows;
const Management = isFirefox() ? browser.management : chrome.management;
isFirefox() ? browser.omnibox : chrome.omnibox;
isFirefox() ? browser.webRequest : chrome.webRequest;

async function sendRuntimeMessage(action, message = {}) {
    try {
        return await Runtime.sendMessage({ action: action, ...message });
    } catch (err) {
        Console.trace('catch runtime', err);
    }
}

const Console = {
    info(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
    },
    log(obj) {
        console.log(obj);
    },
    error(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
    },
    warn(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
    },
    success(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
    },
    trace(label, obj) {
        console.trace(label, obj);
    },
    critical(obj) {
        console.error(obj);
    },

    _getFormatOperator(obj) {
        switch (typeof obj) {
            case 'string':
                return '%s';
            case 'number':
                return '%s';
            case 'object':
                return '%O';
            default:
                return '%s';
        }
    },
};

async function getUserLocation() {
    return await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
            (loc) => resolve(loc.coords),
            (error) => reject(error)
        );
    });
}

function createTitleFromJSON(obj) {
    return escapeForHTMLTitle(JSON.stringify(obj));
}

function escapeForHTMLTitle(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
        .replace(/\n/g, '&#10;');
}

const MESSAGE_ACTION = {
    TO_BACKGROUND: {
        GET_FEATURES_LIST: 'GET_FEATURES_LIST',
        GET_FINAL_RUNBOT_URL: 'GET_FINAL_RUNBOT_URL',
        UPDATE_EXT_STATUS: 'UPDATE_EXT_STATUS',
        TRIGGER_FEATURE: 'TRIGGER_FEATURE',
        RECREATE_MENU: 'RECREATE_MENU',
        TAB_LOADED: 'TAB_LOADED',
    },
    TO_CONTENT: {
        TAB_NAVIGATION: 'TAB_NAVIGATION',
        POPUP_HAS_CHANGE: 'POPU¨_HAS_CHANGE',
        REQUEST_ODOO_INFO: 'REQUEST_ODOO_INFO',
        CM_OPEN_MENU: 'CM_OPEN_MENU',
        CM_OPEN_RUNBOT: 'CM_OPEN_RUNBOT',
        WEB_REQUEST_COMPLETE: 'WEB_REQUEST_COMPLETE',
    },
};

function __variableDynamicImportRuntime5__(path) {
  switch (path) {
    case './src/features/awesomeLoadingLarge/option_customization.js': return Promise.resolve().then(function () { return option_customization$5; });
    case './src/features/awesomeLoadingSmall/option_customization.js': return Promise.resolve().then(function () { return option_customization$4; });
    case './src/features/awesomeStyle/option_customization.js': return Promise.resolve().then(function () { return option_customization$3; });
    case './src/features/contextOdooMenus/option_customization.js': return Promise.resolve().then(function () { return option_customization$2; });
    case './src/features/themeSwitch/option_customization.js': return Promise.resolve().then(function () { return option_customization$1; });
    case './src/features/unfocusApp/option_customization.js': return Promise.resolve().then(function () { return option_customization; });
    default: return new Promise(function(resolve, reject) {
      (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
        reject.bind(null, new Error("Unknown variable dynamic import: " + path))
      );
    })
   }
 }

function __variableDynamicImportRuntime4__(path) {
  switch (path) {
    case './src/features/adminDebugLoginRunbot/option.js': return Promise.resolve().then(function () { return option$g; });
    case './src/features/ambient/option.js': return Promise.resolve().then(function () { return option$f; });
    case './src/features/assignMeTask/option.js': return Promise.resolve().then(function () { return option$e; });
    case './src/features/autoOpenRunbot/option.js': return Promise.resolve().then(function () { return option$d; });
    case './src/features/awesomeLoadingLarge/option.js': return Promise.resolve().then(function () { return option$c; });
    case './src/features/awesomeLoadingSmall/option.js': return Promise.resolve().then(function () { return option$b; });
    case './src/features/awesomeStyle/option.js': return Promise.resolve().then(function () { return option$a; });
    case './src/features/contextOdooMenus/option.js': return Promise.resolve().then(function () { return option$9; });
    case './src/features/impersonateLoginRunbot/option.js': return Promise.resolve().then(function () { return option$8; });
    case './src/features/newServerActionCode/option.js': return Promise.resolve().then(function () { return option$7; });
    case './src/features/pinMessage/option.js': return Promise.resolve().then(function () { return option$6; });
    case './src/features/saveKnowledge/option.js': return Promise.resolve().then(function () { return option$5; });
    case './src/features/showMyBadge/option.js': return Promise.resolve().then(function () { return option$4; });
    case './src/features/starringTaskEffect/option.js': return Promise.resolve().then(function () { return option$3; });
    case './src/features/themeSwitch/option.js': return Promise.resolve().then(function () { return option$2; });
    case './src/features/tooltipMetadata/option.js': return Promise.resolve().then(function () { return option$1; });
    case './src/features/unfocusApp/option.js': return Promise.resolve().then(function () { return option; });
    default: return new Promise(function(resolve, reject) {
      (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
        reject.bind(null, new Error("Unknown variable dynamic import: " + path))
      );
    })
   }
 }

const baseSettings = {
    configurationVersion: 1,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['17.0'],

    // Experimental
    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
    cacheEncodingBase64: true,
};

const extensionFeatureState = FeaturesState;
Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

function importFeatureOptionFile(featureID) {
    return __variableDynamicImportRuntime4__(`./src/features/${featureID}/option.js`).then((f) => new f.default());
}

function importFeatureCustomizationFile(featureID) {
    return __variableDynamicImportRuntime5__(`./src/features/${featureID}/option_customization.js`).then((f) => new f.default());
}

async function getFeaturesAndCurrentSettings() {
    const response = await sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.GET_FEATURES_LIST);
    const features = response.features;

    const configuration = await getCurrentSettings(features);
    return { features: features, currentSettings: configuration };
}

async function getCurrentSettings(features) {
    const defaultSettings = features.reduce((acc, obj) => {
        return Object.assign(acc, obj.defaultSettings);
    }, {});

    const settings = await StorageSync.get({
        ...baseSettings,
        ...defaultSettings,
    });
    return settings;
}

function ValueIsNaN(value) {
    return isNaN(value) || Number.isNaN(value);
}

async function sleep(timeMS) {
    return await new Promise((r) => setTimeout(r, timeMS));
}

function yyyymmdd_hhmmssToDate(datetimeStr) {
    const [dateStr, timeStr] = datetimeStr.split(' ');
    return new Date(`${dateStr}T${timeStr}Z`).toISOString();
}

function toLocaleDateStringFormatted(date) {
    return date.toLocaleDateString([], { year: '2-digit', month: '2-digit', day: '2-digit' });
}

function toLocaleTimeStringFormatted(date) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function toLocaleDateTimeStringFormatted(date) {
    return `${toLocaleDateStringFormatted(date)} ${toLocaleTimeStringFormatted(date)}`;
}

function toOdooBackendDateGMT0(date) {
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const hours = String(date.getUTCHours()).padStart(2, '0');
    const minutes = String(date.getUTCMinutes()).padStart(2, '0');
    const seconds = String(date.getUTCSeconds()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

function hasUnknownKey(sourceObj, targetObj) {
    for (const key in sourceObj) {
        if (!(key in targetObj)) {
            return true;
        }
    }
    return false;
}

// Private
const LOCAL_DEFAULT = {
    journey_announces: {},
    offs: [],
    ambient_dates: {},
    joorney_sunrise: 0,
    joorney_sunset: 23 * 60 + 59,
    joorney_date: '',
    joorneyLocalCacheCall: {},
};

async function setLocal(obj) {
    if (hasUnknownKey(obj, LOCAL_DEFAULT)) {
        Console.warn(`Unknown local key in: ${JSON.stringify(obj)}`);
    }
    await StorageLocal.set(obj);
}

// Developer
async function getStorageUsage(...keysArg) {
    const keys = Array.from(keysArg);
    const usage = await StorageLocal.getBytesInUse(keys && keys.length > 0 ? keys : undefined);
    return usage;
}
async function clearLocal() {
    await StorageLocal.clear();
}
async function getLocal() {
    return await StorageLocal.get(LOCAL_DEFAULT);
}

// Announce
async function getAnnounceCloseStatus(version) {
    const { journey_announces } = await StorageLocal.get({ journey_announces: LOCAL_DEFAULT.journey_announces });
    return journey_announces[version] ?? false;
}

async function closeAnnounce(announce) {
    const { journey_announces } = await StorageLocal.get({ journey_announces: LOCAL_DEFAULT.journey_announces });
    journey_announces[announce.hash] = true;
}

// Cache
async function getLocalCache() {
    const { joorneyLocalCacheCall } = await StorageLocal.get({
        joorneyLocalCacheCall: LOCAL_DEFAULT.joorneyLocalCacheCall,
    });
    return joorneyLocalCacheCall;
}
async function setLocalCache(cacheData) {
    await setLocal({ joorneyLocalCacheCall: cacheData });
}

// Ambient
async function getAmbientDates() {
    const { ambient_dates } = await StorageLocal.get({ ambient_dates: LOCAL_DEFAULT.ambient_dates });
    return ambient_dates;
}
async function setAmbientDates(datesData) {
    await setLocal({ ambient_dates: datesData });
}

const store$4 = {
    tour_hostControls: false,
    tour_hostControls_version: 1,
    step_hostControls_moveFeature: false,
    step_hostControls_addHost: false,
    step_hostControls_configureHost: false,
    step_hostControls_deleteHost: false,
};

const steps$4 = {
    step_hostControls_moveFeature: {
        id: 'step_hostControls_moveFeature',
        tour: 'joorney_tour_hostControls',
        name: 'Manage Features',
        description: 'Drag and drop to enable or disable a feature for optimal control.',
        trigger: [{ selector: '#joorney_showMyBadge_feature', run: 'dragend' }],
        next: 'step_hostControls_addHost',
        progression: 30,
    },
    step_hostControls_addHost: {
        id: 'step_hostControls_addHost',
        tour: 'joorney_tour_hostControls',
        name: 'Add your own origin',
        description: "Add a new origin by saving your changes or pressing 'Enter'.",
        trigger: [
            { selector: '#joorney_origins_filter_new_origin_save', run: 'click' },
            { selector: '#joorney_origins_filter_new_origin', run: 'onkeydown', conditional: (e) => e.key === 'Enter' },
        ],
        next: 'step_hostControls_configureHost',
        progression: 20,
    },
    step_hostControls_configureHost: {
        id: 'step_hostControls_configureHost',
        tour: 'joorney_tour_hostControls',
        name: 'Configure your origin',
        description: 'Adjust the settings for each origin by enabling or disabling features using the checkboxes.',
        trigger: [{ selector: '.joorney_origins_filter_origin_0_showMyBadge', run: 'click' }],
        next: 'step_hostControls_deleteHost',
        progression: 30,
    },
    step_hostControls_deleteHost: {
        id: 'step_hostControls_deleteHost',
        tour: 'joorney_tour_hostControls',
        name: 'Remove your origin',
        description: 'Initiate and confirm origin deletion in the prompt.',
        trigger: [{ selector: '.joorney_origins_filter_origin_delete_0', run: 'click' }],
        progression: 20,
    },
};

const store$3 = {
    tour_preferences: false,
    tour_preferences_version: 1,
    step_preferences_awesomeLoading: false,
    step_preferences_awesomeStyle: false,
    step_preferences_unfocusApp: false,
    step_preferences_themeSwitchLocation: false,
    step_preferences_themeSwitchTime: false,
    step_preferences_contextOdooMenus: false,
};

const steps$3 = {
    step_preferences_awesomeLoading: {
        id: 'step_preferences_awesomeLoading',
        tour: 'tour_preferences',
        name: 'Custom Loading',
        description: 'Upload and set a custom loading GIF for a personalized Odoo loading.',
        trigger: [{ selector: '#joorney_awe_loading_new_image_save', run: 'click', align: 'nearest' }],
        next: 'step_preferences_awesomeStyle',
        progression: 20,
    },
    step_preferences_awesomeStyle: {
        id: 'step_preferences_awesomeStyle',
        tour: 'tour_preferences',
        name: 'Stylus Like',
        description: 'Adjust and customize the visual style to match your preferences.',
        trigger: [{ selector: '#joorney_awe_style_css', run: 'click' }],
        next: 'step_preferences_unfocusApp',
        progression: 15,
    },
    step_preferences_unfocusApp: {
        id: 'step_preferences_unfocusApp',
        tour: 'tour_preferences',
        name: 'App Icon Background',
        description: 'Personalize the app icon background, used for superfocused apps.',
        trigger: [{ selector: '#joorney_unfocus_app_light_image_input', run: 'click' }],
        next: 'step_preferences_themeSwitchLocation',
        progression: 20,
    },
    step_preferences_themeSwitchLocation: {
        id: 'step_preferences_themeSwitchLocation',
        tour: 'tour_preferences',
        name: 'Sunlight Theme Mode',
        description: 'Enable automatic theme switching based on sunrise and sunset times.',
        trigger: [{ selector: '#joorney_theme_switch_get_location_button', run: 'click' }],
        next: 'step_preferences_themeSwitchTime',
        progression: 15,
    },
    step_preferences_themeSwitchTime: {
        id: 'step_preferences_themeSwitchTime',
        tour: 'tour_preferences',
        name: 'Scheduled Theme Mode',
        description: 'Set a schedule time range for automatic theme switching.',
        trigger: [
            { selector: '#joorney_theme_switch_dark_start', run: 'click' },
            { selector: '#joorney_theme_switch_dark_stop', run: 'click' },
        ],
        next: 'step_preferences_contextOdooMenus',
        progression: 15,
    },
    step_preferences_contextOdooMenus: {
        id: 'step_preferences_contextOdooMenus',
        tour: 'tour_preferences',
        name: 'Context Menus',
        description: "Setup some Odoo's menus to use in Joorney context menu.",
        trigger: [{ selector: '#joorney_contextOdooMenus_new_save', run: 'click' }],
        progression: 15,
    },
};

const store$2 = {
    tour_technical: true,
    tour_technical_version: 1,
    step_technical_experimentalOption: false,
    step_technical_addWAFallback: false,
    step_technical_removeWAFallback: false,
    step_technical_extensionState: false,
    step_technical_onboardingProgress: false,
    step_technical_extensionFeaturesConfiguration: false,
    step_technical_extensionConfiguration: false,
};

const steps$2 = {
    step_technical_experimentalOption: {
        id: 'step_technical_experimentalOption',
        tour: 'tour_technical',
        name: 'Experimental / Advanced',
        description: 'Advanced options for informed user.',
        next: 'step_technical_addWAFallback',
        progression: 20,
    },
    step_technical_addWAFallback: {
        id: 'step_technical_addWAFallback',
        tour: 'tour_technical',
        name: 'Window Actions - No access',
        description: "You don't have the access to see 'Window Action' records? Add model fallback here",
        trigger: [{ selector: '#joorney_window_action_fallback_new_path_save', run: 'click' }],
        next: 'step_technical_removeWAFallback',
        progression: 20,
    },
    step_technical_removeWAFallback: {
        id: 'step_technical_removeWAFallback',
        tour: 'tour_technical',
        name: 'Window Actions - Removal',
        description: "Revoke or adjust the fallback for 'Window Action' records as needed.",
        trigger: [{ selector: '[class^="joorney_window_action_fallback_origin_delete"]', run: 'click' }],
        next: 'step_technical_extensionState',
        progression: 20,
    },
    step_technical_extensionState: {
        id: 'step_technical_extensionState',
        tour: 'tour_technical',
        name: 'Extension State',
        description: '', // 'Review the list of enabled features in the current version/build.',
        trigger: [{ selector: '#joorney-extension-state .expander', run: 'click' }],
        next: 'step_technical_onboardingProgress',
        progression: 15,
    },
    step_technical_onboardingProgress: {
        id: 'step_technical_onboardingProgress',
        tour: 'tour_technical',
        name: 'Onboarding progression',
        description: '', // "Check your onboarding progression stored in Chrome's local storage.",
        trigger: [{ selector: '#joorney-onboarding-progression .expander', run: 'click' }],
        next: 'step_technical_extensionFeaturesConfiguration',
        progression: 15,
    },
    step_technical_extensionFeaturesConfiguration: {
        id: 'step_technical_extensionFeaturesConfiguration',
        tour: 'tour_technical',
        name: 'Feature Setup',
        description: '', // 'Explore configurations for all features.',
        trigger: [{ selector: '#joorney-extension-features .expander', run: 'click' }],
        next: 'step_technical_extensionConfiguration',
        progression: 15,
    },
    step_technical_extensionConfiguration: {
        id: 'step_technical_extensionConfiguration',
        tour: 'tour_technical',
        name: 'User Configuration',
        description: '', // "Check your user configuration stored in Chrome's sync storage.",
        trigger: [{ selector: '#joorney-storage-configuration .expander', run: 'click' }],
        progression: 15,
    },
};

const store$1 = {
    tour_versions: false,
    tour_versions_version: 1,
    step_versions_addLTSVersion: false,
    step_versions_addSubVersion: false,
    step_versions_checkCompatibility: false,
    step_versions_removeSubVersion: false,
};

const steps$1 = {
    step_versions_addLTSVersion: {
        id: 'step_versions_addLTSVersion',
        tour: 'joorney_tour_versions',
        name: 'Enable LTS version',
        description: 'Select and enable a new Long-Term Support (LTS) version.',
        trigger: [{ selector: 'label[for="joorney_16_0_version"]', run: 'click' }],
        next: 'step_versions_addSubVersion',
        progression: 30,
    },
    step_versions_addSubVersion: {
        id: 'step_versions_addSubVersion',
        tour: 'joorney_tour_versions',
        name: 'Enable Version',
        description: 'Enable a version to explore new features.',
        trigger: [{ selector: 'label[for="joorney_15_2_version"]', run: 'click' }],
        next: 'step_versions_checkCompatibility',
        progression: 30,
    },
    step_versions_checkCompatibility: {
        id: 'step_versions_checkCompatibility',
        tour: 'joorney_tour_versions',
        name: 'Compatibility Table',
        description: 'Review compatibility between features and versions.',
        next: 'step_versions_removeSubVersion',
        progression: 10,
    },
    step_versions_removeSubVersion: {
        id: 'step_versions_removeSubVersion',
        tour: 'joorney_tour_versions',
        name: 'Disable Version',
        description: 'Disable the previously enabled version.',
        trigger: [{ selector: 'label[for="joorney_15_2_version"]', run: 'click' }],
        progression: 30,
    },
};

// biome-ignore lint/complexity/noStaticOnlyClass: <explanation>
class Checklist {
    static manager = undefined;
    static bubble = undefined;
    static content = undefined;
}

async function getOnboardingProgressData() {
    const progress = await StorageLocal.get({
        ...store$4,
        ...store$3,
        ...store$1,
        ...store$2,
    });
    return progress;
}

async function getNextTourID() {
    const tourState = await StorageLocal.get({
        tour_hostControls: false,
        tour_preferences: false,
        tour_versions: false,
        tour_toasts: false,
    });
    const tourOrder = ['tour_versions', 'tour_hostControls', 'tour_preferences', 'tour_toasts'];
    const defaultMenuTour = tourOrder.find((t) => !tourState[t]);
    return defaultMenuTour;
}

class Bubble {
    constructor() {
        this.bubble = document.getElementById('bubble');
        this.target = null;
    }

    isShow() {
        return this.bubble?.classList.contains('opacity-100');
    }

    reposition() {
        this.positionBubble(this.target, this.bubble);
    }

    move(target) {
        this.target = target;
        this.positionBubble(this.target, this.bubble);
        this.bubble.classList.add('opacity-100');

        // this.observer?.disconnect();
        // this.observer = new MutationObserver(() => {
        //     this.positionBubble(this.target, this.bubble);
        // });

        // this.observer.observe(this.target, {
        //     attributes: true,
        //     childList: true,
        //     subtree: true,
        // });
    }

    close() {
        this.target = null;
        this.bubble.classList.remove('opacity-100');
    }

    positionBubble(target, bubble) {
        if (!target || !bubble) return;
        const targetRect = target.getBoundingClientRect();

        bubble.style.top = `${targetRect.y + targetRect.height / 2 - bubble.offsetHeight / 2}px`;
        bubble.style.left = `${targetRect.x + targetRect.width / 2 - bubble.offsetWidth / 2}px`;
    }
}

// import { getVersionInfo } from '../api/odoo.js';

const SUPPORTED_VERSION = [
    '15.0',
    'saas-15.2',
    '16.0',
    'saas-16.1',
    'saas-16.2',
    'saas-16.3',
    'saas-16.4',
    '17.0',
    'saas-17.1',
    'saas-17.2',
    'saas-17.3',
    'saas-17.4',
    'saas-17.5', // master
    //'18.0'
].map((v) => sanitizeVersion(v));
function sanitizeVersion(version) {
    return `${version}`.replaceAll(/saas[~|-]/g, '');
}

/**
 * Caches the result of a function call for a specified amount of time.
 * If the cached result exists and hasn't expired, it is returned;
 * otherwise, the function is executed and the result is cached.
 *
 * @async
 * @function cache
 * @param {number} cachingTime - The amount of time (in minutes) to cache the result. If 0 or less, the result will not be cached.
 * @param {Function} call - The asynchronous function to call if there is no cached data.
 * @param {string} callID - A unique identifier for the cached data.
 * @param {...any} params - Additional parameters passed to both the `readCacheCall` and `saveCacheCall` functions.
 * @returns {Promise<{fromCache: boolean, data: any}>} - An object containing two properties:
 *          - `fromCache` (boolean): Whether the data was retrieved from the cache.
 *          - `data` (any): The cached data or the result of the function call.
 */
async function cache(cachingTime, call, callID, ...params) {
    let data = undefined;
    let fromCache = true;
    if (cachingTime > 0) {
        data = await readCacheCall(callID, ...params);
    }
    if (!data) {
        data = await call();
        fromCache = false;

        if (cachingTime > 0) await saveCacheCall(cachingTime, callID, data, ...params);
    }
    return { fromCache, data };
}

function getHost() {
    if (typeof window === 'undefined' || window.location.host === Runtime.id) return `joorney://${Runtime.id}`;
    return window.location.host;
}

// Clear host if last change is 12h hours old
async function _checkHostsExpiration(cache, now) {
    let hasChange = false;
    for (const [k, v] of Object.entries(cache)) {
        if (now - (v.lastChange ?? 0) > 12 * 60 * 60 * 1000) {
            delete cache[k];
            hasChange = true;
        }
    }
    return { changed: hasChange, cache: cache };
}

async function saveCacheCall(expireAfterMinute, call, result, ...params) {
    const { cacheEncodingBase64 } = await StorageSync.get({ cacheEncodingBase64: true });
    const hash = jbtoa(JSON.stringify(params), cacheEncodingBase64);
    const host = getHost();

    let cache = await getLocalCache();

    const now = Date.now();

    cache[host] ??= {};
    cache[host][call] ??= {};
    cache[host][call][hash] = {
        date: now,
        dateStr: new Date(now).toISOString(),
        expireAfterMinute: expireAfterMinute ?? 0,
        data: jbtoa(JSON.stringify(result), cacheEncodingBase64),
    };
    cache[host].lastChange = now;

    cache = await _checkHostsExpiration(cache, now);
    await setLocalCache(cache.cache);
}

async function readCacheCall(call, ...params) {
    const { cacheEncodingBase64 } = await StorageSync.get({ cacheEncodingBase64: true });
    const hash = jbtoa(JSON.stringify(params), cacheEncodingBase64);
    const host = getHost();
    let cache = await getLocalCache();
    cache = cache?.[host]?.[call]?.[hash];
    if (!cache) return undefined;
    const { date, expireAfterMinute, data } = cache;

    const now = Date.now();
    if (now - date > expireAfterMinute * 60 * 1000) return undefined;
    const decodeData = jatob(data, cacheEncodingBase64);
    return decodeData ? JSON.parse(decodeData) : undefined;
}

// TODO[IMP] Encryption/Decryption instead of Encoding/Decoding
function jbtoa(str, cacheEncodingBase64) {
    if (!cacheEncodingBase64) return str;
    try {
        return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (_, p1) => String.fromCharCode(`0x${p1}`)));
    } catch (e) {
        Console.error(e);
        return undefined;
    }
}

function jatob(data, cacheEncodingBase64) {
    if (!cacheEncodingBase64) return data;
    try {
        return decodeURIComponent(
            atob(data)
                .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
                .join('')
        );
    } catch (e) {
        Console.error(e);
        return undefined;
    }
}

//#region External Public Odoo API
async function getFutureEventWithName(domainName, host) {
    const { data } = await cache(
        30 * 24 * 60,
        async () => {
            const url = `https://${host}/web/dataset/call_kw/event.event/search_read`;
            const today = toOdooBackendDateGMT0(new Date());
            const payload = {
                method: 'call',
                jsonrpc: '2.0',
                params: {
                    args: [],
                    kwargs: {
                        context: { active_test: true, lang: 'en_US' },
                        domain: [domainName, ['date_end', '>=', today]],
                        limit: 1,
                        fields: ['date_begin', 'date_end', 'name', 'display_name'],
                    },
                    model: 'event.event',
                    method: 'search_read',
                },
            };
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });
            return await response.json();
        },
        'getFutureEventWithName',
        domainName,
        host
    );
    if (!data) return undefined;
    if (data.error) return undefined;
    if (!data.result || data.result.length !== 1) return undefined;
    return data.result[0];
}
//#endregion

// Based on: https://github.com/catdad/canvas-confetti/blob/master/src/confetti.js

const global = globalThis;

class Confetti {
    constructor(canvas = null, globalOpts = { resize: true, disableForReducedMotion: true }) {
        this.cannon = new ConfettiCannon(canvas, globalOpts);
    }

    fire(options) {
        this.cannon.fire(options);
    }

    reset() {
        this.cannon.reset();
    }
}

class ConfettiCannon {
    constructor(canvas, globalOpts) {
        this.isLibCanvas = !canvas;
        this.allowResize = !!prop(globalOpts || {}, 'resize');
        this.disableForReducedMotion = prop(globalOpts, 'disableForReducedMotion', Boolean);
        this.resizer = this.isLibCanvas ? this.setCanvasWindowSize : this.setCanvasRectSize;
        this.initialized = false;
        this.preferLessMotion = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion)').matches;
        this.animationObj = undefined;
        this.canvas = canvas;

        this.animator = new ConfettiAnimator();
    }

    //#region Canvas
    loadCanvas(zIndex) {
        if (this.isLibCanvas && this.animationObj) {
            // use existing canvas from in-progress animation
            this.canvas = this.animationObj.canvas;
        } else if (this.isLibCanvas && !this.canvas) {
            // create and initialize a new canvas
            this.canvas = this.getCanvas(zIndex);
            document.body.appendChild(this.canvas);
        }

        if (this.allowResize && !this.initialized) {
            // initialize the size of a user-supplied canvas
            this.resizer(this.canvas);
        }

        return this.canvas;
    }

    getCanvas(zIndex) {
        const canvas = document.createElement('canvas');

        canvas.style.position = 'fixed';
        canvas.style.top = '0px';
        canvas.style.left = '0px';
        canvas.style.pointerEvents = 'none';
        canvas.style.zIndex = zIndex;

        return canvas;
    }

    setCanvasRectSize(canvas) {
        const rect = canvas.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
    }

    setCanvasWindowSize(canvas) {
        canvas.width = document.documentElement.clientWidth;
        canvas.height = document.documentElement.clientHeight;
    }
    //#endregion

    fire(options) {
        if (this.disableForReducedMotion && this.preferLessMotion) {
            return promise((resolve) => resolve());
        }

        this.loadCanvas(prop(options, 'zIndex', Number));

        const size = {
            width: this.canvas.width,
            height: this.canvas.height,
        };

        this.initialized = true;

        function onResize() {
            // don't actually query the size here, since this
            // can execute frequently and rapidly
            size.width = size.height = null;
        }

        if (this.allowResize) global.addEventListener('resize', onResize, false);

        const fireDone = () => {
            this.animationObj = null;

            if (this.allowResize) global.removeEventListener('resize', onResize);

            if (this.isLibCanvas && this.canvas) {
                document.body.removeChild(this.canvas);
                this.canvas = null;
                this.initialized = false;
            }
        };

        return this.fireLocal(options, size, fireDone);
    }

    reset() {
        if (this.animationObj) this.animationObj.reset();
    }

    fireLocal(options, size, done) {
        const particleCount = prop(options, 'particleCount', onlyPositiveInt);
        const angle = prop(options, 'angle', Number);
        const spread = prop(options, 'spread', Number);
        const startVelocity = prop(options, 'startVelocity', Number);
        const decay = prop(options, 'decay', Number);
        const gravity = prop(options, 'gravity');
        const drift = prop(options, 'drift');
        const colors = prop(options, 'colors', colorsToRgb);
        const ticks = prop(options, 'ticks', Number);
        const shapes = prop(options, 'shapes');
        const scalar = prop(options, 'scalar');
        const flat = !!prop(options, 'flat');
        const origin = getOrigin(options);
        const alpha = getAlpha(options);

        let temp = particleCount;
        const fettis = [];

        const startX = this.canvas.width * origin.x;
        const startY = this.canvas.height * origin.y;

        while (temp--) {
            fettis.push(
                Fetti.randomPhysics({
                    x: startX,
                    y: startY,
                    angle: angle,
                    spread: spread,
                    startVelocity: startVelocity,
                    color:
                        colors.length <= particleCount
                            ? colors[temp % colors.length]
                            : colors[Math.round(randomInRange$1(0, colors.length - 1))],
                    shape: shapes[randomInt(0, shapes.length)],
                    ticks: ticks,
                    decay: decay,
                    gravity: gravity,
                    drift: drift,
                    scalar: scalar,
                    flat: flat,
                    alpha: alpha,
                })
            );
        }

        // if we have a previous canvas already animating, add to it
        if (this.animationObj) return this.animationObj.addFettis(fettis);

        this.animationObj = this.animator.animate(this.canvas, fettis, this.resizer, size, done);
        return this.animationObj.promise;
    }
}

class ConfettiAnimator {
    constructor() {
        this.TIME = Math.floor(1000 / 60);
        this.frames = {};
        this.lastFrameTime = 0;

        if (typeof requestAnimationFrame === 'function' && typeof cancelAnimationFrame === 'function') {
            this.frame = (cb) => this.frameFct(cb);
            this.cancel = (id) => this.cancelFct(id);
        } else {
            this.frame = (cb) => setTimeout(cb, this.TIME);
            this.cancel = (timer) => clearTimeout(timer);
        }
    }

    onFrame(time, id, cb) {
        if (this.lastFrameTime === time || this.lastFrameTime + this.TIME - 1 < time) {
            this.lastFrameTime = time;
            delete this.frames[id];
            cb();
            return;
        }
        this.frames[id] = requestAnimationFrame((time) => this.onFrame(time, id, cb));
    }

    frameFct(cb) {
        const id = Math.random();
        this.frames[id] = requestAnimationFrame((time) => this.onFrame(time, id, cb));
        return id;
    }

    cancelFct(id) {
        if (frames[id]) cancelAnimationFrame(frames[id]);
    }

    animate(canvas, fettis, resizer, size, done) {
        let animatingFettis = fettis.slice();
        const context = canvas.getContext('2d');
        let animationFrame;
        let destroy;

        const self = this;
        function getAnimatePromise() {
            return promise((resolve) => {
                function onDone() {
                    animationFrame = destroy = null;
                    context.clearRect(0, 0, size.width, size.height);

                    done();
                    resolve();
                }

                function update() {
                    if (!size.width && !size.height) {
                        resizer(canvas);
                        size.width = canvas.width;
                        size.height = canvas.height;
                    }

                    context.clearRect(0, 0, size.width, size.height);

                    animatingFettis = animatingFettis.filter((fetti) => fetti.updateFetti(context));

                    if (animatingFettis.length) {
                        animationFrame = self.frame(update);
                    } else {
                        onDone();
                    }
                }

                animationFrame = self.frame(update);
                destroy = onDone;
            });
        }

        const prom = getAnimatePromise();

        return {
            canvas: canvas,
            promise: prom,
            addFettis: (fettis) => {
                animatingFettis = animatingFettis.concat(fettis);
                return prom;
            },
            reset: () => {
                if (animationFrame) this.cancel(animationFrame);
                if (destroy) destroy();
            },
        };
    }
}

class Fetti {
    static randomPhysics(opts) {
        const radAngle = opts.angle * (Math.PI / 180);
        const radSpread = opts.spread * (Math.PI / 180);
        let scalar = opts.scalar;
        if (typeof scalar === 'function') {
            scalar = scalar() ?? 1;
        }
        let gravity = opts.gravity;
        if (typeof gravity === 'function') {
            gravity = gravity() ?? 1;
        }
        let drift = opts.drift;
        if (typeof drift === 'function') {
            drift = drift() ?? 1;
        }

        return new Fetti(
            opts.x,
            opts.y,
            Math.random() * 10,
            Math.min(0.11, Math.random() * 0.1 + 0.05),
            opts.startVelocity * 0.5 + Math.random() * opts.startVelocity,
            -radAngle + (0.5 * radSpread - Math.random() * radSpread),
            (Math.random() * (0.75 - 0.25) + 0.25) * Math.PI,
            opts.color,
            opts.shape,
            0,
            opts.ticks,
            opts.decay,
            drift,
            Math.random() + 2,
            0,
            0,
            0,
            0,
            gravity * 3,
            0.6,
            scalar,
            opts.flat,
            opts.alpha
        );
    }

    constructor(
        x,
        y,
        wobble,
        wobbleSpeed,
        velocity,
        angle2D,
        tiltAngle,
        color,
        shape,
        tick,
        totalTicks,
        decay,
        drift,
        random,
        tiltSin,
        tiltCos,
        wobbleX,
        wobbleY,
        gravity,
        ovalScalar,
        scalar,
        flat,
        alpha
    ) {
        this.x = x;
        this.y = y;
        this.wobble = wobble;
        this.wobbleSpeed = wobbleSpeed;
        this.velocity = velocity;
        this.angle2D = angle2D;
        this.tiltAngle = tiltAngle;
        this.color = color;
        this.shape = shape;
        this.tick = tick;
        this.totalTicks = totalTicks;
        this.decay = decay;
        this.drift = drift;
        this.random = random;
        this.tiltSin = tiltSin;
        this.tiltCos = tiltCos;
        this.wobbleX = wobbleX;
        this.wobbleY = wobbleY;
        this.gravity = gravity;
        this.ovalScalar = ovalScalar;
        this.scalar = scalar;
        this.flat = flat;
        this.alpha = alpha;
    }

    ellipse(context, x, y, radiusX, radiusY, rotation, startAngle, endAngle, antiClockwise) {
        context.save();
        context.translate(x, y);
        context.rotate(rotation);
        context.scale(radiusX, radiusY);
        context.arc(0, 0, 1, startAngle, endAngle, antiClockwise);
        context.restore();
    }

    updateFettiBitmap(context, x1, x2, y1, y2, alpha) {
        const rotation = (Math.PI / 10) * this.wobble;
        const scaleX = Math.abs(x2 - x1) * 0.1;
        const scaleY = Math.abs(y2 - y1) * 0.1;
        const width = this.shape.bitmap.width * this.scalar;
        const height = this.shape.bitmap.height * this.scalar;

        const matrix = new DOMMatrix([
            Math.cos(rotation) * scaleX,
            Math.sin(rotation) * scaleX,
            -Math.sin(rotation) * scaleY,
            Math.cos(rotation) * scaleY,
            this.x,
            this.y,
        ]);

        // apply the transform matrix from the confetti shape
        matrix.multiplySelf(new DOMMatrix(this.shape.matrix));

        const pattern = context.createPattern(this.shape.bitmap, 'no-repeat');
        pattern.setTransform(matrix);

        context.globalAlpha = alpha;
        context.fillStyle = pattern;
        context.fillRect(this.x - width / 2, this.y - height / 2, width, height);
        context.globalAlpha = 1;
    }

    updateFettiCircle(context, x1, x2, y1, y2) {
        context.ellipse
            ? context.ellipse(
                  this.x,
                  this.y,
                  Math.abs(x2 - x1) * this.ovalScalar,
                  Math.abs(y2 - y1) * this.ovalScalar,
                  (Math.PI / 10) * this.wobble,
                  0,
                  2 * Math.PI
              )
            : this.ellipse(
                  context,
                  this.x,
                  this.y,
                  Math.abs(x2 - x1) * this.ovalScalar,
                  Math.abs(y2 - y1) * this.ovalScalar,
                  (Math.PI / 10) * this.wobble,
                  0,
                  2 * Math.PI
              );
    }

    updateFettiStar(context) {
        let rot = (Math.PI / 2) * 3;
        const innerRadius = 4 * this.scalar;
        const outerRadius = 8 * this.scalar;
        let x = this.x;
        let y = this.y;
        let spikes = 5;
        const step = Math.PI / spikes;

        while (spikes--) {
            x = this.x + Math.cos(rot) * outerRadius;
            y = this.y + Math.sin(rot) * outerRadius;
            context.lineTo(x, y);
            rot += step;

            x = this.x + Math.cos(rot) * innerRadius;
            y = this.y + Math.sin(rot) * innerRadius;
            context.lineTo(x, y);
            rot += step;
        }
    }

    updateFetti(context) {
        this.x += Math.cos(this.angle2D) * this.velocity + this.drift;
        this.y += Math.sin(this.angle2D) * this.velocity + this.gravity;
        this.velocity *= this.decay;

        if (this.flat) {
            this.wobble = 0;
            this.wobbleX = this.x + 10 * this.scalar;
            this.wobbleY = this.y + 10 * this.scalar;

            this.tiltSin = 0;
            this.tiltCos = 0;
            this.random = 1;
        } else {
            this.wobble += this.wobbleSpeed;
            this.wobbleX = this.x + 10 * this.scalar * Math.cos(this.wobble);
            this.wobbleY = this.y + 10 * this.scalar * Math.sin(this.wobble);

            this.tiltAngle += 0.1;
            this.tiltSin = Math.sin(this.tiltAngle);
            this.tiltCos = Math.cos(this.tiltAngle);
            this.random = Math.random() + 2;
        }

        const progress = this.tick++ / this.totalTicks;

        const x1 = this.x + this.random * this.tiltCos;
        const y1 = this.y + this.random * this.tiltSin;
        const x2 = this.wobbleX + this.random * this.tiltCos;
        const y2 = this.wobbleY + this.random * this.tiltSin;

        let alpha = 1 - progress;
        if (this.alpha.invert) {
            alpha = progress;
        } else if (this.alpha.double) {
            alpha = progress < 0.5 ? progress / 0.5 : progress > 0.5 ? 1 - (progress / 0.5 - 1) : 1;
        }
        if (this.alpha.max) {
            alpha *= this.alpha.max;
        }

        context.fillStyle = `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${alpha})`;
        context.beginPath();

        if (this.shape.type === 'path' && typeof this.shape.path === 'string' && Array.isArray(this.shape.matrix)) {
            context.fill(
                this.transformPath2D(
                    this.shape.path,
                    this.shape.matrix,
                    this.x,
                    this.y,
                    Math.abs(x2 - x1) * 0.1,
                    Math.abs(y2 - y1) * 0.1,
                    (Math.PI / 10) * this.wobble
                )
            );
        } else if (this.shape.type === 'bitmap') {
            this.updateFettiBitmap(context, x1, x2, y1, y2, alpha);
        } else if (this.shape === 'circle') {
            this.updateFettiCircle(context, x1, x2, y1, y2);
        } else if (this.shape === 'star') {
            this.updateFettiStar(context);
        } else {
            context.moveTo(Math.floor(this.x), Math.floor(this.y));
            context.lineTo(Math.floor(this.wobbleX), Math.floor(y1));
            context.lineTo(Math.floor(x2), Math.floor(y2));
            context.lineTo(Math.floor(x1), Math.floor(this.wobbleY));
        }

        context.closePath();
        context.fill();

        return this.tick < this.totalTicks;
    }

    transformPath2D(pathString, pathMatrix, x, y, scaleX, scaleY, rotation) {
        const path2d = new Path2D(pathString);

        const t1 = new Path2D();
        t1.addPath(path2d, new DOMMatrix(pathMatrix));

        const t2 = new Path2D();
        // see https://developer.mozilla.org/en-US/docs/Web/API/DOMMatrix/DOMMatrix
        t2.addPath(
            t1,
            new DOMMatrix([
                Math.cos(rotation) * scaleX,
                Math.sin(rotation) * scaleX,
                -Math.sin(rotation) * scaleY,
                Math.cos(rotation) * scaleY,
                x,
                y,
            ])
        );

        return t2;
    }
}

//#region Options
const defaults = {
    particleCount: 50,
    angle: 90,
    spread: 45,
    startVelocity: 45,
    decay: 0.9,
    gravity: 1,
    drift: 0,
    ticks: 200,
    x: 0.5,
    y: 0.5,
    shapes: ['square', 'circle'],
    zIndex: 100,
    colors: ['#26ccff', '#a25afd', '#ff5e7e', '#88ff5a', '#fcff42', '#ffa62d', '#ff36ff'],
    // probably should be true, but back-compat
    disableForReducedMotion: false,
    scalar: 1,
};

function getOrigin(options) {
    const origin = prop(options, 'origin', Object);
    origin.x = prop(origin, 'x', Number);
    origin.y = prop(origin, 'y', Number);

    return origin;
}

function getAlpha(options) {
    const alpha = prop(options, 'alpha', Object);
    alpha.max = prop(alpha, 'max', Number);
    alpha.double = prop(alpha, 'double', Boolean);
    alpha.invert = prop(alpha, 'invert', Boolean);

    return alpha;
}

function convert(val, transform) {
    return transform ? transform(val) : val;
}

function isOk(val) {
    return !(val === null || val === undefined);
}

function prop(options, name, transform) {
    return convert(options && isOk(options[name]) ? options[name] : defaults[name], transform);
}
//#endregion

//#region Utils
function promise(func) {
    return new Promise(func);
}

function onlyPositiveInt(number) {
    return number < 0 ? 0 : Math.floor(number);
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function toDecimal(str) {
    return Number.parseInt(str, 16);
}

function colorsToRgb(colors) {
    return colors.map(hexToRgb);
}

function hexToRgb(str) {
    let val = String(str).replace(/[^0-9a-f]/gi, '');

    if (val.length < 6) {
        val = val[0] + val[0] + val[1] + val[1] + val[2] + val[2];
    }

    return {
        r: toDecimal(val.substring(0, 2)),
        g: toDecimal(val.substring(2, 4)),
        b: toDecimal(val.substring(4, 6)),
    };
}

function shapeFromText(textData, flips = { vertical: false, horizontal: false }) {
    let text;
    let scalar = 1;
    let color = '#000000';
    let // see https://nolanlawson.com/2022/04/08/the-struggle-of-using-native-emoji-on-the-web/
        fontFamily =
            '"Twemoji Mozilla", "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "system emoji", sans-serif';

    if (typeof textData === 'string') {
        text = textData;
    } else {
        text = textData.text;
        scalar = 'scalar' in textData ? textData.scalar : scalar;
        fontFamily = 'fontFamily' in textData ? textData.fontFamily : fontFamily;
        color = 'color' in textData ? textData.color : color;
    }

    // all other confetti are 10 pixels,
    // so this pixel size is the de-facto 100% scale confetti
    const fontSize = 10 * scalar;
    const font = `${fontSize}px ${fontFamily}`;

    let canvas = new OffscreenCanvas(1, 1);
    let ctx = canvas.getContext('2d');

    ctx.font = font;
    const size = ctx.measureText(text);
    const width = Math.floor(size.width);
    const height = Math.floor(size.fontBoundingBoxAscent + size.fontBoundingBoxDescent);

    canvas = new OffscreenCanvas(width, height);
    ctx = canvas.getContext('2d');
    ctx.font = font;
    ctx.fillStyle = color;

    ctx.fillText(text, 0, fontSize);

    const scale = 1 / scalar;

    return {
        type: 'bitmap',
        // TODO these probably need to be transfered for workers
        bitmap: canvas.transferToImageBitmap(),
        matrix: [
            scale * (flips?.horizontal ? -1 : 1),
            0,
            0,
            scale * (flips?.vertical ? -1 : 1),
            (-width * scale) / 2,
            (-height * scale) / 2,
        ],
    };
}

//#endregion

function randomInRange$1(min, max) {
    return Math.random() * (max - min) + min;
}

// note: you CAN only use a path for confetti.shapeFrompath(), but for
// performance reasons it is best to use it once in development and save
// the result to avoid the performance penalty at runtime
// https://svg-path-visualizer.netlify.app/

/*
// From bubble emoji: https://images.emojiterra.com/google/noto-emoji/unicode-15.1/color/svg/1fae7.svg
// Large
shapeFromPath(
	'M68.48 46.02C65.29 45.09 65.41 48.52 62.05 53.99C59.81 57.63 55.09 62.36 47.41 64.25C42.89 65.36 40.86 66.31 40.73 67.97C40.5 70.8 44.35 71.56 49.94 70.1C64.76 66.25 75.25 47.99 68.48 46.02Z M34.9902 10.2501C39.3802 11.7601 40.5402 15.6801 39.1902 19.0301C37.9502 22.1101 33.2902 23.5001 30.3702 25.0901C25.9202 27.5001 22.6902 30.6301 20.2802 35.0801C17.9502 39.3801 11.6702 41.1201 10.8102 34.8701C10.1402 29.9801 13.1802 23.0201 16.0302 19.4501C18.5502 16.3001 22.0102 13.4901 25.6302 11.6901C28.1802 10.4301 32.2202 9.30006 34.9902 10.2501Z M55.4199 12.46C57.2199 13.98 57.4299 16.77 54.9399 17.64C53.8299 17.95 52.6699 17.45 51.5199 17.37C49.1799 17.21 48.2099 18.04 46.2099 17.19C43.2299 15.91 41.9999 13.33 43.4199 11.21C44.1199 10.17 45.4499 9.63996 46.6299 9.40996C49.8299 8.78996 53.1699 10.2 55.4199 12.46Z M39.88 79.75C17.89 79.75 0 61.86 0 39.87C0 17.88 17.89 0 39.88 0C61.87 0 79.76 17.89 79.76 39.88C79.76 61.87 61.86 79.75 39.88 79.75ZM40.5 4.22C20.44 4.22 4.13 20.53 4.13 40.59C4.13 60.65 20.45 76.96 40.5 76.96C60.55 76.96 76.87 60.64 76.87 40.59C76.87 20.54 60.55 4.22 40.5 4.22Z'
)
// Medium
shapeFromPath(
	'M40.6301 28.96C38.1901 28.13 38.7701 31.89 33.9501 35.28C28.8101 38.9 25.7001 38.03 25.5201 40.08C25.3301 42.27 30.6801 42.26 36.2501 38.11C41.0801 34.53 43.1001 29.8 40.6301 28.96Z M24.2696 47.52C11.2296 47.52 0.619629 36.91 0.619629 23.87C0.619629 10.83 11.2296 0.219971 24.2696 0.219971C37.3096 0.219971 47.9196 10.83 47.9196 23.87C47.9196 36.91 37.3096 47.52 24.2696 47.52ZM24.8696 3.10997C13.3496 3.10997 3.97963 12.48 3.97963 24C3.97963 35.52 13.3496 44.89 24.8696 44.89C36.3896 44.89 45.7596 35.52 45.7596 24C45.7596 12.48 36.3896 3.10997 24.8696 3.10997Z M19.0198 7.31001C23.4198 7.01001 24.9398 10.15 23.8498 12.64C22.4498 15.84 19.1898 14.7 16.3198 17.81C14.3398 19.96 10.1098 22.29 9.51979 17.54C8.99979 13.34 13.6498 7.68001 19.0198 7.31001Z M31.7194 13C34.3694 12.99 34.6894 10.01 33.2694 8.41996C31.6294 5.96996 26.1394 6.22996 27.4394 10.27C28.0094 12.05 29.0494 13.01 31.7194 13Z'
)
// Small
shapeFromPath(
	'M31.6804 20.37C32.2604 17.3 31.5304 10.85 28.4204 12.91C27.1704 13.74 29.1404 17.29 28.5404 20.34C27.7404 24.43 26.2204 26.57 22.6404 29.12C21.8204 29.7 22.2604 30.78 23.8104 30.22C27.9004 28.75 30.6804 25.71 31.6804 20.37Z M16.5102 6.67002C17.2202 8.15002 14.9602 10.03 14.0802 11.2C11.7902 14.25 12.9802 16.62 11.2702 19.4C9.98017 21.49 5.89016 22.93 5.12016 17.82C4.64016 14.62 6.64016 11 8.00016 9.52002C12.5102 4.62002 15.9202 5.45002 16.5102 6.67002Z M18.37 36.74C8.24 36.74 0 28.5 0 18.37C0 8.24 8.24 0 18.37 0C28.5 0 36.74 8.24 36.74 18.37C36.74 28.5 28.49 36.74 18.37 36.74ZM18.02 2.6C9.32 2.6 2.24001 9.68 2.24001 18.38C2.24001 27.08 9.32 34.16 18.02 34.16C26.72 34.16 33.8 27.08 33.8 18.38C33.8 9.68 26.73 2.6 18.02 2.6Z'
)
*/
const bubbles = {
    large: {
        type: 'path',
        path: 'M68.48 46.02C65.29 45.09 65.41 48.52 62.05 53.99C59.81 57.63 55.09 62.36 47.41 64.25C42.89 65.36 40.86 66.31 40.73 67.97C40.5 70.8 44.35 71.56 49.94 70.1C64.76 66.25 75.25 47.99 68.48 46.02Z M34.9902 10.2501C39.3802 11.7601 40.5402 15.6801 39.1902 19.0301C37.9502 22.1101 33.2902 23.5001 30.3702 25.0901C25.9202 27.5001 22.6902 30.6301 20.2802 35.0801C17.9502 39.3801 11.6702 41.1201 10.8102 34.8701C10.1402 29.9801 13.1802 23.0201 16.0302 19.4501C18.5502 16.3001 22.0102 13.4901 25.6302 11.6901C28.1802 10.4301 32.2202 9.30006 34.9902 10.2501Z M55.4199 12.46C57.2199 13.98 57.4299 16.77 54.9399 17.64C53.8299 17.95 52.6699 17.45 51.5199 17.37C49.1799 17.21 48.2099 18.04 46.2099 17.19C43.2299 15.91 41.9999 13.33 43.4199 11.21C44.1199 10.17 45.4499 9.63996 46.6299 9.40996C49.8299 8.78996 53.1699 10.2 55.4199 12.46Z M39.88 79.75C17.89 79.75 0 61.86 0 39.87C0 17.88 17.89 0 39.88 0C61.87 0 79.76 17.89 79.76 39.88C79.76 61.87 61.86 79.75 39.88 79.75ZM40.5 4.22C20.44 4.22 4.13 20.53 4.13 40.59C4.13 60.65 20.45 76.96 40.5 76.96C60.55 76.96 76.87 60.64 76.87 40.59C76.87 20.54 60.55 4.22 40.5 4.22Z',
        matrix: [0.1282051282051282, 0, 0, 0.1282051282051282, -5, -5.128205128205128],
    },
    medium: {
        type: 'path',
        path: 'M40.6301 28.96C38.1901 28.13 38.7701 31.89 33.9501 35.28C28.8101 38.9 25.7001 38.03 25.5201 40.08C25.3301 42.27 30.6801 42.26 36.2501 38.11C41.0801 34.53 43.1001 29.8 40.6301 28.96Z M24.2696 47.52C11.2296 47.52 0.619629 36.91 0.619629 23.87C0.619629 10.83 11.2296 0.219971 24.2696 0.219971C37.3096 0.219971 47.9196 10.83 47.9196 23.87C47.9196 36.91 37.3096 47.52 24.2696 47.52ZM24.8696 3.10997C13.3496 3.10997 3.97963 12.48 3.97963 24C3.97963 35.52 13.3496 44.89 24.8696 44.89C36.3896 44.89 45.7596 35.52 45.7596 24C45.7596 12.48 36.3896 3.10997 24.8696 3.10997Z M19.0198 7.31001C23.4198 7.01001 24.9398 10.15 23.8498 12.64C22.4498 15.84 19.1898 14.7 16.3198 17.81C14.3398 19.96 10.1098 22.29 9.51979 17.54C8.99979 13.34 13.6498 7.68001 19.0198 7.31001Z M31.7194 13C34.3694 12.99 34.6894 10.01 33.2694 8.41996C31.6294 5.96996 26.1394 6.22996 27.4394 10.27C28.0094 12.05 29.0494 13.01 31.7194 13Z',
        matrix: [0.22727272727272727, 0, 0, 0.22727272727272727, -5.454545454545454, -5.454545454545454],
    },
    small: {
        type: 'path',
        path: 'M31.6804 20.37C32.2604 17.3 31.5304 10.85 28.4204 12.91C27.1704 13.74 29.1404 17.29 28.5404 20.34C27.7404 24.43 26.2204 26.57 22.6404 29.12C21.8204 29.7 22.2604 30.78 23.8104 30.22C27.9004 28.75 30.6804 25.71 31.6804 20.37Z M16.5102 6.67002C17.2202 8.15002 14.9602 10.03 14.0802 11.2C11.7902 14.25 12.9802 16.62 11.2702 19.4C9.98017 21.49 5.89016 22.93 5.12016 17.82C4.64016 14.62 6.64016 11 8.00016 9.52002C12.5102 4.62002 15.9202 5.45002 16.5102 6.67002Z M18.37 36.74C8.24 36.74 0 28.5 0 18.37C0 8.24 8.24 0 18.37 0C28.5 0 36.74 8.24 36.74 18.37C36.74 28.5 28.49 36.74 18.37 36.74ZM18.02 2.6C9.32 2.6 2.24001 9.68 2.24001 18.38C2.24001 27.08 9.32 34.16 18.02 34.16C26.72 34.16 33.8 27.08 33.8 18.38C33.8 9.68 26.73 2.6 18.02 2.6Z',
        matrix: [0.29411764705882354, 0, 0, 0.29411764705882354, -5.588235294117648, -5.588235294117648],
    },
};

//#region Abstract Loader
const lockedState = ['circle', 'square', 'star'];
const emojisLoader = ({
    emojis,
    alpha,
    size,
    gravity,
    drift,
    xRange,
    yRange,
    color = '#ffffff',
    flat = true,
    flipHorizontal = false,
    flipVertical = false,
}) => {
    const emojisBitmap = emojis.map((emoji) =>
        lockedState.includes(emoji)
            ? emoji
            : shapeFromText(
                  { text: emoji, scalar: size?.max ?? 1, color: color },
                  { vertical: flipVertical, horizontal: flipHorizontal }
              )
    );

    return shapesLoader({
        shapes: emojisBitmap,
        alpha,
        size,
        gravity,
        drift,
        xRange,
        yRange,
        colors: [color],
        flat,
    });
};

const shapesLoader = ({
    shapes,
    alpha = { max: 1, double: true },
    size = { min: 1, max: 1, dynamic: false },
    gravity = { min: 0.4, max: 0.6, dynamic: false },
    drift = { min: -0.4, max: 0.4, dynamic: false },
    xRange = { min: 0, max: 1 },
    yRange = { min: 0, max: 1 }, // Top = 0, Bottom = 1
    colors = ['#ffffff'],
    flat = true,
}) => {
    const scalarComputed = size.dynamic ? () => Math.round(randomInRange(size.min, size.max)) : size.max;
    const gravityComputed = gravity.dynamic ? () => randomInRange(gravity.min, gravity.max) : gravity.max;
    const driftComputed = drift.dynamic ? () => randomInRange(drift.min, drift.max) : drift.max;

    return (ticks) => ({
        flat,
        particleCount: 1,
        startVelocity: 0,
        ticks,
        origin: {
            x: randomInRange(xRange.min, xRange.max),
            y: randomInRange(yRange.min, yRange.max),
        },
        colors,
        shapes,
        gravity: gravityComputed,
        scalar: scalarComputed,
        drift: driftComputed,
        alpha,
    });
};

const fireworkLoader = (colors, mixColor, smallAndLarge, doubleBurst) => {
    return (_ticks) => {
        const loads = [
            {
                startVelocity: 30,
                spread: 360,
                ticks: 60,
                zIndex: 0,
                particleCount: 50,
                origin: { x: randomInRange(0.1, 0.5), y: Math.random() - 0.2 },
                colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
            },
            {
                startVelocity: 30,
                spread: 360,
                ticks: 60,
                zIndex: 0,
                particleCount: 50,
                origin: { x: randomInRange(0.5, 0.9), y: Math.random() - 0.2 },
                colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
            },
        ];
        if (smallAndLarge) {
            loads.concat(
                loads.map((l) => {
                    l.particleCount *= 2;
                    return l;
                })
            );
        }

        const firework = loads[Math.round(randomInRange(0, loads.length - 1))];
        if (doubleBurst) {
            const fireworkInside = {
                ...firework,
                startVelocity: 15,
                colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
            };
            return [firework, fireworkInside];
        }
        return firework;
    };
};
const schoolPrideLoader = (colors) => {
    return (_ticks) => {
        return [
            {
                particleCount: 2,
                angle: 60,
                spread: 55,
                origin: { x: 0 },
                colors: colors,
            },
            {
                particleCount: 2,
                angle: 120,
                spread: 55,
                origin: { x: 1 },
                colors: colors,
            },
        ];
    };
};
const floatingLoader = (emojis) => {
    return emojisLoader({
        emojis: emojis,
        alpha: { max: 0.2, double: true },
        size: { min: 8, max: 20, dynamic: true },
        gravity: { min: -0.6, max: -0.4, dynamic: true },
        drift: { min: -0.4, max: 0.4, dynamic: true },
        yRange: { min: 0.5, max: 1 },
    });
};
//#endregion

function estimateAmbientDuration(ambient) {
    if (!ambient) return 1000;
    switch (ambient.type) {
        case 'long':
            return ambient.duration;
        case 'count':
            return ambient.count * ambient.delay;
        case 'onetime':
            return 1;
    }
    return 0;
}

const ambients = {
    compute: {
        name: 'Computed Events',
        ambients: [
            {
                name: `Odoo Experience ${new Date().getFullYear()}`,
                id: 'odoo-experience-oxp-cpt',
                computeDates: async () => {
                    return await getOdooEventDate(['name', '=', `Odoo Experience ${new Date().getFullYear()}`]);
                },
                type: 'long',
                duration: 3000,
                load: schoolPrideLoader(['#FBB130', '#714b67', '#050a30']),
            },
            {
                name: 'Future Community Days',
                id: 'odoo-community-days-cpt',
                computeDates: async () => {
                    return await getOdooEventDate(['name', '=like', '%Community Days%']);
                },
                type: 'long',
                duration: 3000,
                load: schoolPrideLoader(['#714B67', '#FFFFFF', '#017E84']),
            },
        ],
    },
    event: {
        name: 'Events',
        ambients: [
            // {
            //     name: 'Developer Test',
            //     id: 'joorney-test-ambient-evt',
            //     date: new Date().toISOString(),
            //     type: 'count',
            //     count: 20,
            //     delay: 250,
            //     load: fireworkLoader(['#FFFFFF', '#000000'], true, false, false),
            // },
            {
                name: 'Happy Birthday Odoo!',
                id: 'odoo-birthday-evt',
                // date: '2005-02-22T12:00:00Z', // TinyERP
                // date: '2009-04-14T12:00:00Z', // OpenERP
                date: '2014-05-15T12:00:00Z',
                type: 'count',
                count: 20,
                delay: 250,
                load: fireworkLoader(['#E46E78', '#21B799', '#5B899E', '#E4A900'], true, false, false),
            },
            {
                name: 'New Year, Countdown',
                id: 'new-year-evt',
                date_from: `${new Date().getFullYear()}-12-31T23:59:30`,
                date_to: `${new Date().getFullYear() + 1}-01-01T00:00:30`,
                type: 'count',
                count: 480,
                delay: 250,
                load: fireworkLoader(
                    [
                        // Palette 1
                        '#C63347',
                        '#F28E63',
                        '#FC7F81',
                        '#FAEFC4',
                        '#F9AE9B',
                        '#792BB2',
                        '#2E42CB',
                        '#F75781',
                        '#E365E4',
                        '#FA5348',
                        // Palette 2
                        '#FFD07E',
                        '#FA9B49',
                        '#90CA80',
                        '#62ABCC',
                        '#7984DE',
                        '#DE6C90',
                    ],
                    false,
                    true,
                    true
                ),
            },
        ],
    },
    yearly: {
        name: 'Every year, one day',
        ambients: [
            {
                name: 'New Year',
                id: 'new-year-yly',
                day: 1,
                month: 1,
                type: 'long',
                duration: 10000,
                load: schoolPrideLoader(['#BF7218', '#FADE98', '#F1A738', '#f9eb82', '#180D1C', '#514414']),
            },
            {
                name: "Valentine's Day",
                id: 'valentine-yly',
                day: 14,
                month: 2,
                type: 'count',
                count: 30,
                delay: 1000,
                load: floatingLoader(['♥️', '🌹']),
            },
            {
                name: "Lucky Day (St. Patrick's)",
                id: 'patrick-yly',
                day: 17,
                month: 3,
                type: 'onetime',
                load: (_ticks) => {
                    const emojisBitmap = ['🍻', '🪙', '🍀', '🌈'].map((emoji) =>
                        shapeFromText({ text: emoji, scalar: 4 })
                    );
                    return [
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 26,
                            startVelocity: 55,
                            particleCount: 50,
                            scalar: 2,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 60,
                            particleCount: 40,
                            scalar: 2,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 100,
                            decay: 0.91,
                            scalar: 1.6,
                            particleCount: 70,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 120,
                            startVelocity: 25,
                            decay: 0.92,
                            scalar: 2.4,
                            particleCount: 20,
                        },
                        {
                            shapes: emojisBitmap,
                            origin: { y: 0.7 },
                            spread: 120,
                            scalar: 2,
                            startVelocity: 45,
                            particleCount: 20,
                        },
                    ];
                },
            },
            {
                name: "April Fool's",
                id: 'aprilfool-yly',
                day: 1,
                month: 4,
                type: 'count',
                count: 15,
                delay: 1000,
                load: (ticks) => {
                    const left = emojisLoader({
                        emojis: ['🐟', '🐠', '🐡'],
                        alpha: { max: 0.5, double: true },
                        size: { min: 4, max: 10, dynamic: true },
                        gravity: { min: -0.1, max: 0.1, dynamic: true },
                        drift: { min: -1, max: -0.3, dynamic: true },
                    })(ticks);
                    const right = emojisLoader({
                        emojis: ['🐟', '🐠', '🐡'],
                        alpha: { max: 0.5, double: true },
                        size: { min: 4, max: 10, dynamic: true },
                        gravity: { min: -0.1, max: 0.1, dynamic: true },
                        drift: { min: 0.3, max: 1, dynamic: true },
                        flipHorizontal: true,
                    })(ticks);
                    const bubble = shapesLoader({
                        shapes: [bubbles.large, bubbles.medium, bubbles.small],
                        alpha: { max: 0.2, double: true },
                        size: { min: 2, max: 5, dynamic: true },
                        gravity: { min: -0.4, max: -0.2, dynamic: true },
                        drift: { min: -0.4, max: 0.4, dynamic: true },
                        yRange: { min: 0.5, max: 1 },
                        colors: ['#89cff0', 'e7feff', '#a1caf1', '#39a78e'],
                    })(ticks);
                    return [left, right, bubble];
                },
            },
            {
                name: 'Halloween Night',
                id: 'halloween-yly',
                day: 31,
                month: 10,
                type: 'count',
                count: 30,
                delay: 1000,
                load: floatingLoader(['🎃']),
            },
            {
                name: "New Year's Eve",
                id: 'new-year-eve-yly',
                day: 31,
                month: 12,
                type: 'count',
                count: 30,
                delay: 1000,
                load: floatingLoader(['🥂']),
            },
        ],
    },
    // season: {
    //     winter: {},
    //     spring: {},
    //     summer: {},
    //     fall: {},
    // },
    // weather: {
    //     rain: {},
    //     snow: {},
    //     sun: {},
    // },
};

// Utils
function randomInRange(min, max) {
    return Math.random() * (max - min) + min;
}

async function getOdooEventDate(domainName) {
    const event = await getFutureEventWithName(domainName, 'www.odoo.com');
    if (!event) return undefined;

    return {
        event_name: event.display_name,
        event_date_from: yyyymmdd_hhmmssToDate(event.date_begin),
        event_date_to: yyyymmdd_hhmmssToDate(event.date_end),
    };
}

//#region SEASON
// export const fallSeasonLoader = emojisLoader({
//     emojis: ['🍂'],
//     alpha: { max: 0.5 },
//     size: { min: 1, max: 2, dynamic: true },
//     gravity: { min: 0.4, max: 0.9, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.75 },
//     flat: false,
// });

// export const winterSeasonLoader = emojisLoader({
//     emojis: ['❄️', 'circle'],
//     alpha: { max: 1 },
//     size: { min: 0.4, max: 1, dynamic: true },
//     gravity: { min: 0.4, max: 0.6, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.5 },
//     color: '#ffffff',
//     flat: false,
// });

// export const summerSeasonLoader = emojisLoader({
//     emojis: ['☀️'],
//     alpha: { max: 0.5 },
//     size: { min: 1, max: 2, dynamic: true },
//     gravity: { min: 0.4, max: 0.9, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.75 },
//     flat: false,
// });

// export const springSeasonLoader = emojisLoader({
//     emojis: ['🌸'],
//     alpha: { max: 1 },
//     size: { min: 0.4, max: 1, dynamic: true },
//     gravity: { min: 0.4, max: 0.6, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: 0, max: 0.5 },
//     color: '#ffffff',
//     flat: false,
// });
//#endregion

//#region WEATHER
// export const rainWeatherLoader = emojisLoader({
//     emojis: ['💧'],
//     alpha: { max: 1 },
//     size: { min: 0.1, max: 0.6, dynamic: true },
//     gravity: { min: 4, max: 5, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: -0.1, max: 0 },
//     color: '#4a6583',
//     flat: true,
// });

// export const snowWeatherLoader = emojisLoader({
//     emojis: ['circle'],
//     alpha: { max: 1 },
//     size: { min: 0.1, max: 0.6, dynamic: true },
//     gravity: { min: 0.4, max: 0.6, dynamic: true },
//     drift: { min: -0.4, max: 0.4, dynamic: true },
//     yRange: { min: -0.1, max: 0.5 },
//     color: '#ffffff',
//     flat: false,
// });
//#endregion

class AmbientLoader {
    constructor(ambientConfetti) {
        this.ambientConfetti = ambientConfetti;
        this.stopped = true;
    }

    async stop(delay) {
        this.stopped = true;
        await this.ambientConfetti.reset();
        await new Promise((r) => setTimeout(r, delay + 10));
    }

    async load(ambientData) {
        if (!ambientData) return;
        switch (ambientData.type) {
            case 'long':
                this.loadAmbient(ambientData.load, ambientData.duration);
                break;
            case 'count':
                this.loadAmbientCount(ambientData.load, ambientData.count, ambientData.delay);
                break;
            case 'onetime':
                this.loadOneTimeAmbient(ambientData.load);
                break;
        }
    }

    async loadAmbientCount(ambientLoader, count, delay) {
        await this.stop(0);
        this.stopped = false;
        this.loadAmbient(ambientLoader, count * delay, count);
    }

    async loadOneTimeAmbient(ambientLoader) {
        await this.stop(0);
        this.stopped = false;
        const ambients = await ambientLoader();
        this.playAmbients(ambients);
    }

    async loadAmbient(
        ambientLoader,
        duration,
        countArg = undefined,
        animationStartArg = Date.now(),
        animationEnd = animationStartArg + duration,
        delay = countArg ? duration / Number.parseFloat(countArg) : 1
    ) {
        await this.stop(delay);
        this.stopped = false;
        this._loadAmbient(ambientLoader, duration, countArg, animationStartArg, animationEnd, delay);
    }

    async _loadAmbient(ambientLoader, duration, countArg, animationStartArg, animationEnd, delay) {
        const now = Date.now();
        const timeLeft = animationEnd - now;
        const ticks = Math.max(200, 500 * (timeLeft / duration));
        const ambients = await ambientLoader(ticks);

        let count = countArg;
        let animationStart = animationStartArg;

        if (count) {
            const ellapsed = now - animationStart;

            if (ellapsed >= delay) {
                this.playAmbients(ambients);
                count--;
                animationStart = now;
            }
        } else if (count === undefined) {
            this.playAmbients(ambients);
        }

        if (timeLeft > 0 && !this.stopped) {
            requestAnimationFrame(() =>
                this._loadAmbient(ambientLoader, duration, count, animationStart, animationEnd, delay)
            );
        }
    }

    playAmbients(ambientsArg) {
        const ambients = Array.isArray(ambientsArg) ? ambientsArg : [ambientsArg];
        for (const ambient of ambients) {
            this.ambientConfetti.fire(ambient);
        }
    }
}

class AmbientManager {
    static async computeEvents() {
        const ambient_dates = {};

        for (const c of ambients.compute.ambients) {
            const dates = await c.computeDates();
            if (!dates) continue;
            ambient_dates[c.id] = {
                date_from: dates.event_date_from,
                date_to: dates.event_date_to,
                name: dates.event_name,
            };
        }

        await setAmbientDates(ambient_dates);
    }

    async getAmbientForDate(date) {
        let ambient = undefined;
        const { ambientStatus } = await StorageSync.get({ ambientStatus: {} });

        if (!ambient) ambient = await this.getComputedEventForDate(ambientStatus, date);
        if (!ambient) ambient = this.getEventAmbientForDate(ambientStatus, date);
        if (!ambient) ambient = this.getYearlyAmbientForDate(ambientStatus, date);
        if (!ambient) ambient = this.getSeasonAmbientForDate(ambientStatus, date);
        if (!ambient) ambient = await this.getWeatherAmbientForDate(ambientStatus, date);

        return ambient;
    }

    getEventForDate(date, events) {
        let from = undefined;
        let to = undefined;

        for (const event of events) {
            if (event.date_from && event.date_to) {
                from = new Date(event.date_from);
                to = new Date(event.date_to);
                if (this.isDateBetween(date, from, to)) return event;
                continue;
            }
            if (event.date) {
                from = new Date(event.date);
                if (this.isSameDay(date, from)) return event;
            }
        }

        return undefined;
    }

    getEventAmbientForDate(ambientStatus, date) {
        const activeAmbients = ambients.event.ambients.filter((a) => ambientStatus[a] ?? true);
        return this.getEventForDate(date, activeAmbients);
    }

    async getComputedEventForDate(ambientStatus, date) {
        const computes = ambients.compute.ambients.filter((a) => ambientStatus[a.id] ?? true);
        const ambient_dates = await getAmbientDates();
        for (const c of computes) {
            const dates = ambient_dates[c.id];
            if (dates) Object.assign(c, dates);
        }
        return this.getEventForDate(date, computes);
    }

    getYearlyAmbientForDate(ambientStatus, date) {
        const mm = date.getMonth() + 1; // Months start at 0!
        const dd = date.getDate();

        return ambients.event.ambients.find((a) => (ambientStatus[a] ?? true) && a.day === dd && a.month === mm);
    }

    getSeasonAmbientForDate(_ambientStatus, _date) {
        return undefined;
    }

    async getWeatherAmbientForDate(_ambientStatus, _date) {
        return undefined;
    }

    isDateBetween(targetDate, startDate, endDate) {
        return targetDate >= startDate && targetDate <= endDate;
    }

    isSameDay(date1, date2) {
        // return date1.toDateString() === date2.toDateString();
        return (
            date1.getFullYear() === date2.getFullYear() &&
            date1.getMonth() === date2.getMonth() &&
            date1.getDate() === date2.getDate()
        );
    }
}

function stringToHTML(str) {
    const template = document.createElement('template');
    template.innerHTML = str.trim();
    return template.content.firstChild;
}

function generateLimitedFeatureOptionButtonItem(feature) {
    return stringToHTML(`
		<label
			title="[Limited Feature] ${feature.display_name ?? feature.id}"
			for="joorney_${feature.id}_limited_feature"
		>
			<input id="joorney_${feature.id}_limited_feature" class="input-hide" type="checkbox" />
			<div class="limited-feature-wrapper d-flex">
				<i class="joorney-font-icon-size fa-regular me-2"></i>
				<p>${feature.display_name ?? feature.id}</p>
			</div>
		</label>
	`);
}

function generateFeatureOptionListItem(feature) {
    return stringToHTML(`
		<label
			id="joorney_${feature.id}_feature"
			title="[Feature] ${feature.display_name ?? feature.id}"
			data-feature="${feature.id}"
			class="draggable-feature" draggable="true"
		>
			<div class="feature-wrapper d-flex">
				<div class="icon-wrapper pe-1">
					${feature.icon}
				</div>
				<p>${feature.display_name ?? feature.id}</p>
			</div>
		</label>
	`);
}

function generateFeatureOptionTableHeadItem(feature) {
    return stringToHTML(`
		<th title="[Feature Origin] ${feature.display_name ?? feature.id}" class="icon-wrapper-head">
			<div class="icon-wrapper" id="joorney_origins_filter_feature_header_${feature.id}">
				${feature.icon}
			</div>
		</th>
	`);
}

function setCancellableTimeout(callback, ms) {
    const timeoutID = setTimeout(callback, ms);
    return {
        clear: () => clearTimeout(timeoutID),
        trigger: () => {
            clearTimeout(timeoutID);
            callback();
        },
    };
}

let ambientConfetti = undefined;
let ambientManager = undefined;
let ambientLoader = undefined;
const ambientsData = {};

async function loadPage$6(_features, _currentSettings) {
    setupSlider();

    const canva = document.getElementById('previewAmbient');
    ambientConfetti = new Confetti(canva);
    ambientManager = new AmbientManager(ambientConfetti);
    ambientLoader = new AmbientLoader(ambientConfetti);

    loadAmbientList();
}

async function loadAmbientList() {
    const container = document.getElementById('joorney-ambient-list');
    container.innerHTML = '';

    const ambient_dates = await getAmbientDates();
    const todayAmbient = await ambientManager.getAmbientForDate(new Date());

    for (const [id, category] of Object.entries(ambients)) {
        container.appendChild(
            stringToHTML(`
            <div class="d-flex justify-content-between bg-body-tertiary p-2 border-bottom" data-ambient-category-id="${id}">
                <h6 class="m-0"><span class="ambient-category-toggle me-1 opacity-25" style="cursor: pointer;"><i class="fa-fw fa-solid fa-chevron-down"></i></span>${category.name}</h6>
                <p class="m-0">
                    <small class="text-decoration-underline ambient-category-all-toggle" style="cursor: pointer;">All</small>
                    &nbsp;/&nbsp;
                    <small class="text-decoration-underline ambient-category-none-toggle" style="cursor: pointer;">None</small>
                </p>
            </div>
            `)
        );

        for (const v of category.ambients) {
            ambientsData[v.id] = v;

            let name = v.name;
            let description = '';
            if (v.date) {
                description = toLocaleDateStringFormatted(new Date(v.date));
            } else if (v.date_from && v.date_to) {
                const from = new Date(v.date_from);
                const to = new Date(v.date_to);
                description = `${toLocaleDateTimeStringFormatted(from)} - ${toLocaleDateTimeStringFormatted(to)}`;
            } else if (v.month && v.day) {
                const d = new Date();
                d.setMonth(v.month - 1);
                d.setDate(v.day);
                description = toLocaleDateStringFormatted(d);
            } else if (ambient_dates[v.id]) {
                const from = new Date(ambient_dates[v.id].date_from);
                const to = new Date(ambient_dates[v.id].date_to);
                name = ambient_dates[v.id].name;
                description = `${toLocaleDateTimeStringFormatted(from)} - ${toLocaleDateTimeStringFormatted(to)}`;
            }

            container.appendChild(
                stringToHTML(`
                <li class="list-collapsible show list-group-item d-flex justify-content-between align-items-center" data-ambient-id="${v.id}" title='${createTitleFromJSON(v)}'>
                    <div class="d-flex align-items-center">
                        <button class="joorney-play-ambient btn me-3"><i class="fa-fw fa-solid fa-play"></i></button>
                        <label class="form-check-label">
                            <p class="m-0" >${name}${todayAmbient?.id === v.id ? ' <span title="This effect is currently active for today" class="badge badge-success rounded-pill">active</span>' : ''}</p>
                            ${description ? `<span class="small text-muted">${description}</span>` : ''}
                        </label>
                    </div>
                    <!--<span class="badge rounded-pill badge-success">Active</span>-->
                    <div class="vc-toggle-container">
                        <label class="vc-switch" style="--vc-width: 75px;">
                            <input type="checkbox" class="vc-switch-input" checked />
                            <span class="vc-switch-label" data-on="Enable" data-off="Disable"></span>
                            <span class="vc-handle"></span>
                        </label>
                    </div>
                </li>
            `)
            );
        }
    }

    for (const el of container.getElementsByClassName('joorney-play-ambient')) {
        el.onclick = playAmbient;
    }
    for (const el of container.getElementsByClassName('ambient-category-all-toggle')) {
        el.onclick = (e) => onSwitchCategory(e, true);
    }
    for (const el of container.getElementsByClassName('ambient-category-none-toggle')) {
        el.onclick = (e) => onSwitchCategory(e, false);
    }
    for (const header of container.getElementsByClassName('ambient-category-toggle')) {
        const icon = header.querySelector('i');
        icon.style.transition = 'transform .25s';
        header.onclick = () => {
            icon.style.transform = icon.style.transform === '' ? 'rotate(-90deg)' : '';

            let sibling = header.parentElement.parentElement.nextElementSibling;
            while (sibling && sibling.tagName.toLowerCase() !== 'div') {
                if (sibling.tagName.toLowerCase() === 'li') {
                    sibling.classList.toggle('show');
                }
                sibling = sibling.nextElementSibling;
            }
        };
    }

    const { ambientStatus } = await StorageSync.get({ ambientStatus: {} });
    updateAmbientState(ambientStatus);
}

function updateAmbientState(ambientStatus) {
    const container = document.getElementById('joorney-ambient-list');
    for (const el of container.getElementsByClassName('vc-switch-input')) {
        const dataElement = el.parentElement.parentElement.parentElement;
        const ambientId = dataElement.dataset.ambientId;
        el.checked = ambientStatus[ambientId] ?? true;
        el.onchange = onSwitch;
    }
}

async function onSwitchCategory(event, enable) {
    const dataElement = event.currentTarget.parentElement.parentElement;
    const ambientsList = ambients[dataElement.dataset.ambientCategoryId].ambients ?? [];
    if (!ambientsList || ambientsList.lenght <= 0) return;

    const { ambientStatus } = await StorageSync.get({ ambientStatus: {} });
    for (const a of ambientsList) {
        ambientStatus[a.id] = enable;
    }
    await StorageSync.set({ ambientStatus });
    updateAmbientState(ambientStatus);
}

async function onSwitch(event) {
    const input = event.currentTarget;
    const dataElement = input.parentElement.parentElement.parentElement;
    const { ambientStatus } = await StorageSync.get({ ambientStatus: {} });
    ambientStatus[dataElement.dataset.ambientId] = input.checked;
    await StorageSync.set({ ambientStatus });
}

function playAmbient(event) {
    disableAllButtons();

    const button = event.currentTarget;
    const dataElement = button.parentElement.parentElement;
    const ambient = ambientsData[dataElement.dataset.ambientId];
    if (!ambient) {
        enableAllButtons();
        return;
    }
    const estimatedDuration = estimateAmbientDuration(ambient);

    document.getElementById('joorney-playing-ambient-info').innerText =
        `Ambient: "${ambient.name}" - Duration: ${estimatedDuration}ms`;

    ambientLoader?.load(ambient);
    const timeout = setCancellableTimeout(() => {
        stopAmbient();
    }, estimatedDuration + 1000);

    const iconClass = button.querySelector('i').classList;
    iconClass.remove('fa-pause');
    iconClass.add('fa-stop');
    button.onclick = () => {
        timeout.trigger();
    };

    button.removeAttribute('disabled');
}

function stopAmbient() {
    ambientLoader.stop();
    document.getElementById('joorney-playing-ambient-info').innerText = '';
    enableAllButtons();
}

function disableAllButtons() {
    for (const btn of document.getElementsByClassName('joorney-play-ambient')) {
        btn.onclick = null;
        btn.setAttribute('disabled', true);
        const iconClass = btn.querySelector('i').classList;
        iconClass.add('fa-pause');
        iconClass.remove('fa-play');
        iconClass.remove('fa-stop');
    }
}

function enableAllButtons() {
    for (const btn of document.getElementsByClassName('joorney-play-ambient')) {
        btn.onclick = playAmbient;
        btn.removeAttribute('disabled');
        const iconClass = btn.querySelector('i').classList;
        iconClass.add('fa-play');
        iconClass.remove('fa-pause');
        iconClass.remove('fa-stop');
    }
}

function setupSlider() {
    const slider = document.querySelector('.images-comparison .slider');
    const leftImageElement = document.querySelector('.images-comparison .left-image');
    const sliderLineElement = document.querySelector('.images-comparison .slider-line');
    const sliderIconElement = document.querySelector('.images-comparison .slider-icon');

    slider.addEventListener('input', (e) => {
        const sliderValue = `${e.target.value}%`;

        leftImageElement.style.width = sliderValue;
        sliderLineElement.style.left = sliderValue;
        sliderIconElement.style.left = sliderValue;
    });
}

async function loadPage$5(features, _currentSettings) {
    loadFeatures$1(features);
}

async function loadFeatures$1(features) {
    for (const feature of features.filter((f) => f.customization.option)) {
        importFeatureCustomizationFile(feature.id).then((featureModule) => featureModule.load());
    }
}

// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
let getRandomValues;
const rnds8 = new Uint8Array(16);
function rng() {
  // lazy load so that environments that need to polyfill have a chance to do so
  if (!getRandomValues) {
    // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation.
    getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);

    if (!getRandomValues) {
      throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
    }
  }

  return getRandomValues(rnds8);
}

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */

const byteToHex = [];

for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).slice(1));
}

function unsafeStringify(arr, offset = 0) {
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];
}

const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
var native = {
  randomUUID
};

function v4(options, buf, offset) {
  if (native.randomUUID && !buf && !options) {
    return native.randomUUID();
  }

  options = options || {};
  const rnds = options.random || (options.rng || rng)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  return unsafeStringify(rnds);
}

// https://github.com/callumlocke/json-formatter

function handleExpanderClick() {
    for (const element of document.getElementsByClassName('expander')) {
        element.onclick = onClickExpander;
    }
}

function onClickExpander(event) {
    event.preventDefault();
    const parent = event.target.parentNode;

    // Expand or collapse
    if (parent.classList.contains('json-collapsed')) {
        // EXPAND
        if (event.metaKey || event.ctrlKey) {
            const gp = parent.parentNode;
            expand(gp.children, event.shiftKey);
            return;
        }
        expand([parent], event.shiftKey);
        return;
    }

    // COLLAPSE
    if (event.metaKey || event.ctrlKey) {
        const gp = parent.parentNode;
        collapse(gp.children, event.shiftKey);
        return;
    }
    collapse([parent], event.shiftKey);
}

// (CSS shows/hides the contents and hides/shows an ellipsis.)
function collapse(elements, recursive = false) {
    for (const el of elements) {
        el.classList.add('json-collapsed');
        if (recursive) {
            for (const sel of el.getElementsByClassName('jsonEntry')) {
                sel.classList.add('json-collapsed');
            }
        }
    }
}

function expand(elements, recursive = false) {
    for (const el of elements) {
        el.classList.remove('json-collapsed');
        if (recursive) {
            for (const sel of el.getElementsByClassName('jsonEntry')) {
                sel.classList.remove('json-collapsed');
            }
        }
    }
}

// https://github.com/callumlocke/json-formatter

const baseSpan = document.createElement('span');

const createBlankSpan = () => baseSpan.cloneNode(false);

const getSpanWithClass = (className) => {
    const span = createBlankSpan();
    span.className = className;
    return span;
};

const getSpanWithBoth = (innerText, className) => {
    const span = createBlankSpan();
    span.className = className;
    span.innerText = innerText;
    return span;
};

const templates = {
    t_entry: getSpanWithClass('jsonEntry'),
    t_exp: getSpanWithClass('expander'),
    t_key: getSpanWithClass('key'),
    t_string: getSpanWithClass('stringValue'),
    t_number: getSpanWithClass('numberValue'),

    t_null: getSpanWithBoth('null', 'nullValue'),
    t_true: getSpanWithBoth('true', 'boolValue'),
    t_false: getSpanWithBoth('false', 'boolValue'),

    t_oBrace: getSpanWithBoth('{', 'brace_bracket'),
    t_cBrace: getSpanWithBoth('}', 'brace_bracket'),
    t_oBracket: getSpanWithBoth('[', 'brace_bracket'),
    t_cBracket: getSpanWithBoth(']', 'brace_bracket'),

    t_sizeComment: getSpanWithClass('comment'),

    t_ellipsis: getSpanWithClass('collectionEllipsis'),
    t_blockInner: getSpanWithClass('innerJSON'),

    t_colonAndSpace: document.createTextNode(':\u00A0'),
    t_commaText: document.createTextNode(','),
    t_dblqText: document.createTextNode('"'),
};

// https://github.com/callumlocke/json-formatter

const getValueType = (value) => {
    if (typeof value === 'string') return TYPE_STRING;
    if (typeof value === 'number') return TYPE_NUMBER;
    if (value === false || value === true) return TYPE_BOOL;
    if (value === null) return TYPE_NULL;
    if (Array.isArray(value)) return TYPE_ARRAY;

    return TYPE_OBJECT;
};

const TYPE_STRING = 1;
const TYPE_NUMBER = 2;
const TYPE_OBJECT = 3;
const TYPE_ARRAY = 4;
const TYPE_BOOL = 5;
const TYPE_NULL = 6;

// https://github.com/callumlocke/json-formatter


function buildDom(value, keyName = false, collapse = false) {
    const type = getValueType(value);

    const entry = templates.t_entry.cloneNode(false);
    if (collapse) entry.classList.add('json-collapsed');

    let collectionSize = 0;
    if (type === TYPE_OBJECT) {
        collectionSize = Object.keys(value).length;
        //entry.classList.add('objProp');
    } else if (type === TYPE_ARRAY) {
        collectionSize = value.length;
        //entry.classList.add('arrElem');
    }

    const nonZeroSize = collectionSize > 0;
    if (nonZeroSize) entry.appendChild(templates.t_exp.cloneNode(false));

    // NB: "" is a legal keyname in JSON
    if (keyName !== false) {
        const keySpan = templates.t_key.cloneNode(false);
        keySpan.textContent = JSON.stringify(keyName).slice(1, -1); // remove quotes

        entry.appendChild(templates.t_dblqText.cloneNode(false));
        entry.appendChild(keySpan);
        entry.appendChild(templates.t_dblqText.cloneNode(false));

        entry.appendChild(templates.t_colonAndSpace.cloneNode(false));
    }

    let blockInner = undefined;
    let childEntry = undefined;

    switch (type) {
        case TYPE_STRING: {
            const innerStringEl = createBlankSpan();

            const escapedString = JSON.stringify(value).slice(1, -1); // remove outer quotes

            if (value.substring(0, 8) === 'https://' || value.substring(0, 7) === 'http://') {
                const innerStringA = document.createElement('a');
                innerStringA.href = value;
                innerStringA.innerText = escapedString;
                innerStringEl.appendChild(innerStringA);
            } else {
                innerStringEl.innerText = escapedString;
            }
            const valueElement = templates.t_string.cloneNode(false);
            valueElement.appendChild(templates.t_dblqText.cloneNode(false));
            valueElement.appendChild(innerStringEl);
            valueElement.appendChild(templates.t_dblqText.cloneNode(false));
            entry.appendChild(valueElement);
            break;
        }

        case TYPE_NUMBER: {
            const valueElement = templates.t_number.cloneNode(false);
            valueElement.innerText = String(value);
            entry.appendChild(valueElement);
            break;
        }

        case TYPE_OBJECT: {
            entry.appendChild(templates.t_oBrace.cloneNode(true));

            if (nonZeroSize) {
                entry.appendChild(templates.t_ellipsis.cloneNode(false));
                blockInner = templates.t_blockInner.cloneNode(false);

                let lastComma;
                for (const k in value) {
                    childEntry = buildDom(value[k], k, collapse);

                    const comma = templates.t_commaText.cloneNode();

                    childEntry.appendChild(comma);

                    blockInner.appendChild(childEntry);

                    lastComma = comma;
                }

                if (childEntry && lastComma) {
                    childEntry.removeChild(lastComma);
                }

                entry.appendChild(blockInner);
            }

            entry.appendChild(templates.t_cBrace.cloneNode(true));

            entry.dataset.size = ` // ${collectionSize} ${collectionSize === 1 ? 'item' : 'items'}`;

            break;
        }

        case TYPE_ARRAY: {
            entry.appendChild(templates.t_oBracket.cloneNode(true));

            if (nonZeroSize) {
                entry.appendChild(templates.t_ellipsis.cloneNode(false));

                blockInner = templates.t_blockInner.cloneNode(false);

                for (let i = 0, length = value.length, lastIndex = length - 1; i < length; i++) {
                    childEntry = buildDom(value[i], false, collapse);

                    if (i < lastIndex) {
                        const comma = templates.t_commaText.cloneNode();
                        childEntry.appendChild(comma);
                    }

                    blockInner.appendChild(childEntry);
                }
                entry.appendChild(blockInner);
            }
            entry.appendChild(templates.t_cBracket.cloneNode(true));

            entry.dataset.size = ` // ${collectionSize} ${collectionSize === 1 ? 'item' : 'items'}`;

            break;
        }

        case TYPE_BOOL: {
            if (value) entry.appendChild(templates.t_true.cloneNode(true));
            else entry.appendChild(templates.t_false.cloneNode(true));
            break;
        }

        case TYPE_NULL: {
            entry.appendChild(templates.t_null.cloneNode(true));
            break;
        }
    }

    return entry;
}

const store = {
    tour_toasts: false,
    tour_toasts_version: 1,
    step_toast_showMe_1: false,
    step_toast_switchMode: false,
    step_toast_disableType: false,
    step_toast_showMe_2: false,
};

const steps = {
    step_toast_showMe_1: {
        id: 'step_toast_showMe_1',
        tour: 'tour_toasts',
        name: 'Notification Look',
        description: 'Display some notifications with your current configuration!',
        trigger: [{ selector: '#joorney-toast-mode-showme', run: 'click' }],
        next: 'step_toast_switchMode',
        progression: 25,
    },
    step_toast_switchMode: {
        id: 'step_toast_switchMode',
        tour: 'tour_toasts',
        name: 'Switch Mode',
        description: 'Change the display of notification, larger or hide in console!',
        trigger: [
            { selector: 'label[for="joorney-toast-mode-log"]', run: 'click' },
            { selector: 'label[for="joorney-toast-mode-small"]', run: 'click' },
            { selector: 'label[for="joorney-toast-mode-large"]', run: 'click' },
        ],
        next: 'step_toast_disableType',
        progression: 25,
    },
    step_toast_disableType: {
        id: 'step_toast_disableType',
        tour: 'tour_toasts',
        name: 'Disable Type',
        description: 'Choose your prefered notifications types!',
        trigger: [
            { selector: 'label[for="joorney-toast-mode-info"]', run: 'click' },
            { selector: 'label[for="joorney-toast-mode-warn"]', run: 'click' },
            { selector: 'label[for="joorney-toast-mode-error"]', run: 'click' },
            { selector: 'label[for="joorney-toast-mode-succss"]', run: 'click' },
        ],
        next: 'step_toast_showMe_2',
        progression: 25,
    },
    step_toast_showMe_2: {
        id: 'step_toast_showMe_2',
        tour: 'tour_toasts',
        name: 'Notification Look',
        description: 'Display some notifications with your current configuration!',
        progression: 25,
    },
};

const tours = {
    tour_hostControls: {
        id: 'tour_hostControls',
        version: 1,
        title: 'Hosts control',
        description: 'Manage feature by host!',
        steps: steps$4,
        store: store$4,
    },
    tour_preferences: {
        id: 'tour_preferences',
        version: 1,
        title: 'Preferences',
        description: 'Setup your preferences for many features.',
        steps: steps$3,
        store: store$3,
    },
    tour_versions: {
        id: 'tour_versions',
        version: 1,
        title: 'Versions',
        description: 'Choose in which version you want to use Joorney!',
        steps: steps$1,
        store: store$1,
    },
    tour_toasts: {
        id: 'tour_toasts',
        version: 1,
        title: 'Notifications',
        description: 'Setup your notification preferences!',
        steps: steps,
        store: store,
    },
    tour_technical: {
        id: 'tour_technical',
        version: 1,
        title: 'Technical / Developers',
        description: 'Welcome to the dark side, we have cookies!',
        steps: steps$2,
        store: store$2,
    },
};

async function getAnnounceData() {
    const source = 'https://raw.githubusercontent.com/MrSweeter/joorney/master/store/announce.json';
    try {
        const { data } = await cache(
            1 * 24 * 60,
            async () => {
                const response = await fetch(source);
                if (!response.ok) return {};
                return await response.json();
            },
            'getAnnounceData'
        );
        return data;
    } catch (error) {
        Console.critical('There was a problem with the fetch operation:', error);
    }
    return {};
}

async function getInstallType() {
    const extension = await Management.getSelf();
    return extension.installType;
}

async function isDevMode() {
    const installType = await getInstallType();
    return installType === 'development';
}

function removeBuildFromVersion(version) {
    return version.split('.').slice(0, 3).join('.');
}

async function getAnnounce() {
    const currentVersion = removeBuildFromVersion(Runtime.getManifest().version);
    const announces = await getAnnounceData();
    const announce = announces[currentVersion];
    if (!announce || !announce.hash) return undefined;
    if (announce.closeable !== false) {
        const status = await getAnnounceCloseStatus(currentVersion);
        if (status) return undefined;
    }
    return { ...announce, version: currentVersion, closeable: announce.closeable === true };
}

const colors = [
    'red',
    'blue',
    'green',
    'yellow',
    'orange',
    'purple',
    'pink',
    'brown',
    'cyan',
    'magenta',
    'lime',
    'indigo',
    'violet',
    'turquoise',
    'maroon',
    'olive',
    'teal',
    'coral',
    'gold',
];

class DoubleProgressBar {
    constructor(progressName, labelID, switcherID, totalBarID, partialBarID, maximum, total, sections) {
        this.label = document.getElementById(labelID);
        this.switcher = document.getElementById(switcherID);
        this.totalBar = document.getElementById(totalBarID);
        this.partialBar = document.getElementById(partialBarID);

        this.maximum = maximum;
        this.total = total;
        this.sections = sections;

        this.loadTotal();
        this.loadPartial();

        this.switcher.onclick = () => this.switch();
        this.label.innerHTML = `${progressName}: ${this.total} / ${this.maximum} bytes`;
    }

    switch() {
        this.totalBar.classList.toggle('d-none');
        this.partialBar.classList.toggle('d-none');
    }

    loadTotal() {
        this.totalBar.innerHTML = '';
        this.totalBar.title = `${this.maximum}`;
        const usageElement = this.getSectionElement(
            `${this.total} / ${this.maximum}`,
            (this.total / this.maximum) * 100,
            'var(--joorney-secondary)'
        );
        usageElement.onclick = () => this.switch();
        this.totalBar.appendChild(usageElement);
    }

    loadPartial() {
        this.partialBar.innerHTML = '';
        this.partialBar.title = `${this.total}`;
        let usageElement = undefined;
        let i = 0;
        for (const section of this.sections) {
            usageElement = this.getSectionElement(
                `${section.label}: ${section.usage} / ${this.total}`,
                (section.usage / this.total) * 100,
                colors[i % colors.length]
            );
            this.partialBar.appendChild(usageElement);
            i++;
        }
    }

    getSectionElement(label, value, color) {
        return stringToHTML(
            `<div title="${label}" class="progress-bar" style="width: ${value}%; background-color: ${color}"></div>`
        );
    }
}

async function loadPage$4(features, currentSettings) {
    loadExperimental(currentSettings);

    handleWindowActionFallback(currentSettings.windowActionFallbacks);

    loadStorage(features, currentSettings);

    await loadChaos();
}

function loadExperimental(currentSettings) {
    const { useSimulatedUI, omniboxFocusCurrentTab, cacheEncodingBase64 } = currentSettings;

    const useSimulatedUIElement = document.getElementById('joorney_experimentalSimulatedUI');
    useSimulatedUIElement.checked = useSimulatedUI;
    useSimulatedUIElement.onchange = (e) => {
        StorageSync.set({ useSimulatedUI: e.target.checked });
    };

    const omniboxElement = document.getElementById('joorney_experimentalOmniboxFocusCurrentTab');
    omniboxElement.checked = omniboxFocusCurrentTab;
    omniboxElement.onchange = (e) => {
        StorageSync.set({ omniboxFocusCurrentTab: e.target.checked });
    };

    const base64Element = document.getElementById('joorney_experimentalBase64CacheEncoding');
    base64Element.checked = cacheEncodingBase64;
    base64Element.onchange = (e) => {
        StorageSync.set({ cacheEncodingBase64: e.target.checked });
    };
}

//#region Storage
async function loadStorage(features, currentSettings) {
    loadFeaturesPreview(features);
    loadConfigurationPreview(currentSettings);
    await loadLocalDataPreview();
    await loadOnboardingProgression();
    handleExpanderClick();

    let sections = [];
    for (const feature of features) {
        sections.push({
            label: feature.display_name,
            usage: await StorageSync.getBytesInUse(Object.keys(feature.defaultSettings)),
        });
    }
    sections.push({
        label: 'Base',
        usage: await StorageSync.getBytesInUse(Object.keys(baseSettings)),
    });

    new DoubleProgressBar(
        'Sync Storage',
        'joorney-sync-storage-progress-label',
        'joorney-sync-storage-progress-switch',
        'joorney-sync-storage-byteUsageTotal',
        'joorney-sync-storage-byteUsageFeature',
        StorageSync.QUOTA_BYTES,
        await StorageSync.getBytesInUse(undefined),
        sections
    );

    sections = [];
    for (const tour of Object.values(tours)) {
        sections.push({
            label: `[Onboard] ${tour.title}`,
            usage: await getStorageUsage(...Object.keys(tour.store)),
        });
    }
    sections.push({
        label: 'Cache',
        usage: await getStorageUsage('joorneyLocalCacheCall'),
    });
    sections.push({
        label: 'Extension Off',
        usage: await getStorageUsage('offs'),
    });
    sections.push({
        label: 'Extension Announcement',
        usage: await getStorageUsage('journey_announces'),
    });
    sections.push({
        label: 'Ambient computed events',
        usage: await getStorageUsage('ambient_dates'),
    });
    sections.push({
        label: 'Sunrise / Sunset ',
        usage: await getStorageUsage('joorney_sunrise', 'joorney_sunset', 'joorney_date'),
    });

    new DoubleProgressBar(
        'Local Storage',
        'joorney-local-storage-progress-label',
        'joorney-local-storage-progress-switch',
        'joorney-local-storage-byteUsageTotal',
        'joorney-local-storage-byteUsageFeature',
        StorageLocal.QUOTA_BYTES,
        await getStorageUsage(),
        sections
    );
}

function loadFeaturesPreview(features) {
    let preview = document.getElementById('joorney-extension-state');
    preview.innerHTML = '';
    preview.appendChild(buildDom(extensionFeatureState, false, true));
    //preview.innerHTML = JSON.stringify(extensionFeatureState, null, 4);
    preview = document.getElementById('joorney-extension-features');
    preview.innerHTML = '';
    preview.appendChild(buildDom(features, false, true));
    //preview.innerHTML = JSON.stringify(features, null, 4);
}

function loadConfigurationPreview(currentSettings) {
    const preview = document.getElementById('joorney-storage-configuration');
    preview.innerHTML = '';
    preview.appendChild(buildDom(currentSettings, false, true));
    //debug.innerHTML = JSON.stringify(currentSettings, null, 4);
}

async function loadLocalDataPreview() {
    const cache = await getLocal();
    const preview = document.getElementById('joorney-storage-local');
    preview.innerHTML = '';
    preview.appendChild(buildDom(cache, false, true));
}

async function loadOnboardingProgression() {
    const progress = await getOnboardingProgressData();
    const preview = document.getElementById('joorney-onboarding-progression');
    preview.innerHTML = '';
    preview.appendChild(buildDom(progress, false, true));
    //debug.innerHTML = JSON.stringify(progress, null, 4);
}
//#endregion

//#region Window Action Fallback
function handleWindowActionFallback(windowActionFallbacks) {
    loadWindowActionFallback(windowActionFallbacks);
    document.getElementById('joorney_window_action_fallback_new_path_save').onclick = createFallback;
}

async function createFallback() {
    const originString = document.getElementById('joorney_window_action_fallback_new_origin')?.value?.trim();
    const path = document.getElementById('joorney_window_action_fallback_new_action_path')?.value?.trim();
    const model = document.getElementById('joorney_window_action_fallback_new_action_model')?.value?.trim();

    if (!originString) {
        renderFallbackError('Missing origin');
        return;
    }

    if (!path) {
        renderFallbackError('Missing path');
        return;
    }

    if (!model) {
        renderFallbackError('Missing model');
        return;
    }

    try {
        const origin = new URL(originString).origin;
        const windowActionFallbacks = await readFallbacks();

        const originsFallbacks = windowActionFallbacks[origin] ?? {};
        originsFallbacks[path] = model;

        windowActionFallbacks[origin] = originsFallbacks;
        await StorageSync.set({ windowActionFallbacks });

        loadWindowActionFallback(windowActionFallbacks);
    } catch (ex) {
        renderFallbackError(ex);
    }
}

function renderFallbackError(errorMessage) {
    const container = document.getElementById('joorney_window_action_fallback_error_footer');
    container.textContent = errorMessage;
    container.style.display = errorMessage ? 'table-cell' : 'none';
}

function loadWindowActionFallback(windowActionFallbacks) {
    const container = document.getElementById('joorney_window_action_fallback_table_body');
    container.innerHTML = '';
    renderFallbackError();

    for (const [k, v] of Object.entries(windowActionFallbacks)) {
        renderOriginFallback(k, v, container);
    }
}

function renderOriginFallback(origin, values, container) {
    if (Object.keys(values).length === 0) return;

    const idx = v4();
    const originID = `joorney_window_action_fallback_origin_delete_${idx}`;
    const originRow = stringToHTML(`
        <tr>
            <td colspan="3" class="text-center fw-bold joorney-valign-middle">${origin}</td>
            <td class="joorney-valign-middle">
                <button
                    class="${originID} btn btn-outline-danger border-0 btn-floating"
                    title="Delete all fallbacks"
                >
                    <i class="joorney-font-icon-size fa fa-trash"></i>
                </button>
            </td>
        </tr>
    `);
    const deleteButton = originRow.getElementsByClassName(originID)[0];
    deleteButton.onclick = () => deleteOriginsFallback(origin);
    container.appendChild(originRow);

    for (const [k, v] of Object.entries(values)) {
        renderFallback(origin, k, v, container);
    }
}

function renderFallback(origin, actionPath, actionModel, container) {
    const idx = v4();
    const originID = `joorney_window_action_fallback_delete_${idx}`;
    const fallbackRow = stringToHTML(`
        <tr>
            <td class="joorney-valign-middle">${origin}</td>
            <td class="joorney-valign-middle">${actionPath}</td>
            <td class="joorney-valign-middle">${actionModel}</td>
            <td class="joorney-valign-middle">
                <button
                    class="${originID} btn btn-outline-danger border-0 btn-floating"
                    title="Delete fallback"
                >
                    <i class="joorney-font-icon-size fa fa-trash"></i>
                </button>
            </td>
        </tr>
    `);
    const deleteButton = fallbackRow.getElementsByClassName(originID)[0];
    deleteButton.onclick = () => deleteFallbackPath(origin, actionPath);
    container.appendChild(fallbackRow);
}

async function readFallbacks() {
    const { windowActionFallbacks } = await StorageSync.get(baseSettings);
    return windowActionFallbacks;
}

async function deleteOriginsFallback(origin) {
    if (confirm(`Are you sure you want to remove origin: ${origin}?`)) {
        const windowActionFallbacks = await readFallbacks();
        delete windowActionFallbacks[origin];
        StorageSync.set({ windowActionFallbacks });

        loadWindowActionFallback(windowActionFallbacks);
    }
}

async function deleteFallbackPath(origin, actionPath) {
    if (confirm(`Are you sure you want to remove path "${actionPath}" for origin "${origin}"?`)) {
        const windowActionFallbacks = await readFallbacks();
        delete windowActionFallbacks[origin]?.[actionPath];
        if (Object.keys(windowActionFallbacks[origin]).length === 0) {
            delete windowActionFallbacks[origin];
        }
        StorageSync.set({ windowActionFallbacks });

        loadWindowActionFallback(windowActionFallbacks);
    }
}
//#endregion

//#region Developer Mode
async function loadChaos() {
    const isdev = await isDevMode();
    const ischaos = new URL(window.location.href).searchParams.get('chaos');
    if (!isdev || !ischaos) return;
    await sleep(5000);
    const chaos = document.getElementById('joorney_chaos_mode');
    if (!chaos) return;
    const actions = [
        { id: 'joorney_chaos_destroy_local_storage', action: () => clearLocal() },
        { id: 'joorney_chaos_destroy_sync_storage', action: () => StorageSync.clear() },
    ];
    for (const action of actions) {
        const actionElement = document.getElementById(action.id);
        actionElement.onclick = (e) => {
            confirmChaos(e.target.innerText, action.action);
        };
        actionElement.classList.remove('d-none');
    }
    chaos.classList.remove('d-none');
}

async function confirmChaos(name, action) {
    if (confirm(`Confirm "${name}". This page will be reloaded!!!`)) {
        const isdev = await isDevMode();
        const ischaos = new URL(window.location.href).searchParams.get('chaos');
        if (isdev && ischaos) {
            action();
            window.location.reload();
        } else {
            alert('DEVELOPMENT MODE NOT ACTIVE');
        }
    }
}
//#endregion

const regexSchemePrefix = 'regex://';

function includeVersion(versions, version, empty = false) {
    const supportedVersions = Array.isArray(versions) ? versions : [versions];
    if (supportedVersions.length === 0) return empty;
    if (supportedVersions.includes(version)) return true;

    const versionNum = sanitizeVersion(version);
    if (ValueIsNaN(versionNum)) return false;

    const uniqueOperator = versions.length === 1;

    for (const supportedVersion of supportedVersions) {
        const sanitizedVersion = sanitizeVersion(supportedVersion);
        if (!sanitizedVersion) continue;
        if (isVersionSupported(sanitizedVersion, versionNum, uniqueOperator)) return true;
    }

    return false;
}

function isVersionSupported(supportedVersion, version, uniqueOperator) {
    const supportedVersionNum = Number.parseFloat(supportedVersion);
    if (ValueIsNaN(supportedVersionNum)) return false;

    const versionNum = Number.parseFloat(version);
    if (ValueIsNaN(versionNum)) return false;

    if (supportedVersion.endsWith('+')) {
        if (uniqueOperator) return versionNum >= supportedVersionNum;
        Console.warn('Version operator "+" cannot be used with other values, with ":" for range');
        return false;
    }

    if (supportedVersion.endsWith('-')) {
        if (uniqueOperator) return versionNum < supportedVersionNum;
        Console.warn('Version operator "-" cannot be used with other values, with ":" for range');
        return false;
    }

    if (supportedVersion.includes(':')) {
        const fromTo = supportedVersion.split(':');
        const minimum = Number.parseFloat(fromTo[0]);
        const maximum = Number.parseFloat(fromTo[1]);
        if (ValueIsNaN(minimum) || ValueIsNaN(maximum)) {
            Console.warn(`Invalid range for operator ":" --> ${supportedVersion}`);
            return false;
        }
        return versionNum >= minimum && versionNum < maximum;
    }
    return versionNum === supportedVersionNum;
}

const html = String.raw;
const css = String.raw;

const toastFadeInOutDurationMillis = 500;
const toastDelayMillis = 100;
const toastDurationMillis = 3000;

const ToastContainerElementID = 'joorney-toast-container';
const ToastItemElementClass = 'joorney-toasty';

const iconForType = {
    success: 'fa fa-check-circle',
    danger: 'fa fa-exclamation-circle',
    warning: 'fa fa-exclamation-triangle',
    info: 'fa fa-info-circle',
};

const ToastStyle = css`
    #${ToastContainerElementID} {
        display: flex;
        flex-direction: column;
        padding: 16px;
        position: fixed;
        top: 32px;
        width: 100%;
        z-index: 9999;
        pointer-events: none;
        font-family: Roboto, sans-serif;
    }

    .${ToastItemElementClass} {
        display: none;
        opacity: 0;
        align-self: end;
        padding: 16px;
        margin-bottom: 10px;
        border-radius: 4px;
        min-width: 300px;
        max-width: 600px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        position: relative;
        overflow: hidden;
        pointer-events: auto;
    }

    .${ToastItemElementClass}-success .toast-progress {
        background-color: #4caf50;
    }

    .${ToastItemElementClass}-danger .toast-progress {
        background-color: #f44336;
    }

    .${ToastItemElementClass}-info .toast-progress {
        background-color: #2196f3;
    }

    .${ToastItemElementClass}-warning .toast-progress {
        background-color: #ff9800;
    }

    .toast-icon {
        margin-right: 10px;
        font-size: 24px;
    }

    .toast-content {
        flex-grow: 1;
        align-content: center;
    }

    .toast-title {
        font-weight: bold;
        margin-bottom: 5px;
    }

    .toast-text {
        max-width: 500px;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .toast-feature span {
        background-color: rgba(128, 128, 128, .25);
    }

    .toast-close {
        cursor: pointer;
        position: absolute;
        top: 8px;
        right: 8px;
        font-size: 16px;
        background: transparent;
        border: none;
    }

    .toast-progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 5px;
        animation: progressBar ${toastDurationMillis}ms linear forwards;
        animation-delay: ${toastDelayMillis + toastFadeInOutDurationMillis}ms;
    }

    @keyframes progressBar {
        from { width: 100%; }
        to { width: 0%; }
    }
  `.trim();

const ToastContainer = html`
    <div id="${ToastContainerElementID}">
        <style>${ToastStyle}</style>
    </div>
`.trim();

function buildContainer() {
    const container = stringToHTML(ToastContainer);
    return container;
}

function buildToastItem(feature, title, message, type, large) {
    const toastID = `toast-${Date.now()}`;
    const textHeight = !large ? 'height: 20px; white-space: nowrap;' : '';
    const item = stringToHTML(html`
        <div id="${toastID}" class="${ToastItemElementClass} ${ToastItemElementClass}-${type} alert-${type}">
            <div class="toast-icon"><i class="${iconForType[type]}"></i></div>
            <div class="toast-content">
                <div>
                    <strong>Joorney: </strong>
                    <span class="toast-feature">
                        <span class="badge rounded-pill">${feature}</span>
                    </span>
                </span>
                <div class="toast-title">${title}</div>
                <div
                    class="toast-text"
                    style="${textHeight}"
                >${message}</div>
            </div>
            <button id="close-${toastID}" class="toast-close"><i class="fa-solid fa-xmark"></i></button>
            <div class="toast-progress"></div>
        </div>
    `);
    return item;
}

const existingToast = {};
const maximumNotification = 3;

const ToastManager = {
    async load() {
        const container = buildContainer();
        const existElement = document.getElementById(container.id);
        if (existElement) existElement.remove();

        document.documentElement.appendChild(container);
        this.toastMode = (await StorageSync.get(baseSettings))?.toastMode ?? 'ui';
        this.toastType = JSON.parse((await StorageSync.get(baseSettings))?.toastType);
    },

    isDisabled() {
        return this.toastMode === 'disabled';
    },

    isLogConsole() {
        return this.toastMode === 'log';
    },

    isLargeMode() {
        return this.toastMode === 'large-ui';
    },

    info(feature, title, message, force = false) {
        return this._notify(feature, title, message, 'info', force);
    },

    warn(feature, title, message, force = false) {
        return this._notify(feature, title, message, 'warning', force);
    },

    error(feature, title, message, force = false) {
        return this._notify(feature, title, message, 'danger', force);
    },

    success(feature, title, message, force = false) {
        return this._notify(feature, title, message, 'success', force);
    },

    async _notify(feature, title, message, type, force) {
        if (this.isDisabled()) return false;
        if (!this.toastType[type]) return false;

        const existing = Object.entries(existingToast).find((entry) => entry[1].msg === message);
        if (existing) {
            if (existing[1].id) clearTimeout(existing[1].id);
            this._updateui(existing, feature);
            return true;
        }

        const isLogConsole = this.isLogConsole();
        if (isLogConsole) {
            this._log(feature, title, message, type);
            return true;
        }

        if (!force && Object.keys(existingToast).length >= maximumNotification) {
            this._log(feature, title, message, type, false);
            this._ui(
                'notification',
                '',
                `You have reached the notification limit (${maximumNotification}). Notification logged to console.`,
                'warning'
            );
            return true;
        }

        if (this.isLargeMode()) {
            this._ui(feature, title, message, type, true);
            return true;
        }

        this._log(feature, title, message, type, false);
        this._ui(feature, title, message, type, false);

        return true;
    },

    _ui(feature, title, message, type, large) {
        const container = document.getElementById(ToastContainerElementID);
        if (!container) return;
        const item = buildToastItem(feature, title, message, type, large);
        container.appendChild(item);
        const toastID = item.id;
        existingToast[toastID] = { msg: message, id: this._show(toastID) };
    },

    _log(feature, title, message, type, antispam = true) {
        const itemID = `log-${Date.now()}`;
        if (antispam) existingToast[itemID] = message;
        switch (type) {
            case 'info':
                Console.info(`(${feature})\n${title}\n${message}`);
                break;
            case 'danger':
                Console.error(`(${feature})\n${title}\n${message}`);
                break;
            case 'warning':
                Console.warn(`(${feature})\n${title}\n${message}`);
                break;
            case 'success':
                Console.success(`(${feature})\n${title}\n${message}`);
                break;
            default:
                Console.log(`[${type}] (${feature})\n${title}\n${message}`);
        }
        if (antispam) {
            setTimeout(() => {
                delete existingToast[itemID];
            }, toastDelayMillis * 1000);
        }
    },

    _show(toastID) {
        const toast = document.getElementById(toastID);
        if (!toast) return;

        toast.style.display = 'flex';
        toast.style.transform = 'translateX(200%)';
        toast.style.transition = `transform ${toastFadeInOutDurationMillis}ms ease-in-out, opacity ${toastFadeInOutDurationMillis}ms ease-in-out`;
        setTimeout(() => {
            toast.style.transform = 'translateX(0%)';
            toast.style.opacity = 1;
        }, toastDelayMillis);

        document.getElementById(`close-${toastID}`).onclick = () => this._hide(toastID);
        toast.onclick = () => this._hide(toastID);

        return setTimeout(
            () => {
                this._hide(toastID);
            },
            toastDelayMillis + toastFadeInOutDurationMillis + toastDurationMillis
        );
    },

    _hide(toastID) {
        const toast = document.getElementById(toastID);
        if (!toast) return;
        toast.style.transform = 'translateX(200%)';
        toast.style.opacity = 0;
        setTimeout(() => {
            toast.remove();
            delete existingToast[toastID];
        }, toastDelayMillis + toastFadeInOutDurationMillis);
    },

    _updateui(existing, feature) {
        const features = document.getElementById(existing[0]).getElementsByClassName('toast-feature')[0];
        const featureBadge = stringToHTML(`
                <span class="badge rounded-pill">${feature}</span>
            `);
        features.appendChild(featureBadge);

        const toast = document.getElementById(existing[0]);
        if (!toast) return true;
        const progress = toast.getElementsByClassName('toast-progress')[0];
        if (!progress) return true;

        progress.style.animation = 'none';
        progress.offsetWidth; // force re-render
        progress.style.animation = '';
        existingToast[existing[0]].id = setTimeout(() => {
            this._hide(existing[0]);
        }, toastDurationMillis + toastFadeInOutDurationMillis);
    },
};

async function loadPage$3(features, currentSettings) {
    ToastManager.load();

    handleToastMode(currentSettings.toastMode);
    handleToastType(JSON.parse(currentSettings.toastType));
}

let joorneyCurrentToastMode = undefined;

function handleToastMode(mode) {
    const radioButtons = document.querySelectorAll('.joorney-toast-mode-control input[type="radio"]');
    for (const radio of radioButtons) {
        radio.checked = mode === radio.value;
        if (radio.checked) joorneyCurrentToastMode = mode;
        radio.onchange = (e) => {
            joorneyCurrentToastMode = e.target.value;
            StorageSync.set({ toastMode: joorneyCurrentToastMode });
            ToastManager.load();
        };
    }

    document.getElementById('joorney-toast-mode-showme').onclick = () => showMockToast();
}

function handleToastType(types) {
    const checkboxes = document.querySelectorAll('.joorney-toast-mode-control input[type="checkbox"]');
    for (const checkbox of checkboxes) {
        checkbox.checked = types[checkbox.dataset.toastType];
        checkbox.onchange = (e) => {
            StorageSync.set({
                toastType: JSON.stringify({ ...types, [e.target.dataset.toastType]: e.target.checked }),
            });
            ToastManager.load();
        };
    }
}

async function showMockToast() {
    if (!joorneyCurrentToastMode) return;
    const types = await StorageSync.get('toastType');
    const toastType = JSON.parse(types.toastType);

    if (
        ToastManager.info(
            'options-demo-info',
            'Update Available',
            `A new software update is available for download.

        This update includes several new features and performance improvements.
        It is recommended to install the update as soon as possible.

        Make sure your device is connected to the internet and has sufficient battery life.
        Click on the update button to start the process.
        <br /><br /><small>Generated by ChatGPT.</small>`,
            true
        )
    )
        await sleep(500);
    if (
        ToastManager.warn(
            'options-demo-warn',
            'Password Expiring',
            `Your profile has been successfully updated.
            All changes have been saved and are now active.
            You can review your updated profile information in the settings section.
            If you encounter any issues, please contact support.
            Thank you for keeping your information current.
            <br /><br /><small>Generated by ChatGPT.</small>`,
            true
        )
    )
        await sleep(500);

    if (
        ToastManager.error(
            'options-demo-error',
            'Connection Lost',
            `Your password will expire in 3 days.
            Please update it to ensure continued access to your account.
            It is recommended to choose a strong and unique password that you haven't used before.
            If you do not update your password, you may be locked out of your account.
             Go to the settings page to change your password.
            <br /><br /><small>Generated by ChatGPT.</small>`,
            true
        )
    )
        await sleep(500);

    if (toastType.success) {
        ToastManager.success(
            'options-demo-success',
            'Profile Updated',
            `Unable to connect to the server.
            Please check your internet connection and try again.
            If the problem persists, it might be due to server maintenance or network issues on our end.
            We apologize for the inconvenience.
            You can retry the connection or contact support for further assistance.
            <br /><br /><small>Generated by ChatGPT.</small>`,
            true
        );
    }
}

async function loadPage$2(features, currentSettings) {
    loadSupportedOdoo(currentSettings, features);
    loadSupportedFeature(features, currentSettings.supportedVersions);
}

function loadSupportedOdoo(currentSettings, features) {
    const versionContainer = document.getElementById('joorney-odoo-versions');
    const supported = currentSettings.supportedVersions;

    for (const version of SUPPORTED_VERSION) {
        const versionID = sanitizeVersionID(version);
        const versionElement = stringToHTML(`
			<label
				title="[Odoo Version] ${version}"
				for="joorney_${versionID}_version"
				style="width: 200px"
			>
				<input id="joorney_${versionID}_version" class="input-hide" type="checkbox" />
				<div class="odoo-version-wrapper d-flex align-items-center justify-content-center">
					<i class="joorney-font-icon-size fa-regular me-2"></i>
					<p>${version}</p>
				</div>
			</label>
		`);
        versionContainer.appendChild(versionElement);

        const versionInput = document.getElementById(`joorney_${versionID}_version`);
        versionInput.checked = supported.includes(version);
        versionInput.onchange = async (e) => {
            const { supportedVersions } = await StorageSync.get(baseSettings);
            let versions = new Set(supportedVersions);
            e.target.checked ? versions.add(version) : versions.delete(version);
            versions = Array.from(versions);
            await StorageSync.set({ supportedVersions: versions });
            await loadSupportedFeature(features, versions);
        };
    }
}

async function loadSupportedFeature(features, supportedVersions) {
    const versionContainerHead = document.getElementById('joorney-feature-versions-head');
    versionContainerHead.innerHTML = '';

    const header = stringToHTML(`
        <tr>
            <th class="text-end opacity-50">Compatibility</th>
            <th class="text-center" style="width: 32px"><i class="fa-solid fa-icons"></i></th>
            ${SUPPORTED_VERSION.map((v) => `<th class="text-center">${v}</th>`).join('')}
        </tr>
    `);
    versionContainerHead.appendChild(header);

    const versionContainerBody = document.getElementById('joorney-feature-versions-body');
    versionContainerBody.innerHTML = '';

    for (const feature of features.filter((f) => !f.limited)) {
        const versions = SUPPORTED_VERSION.map((v) => {
            return {
                odoo: includeVersion(supportedVersions, v),
                feature: includeVersion(feature.supported_version, v, true),
            };
        });
        const versionRow = stringToHTML(`
            <tr>
                <th class="text-end">
                    <span>${feature.display_name ?? feature.id}</span>
                </th>
                <th>
                    <div class="icon-wrapper">
                        ${feature.icon}
                    </div>
                </th>
                ${versions
                    .map(
                        (v) =>
                            `<td class="text-center table-${v.feature ? (v.odoo ? 'success' : 'warning') : 'danger'}">
                                <span class="opacity-25">${v.feature}</span>
                            </td>`
                    )
                    .join('')}
            </tr>
		`);
        versionContainerBody.appendChild(versionRow);
    }
}

function sanitizeVersionID(version) {
    return version.replace('.', '_');
}

function disableFeatureInput(feature) {
    const inputs = Array.from(document.getElementsByClassName(`joorney_origins_filter_feature_input_${feature}`));
    for (const i of inputs) {
        i.disabled = true;
        i.classList.add('feature-disabled');
    }

    document.getElementById(`joorney_origins_filter_feature_header_${feature}`).style.opacity = 0.5;
}

function enableFeatureInput(feature) {
    const inputs = Array.from(document.getElementsByClassName(`joorney_origins_filter_feature_input_${feature}`));

    for (const i of inputs) {
        i.disabled = false;
        i.classList.remove('feature-disabled');
    }

    document.getElementById(`joorney_origins_filter_feature_header_${feature}`).style.opacity = 1;
}

//#region Drag and Drop
function setupDragAndDrop() {
    const whitelistFeature = document.getElementById('joorney-whitelist-feature');
    whitelistFeature.ondrop = (e) => {
        dropElement(e, true, true);
    };
    whitelistFeature.ondragover = allowDropInArea;

    const blacklistFeature = document.getElementById('joorney-blacklist-feature');
    blacklistFeature.ondrop = (e) => {
        dropElement(e, true, false);
    };
    blacklistFeature.ondragover = allowDropInArea;

    const disableFeature = document.getElementById('joorney-disable-feature');
    disableFeature.ondrop = (e) => {
        dropElement(e, false, undefined);
    };
    disableFeature.ondragover = allowDropInArea;
}

function allowDropInArea(e) {
    e.preventDefault();
}

function startDrag(e) {
    e.dataTransfer.setData('text/feature', e.currentTarget.getAttribute('data-feature'));
    e.dataTransfer.setData('text/id', e.currentTarget.id);
}

async function dropElement(e, enable, isWhitelist) {
    e.preventDefault();
    const dataFeature = e.dataTransfer.getData('text/feature');
    const dataID = e.dataTransfer.getData('text/id');
    const container = e.currentTarget;
    await StorageSync.set({
        [`${dataFeature}Enabled`]: enable,
        [`${dataFeature}WhitelistMode`]: isWhitelist,
    });
    if (enable) enableFeatureInput(dataFeature);
    else disableFeatureInput(dataFeature);
    const element = document.getElementById(dataID);
    if (container.id === element.parentElement.id) return;
    container.appendChild(document.getElementById(dataID));
    updateInputColor(dataFeature, enable, isWhitelist);
}
//#endregion

//#region Element dragging
const dragStart = (e) => e.currentTarget.classList.add('feature-dragging');
const dragEnd = (e) => e.currentTarget.classList.remove('feature-dragging');
for (const card of document.querySelectorAll('.draggable-feature')) {
    card.addEventListener('dragstart', dragStart);
    card.addEventListener('dragend', dragEnd);
}

/*const dragEnter = (e) => e.currentTarget.classList.add('drop');
const dragLeave = (e) => e.currentTarget.classList.remove('drop');
for (const column of document.querySelectorAll('.joorney-state-feature')) {
    column.addEventListener('dragenter', dragEnter);
    column.addEventListener('dragleave', dragLeave);
};*/
//#endregion

//#region Update Origins
async function updateFeatureOriginInputs(featureID, isEnable, isWhitelist) {
    updateInputColor(featureID, isEnable, isWhitelist);

    if (isEnable) enableFeatureInput(featureID);
    else disableFeatureInput(featureID);
}

function updateInputColor(feature, isEnable, isWhitelist) {
    for (const el of document.getElementsByClassName(`joorney_origins_filter_feature_input_${feature}`)) {
        el.classList.remove('joorney_f_whitelist');
        el.classList.remove('joorney_f_blacklist');
        el.classList.remove('joorney_f_disable');
        let toAdd = 'joorney_f_disable';
        if (isEnable) {
            if (isWhitelist) {
                toAdd = 'joorney_f_whitelist';
            } else {
                toAdd = 'joorney_f_blacklist';
            }
        }
        el.classList.add(toAdd);
    }
}
//#endregion

//#region CRUD
async function createOriginsFilterOrigin() {
    const origin = document.getElementById('joorney_origins_filter_new_origin');
    let originString = origin.value.trim();
    if (!originString) {
        renderOriginsFilterError('Missing origin');
        return;
    }

    const origins = await readOriginsFilterOrigins();

    if (originString.startsWith(regexSchemePrefix)) {
        let regexString = originString.replace(regexSchemePrefix, '');
        try {
            regexString = regexSchemePrefix + new RegExp(regexString).source;
            origins[regexString] = {};
            await renderOriginsObject(origins);
            origin.value = '';
        } catch (ex) {
            renderOriginsFilterError(ex);
        }
        return;
    }

    originString = originString.trim().toLowerCase().replace(/\s/g, '');

    if (origins[originString]) {
        renderOriginsFilterError('Origin already added');
        return;
    }

    try {
        originString = new URL(originString).origin;
        origins[originString] = {};
        await renderOriginsObject(origins);
        origin.value = '';
    } catch (ex) {
        renderOriginsFilterError(ex);
    }
}

async function readOriginsFilterOrigins() {
    const { originsFilterOrigins } = await StorageSync.get(baseSettings);
    return originsFilterOrigins;
}

async function deleteOriginsFilterOrigin(origin) {
    if (confirm(`Are you sure you want to remove origin: ${origin}?`)) {
        const origins = await readOriginsFilterOrigins();
        delete origins[origin];
        await renderOriginsObject(origins);
    }
}
//#endregion

//#region Event
function onKeydownHost(event) {
    if (event.key === 'Enter') createOriginsFilterOrigin();
}
async function load$1() {
    const originsFilterNewOrigin = document.getElementById('joorney_origins_filter_new_origin');
    originsFilterNewOrigin.onkeydown = onKeydownHost;

    document.getElementById('joorney_origins_filter_new_origin_save').onclick = createOriginsFilterOrigin;

    await restore();
}

async function restore() {
    const configuration = await StorageSync.get(baseSettings);

    await renderOriginsObject(configuration.originsFilterOrigins);
}
//#endregion

//#region UI
function renderOriginsFilterError(errorMessage) {
    const container = document.getElementById('joorney_origins_filter_error_footer');
    container.textContent = errorMessage;
    container.style.display = errorMessage ? 'table-cell' : 'none';
}

function updateColSpan(count) {
    const footers = document.querySelectorAll('tfoot tr td:first-child');
    footers[0].colSpan = `${count + 2}`;
    footers[1].colSpan = `${count + 1}`;
    footers[2].colSpan = `${count + 2}`;
}

async function renderOriginsObject(origins) {
    const originsArray = [];
    for (const o of Object.keys(origins)) originsArray.push({ ...origins[o], origin: o });

    await StorageSync.set({ originsFilterOrigins: origins });

    const response = await sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.GET_FEATURES_LIST);
    const features = response.features.filter((f) => !f.limited);

    const tableHeader = document.querySelector('#joorney_origins_filter_table thead tr');
    tableHeader.innerHTML = '';
    tableHeader.appendChild(
        stringToHTML(`<th class="joorney-origins_filter-origin-input" title="Odoo Database Origin">Origins</th>`)
    );
    for (const f of features) tableHeader.appendChild(generateFeatureOptionTableHeadItem(f));
    tableHeader.appendChild(stringToHTML(`<th class="py-0 joorney-valign-middle action-head"></th>`));

    const container = document.getElementById('joorney_origins_filter_table_body');
    container.innerHTML = '';
    for (const [id, o] of originsArray.entries())
        container.appendChild(
            renderOrigin(
                id,
                o,
                features.map((f) => f.id)
            )
        );
    renderOriginsFilterError();
    updateColSpan(features.length);

    const defaultConfiguration = await getCurrentSettings(features);

    for (const feature of features) {
        const enabled = defaultConfiguration[`${feature.id}Enabled`];
        const isWhitelist = defaultConfiguration[`${feature.id}WhitelistMode`];

        updateFeatureOriginInputs(feature.id, enabled, isWhitelist);
    }
}

function setupOriginFeature(container, idx, feature, origin) {
    const checkInput = container.getElementsByClassName(`joorney_origins_filter_origin_${idx}_${feature}`)[0];
    checkInput.onchange = (e) => updateOriginFeature(idx, origin, feature, e.currentTarget.checked);
}

async function updateOriginFeature(idx, origin, feature, checked) {
    // Disable row on update to avoid spamming/inconsistency if StorageSync.set take time
    const rowInputs = Array.from(
        document.getElementsByClassName(`joorney_origins_filter_feature_input_${idx} `)
    ).filter((i) => !i.className.includes('feature-disabled'));
    for (const i of rowInputs) i.disabled = true;

    const origins = await readOriginsFilterOrigins();
    origins[origin][feature] = checked;
    await StorageSync.set({ originsFilterOrigins: origins });

    for (const i of rowInputs) i.disabled = false;
}

function renderOrigin(idx, origin, features) {
    const originTemplate = document.createElement('template');

    const featuresUI = features
        .map((f) =>
            `
			<td>
				<input
					class="
					    joorney_origins_filter_feature_input_${idx}
                        joorney_origins_filter_feature_input_${f}
                        joorney_origins_filter_origin_${idx}_${f}
                        m-0 form-check-input
                    "
                    ${!document.getElementById(`joorney_${f}_feature`)?.checked ? 'disabled' : ''}
					type="checkbox"
					${origin[f] === true ? 'checked' : ''}
				/>
			</td>
		`.trim()
        )
        .join('\n');

    originTemplate.innerHTML = `
		<tr>
			<td class="p-1 joorney-valign-middle">
				<input
					id="joorney_origins_filter_origin_${idx}"
					class="joorney-bg-white form-control border border-0 joorney_origins_filter_origin_input"
					type="text"
					disabled
					value="${origin.origin}"
				/>
			</td>
			${featuresUI}
			<td class="p-1 joorney-valign-middle">
				<button
					class="joorney_origins_filter_origin_delete_${idx} btn btn-outline-danger border-0 btn-floating"
					title="Delete origin"
				>
					<i class="joorney-font-icon-size fa fa-trash"></i>
				</button>
			</td>
		</tr>
	`.trim();

    const originElement = originTemplate.content.firstChild;

    for (const f of features) setupOriginFeature(originElement, idx, f, origin.origin);

    const deleteButton = originElement.getElementsByClassName(`joorney_origins_filter_origin_delete_${idx}`)[0];
    deleteButton.onclick = () => deleteOriginsFilterOrigin(origin.origin);

    return originElement;
}
//#endregion

async function loadPage$1(features, _currentSettings) {
    await load$1();

    loadFeatures(features);

    setupDragAndDrop();
}

async function loadFeatures(features) {
    for (const feature of features) {
        importFeatureOptionFile(feature.id).then((featureModule) => featureModule.load());
    }
}

const PAGES = [
    {
        id: 'page-website',
        menu: 'page-website',
        tour: 'tour_hostControls',
        label: 'Hosts control',
        path: './pages/website/index.html',
        loader: loadPage$1,
        default: true,
    },
    {
        id: 'page-configuration',
        menu: 'page-configuration',
        tour: 'tour_preferences',
        label: 'Preferences',
        path: './pages/configuration/index.html',
        loader: loadPage$5,
    },
    {
        id: 'page-version',
        menu: 'page-version',
        tour: 'tour_versions',
        label: 'Versions',
        path: './pages/version/index.html',
        loader: loadPage$2,
    },
    {
        id: 'page-toast',
        menu: 'page-toast',
        tour: 'tour_toasts',
        label: 'Notifications',
        path: './pages/toast/index.html',
        loader: loadPage$3,
    },
    {
        id: 'page-ambient',
        menu: 'page-ambient',
        tour: undefined,
        label: 'Ambient',
        path: './pages/ambient/index.html',
        loader: loadPage$6,
    },
    {
        id: 'page-technical',
        menu: 'page-technical',
        tour: 'tour_technical',
        label: 'Developers',
        path: './pages/technical/index.html',
        loader: loadPage$4,
        technical: true,
    },
];

class ChecklistContent {
    constructor(id) {
        const tour = tours[id];
        if (!tour) {
            Console.warn(`No tour: ${id}`);
            Checklist.manager.hide();
            return;
        }
        if (Object.keys(tour.steps).length <= 0) {
            Console.warn(`Empty tour: ${id}`);
            Checklist.manager.hide();
            return;
        }
        Checklist.manager.toggle(true);
        this.tour = tour;

        this.load();
    }

    async load() {
        await this.congrats(false);
        document.getElementById('joorney_checklist_tour_title').innerText = this.tour.title;
        document.getElementById('joorney_checklist_tour_description').innerText = this.tour.description;

        const stepIDs = Object.keys(this.tour.steps);
        const tourStore = stepIDs.length > 0 ? await StorageLocal.get(this.tour.store) : {};
        const stepCount = stepIDs.length > 0 ? stepIDs.length : 1;

        this.progressInc = (1 / stepCount) * 100;
        this.progressStatePct = 0;
        this.updateProgress();

        this.updateSteps(this.tour.steps, tourStore);

        const titleIcon = document.getElementById('joorney_checklist_tour_title_markall_done');
        titleIcon.onclick = async () => {
            for (const step of Object.values(this.tour.steps)) {
                const isComplete = await this.markDone(step);
                if (!isComplete) await sleep(100);
            }
        };
        titleIcon.className = 'fa-solid fa-clipboard-list fa-2xs';
        titleIcon.title = 'Wave a magic wand and deem all steps magically done!';

        const tourState = tourStore[this.tour.id];
        const lastTourVersion = tourStore[`${this.tour.id}_version`];
        const tourVersion = this.tour.version;

        Checklist.manager.toggle(!tourState || lastTourVersion < tourVersion);
    }

    updateProgress() {
        document.getElementById('joorney_checklist_tour_progress').style.width = `${this.progressStatePct}%`;
    }

    updateSteps(steps, tourStore) {
        document.getElementById('joorney_checklist_steps_list').innerHTML = '';
        const stepArray = Object.values(steps);
        if (stepArray.length <= 0) return;
        for (const step of stepArray) {
            this.createStep(step, tourStore[step.id]);
            this.lockStep(step);
            if (tourStore[step.id]) this.markDone(step);
        }

        this.loadNextStep(stepArray[0]);
    }

    createStep(step, done) {
        const stepElement = stringToHTML(`
			<div class="checklist-item">
				<input type="checkbox" id="${step.id}" ${done ? 'checked' : ''} ${done ? 'disabled' : ''} />
				<label for="${step.id}">
					<p class="m-0">${step.name} <i class="joorney_checklist_target_btn fa-solid fa-arrows-to-eye fa-xs d-none"></i></p>
					<small class="text-muted">${step.description}</small>
				</label>
			</div>
		`);
        if (step.trigger && step.trigger.length > 0 && Checklist.bubble) {
            const inspectButton = stepElement.querySelector('.joorney_checklist_target_btn');
            inspectButton.onclick = (e) => {
                e.preventDefault();
                this.inspect(step.trigger[0], e.target);
            };
            inspectButton.classList.remove('d-none');
        }
        document.getElementById('joorney_checklist_steps_list').appendChild(stepElement);
        if (!done) this.loadTrigger(step);
    }

    loadTrigger(step) {
        const triggers = step.trigger?.filter((t) => t.run) ?? [];
        const added = {};

        function removeTriggers() {
            for (const [triggerStr, fct] of Object.entries(added)) {
                const trigger = JSON.parse(triggerStr);
                const triggerElement = document.querySelector(trigger.selector);
                if (!triggerElement) continue;
                triggerElement.removeEventListener(trigger.run, fct);
            }
        }

        const next = () => {
            removeTriggers();
            this.markDoneAndNext(step);
        };

        for (const trigger of triggers) {
            const triggerElement = document.querySelector(trigger.selector);
            if (!triggerElement) continue;

            const run = () => next();
            added[JSON.stringify(trigger)] = run;
            triggerElement.addEventListener(trigger.run, run);
        }

        document.getElementById(step.id).onchange = (e) => {
            if (e.target.checked) next();
            else {
                this.progressStatePct -= step.progression ?? this.progressInc;
                this.updateProgress();
            }
        };
    }

    async markDone(step) {
        await StorageLocal.set({ [step.id]: true });

        const stepElement = document.getElementById(step.id);
        stepElement.setAttribute('disabled', true);
        stepElement.setAttribute('checked', true);
        const parentElement = stepElement.parentElement;
        parentElement.classList.remove('locked');

        this.progressStatePct += step.progression ?? this.progressInc;
        this.updateProgress();

        if (this.progressStatePct >= 100) {
            await this.completeTour();
            return true;
        }
        return false;
    }

    async markDoneAndNext(step) {
        const bubbleShow = Checklist.bubble.isShow();
        this.inspect(null);

        const isComplete = await this.markDone(step);
        if (isComplete) return;

        const next = this.tour.steps[step.next];
        this.loadNextStep(next, bubbleShow);
    }

    async loadNextStep(step, bubbleShow) {
        const tourStore = await StorageLocal.get(this.tour.store);
        let next = step;
        while (next && tourStore[next.id]) {
            next = this.tour.steps[next.next];
        }

        if (next) this.unlockStep(next, bubbleShow);
    }

    unlockStep(step, bubbleShow) {
        const stepElement = document.getElementById(step.id);
        stepElement.removeAttribute('disabled');
        const parentElement = stepElement.parentElement;
        parentElement.classList.remove('locked');

        if (step.trigger && step.trigger.length > 0 && bubbleShow) {
            const inspectButton = parentElement.querySelector('.joorney_checklist_target_btn');
            this.inspect(step.trigger[0], inspectButton);
        }
    }

    lockStep(step) {
        const stepElement = document.getElementById(step.id);
        stepElement.setAttribute('disabled', true);
        const parentElement = stepElement.parentElement;
        parentElement.classList.add('locked');
    }

    async completeTour() {
        await StorageLocal.set({ [this.tour.id]: true, [`${this.tour.id}_version`]: this.tour.version });
        await this.congrats(true);
        const titleIcon = document.getElementById('joorney_checklist_tour_title_markall_done');
        titleIcon.onclick = null;
        titleIcon.title = '';
        titleIcon.className = 'fa-solid fa-clipboard-check text-success fa-2xs';
    }

    async congrats(isShow) {
        const congratsElement = document.getElementById('joorney_checklist_congrats');
        congratsElement.classList.toggle('mt-3', isShow);
        congratsElement.style.height = isShow ? null : 0;
        congratsElement.style.maxHeight = isShow ? '1000px' : 0;
        document.getElementById('joorney_checklist_congrats_separator').classList.toggle('d-none', !isShow);
        document.getElementById('joorney_checklist_congrats_blur').classList.toggle('d-none', !isShow);

        const mainButton = document.getElementById('joorney_checklist_congrats_primary');
        const secondaryButton = document.getElementById('joorney_checklist_congrats_secondary');
        const nextTourID = await getNextTourID();
        if (nextTourID) {
            mainButton.innerText = 'Next';
            mainButton.onclick = () => {
                if (isShow) this.nextTour(nextTourID);
            };
            secondaryButton.innerText = 'Restart';
            secondaryButton.onclick = () => {
                if (isShow) this.restart();
            };
            secondaryButton.classList.remove('d-none');
        } else {
            mainButton.innerText = 'Restart';
            mainButton.onclick = () => {
                if (isShow) this.restart();
            };
            secondaryButton.classList.add('d-none');
            secondaryButton.onclick = () => {};
        }

        const progress = document.getElementById('joorney_checklist_tour_progress');
        progress.classList.toggle('progress-bar-striped', isShow);
        progress.classList.toggle('bg-success', isShow);
    }

    async restart() {
        const stepIDs = Object.keys(this.tour.store);
        await StorageLocal.remove(stepIDs);
        await this.congrats(false);
        this.load();
    }

    async nextTour(nextTourID) {
        if (!nextTourID) return;
        const tourMenu = PAGES.find((m) => m.tour === nextTourID);
        if (!tourMenu) return;

        document.getElementById(tourMenu.id).click();
    }

    inspect(trigger, btn = false) {
        if (!Checklist.bubble) return;
        if (trigger === null || Checklist.bubble.isShow()) {
            Checklist.bubble.close();

            const inspectButtons = document.getElementsByClassName('joorney_checklist_target_btn');
            for (const btn of inspectButtons) {
                btn.classList.remove('active');
            }

            return;
        }
        const target = document.querySelector(trigger.selector);
        if (!target) return;
        if (btn) btn.classList.add('active');
        target.scrollIntoView({ behavior: 'smooth', block: trigger.align ?? 'center' });
        Checklist.bubble.move(target);
    }
}

class ChecklistManager {
    static load() {
        Checklist.manager = new ChecklistManager(document.getElementById('joorney_checklist'));
        Checklist.bubble = new Bubble();
    }

    static onboard(tourID) {
        Checklist.bubble.close();
        Checklist.content = new ChecklistContent(tourID);
    }

    constructor(element) {
        this.element = element;
        this.newX = 0;
        this.newY = 0;
        this.previousX = 0;
        this.previousY = 0;

        this.windowWidth = 0;
        this.windowHeight = 0;
        this.modalWidth = 0;
        this.modalHeight = 0;

        this.menuHeight = document.getElementById('joorney-navig-menu').offsetHeight;

        this.beginDrag = this.beginDrag.bind(this);
        this.moving = this.moving.bind(this);
        this.endDrag = this.endDrag.bind(this);

        this.init();
    }

    init() {
        this.loadSize();
        document.getElementById('joorney_checklist_show_btn').onclick = () => this.toggle(true);
        document.getElementById('joorney_checklist_hide_btn').onclick = () => this.toggle(false);

        window.addEventListener('resize', () => {
            this.reposition();
            Checklist.bubble?.reposition();
        });
        window.addEventListener('scroll', () => {
            Checklist.bubble?.reposition();
        });
    }

    toggle(isOpen = undefined) {
        this.element.style.top = null;
        this.element.style.left = null;
        if (isOpen) {
            document.getElementById('joorney_checklist_show_btn').classList.add('d-none');
            this.element.classList.remove('d-none');
        } else {
            document.getElementById('joorney_checklist_show_btn').classList.remove('d-none');
            this.element.classList.add('d-none');
        }

        this.reset();
    }

    hide() {
        document.getElementById('joorney_checklist_show_btn').classList.add('d-none');
        this.element.classList.add('d-none');
    }

    show() {
        document.getElementById('joorney_checklist_show_btn').classList.remove('d-none');
    }

    beginDrag(e) {
        e.preventDefault();
        this.previousX = e.clientX;
        this.previousY = e.clientY;
        this.loadSize();
        document.onmouseup = this.endDrag;
        document.onmousemove = this.moving;
    }

    moving(e) {
        e.preventDefault();
        this.newX = this.previousX - e.clientX;
        this.newY = this.previousY - e.clientY;
        this.previousX = e.clientX;
        this.previousY = e.clientY;

        this.safeMove(this.element.offsetLeft - this.newX, this.element.offsetTop - this.newY, false);
    }

    endDrag() {
        document.onmouseup = null;
        document.onmousemove = null;
    }

    reposition() {
        this.loadSize();
        this.safeMove(
            Number.parseFloat(this.element.style.left.replace('px', '')),
            Number.parseFloat(this.element.style.top.replace('px')),
            true
        );
    }

    async reset() {
        await sleep(100);
        this.element.onmousedown = this.beginDrag; //ODO[REF] DRAGGING BOUND
        ChecklistManager.bubble?.close();
        this.align(true, true, false, false);
    }

    align(top, right, bottom, left, transition = true) {
        this.loadSize();
        this.safeMove(
            left ? 0 : right ? Number.MAX_SAFE_INTEGER : undefined,
            top ? 0 : bottom ? Number.MAX_SAFE_INTEGER : undefined,
            transition
        );
    }

    safeMove(x, y, transition = false) {
        const margin = 12;
        const vmargin = this.menuHeight + margin;

        this.move(
            Math.min(Math.max(x, margin), this.windowWidth - this.modalWidth - margin),
            Math.min(Math.max(y, vmargin), this.windowHeight - this.modalHeight - margin),
            transition
        );
    }

    move(x, y, transition) {
        if (transition) this.element.style.transition = 'top 0.5s ease, left 0.5s ease';
        if (y || y === 0) this.element.style.top = `${y}px`;
        if (x || x === 0) this.element.style.left = `${x}px`;
        if (transition) {
            setTimeout(() => {
                this.element.style.transition = null;
            }, 500);
        }
    }

    loadSize() {
        this.windowWidth = window.innerWidth;
        this.windowHeight = window.innerHeight;
        this.modalWidth = this.element.offsetWidth;
        this.modalHeight = this.element.offsetHeight;

        this.menuHeight = document.getElementById('joorney-navig-menu').offsetHeight;
    }
}

function importOptions(file) {
    const reader = new FileReader();
    reader.onload = async (eventRead) => {
        const resJson = JSON.parse(eventRead.target.result);
        await StorageSync.set(resJson);
        const tabs = await Tabs.query({ active: true, lastFocusedWindow: true });
        Tabs.reload(tabs[0].id);
    };
    reader.readAsText(file);
}

async function exportOptions() {
    const { currentSettings } = await getFeaturesAndCurrentSettings();

    const dataStr = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(currentSettings))}`;
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute('href', dataStr);
    const version = Runtime.getManifest().version.replaceAll('.', '-');
    const fileName = `joorney_storage_sync_${version}_${new Date().toLocaleDateString()}.json`;
    downloadAnchorNode.setAttribute('download', fileName);
    document.body.appendChild(downloadAnchorNode); // required for firefox
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
}

function confirmImport(file) {
    if (file && confirm('Do you confirm file upload?')) {
        importOptions(file);
    }
}

function setupImportExport() {
    const importInput = document.getElementById('joorney_import_storage_sync_file');
    importInput.onchange = (e) => confirmImport(e.target.files[0]);

    const importButton = document.getElementById('joorney_import_storage_sync');
    importButton.onclick = () => {
        if (!importInput.value.length) {
            importInput.click();
            return;
        }

        confirmImport(importInput.files[0]);
    };

    const exportButton = document.getElementById('joorney_export_storage_sync');
    exportButton.onclick = () => exportOptions();
}

async function checkConfigurationVersion() {
    const { configurationVersion } = await StorageSync.get({
        configurationVersion: baseSettings.configurationVersion,
    });
    if (configurationVersion < baseSettings.configurationVersion) {
        document.getElementById('joorney_migrate_configuration').classList.remove('d-none');
        document.getElementById('joorney_import_storage_sync_file').disabled = true;
        document.getElementById('joorney_import_storage_sync').disabled = true;
    }
}

function initImportExport() {
    setupImportExport();
    checkConfigurationVersion();
}

async function load() {
    const openExtensionShortcut = document.getElementById('open-extension-shortcut');
    openExtensionShortcut.onclick = () => {
        Tabs.create({ url: 'chrome://extensions/shortcuts' });
    };
}

const MENU_ITEMS_CONTAINER = 'joorney-menu-items-container';
const PAGE_CONTAINER = 'joorney-page-container';

async function onDOMContentLoaded() {
    document.getElementById('copyright-year').innerText = new Date().getFullYear();
    //document.getElementById('copyright-link').href = Runtime.getManifest().homepage_url; Not public API

    initImportExport();

    await loadMenus();
    load();

    const searchParams = new URLSearchParams(window.location.search);
    toggleTechnicalMenus(!searchParams.get('debug') && !(await isDevMode()));
    document.getElementById('joorney-brand-debug').onclick = () => toggleTechnicalMenus();

    ChecklistManager.load();

    loadAnnouncement();
    loadManifest();
}

document.removeEventListener('DOMContentLoaded', onDOMContentLoaded);
document.addEventListener('DOMContentLoaded', onDOMContentLoaded);

function toggleTechnicalMenus(force = undefined) {
    for (const element of document.getElementsByClassName('joorney-tech-menu')) {
        element.classList.toggle('d-none', force);
    }
}

async function loadMenus() {
    const container = document.getElementById(MENU_ITEMS_CONTAINER);
    container.innerHTML = '';
    const pageMenus = PAGES.filter((p) => p.menu);
    for (const page of pageMenus) {
        loadMenu(page, container);
    }

    const defaultMenu = await getDefaultMenu(pageMenus);

    document.getElementById(defaultMenu.id).click();
}

async function getDefaultMenu(pageMenus) {
    const defaultMenuTour = await getNextTourID();
    const defaultMenu =
        pageMenus.find((m) => (defaultMenuTour ? m.tour === defaultMenuTour : m.default)) ?? pageMenus[0];

    return defaultMenu;
}

function loadMenu(page, container) {
    const template = document.createElement('template');
    template.innerHTML = `
        <li id="${page.menu}" class="joorney-menu-item ${
            page.technical ? 'joorney-tech-menu' : ''
        } nav-item nav-link">${page.label}</li>
    `.trim();

    template.content.firstChild.onclick = () => {
        loadPage(page);
    };

    container.appendChild(template.content.firstChild);
}

async function loadPage(page) {
    const response = await fetch(page.path);
    const data = await response.text();
    const { features, currentSettings } = await getFeaturesAndCurrentSettings();
    document.getElementById(PAGE_CONTAINER).innerHTML = data;
    page.loader(features, currentSettings);
    if (page.menu) updateActiveMenu(page.menu);
    updateMenuTour(page.tour);
}

function updateActiveMenu(menu) {
    for (const e of document.getElementsByClassName('joorney-menu-item')) {
        if (e.id === menu) e.classList.add('active');
        else e.classList.remove('active');
    }
}

function updateMenuTour(tourID) {
    ChecklistManager.onboard(tourID);
}

async function loadAnnouncement() {
    const announce = await getAnnounce();
    if (!announce) return;
    const announceElement = document.getElementById('joorney-announcement');
    let show = false;
    if (announce.title) {
        document.getElementById('ja-title').innerHTML = announce.title;
        document.getElementById('ja-version').innerText = announce.version ? `[${announce.version}] ` : '';
        document.getElementById('ja-title').parentElement.classList.toggle('d-none');
        show = true;
    }
    if (announce.description) {
        document.getElementById('ja-description').innerHTML = announce.description;
        document.getElementById('ja-description').classList.toggle('d-none');
        show = true;
    }
    if (announce.closeable) {
        document.getElementById('ja-close').onclick = () => {
            closeAnnounce(announce);
            announceElement.parentElement.classList.add('d-none');
        };
        document.getElementById('ja-close').classList.toggle('d-none');
    }
    if (show) announceElement.parentElement.classList.toggle('d-none');
}

async function loadManifest() {
    const manifest = Runtime.getManifest();
    const element = document.getElementById('joorney-manifest');
    element.innerHTML = '';
    const versionElement = stringToHTML(
        `<p class="small m-0 text-muted opacity-25 position-absolute">Joorney ${manifest.version_name} (${manifest.version})`
    );
    element.appendChild(versionElement);
}

function featureIDToPascalCase(id) {
    return id.charAt(0).toUpperCase() + id.slice(1);
}

var adminDebugLoginConfiguration = {
    id: 'adminDebugLoginRunbot',
    display_name: '[Runbot] Admin Debug Login',
    icon: '<i class="fa-solid fa-rocket"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        adminDebugLoginRunbotEnabled: false,
        adminDebugLoginRunbotLimitedOrigins: ['https://runbot.odoo.com', 'regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
    },
    limited: true,
};

var configuration$e = {
    id: 'ambient',
    display_name: 'Ambient',
    icon: '<i class="fa-solid fa-mountain-sun"></i>', // '<i class="fa-solid fa-panorama"></i>'
    trigger: {
        background: false,
        load: true,
        navigate: false,
    },
    customization: {
        option: false,
        popup: false,
    },
    defaultSettings: {
        ambientEnabled: false,
        ambientWhitelistMode: false,
        ambientStatus: {},
    },
    supported_version: [],
};

var configuration$d = {
    id: 'assignMeTask',
    display_name: 'Assign Me Task',
    icon: '<i class="fa-solid fa-user-plus"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        assignMeTaskEnabled: false,
        assignMeTaskWhitelistMode: false,
    },
    supported_version: ['16.3+'],
};

const openRunbotWithVersionMenuItem = {
    id: 'joorney_autoOpenRunbot_open_with_version',
    title: 'Open runbot with version %version%',
    active: true,
    favorite: true,
    order: 100,
};

var autoOpenRunbotConfiguration = {
    id: 'autoOpenRunbot',
    display_name: '[Runbot] Auto Open',
    icon: '<i class="fa-solid fa-fighter-jet"></i>',
    trigger: {
        load: true,
        navigate: true,
        context: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        autoOpenRunbotEnabled: false,
        autoOpenRunbotLimitedOrigins: ['https://runbot.odoo.com'],
        autoOpenRunbotContextMenu: {
            [openRunbotWithVersionMenuItem.id]: openRunbotWithVersionMenuItem,
        },
    },
    limited: true,
};

var configuration$c = {
    id: 'awesomeLoadingLarge',
    display_name: 'Awesome Loading Large',
    icon: '<i class="fa-solid fa-circle-notch"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingSmall',
    defaultSettings: {
        awesomeLoadingLargeEnabled: false,
        awesomeLoadingLargeWhitelistMode: false,
        awesomeLoadingLargeImage: 'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['16:17'],
};

var configuration$b = {
    id: 'awesomeLoadingSmall',
    display_name: 'Awesome Loading Small',
    icon: '<i class="fa-solid fa-spinner"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingLarge',
    defaultSettings: {
        awesomeLoadingSmallEnabled: false,
        awesomeLoadingSmallWhitelistMode: false,
        awesomeLoadingSmallImage: '',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['15+'],
};

var configuration$a = {
    id: 'awesomeStyle',
    display_name: 'Awesome Style',
    icon: '<i class="fa-brands fa-css3-alt"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: true,
    },
    defaultSettings: {
        awesomeStyleEnabled: false,
        awesomeStyleWhitelistMode: false,
        awesomeStyleCSS: '',
    },
    supported_version: ['15+'],
};

var configuration$9 = {
    id: 'contextOdooMenus',
    display_name: 'Context OdooMenus',
    icon: '<i class="fa-solid fa-location-arrow"></i>',
    trigger: {
        background: false,
        load: false,
        navigate: false,
        context: true,
    },
    customization: {
        option: true,
        popup: false,
    },
    defaultSettings: {
        contextOdooMenusEnabled: false,
        contextOdooMenusWhitelistMode: false,
        contextOdooMenusContextMenu: {},
    },
    supported_version: ['15+'],
};

var configuration$8 = {
    id: 'impersonateLoginRunbot',
    display_name: '[Runbot] Impersonate Login',
    icon: '<i class="fa-solid fa-masks-theater"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        impersonateLoginRunbotEnabled: false,
        impersonateLoginRunbotLimitedOrigins: ['regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
    },
    limited: true,
};

var configuration$7 = {
    id: 'newServerActionCode',
    display_name: 'New Server Action Code',
    icon: '<i class="fa-solid fa-code"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        newServerActionCodeEnabled: false,
        newServerActionCodeWhitelistMode: false,
    },
    supported_version: ['16+'],
};

var configuration$6 = {
    id: 'pinMessage',
    display_name: 'Pin Message',
    icon: '<i class="fa-solid fa-thumbtack"></i>',
    trigger: {
        background: false,
        load: true,
        navigate: true,
        context: false,
        onrequest: [
            'https://*/*/mail.message/toggle_message_starred',
            'https://*/mail/message/update_content',
            'https://*/mail/thread/messages',
        ],
    },
    customization: {
        option: false,
        popup: true,
    },
    defaultSettings: {
        pinMessageEnabled: false,
        pinMessageWhitelistMode: false,
        pinMessageContextMenu: {},
        pinMessageSelfAuthorEnabled: true,
        pinMessageDefaultShown: false,
    },
    supported_version: ['17+'],
};

var configuration$5 = {
    id: 'saveKnowledge',
    display_name: 'Save Knowledge',
    icon: '<i class="fa-solid fa-bookmark"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        saveKnowledgeEnabled: false,
        saveKnowledgeWhitelistMode: false,
    },
    supported_version: ['16:17'],
};

var configuration$4 = {
    id: 'showMyBadge',
    display_name: 'Show My Badge',
    icon: '<i class="fa-solid fa-certificate"></i>',
    trigger: {
        background: false,
        load: true,
        navigate: true,
    },
    customization: {
        option: false,
        popup: false,
    },
    defaultSettings: {
        showMyBadgeEnabled: false,
        showMyBadgeWhitelistMode: false,
    },
    supported_version: ['17+'],
};

var configuration$3 = {
    id: 'starringTaskEffect',
    display_name: 'Starring Task Effect',
    icon: '<i class="fa-solid fa-star"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        starringTaskEffectEnabled: false,
        starringTaskEffectWhitelistMode: false,
    },
    supported_version: ['16+'],
};

var configuration$2 = {
    id: 'themeSwitch',
    display_name: 'Theme Switch',
    icon: '<i class="fa-solid fa-sun"></i>',
    trigger: {
        background: true,
        load: false,
        navigate: false,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: "themeSwitchMode: 'system', 'autoDark', 'autoLight', 'dynamicLocation', 'dynamicTime'",
    defaultSettings: {
        themeSwitchEnabled: false,
        themeSwitchWhitelistMode: false,
        themeSwitchMode: 'system',
        themeSwitchLocationLatitude: '51.477928',
        themeSwitchLocationLongitude: '-0.001545',
        themeSwitchDarkStartTime: '20:30',
        themeSwitchDarkStopTime: '07:30',
    },
    supported_version: ['16+'],
};

var configuration$1 = {
    id: 'tooltipMetadata',
    display_name: 'Tooltip Metadata',
    icon: '<i class="fa-solid fa-file-lines"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        tooltipMetadataEnabled: false,
        tooltipMetadataWhitelistMode: false,
    },
    supported_version: ['15+'],
};

var configuration = {
    id: 'unfocusApp',
    display_name: 'Unfocus App',
    icon: '<i class="fa-solid fa-ghost"></i>',
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    defaultSettings: {
        unfocusAppEnabled: false,
        unfocusAppWhitelistMode: false,
        unfocusAppReorderEnabled: false,
        unfocusAppShareEnabled: false,
        unfocusAppLightImageURL: 'https://i.imgur.com/AkTvOga.png',
        unfocusAppDarkImageURL: 'https://i.imgur.com/YzShNtH.png',
        unfocusAppOrigins: {},
    },
    supported_version: ['15+'],
};

class OptionCustomizationFeature {
    constructor(configuration) {
        this.configuration = configuration;
        this.defaultSettings = configuration.defaultSettings;
        if (!configuration.customization.option) throw new Error(`Invalid state for feature: ${this.configuration.id}`);
    }

    async load() {
        const container = document.querySelector(`div[data-feature-customization="${this.configuration.id}"]`);
        if (!container) throw new Error(`Invalid state for feature: ${this.configuration.id}`);
        container.classList.remove('d-none');

        await this.setupCollapse(container);
    }

    async setupCollapse(container) {
        const toggleElement = container.getElementsByClassName('feature-collapse-toggle')[0];
        const contentElements = container.getElementsByClassName('feature-collapse-content');
        const indicatorElement = container.getElementsByClassName('feature-collapse-indicator')[0];

        function toggle() {
            if (indicatorElement.classList.contains('feature-opened')) {
                for (const el of contentElements) el.style.maxHeight = 0;
                indicatorElement.classList.remove('feature-opened');
            } else {
                for (const el of contentElements) el.style.maxHeight = '100%';
                indicatorElement.classList.add('feature-opened');
            }
        }

        toggleElement.onclick = () => toggle();
        for (const el of contentElements) el.style.maxHeight = 0;
    }
}

class AwesomeLoadingShareOptionCustomizationFeature extends OptionCustomizationFeature {
    async load() {
        const container = document.querySelector(`div[data-feature-customization="awesomeLoading"]`);
        if (!container) throw new Error(`Invalid state for feature: ${this.configuration.id}`);
        container.classList.remove('d-none');

        const awesomeLoadingNewImage = document.getElementById('joorney_awe_loading_new_image');
        awesomeLoadingNewImage.onkeydown = (e) => this.onKeydownHost(e);
        awesomeLoadingNewImage.oninput = (e) => this.onImageChange(e);

        document.getElementById('joorney_awe_loading_new_image_save').onclick = () => this.createAwesomeLoadingImage();

        const configuration = await StorageSync.get(this.configuration.defaultSettings);

        this.renderImagesList(configuration.awesomeLoadingImages);

        this.setupCollapse(container);
    }

    //#region CRUD
    async createAwesomeLoadingImage() {
        const imageInput = document.getElementById('joorney_awe_loading_new_image');
        let imageUrl = imageInput.value;
        if (!imageUrl) {
            this.renderAwesomeLoadingError('Missing url');
            return;
        }

        const images = await this.readAwesomeLoadingImages();

        imageUrl = imageUrl.trim().replace(/\s/g, '');

        try {
            imageUrl = new URL(imageUrl).href;
            images.push(imageUrl);
            await this.renderImagesList(images);
            imageInput.value = '';
        } catch (ex) {
            this.renderAwesomeLoadingError(ex);
        }
    }

    async readAwesomeLoadingImages() {
        const { awesomeLoadingImages } = await StorageSync.get({
            awesomeLoadingImages: '',
        });
        return awesomeLoadingImages;
    }

    async deleteAwesomeLoadingImage(imageUrl) {
        if (confirm(`Are you sure you want to remove image: ${imageUrl}?`)) {
            const images = await this.readAwesomeLoadingImages();
            await this.renderImagesList(images.filter((img) => img !== imageUrl));
        }
    }
    //#endregion

    //#region Event
    onKeydownHost(event) {
        if (event.key === 'Enter') this.createAwesomeLoadingImage();
    }
    onImageChange(event) {
        let imageUrl = event.target.value;
        if (!imageUrl) return;

        imageUrl = imageUrl.trim().replace(/\s/g, '');

        try {
            imageUrl = new URL(imageUrl).href;
            const imagePreview = document.getElementById('joorney_awe_loading_new_image_preview');
            imagePreview.src = imageUrl;
        } catch (ex) {
            Console.warn(ex);
        }
    }
    //#endregion

    //#region UI
    renderAwesomeLoadingError(errorMessage) {
        const container = document.getElementById('joorney_awe_loading_error_footer');
        container.textContent = errorMessage;
        container.style.display = errorMessage ? 'table-cell' : 'none';
    }

    async renderImagesList(imagesArg) {
        const images = Array.from(new Set(imagesArg)).sort();
        await StorageSync.set({ awesomeLoadingImages: images });

        const container = document.getElementById('joorney_awe_loading_images_table_body');
        container.innerHTML = '';
        for (const [id, image] of images.entries()) container.appendChild(this.renderImage(id, image));
        this.renderAwesomeLoadingError();
    }

    renderImage(idx, image) {
        const imageTemplate = document.createElement('template');
        imageTemplate.innerHTML = `
            <tr>
                <td class="p-1 joorney-valign-middle">
                    <img class="joorney-awe-loading-preview" loading="lazy" src="${image}" />
                </td>
                <td class="p-1 joorney-valign-middle">
                    <input
                        id="joorney_awe_loading_image_key_${idx}"
                        class="joorney-bg-white form-control border border-0"
                        type="text"
                        disabled
                        value="${image}"
                    />
                </td>
                <td class="p-1 joorney-valign-middle">
                    <button
                        class="joorney_awe_loading_image_delete_${idx} btn btn-outline-danger border-0 btn-floating"
                        title="Delete image"
                    >
                        <i class="joorney-font-icon-size fa fa-trash"></i>
                    </button>
                </td>
            </tr>
        `.trim();

        const imageElement = imageTemplate.content.firstChild;
        const deleteButton = imageElement.getElementsByClassName(`joorney_awe_loading_image_delete_${idx}`)[0];
        deleteButton.onclick = () => this.deleteAwesomeLoadingImage(image);

        return imageElement;
    }
    //#endregion
}

class AwesomeLoadingLargeOptionCustomizationFeature extends AwesomeLoadingShareOptionCustomizationFeature {
    constructor() {
        super(configuration$c);
    }
}

var option_customization$5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeLoadingLargeOptionCustomizationFeature
});

class AwesomeLoadingSmallOptionCustomizationFeature extends AwesomeLoadingShareOptionCustomizationFeature {
    constructor() {
        super(configuration$b);
    }
}

var option_customization$4 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeLoadingSmallOptionCustomizationFeature
});

class AwesomeStyleOptionCustomizationFeature extends OptionCustomizationFeature {
    constructor() {
        super(configuration$a);
    }

    async load() {
        super.load();
        document.getElementById('joorney_awe_style_save').onclick = this.saveAwesomeStyle;

        const configuration = await StorageSync.get(this.configuration.defaultSettings);

        const textareaInput = document.getElementById('joorney_awe_style_css');
        textareaInput.value = configuration.awesomeStyleCSS;
        const linesCount = configuration.awesomeStyleCSS.split(/\r\n|\r|\n/).length;
        textareaInput.setAttribute('rows', Math.max(linesCount + 2, 10));

        textareaInput.onkeydown = (e) => {
            if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                this.saveAwesomeStyle();
            }
        };
    }

    async saveAwesomeStyle() {
        const textareaInput = document.getElementById('joorney_awe_style_css');

        textareaInput.disabled = true;
        await StorageSync.set({ awesomeStyleCSS: textareaInput.value });
        textareaInput.disabled = false;
    }
}

var option_customization$3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeStyleOptionCustomizationFeature
});

class ContextOdooMenusOptionCustomizationFeature extends OptionCustomizationFeature {
    constructor() {
        super(configuration$9);
        this.menusKey = 'contextOdooMenusContextMenu';
    }

    async load() {
        super.load();
        const menus = await this.getItems();
        this.setup(menus);
    }

    async getItems() {
        const settings = await StorageSync.get(this.defaultSettings);
        return settings[this.menusKey];
    }

    async setItems(menus) {
        await StorageSync.set({ [this.menusKey]: menus });
    }

    //#region CRUD
    async create() {
        const pathInput = document.getElementById('joorney_contextOdooMenus_new_path');

        try {
            const menus = await this.updateOrCreate(crypto.randomUUID(), pathInput.value, false);
            await this.saveAndRender(menus, true);
            pathInput.value = '';
        } catch (error) {
            this.displayError(error.message);
        }
    }

    async toggle(id, active) {
        const menus = await this.getItems();
        menus[id].active = active;
        await this.saveAndRender(menus, false);
    }

    async favorite(id, favorite) {
        const menus = await this.getItems();
        menus[id].favorite = favorite;
        await this.saveAndRender(menus, true);
    }

    async updatePath(id, path) {
        try {
            const menus = await this.updateOrCreate(id, path, false);
            await this.saveAndRender(menus, false);
        } catch (error) {
            this.displayError(error.message);
        }
    }

    async reorder(id, moveUp) {
        const menus = await this.getItems();

        const sortedRecordIds = Object.keys(menus).sort((k1, k2) => menus[k1].order - menus[k2].order);

        const curPos = sortedRecordIds.indexOf(id);
        const newPos = Math.min(Math.max(curPos + (moveUp ? -1 : 1), 0), sortedRecordIds.length - 1); // Keep newPos in bounds (0 <= newPos <= maxPos)

        [sortedRecordIds[curPos], sortedRecordIds[newPos]] = [sortedRecordIds[newPos], sortedRecordIds[curPos]]; // ES6 Swap

        sortedRecordIds.forEach((k, i) => {
            menus[k].order = i;
        }); // Rewrite order

        await this.saveAndRender(menus, true);
    }

    async remove(id, path) {
        if (confirm(`Are you sure you want to remove the menu: ${path}?`)) {
            const menus = await this.getItems();
            delete menus[id];
            await this.saveAndRender(menus, true);
        }
    }

    async removeAll() {
        if (confirm('Are you sure you want to delete all menus?')) {
            await this.saveAndRender({}, true);
        }
    }

    async updateOrCreate(id, pathArg, overwrite) {
        if (!pathArg) throw new Error('Missing path');

        const menus = await this.getItems();

        const path = pathArg.trim();
        const existingRecord = menus[id];
        let nextPosition = existingRecord?.order ?? Number.MAX_SAFE_INTEGER;

        if (!overwrite) {
            const ids = Object.keys(menus);
            if (ids.includes(id)) {
                throw new Error(`This id is already registered (should not happen): ${id}`);
            }
            const items = Object.values(menus);
            if (items.some((s) => s.path === path)) {
                throw new Error(`This path is already registered: ${path}`);
            }
            nextPosition = Math.max(...items.map((s) => s.order)) + 1;
        }

        menus[id] = {
            id: id,
            path: path,
            order: Math.max(0, nextPosition),
            active: existingRecord?.active ?? true,
            favorite: existingRecord?.favorite ?? false,
        };
        return menus;
    }
    //#endregion

    //#region UI
    displayError(errorMessage) {
        const container = document.getElementById('joorney_contextOdooMenus_new_error');
        container.textContent = errorMessage;
        container.style.display = errorMessage ? 'table-cell' : 'none';
    }

    async saveAndRender(menus, recreate) {
        await this.setItems(menus);
        if (recreate) await sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.RECREATE_MENU);
        this.render(menus);
    }

    render(menus) {
        const container = document.getElementById('joorney_contextOdooMenus_table_body');
        container.innerHTML = '';

        const menusArray = Object.values(menus).sort((a, b) => a.order - b.order);
        menusArray.forEach((menu, index) =>
            this.renderOne(menu, index === 0, index === menusArray.length - 1, container)
        );

        this.displayError();
    }

    renderOne(menu, isFirst, isLast, container) {
        const template = document.createElement('template');

        template.innerHTML = `
        <tr style="opacity: ${menu.active ? '1' : '0.5'}" ${!menu.active ? 'disabled' : ''}>
            <td class="p-1 ps-3" title="${menu.order}" style="vertical-align: middle">
                <button class="btn p-2 order-up-button-${menu.id}" ${isFirst ? 'disabled style="opacity: 0"' : 0}>
                    <i class="fa fa-caret-up text-success"></i>
                </button>
                <button class="btn p-2 order-down-button-${menu.id}" ${isLast ? 'disabled style="opacity: 0"' : 0}>
                    <i class="fa fa-caret-down text-danger"></i>
                </button>
            </td>
            <td class="p-1" style="vertical-align: middle">
                <input
                    class="joorney_contextOdooMenus_record_path_${menu.id} form-control border border-0 ${
                        menu.active ? '' : 'text-muted'
                    }"
                    placeholder="General Ledger"
                    value="${menu.path}"
                    type="text"
                    ${!menu.active ? 'disabled' : ''}
                    style="background-color: rgba(0,0,0,0)">
            </td>
            <td class="p-1" style="vertical-align: middle">
                <button
                    class="joorney_contextOdooMenus_record_favorite_${menu.id} btn btn-outline-warning ${
                        menu.active ? '' : 'text-muted'
                    } border-0 btn-floating"
                    title="${menu.favorite ? 'Favorite' : 'Not favorite'}">
                    <i style="font-size: 1.2em" class="fa fa-${menu.favorite ? 'solid' : 'regular'} fa-star"></i>
                </button>
                <button
                    class="joorney_contextOdooMenus_record_toggle_${menu.id} btn btn-outline-success ${
                        menu.active ? '' : 'text-muted'
                    } border-0 btn-floating"
                    title="${menu.active ? 'Disable' : 'Enable'} quick menu">
                    <i style="font-size: 1.2em" class="fa fa-toggle-${menu.active ? 'on' : 'off'}"></i>
                </button>
                <button
                    class="joorney_contextOdooMenus_record_update_button_${menu.id} btn btn-outline-success border-0 btn-floating"
                    title="Save modification"
                    disabled>
                    ${menu.active ? '<i class="fa fa-save" style="font-size: 1.2em"></i>' : ''}
                </button>
                <button
                    class="joorney_contextOdooMenus_record_remove_button_${menu.id} btn btn-outline-danger border-0 btn-floating"
                    title="Delete quick menu">
                    <i style="font-size: 1.2em" class="fa fa-trash"></i>
                </button>
            </td>
        </tr>
    `.trim();

        const menuElement = template.content.firstChild;

        const downButton = menuElement.getElementsByClassName(`order-down-button-${menu.id}`)[0];
        const upButton = menuElement.getElementsByClassName(`order-up-button-${menu.id}`)[0];
        const favoriteButton = menuElement.getElementsByClassName(
            `joorney_contextOdooMenus_record_favorite_${menu.id}`
        )[0];
        const stateButton = menuElement.getElementsByClassName(`joorney_contextOdooMenus_record_toggle_${menu.id}`)[0];
        const updateButton = menuElement.getElementsByClassName(
            `joorney_contextOdooMenus_record_update_button_${menu.id}`
        )[0];
        const removeButton = menuElement.getElementsByClassName(
            `joorney_contextOdooMenus_record_remove_button_${menu.id}`
        )[0];
        const pathInput = menuElement.getElementsByClassName(`joorney_contextOdooMenus_record_path_${menu.id}`)[0];

        downButton.addEventListener('click', () => this.reorder(menu.id, false));
        upButton.addEventListener('click', () => this.reorder(menu.id, true));

        favoriteButton.addEventListener('click', () => this.favorite(menu.id, !menu.favorite));
        stateButton.addEventListener('click', () => this.toggle(menu.id, !menu.active));
        updateButton.addEventListener('click', () => this.updatePath(menu.id, pathInput.value));
        removeButton.addEventListener('click', () => this.remove(menu.id, menu.path));

        pathInput.addEventListener('input', (event) => {
            event.target.parentElement.style.backgroundColor = 'rgba(255, 204, 0, 0.25)';
            updateButton.removeAttribute('disabled');
        });

        container.appendChild(menuElement);
    }

    async setup(menus) {
        const newPathInput = document.getElementById('joorney_contextOdooMenus_new_path');
        newPathInput.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                this.create();
            }
        });

        document.getElementById('joorney_contextOdooMenus_new_save').addEventListener('click', () => this.create());
        document
            .getElementById('joorney_contextOdooMenus_delete_all')
            .addEventListener('click', () => this.removeAll());

        this.render(menus);
    }
    //#endregion
}

var option_customization$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ContextOdooMenusOptionCustomizationFeature
});

class ThemeSwitchOptionCustomizationFeature extends OptionCustomizationFeature {
    constructor() {
        super(configuration$2);
        this.updateLocation = this.updateLocation.bind(this);
    }

    async load() {
        super.load();
        const configuration = await StorageSync.get(this.configuration.defaultSettings);

        const latitudeElement = document.getElementById('joorney_theme_switch_latitude');
        latitudeElement.value = configuration.themeSwitchLocationLatitude;
        latitudeElement.onchange = async (e) => await StorageSync.set({ themeSwitchLocationLatitude: e.target.value });

        const longitudeElement = document.getElementById('joorney_theme_switch_longitude');
        longitudeElement.value = configuration.themeSwitchLocationLongitude;
        longitudeElement.onchange = async (e) =>
            await StorageSync.set({ themeSwitchLocationLongitude: e.target.value });

        const getLocationElement = document.getElementById('joorney_theme_switch_get_location_button');
        getLocationElement.onclick = this.updateLocation;

        const darkStartTime = document.getElementById('joorney_theme_switch_dark_start');
        darkStartTime.value = configuration.themeSwitchDarkStartTime;
        darkStartTime.onchange = async (e) => await StorageSync.set({ themeSwitchDarkStartTime: e.target.value });

        const darkStopTime = document.getElementById('joorney_theme_switch_dark_stop');
        darkStopTime.value = configuration.themeSwitchDarkStopTime;
        darkStopTime.onchange = async (e) => await StorageSync.set({ themeSwitchDarkStopTime: e.target.value });
    }

    async updateLocation() {
        const coords = await getUserLocation();
        document.getElementById('joorney_theme_switch_latitude').value = coords.latitude;
        document.getElementById('joorney_theme_switch_longitude').value = coords.longitude;

        await StorageSync.set({
            themeSwitchLocationLatitude: coords.latitude,
            themeSwitchLocationLongitude: coords.longitude,
        });
    }
}

var option_customization$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ThemeSwitchOptionCustomizationFeature
});

class UnfocusAppOptionCustomizationFeature extends OptionCustomizationFeature {
    constructor() {
        super(configuration);
    }

    async load() {
        super.load();
        const origins = await this.readUnfocusAppOrigins();

        await this.restoreImage();
        await this.renderOriginsObject(origins);
    }

    //#region CRUD
    async readUnfocusAppOrigins() {
        const { unfocusAppOrigins } = await StorageSync.get({
            unfocusAppOrigins: this.defaultSettings.unfocusAppOrigins,
        });
        return unfocusAppOrigins;
    }

    async deleteUnfocusAppOrigin(origin) {
        if (confirm(`Are you sure you want to remove origin: ${origin}?`)) {
            const origins = await this.readUnfocusAppOrigins();
            delete origins[origin];
            await this.renderOriginsObject(origins);
        }
    }
    //#endregion

    //#region UI
    async renderOriginsObject(origins) {
        await StorageSync.set({ unfocusAppOrigins: origins });

        const container = document.getElementById('joorney_unfocus_app_table_body');
        container.innerHTML = '';
        for (const [id, o] of Object.keys(origins).entries()) {
            const values = Object.values(origins[o]);
            container.appendChild(
                this.renderOrigin(
                    id,
                    o,
                    values.filter((v) => v === 2).length,
                    values.filter((v) => v === true || v === 0).length
                )
            );
        }
    }

    renderOrigin(idx, origin, superfocusCount, unfocusCount) {
        const originTemplate = document.createElement('template');

        originTemplate.innerHTML = `
		<tr>
			<td class="p-1 joorney-valign-middle">
				<input
					id="joorney_unfocus_app_origin_${idx}"
					class="joorney-bg-white form-control border border-0 joorney_unfocus_app_origin_input"
					type="text"
					disabled
					value="${origin}"
				/>
			</td>
			<td>${superfocusCount}</td>
            <td>${unfocusCount}</td>
			<td class="p-1 joorney-valign-middle">
				<button
					class="joorney_unfocus_app_origin_delete_${idx} btn btn-outline-danger border-0 btn-floating"
					title="Delete origin"
				>
					<i class="joorney-font-icon-size fa fa-trash"></i>
				</button>
			</td>
		</tr>
	`.trim();

        const originElement = originTemplate.content.firstChild;

        const deleteButton = originElement.getElementsByClassName(`joorney_unfocus_app_origin_delete_${idx}`)[0];
        deleteButton.onclick = () => this.deleteUnfocusAppOrigin(origin);

        return originElement;
    }
    //#endregion

    //#region Image
    async restoreImage() {
        const { unfocusAppLightImageURL, unfocusAppDarkImageURL } = await StorageSync.get({
            unfocusAppLightImageURL: this.defaultSettings.unfocusAppLightImageURL,
            unfocusAppDarkImageURL: this.defaultSettings.unfocusAppDarkImageURL,
        });

        document.getElementById('joorney_unfocus_app_light_image').src = unfocusAppLightImageURL;
        document.getElementById('joorney_unfocus_app_dark_image').src = unfocusAppDarkImageURL;

        this.loadImageInput(
            'joorney_unfocus_app_light_image_input',
            'joorney_unfocus_app_light_image',
            'unfocusAppLightImageURL',
            unfocusAppLightImageURL
        );

        this.loadImageInput(
            'joorney_unfocus_app_dark_image_input',
            'joorney_unfocus_app_dark_image',
            'unfocusAppDarkImageURL',
            unfocusAppDarkImageURL
        );
    }

    loadImageInput(inputKey, imageKey, configKey, value) {
        const imageInput = document.getElementById(inputKey);
        imageInput.value = value;

        imageInput.oninput = async (e) => {
            let imageUrl = e.target.value.trim().replace(/\s/g, '');
            if (imageUrl.length === 0) {
                await StorageSync.set({ [configKey]: '' });
                return;
            }

            try {
                imageUrl = new URL(imageUrl);
                if (!this.isImageUrlPath(imageUrl.pathname)) throw new Error('Invalid image extension in the url path');

                await StorageSync.set({ [configKey]: `${imageUrl}` });
                imageInput.value = imageUrl;
                document.getElementById(imageKey).src = imageUrl;
            } catch (ex) {
                Console.warn(ex);
            }
        };
    }

    isImageUrlPath(path) {
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg']; // Add more extensions if needed
        const lowercaseUrl = path.toLowerCase();

        return imageExtensions.some((extension) => lowercaseUrl.endsWith(extension));
    }
    //#endregion
}

var option_customization = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: UnfocusAppOptionCustomizationFeature
});

class OptionFeature {
    constructor(configuration) {
        this.configuration = configuration;
        this.defaultSettings = configuration.defaultSettings;
    }

    async load() {
        this.appendHTMLFeatureElement();

        this.handlePopupMessage();

        return this.restore();
    }

    appendHTMLFeatureElement() {
        const disabledContainer = document.getElementById('joorney-disable-feature');
        disabledContainer.appendChild(generateFeatureOptionListItem(this.configuration));
    }

    handlePopupMessage() {
        if (!this.configuration.customization.popup) return;
        Runtime.onMessage.addListener((msg) => {
            if (msg.action !== MESSAGE_ACTION.TO_CONTENT.POPUP_HAS_CHANGE) return;
            this.onPopupMessage(msg);
        });
    }

    onPopupMessage(msg) {
        const enableFeature = msg[`enable${featureIDToPascalCase(this.configuration.id)}`];
        if (enableFeature === true || enableFeature === false) {
            this.restore();
        }
    }

    async restore() {
        const defaultConfiguration = await this.getDefaultConfiguration();
        this.moveElementToHTMLContainer(defaultConfiguration);
    }

    async getDefaultConfiguration() {
        const configuration = await StorageSync.get({
            [`${this.configuration.id}Enabled`]: false,
            [`${this.configuration.id}WhitelistMode`]: true,
        });
        return configuration;
    }

    moveElementToHTMLContainer(defaultConfiguration) {
        const enabled = defaultConfiguration[`${this.configuration.id}Enabled`];
        const isWhitelist = defaultConfiguration[`${this.configuration.id}WhitelistMode`];

        const featureElement = document.getElementById(`joorney_${this.configuration.id}_feature`);
        let container = document.getElementById('joorney-disable-feature');
        if (enabled) {
            if (isWhitelist) {
                container = document.getElementById('joorney-whitelist-feature');
            } else {
                container = document.getElementById('joorney-blacklist-feature');
            }
        }

        container.appendChild(featureElement);
        updateFeatureOriginInputs(this.configuration.id, enabled, isWhitelist);

        featureElement.ondragstart = startDrag;
    }
}

class LimitedShareOptionFeature extends OptionFeature {
    appendHTMLFeatureElement() {
        const limitedContainer = document.getElementById('joorney-limited-feature');
        limitedContainer.appendChild(generateLimitedFeatureOptionButtonItem(this.configuration));
    }

    moveElementToHTMLContainer(defaultConfiguration) {
        const enabled = defaultConfiguration[`${this.configuration.id}Enabled`];

        const featureInput = document.getElementById(`joorney_${this.configuration.id}_limited_feature`);
        featureInput.checked = enabled;

        featureInput.onchange = async (e) => {
            const checked = e.target.checked;
            await StorageSync.set({ [`${this.configuration.id}Enabled`]: checked });
        };
    }
}

class AdminDebugLoginRunbotOptionFeature extends LimitedShareOptionFeature {
    constructor() {
        super(adminDebugLoginConfiguration);
    }
}

var option$g = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AdminDebugLoginRunbotOptionFeature
});

class AmbientOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$e);
    }
}

var option$f = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AmbientOptionFeature
});

class AssignMeTaskOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$d);
    }
}

var option$e = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AssignMeTaskOptionFeature
});

class AutoOpenRunbotOptionFeature extends LimitedShareOptionFeature {
    constructor() {
        super(autoOpenRunbotConfiguration);
    }
}

var option$d = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AutoOpenRunbotOptionFeature
});

class AwesomeLoadingLargeOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$c);
    }
}

var option$c = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeLoadingLargeOptionFeature
});

class AwesomeLoadingSmallOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$b);
    }
}

var option$b = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeLoadingSmallOptionFeature
});

class AwesomeStyleOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$a);
    }
}

var option$a = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeStyleOptionFeature
});

class ContextOdooMenusOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$9);
    }
}

var option$9 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ContextOdooMenusOptionFeature
});

class ImpersonateLoginRunbotOptionFeature extends LimitedShareOptionFeature {
    constructor() {
        super(configuration$8);
    }
}

var option$8 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ImpersonateLoginRunbotOptionFeature
});

class NewServerActionCodeOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$7);
    }
}

var option$7 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: NewServerActionCodeOptionFeature
});

class PinMessageOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$6);
    }
}

var option$6 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: PinMessageOptionFeature
});

class SaveKnowledgeOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$5);
    }
}

var option$5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: SaveKnowledgeOptionFeature
});

class ShowMyBadgeOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$4);
    }
}

var option$4 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ShowMyBadgeOptionFeature
});

class StarringTaskEffectOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$3);
    }
}

var option$3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: StarringTaskEffectOptionFeature
});

class ThemeSwitchOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$2);
    }
}

var option$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ThemeSwitchOptionFeature
});

class TooltipMetadataOptionFeature extends OptionFeature {
    constructor() {
        super(configuration$1);
    }
}

var option$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: TooltipMetadataOptionFeature
});

class UnfocusAppOptionFeature extends OptionFeature {
    constructor() {
        super(configuration);
    }
}

var option = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: UnfocusAppOptionFeature
});
