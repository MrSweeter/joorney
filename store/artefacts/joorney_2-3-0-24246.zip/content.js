var joorney_content = (function (exports) {
    'use strict';

    var awesomeLoadingLarge = true;
    var awesomeLoadingSmall = true;
    var assignMeTask = true;
    var starringTaskEffect = true;
    var saveKnowledge = true;
    var themeSwitch = true;
    var awesomeStyle = true;
    var unfocusApp = true;
    var newServerActionCode = true;
    var tooltipMetadata = true;
    var impersonateLoginRunbot = true;
    var adminDebugLoginRunbot = true;
    var autoOpenRunbot = true;
    var showMyBadge = true;
    var contextOdooMenus = true;
    var pinMessage = true;
    var ambient = true;
    var FeaturesState = {
    	awesomeLoadingLarge: awesomeLoadingLarge,
    	awesomeLoadingSmall: awesomeLoadingSmall,
    	assignMeTask: assignMeTask,
    	starringTaskEffect: starringTaskEffect,
    	saveKnowledge: saveKnowledge,
    	themeSwitch: themeSwitch,
    	awesomeStyle: awesomeStyle,
    	unfocusApp: unfocusApp,
    	newServerActionCode: newServerActionCode,
    	tooltipMetadata: tooltipMetadata,
    	impersonateLoginRunbot: impersonateLoginRunbot,
    	adminDebugLoginRunbot: adminDebugLoginRunbot,
    	autoOpenRunbot: autoOpenRunbot,
    	showMyBadge: showMyBadge,
    	contextOdooMenus: contextOdooMenus,
    	pinMessage: pinMessage,
    	ambient: ambient
    };

    function isFirefox() {
        return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
    }

    //export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
    isFirefox() ? browser.tabs : chrome.tabs;
    isFirefox() ? browser.contextMenus : chrome.contextMenus;
    const Runtime = isFirefox() ? browser.runtime : chrome.runtime;
    const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
    const StorageLocal = isFirefox() ? browser.storage.local : chrome.storage.local;
    //export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
    isFirefox() ? browser.webNavigation : chrome.webNavigation;
    const Cookies = isFirefox() ? browser.cookies : chrome.cookies;
    isFirefox() ? browser.action : chrome.action;
    isFirefox() ? browser.commands : chrome.commands;
    isFirefox() ? browser.windows : chrome.windows;
    isFirefox() ? browser.management : chrome.management;
    isFirefox() ? browser.omnibox : chrome.omnibox;
    isFirefox() ? browser.webRequest : chrome.webRequest;

    function getPrefersColorScheme() {
        if (window.matchMedia('(prefers-color-scheme: no-preference)').matches) return null;
        if (window.matchMedia('(prefers-color-scheme: light)').matches) return 'light';
        if (window.matchMedia('(prefers-color-scheme: dark)').matches) return 'dark';
        return null;
    }

    async function sendRuntimeMessage(action, message = {}) {
        try {
            return await Runtime.sendMessage({ action: action, ...message });
        } catch (err) {
            Console.trace('catch runtime', err);
        }
    }

    const Console = {
        info(obj) {
            console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
        },
        log(obj) {
            console.log(obj);
        },
        error(obj) {
            console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
        },
        warn(obj) {
            console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
        },
        success(obj) {
            console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
        },
        trace(label, obj) {
            console.trace(label, obj);
        },
        critical(obj) {
            console.error(obj);
        },

        _getFormatOperator(obj) {
            switch (typeof obj) {
                case 'string':
                    return '%s';
                case 'number':
                    return '%s';
                case 'object':
                    return '%O';
                default:
                    return '%s';
            }
        },
    };

    const MESSAGE_ACTION = {
        TO_BACKGROUND: {
            GET_FEATURES_LIST: 'GET_FEATURES_LIST',
            GET_FINAL_RUNBOT_URL: 'GET_FINAL_RUNBOT_URL',
            UPDATE_EXT_STATUS: 'UPDATE_EXT_STATUS',
            TRIGGER_FEATURE: 'TRIGGER_FEATURE',
            RECREATE_MENU: 'RECREATE_MENU',
            TAB_LOADED: 'TAB_LOADED',
        },
        TO_CONTENT: {
            TAB_NAVIGATION: 'TAB_NAVIGATION',
            POPUP_HAS_CHANGE: 'POPU¨_HAS_CHANGE',
            REQUEST_ODOO_INFO: 'REQUEST_ODOO_INFO',
            CM_OPEN_MENU: 'CM_OPEN_MENU',
            CM_OPEN_RUNBOT: 'CM_OPEN_RUNBOT',
            WEB_REQUEST_COMPLETE: 'WEB_REQUEST_COMPLETE',
        },
    };

    function __variableDynamicImportRuntime2__(path) {
      switch (path) {
        case './src/features/themeSwitch/background_trigger.js': return Promise.resolve().then(function () { return background_trigger; });
        default: return new Promise(function(resolve, reject) {
          (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
            reject.bind(null, new Error("Unknown variable dynamic import: " + path))
          );
        })
       }
     }

    function __variableDynamicImportRuntime1__(path) {
      switch (path) {
        case './src/features/adminDebugLoginRunbot/content.js': return Promise.resolve().then(function () { return content$e; });
        case './src/features/ambient/content.js': return Promise.resolve().then(function () { return content$d; });
        case './src/features/assignMeTask/content.js': return Promise.resolve().then(function () { return content$c; });
        case './src/features/autoOpenRunbot/content.js': return Promise.resolve().then(function () { return content$b; });
        case './src/features/awesomeLoadingLarge/content.js': return Promise.resolve().then(function () { return content$a; });
        case './src/features/awesomeLoadingSmall/content.js': return Promise.resolve().then(function () { return content$9; });
        case './src/features/awesomeStyle/content.js': return Promise.resolve().then(function () { return content$8; });
        case './src/features/impersonateLoginRunbot/content.js': return Promise.resolve().then(function () { return content$7; });
        case './src/features/newServerActionCode/content.js': return Promise.resolve().then(function () { return content$6; });
        case './src/features/pinMessage/content.js': return Promise.resolve().then(function () { return content$5; });
        case './src/features/saveKnowledge/content.js': return Promise.resolve().then(function () { return content$4; });
        case './src/features/showMyBadge/content.js': return Promise.resolve().then(function () { return content$3; });
        case './src/features/starringTaskEffect/content.js': return Promise.resolve().then(function () { return content$2; });
        case './src/features/tooltipMetadata/content.js': return Promise.resolve().then(function () { return content$1; });
        case './src/features/unfocusApp/content.js': return Promise.resolve().then(function () { return content; });
        default: return new Promise(function(resolve, reject) {
          (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
            reject.bind(null, new Error("Unknown variable dynamic import: " + path))
          );
        })
       }
     }

    const baseSettings = {
        configurationVersion: 1,
        toastMode: 'ui',
        toastType: JSON.stringify({
            info: false,
            warning: true,
            danger: true,
            success: false,
        }),

        // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
        originsFilterOrigins: {},
        windowActionFallbacks: {
            // 'https://www.odoo.com': {
            //     'my-tasks': 'project.task',
            //     'all-tasks': 'project.task',
            // },
        },

        supportedVersions: ['17.0'],

        // Experimental
        useSimulatedUI: false,
        omniboxFocusCurrentTab: false,
        cacheEncodingBase64: true,
    };
    Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

    function importFeatureContentFile(featureID) {
        return __variableDynamicImportRuntime1__(`./src/features/${featureID}/content.js`).then((f) => new f.default());
    }

    function importFeatureBackgroundTriggerFile(featureID) {
        return __variableDynamicImportRuntime2__(`./src/features/${featureID}/background_trigger.js`).then((f) => new f.default());
    }

    function isNumeric(value) {
        return Boolean(value?.match(/^\d+$/));
    }

    function sanitizeURL(url) {
        return sanitizedHrefToUrl(url);
    }

    function sanitizedHrefToUrl(hrefArg) {
        const href = typeof hrefArg === 'object' ? hrefArg.href : hrefArg;
        const url = new URL(href.replace(/#/g, href.includes('?') ? '&' : '?'));
        return url;
    }

    function ValueIsNaN(value) {
        return isNaN(value) || Number.isNaN(value);
    }

    async function sleep(timeMS) {
        return await new Promise((r) => setTimeout(r, timeMS));
    }

    function yyyymmdd_hhmmssToDate(datetimeStr) {
        const [dateStr, timeStr] = datetimeStr.split(' ');
        return new Date(`${dateStr}T${timeStr}Z`).toISOString();
    }

    function toOdooBackendDateGMT0(date) {
        const year = date.getUTCFullYear();
        const month = String(date.getUTCMonth() + 1).padStart(2, '0');
        const day = String(date.getUTCDate()).padStart(2, '0');
        const hours = String(date.getUTCHours()).padStart(2, '0');
        const minutes = String(date.getUTCMinutes()).padStart(2, '0');
        const seconds = String(date.getUTCSeconds()).padStart(2, '0');

        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }

    function hasUnknownKey(sourceObj, targetObj) {
        for (const key in sourceObj) {
            if (!(key in targetObj)) {
                return true;
            }
        }
        return false;
    }

    // Private
    const LOCAL_DEFAULT = {
        journey_announces: {},
        offs: [],
        ambient_dates: {},
        joorney_sunrise: 0,
        joorney_sunset: 23 * 60 + 59,
        joorney_date: '',
        joorneyLocalCacheCall: {},
    };

    async function setLocal(obj) {
        if (hasUnknownKey(obj, LOCAL_DEFAULT)) {
            Console.warn(`Unknown local key in: ${JSON.stringify(obj)}`);
        }
        await StorageLocal.set(obj);
    }

    // Off website
    async function getWebsiteOff() {
        const { offs } = await StorageLocal.get({ offs: LOCAL_DEFAULT.offs });
        return new Set(offs);
    }

    // Cache
    async function getLocalCache() {
        const { joorneyLocalCacheCall } = await StorageLocal.get({
            joorneyLocalCacheCall: LOCAL_DEFAULT.joorneyLocalCacheCall,
        });
        return joorneyLocalCacheCall;
    }
    async function setLocalCache(cacheData) {
        await setLocal({ joorneyLocalCacheCall: cacheData });
    }

    // Ambient
    async function getAmbientDates() {
        const { ambient_dates } = await StorageLocal.get({ ambient_dates: LOCAL_DEFAULT.ambient_dates });
        return ambient_dates;
    }
    async function setAmbientDates(datesData) {
        await setLocal({ ambient_dates: datesData });
    }

    const NotYetImplemented = new Error('Not yet implemented, abstract method');
    function RunbotException(msg) {
        return new Error(msg);
    }

    class OdooAPIException extends Error {
        constructor(error, fromCache) {
            super(JSON.stringify(error));
            this.type = 'OdooAPIException';
            this.fromCache = fromCache;
            this.error = error;
        }
    }

    let SESSION_INFO = undefined;
    const SessionKey = {
        UID: 'uid',
        PARTNER_ID: 'partner_id',
        SERVER_VERSION_INFO: 'server_version_info',
    };

    function isDebugSession() {
        const dataset = document.querySelector('body').dataset;
        return dataset.odooDebugMode && dataset.odooDebugMode !== '0';
    }

    function getSessionData(key) {
        return SESSION_INFO?.[key];
    }

    async function loadSessionInfo() {
        if (SESSION_INFO) return;
        const scripts = document.querySelectorAll('script[type="text/javascript"]');
        const script = Array.from(scripts).find((s) => s.innerText.includes('odoo.__session_info__'));
        if (!script) return;
        const regex = /odoo\.__session_info__\s*=\s*(\{.*\});/;
        const match = script.innerText.match(regex);
        if (match) {
            await saveSession(JSON.parse(match[1]));
        }
    }

    async function saveSession(data) {
        SESSION_INFO = data;
        console.debug(SESSION_INFO);
    }

    // import { getVersionInfo } from '../api/odoo.js';

    const DEFAULT_VERSION = { isOdoo: false };

    function getOdooVersion() {
        if (!document) return DEFAULT_VERSION;
        const serverVersionInfo = getSessionData(SessionKey.SERVER_VERSION_INFO);
        if (!serverVersionInfo) return DEFAULT_VERSION;
        return { isOdoo: true, version: serverVersionInfo.slice(0, 2).join('.') };

        // TODO[UNCOMMENT/ADAPT] only if a feature works without being logged
        // if (data.isOdoo === true && data.version === undefined) {
        //     const versionInfo = await getVersionInfo(window.location);
        //     data.version = versionInfo;
        //     element.setAttribute('content', JSON.stringify(data));
        // }
    }
    function sanitizeVersion(version) {
        return `${version}`.replaceAll(/saas[~|-]/g, '');
    }

    /**
     * Caches the result of a function call for a specified amount of time.
     * If the cached result exists and hasn't expired, it is returned;
     * otherwise, the function is executed and the result is cached.
     *
     * @async
     * @function cache
     * @param {number} cachingTime - The amount of time (in minutes) to cache the result. If 0 or less, the result will not be cached.
     * @param {Function} call - The asynchronous function to call if there is no cached data.
     * @param {string} callID - A unique identifier for the cached data.
     * @param {...any} params - Additional parameters passed to both the `readCacheCall` and `saveCacheCall` functions.
     * @returns {Promise<{fromCache: boolean, data: any}>} - An object containing two properties:
     *          - `fromCache` (boolean): Whether the data was retrieved from the cache.
     *          - `data` (any): The cached data or the result of the function call.
     */
    async function cache(cachingTime, call, callID, ...params) {
        let data = undefined;
        let fromCache = true;
        if (cachingTime > 0) {
            data = await readCacheCall(callID, ...params);
        }
        if (!data) {
            data = await call();
            fromCache = false;

            if (cachingTime > 0) await saveCacheCall(cachingTime, callID, data, ...params);
        }
        return { fromCache, data };
    }

    function getHost() {
        if (typeof window === 'undefined' || window.location.host === Runtime.id) return `joorney://${Runtime.id}`;
        return window.location.host;
    }

    // Clear host if last change is 12h hours old
    async function _checkHostsExpiration(cache, now) {
        let hasChange = false;
        for (const [k, v] of Object.entries(cache)) {
            if (now - (v.lastChange ?? 0) > 12 * 60 * 60 * 1000) {
                delete cache[k];
                hasChange = true;
            }
        }
        return { changed: hasChange, cache: cache };
    }

    async function saveCacheCall(expireAfterMinute, call, result, ...params) {
        const { cacheEncodingBase64 } = await StorageSync.get({ cacheEncodingBase64: true });
        const hash = jbtoa(JSON.stringify(params), cacheEncodingBase64);
        const host = getHost();

        let cache = await getLocalCache();

        const now = Date.now();

        cache[host] ??= {};
        cache[host][call] ??= {};
        cache[host][call][hash] = {
            date: now,
            dateStr: new Date(now).toISOString(),
            expireAfterMinute: expireAfterMinute ?? 0,
            data: jbtoa(JSON.stringify(result), cacheEncodingBase64),
        };
        cache[host].lastChange = now;

        cache = await _checkHostsExpiration(cache, now);
        await setLocalCache(cache.cache);
    }

    async function readCacheCall(call, ...params) {
        const { cacheEncodingBase64 } = await StorageSync.get({ cacheEncodingBase64: true });
        const hash = jbtoa(JSON.stringify(params), cacheEncodingBase64);
        const host = getHost();
        let cache = await getLocalCache();
        cache = cache?.[host]?.[call]?.[hash];
        if (!cache) return undefined;
        const { date, expireAfterMinute, data } = cache;

        const now = Date.now();
        if (now - date > expireAfterMinute * 60 * 1000) return undefined;
        const decodeData = jatob(data, cacheEncodingBase64);
        return decodeData ? JSON.parse(decodeData) : undefined;
    }

    // TODO[IMP] Encryption/Decryption instead of Encoding/Decoding
    function jbtoa(str, cacheEncodingBase64) {
        if (!cacheEncodingBase64) return str;
        try {
            return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (_, p1) => String.fromCharCode(`0x${p1}`)));
        } catch (e) {
            Console.error(e);
            return undefined;
        }
    }

    function jatob(data, cacheEncodingBase64) {
        if (!cacheEncodingBase64) return data;
        try {
            return decodeURIComponent(
                atob(data)
                    .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
                    .join('')
            );
        } catch (e) {
            Console.error(e);
            return undefined;
        }
    }

    //#region Window Action
    async function getActionWindowModelFallback(actionPath) {
        const { windowActionFallbacks } = await StorageSync.get(baseSettings);
        return windowActionFallbacks[window.location.origin]?.[actionPath];
    }
    async function getActionWindowWithState(action) {
        try {
            if (isNumeric(`${action}`)) {
                return await getActionWindowWithID(action);
            }

            return await getActionWindowWithPath(action);
        } catch (e) {
            // TODO[REMOVE] After more usage/testing, probably useless as /action/load|run is "public" endpoint
            if (e.type === 'OdooAPIException' && e.error.data.name === 'odoo.exceptions.AccessError') {
                // if a fallback exist, ignore the error
                const model = await getActionWindowModelFallback(action);
                if (model) return undefined;
            }
            throw e;
        }
    }
    async function getActionWindowWithPath(path) {
        if (!path) return undefined;
        return await getActionWindow_fromLoadRun(path);
    }
    async function getActionWindowWithID(id) {
        if (!id) return undefined;
        return await getActionWindow_fromLoadRun(id);
    }

    async function getActionWindow_fromLoadRun(idOrPath, cachingTime = 60) {
        let { fromCache, data } = await cache(
            cachingTime,
            async () => {
                const response = await fetch(
                    new Request('/web/action/load', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            jsonrpc: '2.0',
                            method: 'call',
                            params: {
                                action_id: idOrPath,
                            },
                        }),
                    })
                );
                if (!response.ok) return undefined;
                return await response.json();
            },
            'getActionWindow_fromLoadRun_web-action-load',
            idOrPath
        );

        if (!data || !data.result) data = undefined;

        if (data && data.result.type === 'ir.actions.server') {
            ({ fromCache, data } = await cache(
                cachingTime,
                async () => {
                    const response = await fetch(
                        new Request('/web/action/run', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                jsonrpc: '2.0',
                                method: 'call',
                                params: {
                                    action_id: data.result.id,
                                },
                            }),
                        })
                    );
                    if (!response.ok) return undefined;
                    return await response.json();
                },
                'getActionWindow_fromLoadRun_web-action-run',
                idOrPath
            ));
        }

        if (!data) return undefined;

        if (data.error) {
            throw new OdooAPIException(data.error, fromCache);
        }
        if (data.result) {
            if (typeof data.result.context !== 'string') data.result.context = JSON.stringify(data.result.context);
            if (data.result.type !== 'ir.actions.act_window') return undefined;
        }

        return data.result;
    }

    async function getDataset(model, domain, fields, limit, cachingTime = 1) {
        const { fromCache, data } = await cache(
            cachingTime,
            async () => {
                return await _getDataset(model, domain, fields, limit);
            },
            'getDataset',
            model,
            domain,
            fields,
            limit
        );

        if (data.error) {
            throw new OdooAPIException(data.error, fromCache);
        }

        if (data.result === undefined) return limit === 1 ? undefined : [];
        if (data.result.length === 0) return limit === 1 ? undefined : [];

        return limit === 1 ? data.result[0] : data.result;
    }

    async function _getDataset(model, domain, fields, limit) {
        const response = await fetch(
            new Request(`/web/dataset/call_kw/${model}/search_read`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'call',
                    params: {
                        args: [],
                        kwargs: {
                            context: { active_test: false, lang: 'en_US' },
                            fields: fields,
                            domain: domain,
                            limit: limit,
                        },
                        model: model,
                        method: 'search_read',
                    },
                }),
            })
        );

        const data = await response.json();
        return data;
    }

    async function getDatasetWithIDs(model, ids) {
        const recordIDs = Array.isArray(ids) ? ids : [ids];
        const response = await fetch(
            new Request(`/web/dataset/call_kw/${model}/read`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'call',
                    params: {
                        args: [recordIDs],
                        kwargs: {},
                        model: model,
                        method: 'read',
                    },
                }),
            })
        );

        const data = await response.json();

        if (data.result === undefined) return [];
        if (data.result.length === 0) return [];

        return data.result;
    }

    async function getMetadata(model, resId) {
        const metadataResponse = await fetch(
            new Request(`/web/dataset/call_kw/${model}/get_metadata`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'call',
                    params: {
                        args: [[resId]],
                        kwargs: {},
                        model: model,
                        method: 'get_metadata',
                    },
                }),
            })
        );

        const metadataData = await metadataResponse.json();

        if (metadataData.result === undefined) return [];
        if (metadataData.result.length === 0) return [];

        return metadataData.result[0];
    }

    async function writeRecord(model, recordID, writeData) {
        const response = await fetch(
            new Request(`/web/dataset/call_kw/${model}/write`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: 1,
                    method: 'call',
                    jsonrpc: '2.0',
                    params: {
                        args: [[recordID], writeData],
                        kwargs: { context: {} },
                        model: model,
                        method: 'write',
                    },
                }),
            })
        );

        const data = await response.json();

        if (data.error) {
            throw new OdooAPIException(data.error, false);
        }
        if (data?.result === true) {
            return true;
        }
        throw new Error(data?.result);
    }

    async function getMenu(menupath) {
        const parts = menupath.split('/').reverse();
        let field = 'name';
        const domain = [];
        for (const part of parts) {
            domain.push([field, '=', part.trim()]);
            field = `parent_id.${field}`;
        }

        const response = await getDataset('ir.ui.menu', domain, ['action'], 2, 600);
        return response;
    }

    //#region External Public Odoo API
    async function getFutureEventWithName(domainName, host) {
        const { data } = await cache(
            30 * 24 * 60,
            async () => {
                const url = `https://${host}/web/dataset/call_kw/event.event/search_read`;
                const today = toOdooBackendDateGMT0(new Date());
                const payload = {
                    method: 'call',
                    jsonrpc: '2.0',
                    params: {
                        args: [],
                        kwargs: {
                            context: { active_test: true, lang: 'en_US' },
                            domain: [domainName, ['date_end', '>=', today]],
                            limit: 1,
                            fields: ['date_begin', 'date_end', 'name', 'display_name'],
                        },
                        model: 'event.event',
                        method: 'search_read',
                    },
                };
                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(payload),
                });
                return await response.json();
            },
            'getFutureEventWithName',
            domainName,
            host
        );
        if (!data) return undefined;
        if (data.error) return undefined;
        if (!data.result || data.result.length !== 1) return undefined;
        return data.result[0];
    }
    //#endregion

    const joorneySimulatedStyle = 'background-color: rgba(252, 163, 17, 0.25)';

    function stringToHTML(str) {
        const template = document.createElement('template');
        template.innerHTML = str.trim();
        return template.content.firstChild;
    }

    function generateUserAvatarTag(userName, avatarSrc) {
        const tagElement = stringToHTML(`
		<span class="o_tag position-relative d-inline-flex align-items-center mw-100 o_avatar pe-1 rounded joorney-simulated-ui-assignme" title="${userName}">
			<span
				class="position-absolute top-0 end-0 bottom-0 start-0 mx-n2 mt-n1 mb-n1 rounded border"
				style="${joorneySimulatedStyle}"
			></span>
			<img class="o_avatar o_m2m_avatar position-relative rounded" src="${avatarSrc}" />
			<div class="o_tag_badge_text text-truncate position-relative ms-1">${userName}</div>
		</span>
	`);

        return tagElement;
    }

    function generateTrackingMessage(authorName, newValue, fieldName, avatarSrc, date) {
        const messageElement = stringToHTML(`
		<div class="o-mail-Message position-relative py-1 mt-2 px-3 joorney-simulated-ui-assignme">
			<span
				class="position-absolute top-0 end-0 bottom-0 start-0 mx-2 mt-n1 mb-n1 rounded border"
				style="${joorneySimulatedStyle}"
			></span>
			<div class="o-mail-Message-core position-relative d-flex flex-shrink-0">
				<div class="o-mail-Message-sidebar d-flex flex-shrink-0">
					<div class="o-mail-Message-avatarContainer position-relative bg-view rounded">
						<img class="o-mail-Message-avatar w-100 h-100 rounded o_object_fit_cover" src="${avatarSrc}" />
					</div>
				</div>
				<div class="w-100 o-min-width-0">
					<div class="o-mail-Message-header d-flex flex-wrap align-items-baseline mb-1 lh-1">
						<span class="o-mail-Message-author">
							<strong class="me-1 text-truncate">${authorName}</strong>
						</span>
						<small class="o-mail-Message-date text-muted opacity-75 me-2">- ${date.toLocaleDateString()} ${date.toLocaleTimeString()} - Joorney</small>
					</div>
					<div class="position-relative d-flex">
						<div class="o-mail-Message-content o-min-width-0">
							<div class="o-mail-Message-textContent position-relative d-flex">
								<div>
									<ul class="mb-0 ps-4">
										<li class="o-mail-Message-tracking mb-1">
											<span class="o-mail-Message-trackingOld me-1 px-1 text-muted fw-bold">?</span>
											<i class="o-mail-Message-trackingSeparator fa fa-long-arrow-right mx-1 text-600"></i>
											<span class="o-mail-Message-trackingNew me-1 fw-bold text-info">?, ${newValue}</span>
											<span class="o-mail-Message-trackingField ms-1 fst-italic text-muted">(${fieldName})</span>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	`);
        return messageElement;
    }

    function generateMessage(authorName, avatarSrc, bodyContent, date, original) {
        const messageElement = stringToHTML(`
		<div class="o-mail-Message position-relative py-1 mt-2 px-3 rounded border">
			<button class="o-mail-Message-jumpTo d-none btn m-1 position-absolute top-0 end-0 rounded-pill badge badge-secondary" style="z-index: 1;">
				Jump
			</button>
			<div class="o-mail-Message-core position-relative d-flex flex-shrink-0">
				<div class="o-mail-Message-sidebar d-flex flex-shrink-0">
					<div class="o-mail-Message-avatarContainer position-relative bg-view rounded">
						<img class="o-mail-Message-avatar w-100 h-100 rounded o_object_fit_cover" src="${avatarSrc}" />
					</div>
				</div>
				<div class="w-100 o-min-width-0">
					<div class="o-mail-Message-header d-flex flex-wrap align-items-baseline mb-1 lh-1">
						<span class="o-mail-Message-author">
							<strong class="me-1 text-truncate">${authorName}</strong>
						</span>
						<small class="o-mail-Message-date text-muted opacity-75 me-2">- ${date.toLocaleDateString()} ${date.toLocaleTimeString()} - Joorney</small>
					</div>
					<div class="position-relative d-flex">
						<div class="o-mail-Message-content o-min-width-0">
							<div class="o-mail-Message-textContent position-relative d-flex">
								<div class="position-relative overflow-x-auto d-inline-block">
									<div class="o-mail-Message-bubble rounded-bottom-3 position-absolute top-0 start-0 w-100 h-100 rounded-end-3"></div>
									<div class="o-mail-Message-body position-relative text-break mb-0 w-100">${bodyContent}</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	`);

        if (original) {
            const jumpTo = messageElement.querySelector('.o-mail-Message-jumpTo');
            jumpTo.onclick = () => {
                original.scrollIntoView({ behavior: 'instant', block: 'center', inline: 'nearest' });
                original.style = joorneySimulatedStyle;
                setTimeout(() => {
                    original.style = null;
                }, 1000);
            };
            jumpTo.classList.toggle('d-none');
        }

        return messageElement;
    }

    const regexSchemePrefix = 'regex://';

    function isOdooWebsite(url) {
        const regex = /^https?:\/\/(.+?\.odoo\.com|localhost|127\.0\.0\.\d+)(:\d+)?.*$/;
        return regex.test(url);
    }

    async function isStillSamePage(timeout, url) {
        if (timeout > 0) await sleep(timeout);
        const currentURL = sanitizeURL(window.location.href);
        return currentURL.href === url.href;
    }

    async function isStillSameWebsite(timeout, url) {
        if (timeout > 0) await sleep(timeout);
        return window.location.origin === url.origin;
    }

    async function isSupportedFeature(versionInfo, featureSupportedVersion) {
        const { isOdoo, version } = versionInfo;
        if (!isOdoo) return false;
        if (!version) return false;

        const odooSupported = await isSupportedOdoo(version);
        if (!odooSupported) return false;

        return includeVersion(featureSupportedVersion, version, true);
    }

    async function isSupportedOdoo(version) {
        const { supportedVersions } = await StorageSync.get(baseSettings);
        return includeVersion(supportedVersions, version);
    }

    async function isAuthorizedFeature(feature, url) {
        const key = `${feature}Enabled`;
        const configuration = await StorageSync.get({
            [key]: false,
        });
        if (!configuration[key]) return false;

        const authorizedFeature = await authorizeFeature(feature, url.origin);
        return authorizedFeature;
    }

    async function isAuthorizedLimitedFeature(featureName, url) {
        const key = `${featureName}Enabled`;
        const configKey = `${featureName}LimitedOrigins`;
        const configuration = await StorageSync.get({
            [key]: false,
            [configKey]: [],
        });
        if (!configuration[key]) return false;
        const origin = url.origin;

        const offs = await getWebsiteOff();
        if (offs.has(origin)) return false;

        // Check URL
        if (configuration[configKey].includes(origin)) {
            return true;
        }

        // Check Regex
        const activeRegex = configuration[configKey]
            .filter((o) => o.startsWith(regexSchemePrefix))
            .map((o) => new RegExp(o.replace(regexSchemePrefix, '')));
        const validRegex = activeRegex.some((r) => r.test(origin));

        return validRegex;
    }

    async function authorizeFeature(featureName, origin) {
        const offs = await getWebsiteOff();
        if (offs.has(origin)) return false;

        const configuration = await StorageSync.get({
            originsFilterOrigins: {},
            [`${featureName}Enabled`]: false,
            [`${featureName}WhitelistMode`]: true,
        });

        if (!configuration[`${featureName}Enabled`]) return false;

        const activeOrigins = getActiveFeatureOrigins(configuration.originsFilterOrigins, featureName);
        const activeRegex = activeOrigins
            .filter((o) => o.startsWith(regexSchemePrefix))
            .map((o) => new RegExp(o.replace(regexSchemePrefix, '')));

        const originExist = activeOrigins.includes(origin) || activeRegex.some((r) => r.test(origin));

        const isWhitelistMode = configuration[`${featureName}WhitelistMode`];
        if (isWhitelistMode) {
            return originExist;
        }

        if (!isWhitelistMode) {
            return !originExist;
        }

        return false;
    }

    function getActiveFeatureOrigins(originsFilterOrigins, featureName) {
        const enabledOrigins = Object.entries(originsFilterOrigins)
            .filter((origin) => origin[1][featureName] === true)
            .map((origin) => origin[0]);
        return enabledOrigins;
    }

    function includeVersion(versions, version, empty = false) {
        const supportedVersions = Array.isArray(versions) ? versions : [versions];
        if (supportedVersions.length === 0) return empty;
        if (supportedVersions.includes(version)) return true;

        const versionNum = sanitizeVersion(version);
        if (ValueIsNaN(versionNum)) return false;

        const uniqueOperator = versions.length === 1;

        for (const supportedVersion of supportedVersions) {
            const sanitizedVersion = sanitizeVersion(supportedVersion);
            if (!sanitizedVersion) continue;
            if (isVersionSupported(sanitizedVersion, versionNum, uniqueOperator)) return true;
        }

        return false;
    }

    function isVersionSupported(supportedVersion, version, uniqueOperator) {
        const supportedVersionNum = Number.parseFloat(supportedVersion);
        if (ValueIsNaN(supportedVersionNum)) return false;

        const versionNum = Number.parseFloat(version);
        if (ValueIsNaN(versionNum)) return false;

        if (supportedVersion.endsWith('+')) {
            if (uniqueOperator) return versionNum >= supportedVersionNum;
            Console.warn('Version operator "+" cannot be used with other values, with ":" for range');
            return false;
        }

        if (supportedVersion.endsWith('-')) {
            if (uniqueOperator) return versionNum < supportedVersionNum;
            Console.warn('Version operator "-" cannot be used with other values, with ":" for range');
            return false;
        }

        if (supportedVersion.includes(':')) {
            const fromTo = supportedVersion.split(':');
            const minimum = Number.parseFloat(fromTo[0]);
            const maximum = Number.parseFloat(fromTo[1]);
            if (ValueIsNaN(minimum) || ValueIsNaN(maximum)) {
                Console.warn(`Invalid range for operator ":" --> ${supportedVersion}`);
                return false;
            }
            return versionNum >= minimum && versionNum < maximum;
        }
        return versionNum === supportedVersionNum;
    }

    const html = String.raw;
    const css = String.raw;

    const toastFadeInOutDurationMillis = 500;
    const toastDelayMillis = 100;
    const toastDurationMillis = 3000;

    const ToastContainerElementID = 'joorney-toast-container';
    const ToastItemElementClass = 'joorney-toasty';

    const iconForType = {
        success: 'fa fa-check-circle',
        danger: 'fa fa-exclamation-circle',
        warning: 'fa fa-exclamation-triangle',
        info: 'fa fa-info-circle',
    };

    const ToastStyle = css`
    #${ToastContainerElementID} {
        display: flex;
        flex-direction: column;
        padding: 16px;
        position: fixed;
        top: 32px;
        width: 100%;
        z-index: 9999;
        pointer-events: none;
        font-family: Roboto, sans-serif;
    }

    .${ToastItemElementClass} {
        display: none;
        opacity: 0;
        align-self: end;
        padding: 16px;
        margin-bottom: 10px;
        border-radius: 4px;
        min-width: 300px;
        max-width: 600px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        position: relative;
        overflow: hidden;
        pointer-events: auto;
    }

    .${ToastItemElementClass}-success .toast-progress {
        background-color: #4caf50;
    }

    .${ToastItemElementClass}-danger .toast-progress {
        background-color: #f44336;
    }

    .${ToastItemElementClass}-info .toast-progress {
        background-color: #2196f3;
    }

    .${ToastItemElementClass}-warning .toast-progress {
        background-color: #ff9800;
    }

    .toast-icon {
        margin-right: 10px;
        font-size: 24px;
    }

    .toast-content {
        flex-grow: 1;
        align-content: center;
    }

    .toast-title {
        font-weight: bold;
        margin-bottom: 5px;
    }

    .toast-text {
        max-width: 500px;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .toast-feature span {
        background-color: rgba(128, 128, 128, .25);
    }

    .toast-close {
        cursor: pointer;
        position: absolute;
        top: 8px;
        right: 8px;
        font-size: 16px;
        background: transparent;
        border: none;
    }

    .toast-progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 5px;
        animation: progressBar ${toastDurationMillis}ms linear forwards;
        animation-delay: ${toastDelayMillis + toastFadeInOutDurationMillis}ms;
    }

    @keyframes progressBar {
        from { width: 100%; }
        to { width: 0%; }
    }
  `.trim();

    const ToastContainer = html`
    <div id="${ToastContainerElementID}">
        <style>${ToastStyle}</style>
    </div>
`.trim();

    function buildContainer() {
        const container = stringToHTML(ToastContainer);
        return container;
    }

    function buildToastItem(feature, title, message, type, large) {
        const toastID = `toast-${Date.now()}`;
        const textHeight = !large ? 'height: 20px; white-space: nowrap;' : '';
        const item = stringToHTML(html`
        <div id="${toastID}" class="${ToastItemElementClass} ${ToastItemElementClass}-${type} alert-${type}">
            <div class="toast-icon"><i class="${iconForType[type]}"></i></div>
            <div class="toast-content">
                <div>
                    <strong>Joorney: </strong>
                    <span class="toast-feature">
                        <span class="badge rounded-pill">${feature}</span>
                    </span>
                </span>
                <div class="toast-title">${title}</div>
                <div
                    class="toast-text"
                    style="${textHeight}"
                >${message}</div>
            </div>
            <button id="close-${toastID}" class="toast-close"><i class="fa-solid fa-xmark"></i></button>
            <div class="toast-progress"></div>
        </div>
    `);
        return item;
    }

    async function loadToast(versionInfo) {
        const { isOdoo, version } = versionInfo;
        if (!isOdoo) return;
        if (!version) return;

        const odooSupported = await isSupportedOdoo(version);
        if (!odooSupported) return;
        await ToastManager.load();
    }

    const existingToast = {};
    const maximumNotification = 3;

    const ToastManager = {
        async load() {
            const container = buildContainer();
            const existElement = document.getElementById(container.id);
            if (existElement) existElement.remove();

            document.documentElement.appendChild(container);
            this.toastMode = (await StorageSync.get(baseSettings))?.toastMode ?? 'ui';
            this.toastType = JSON.parse((await StorageSync.get(baseSettings))?.toastType);
        },

        isDisabled() {
            return this.toastMode === 'disabled';
        },

        isLogConsole() {
            return this.toastMode === 'log';
        },

        isLargeMode() {
            return this.toastMode === 'large-ui';
        },

        info(feature, title, message, force = false) {
            return this._notify(feature, title, message, 'info', force);
        },

        warn(feature, title, message, force = false) {
            return this._notify(feature, title, message, 'warning', force);
        },

        error(feature, title, message, force = false) {
            return this._notify(feature, title, message, 'danger', force);
        },

        success(feature, title, message, force = false) {
            return this._notify(feature, title, message, 'success', force);
        },

        async _notify(feature, title, message, type, force) {
            if (this.isDisabled()) return false;
            if (!this.toastType[type]) return false;

            const existing = Object.entries(existingToast).find((entry) => entry[1].msg === message);
            if (existing) {
                if (existing[1].id) clearTimeout(existing[1].id);
                this._updateui(existing, feature);
                return true;
            }

            const isLogConsole = this.isLogConsole();
            if (isLogConsole) {
                this._log(feature, title, message, type);
                return true;
            }

            if (!force && Object.keys(existingToast).length >= maximumNotification) {
                this._log(feature, title, message, type, false);
                this._ui(
                    'notification',
                    '',
                    `You have reached the notification limit (${maximumNotification}). Notification logged to console.`,
                    'warning'
                );
                return true;
            }

            if (this.isLargeMode()) {
                this._ui(feature, title, message, type, true);
                return true;
            }

            this._log(feature, title, message, type, false);
            this._ui(feature, title, message, type, false);

            return true;
        },

        _ui(feature, title, message, type, large) {
            const container = document.getElementById(ToastContainerElementID);
            if (!container) return;
            const item = buildToastItem(feature, title, message, type, large);
            container.appendChild(item);
            const toastID = item.id;
            existingToast[toastID] = { msg: message, id: this._show(toastID) };
        },

        _log(feature, title, message, type, antispam = true) {
            const itemID = `log-${Date.now()}`;
            if (antispam) existingToast[itemID] = message;
            switch (type) {
                case 'info':
                    Console.info(`(${feature})\n${title}\n${message}`);
                    break;
                case 'danger':
                    Console.error(`(${feature})\n${title}\n${message}`);
                    break;
                case 'warning':
                    Console.warn(`(${feature})\n${title}\n${message}`);
                    break;
                case 'success':
                    Console.success(`(${feature})\n${title}\n${message}`);
                    break;
                default:
                    Console.log(`[${type}] (${feature})\n${title}\n${message}`);
            }
            if (antispam) {
                setTimeout(() => {
                    delete existingToast[itemID];
                }, toastDelayMillis * 1000);
            }
        },

        _show(toastID) {
            const toast = document.getElementById(toastID);
            if (!toast) return;

            toast.style.display = 'flex';
            toast.style.transform = 'translateX(200%)';
            toast.style.transition = `transform ${toastFadeInOutDurationMillis}ms ease-in-out, opacity ${toastFadeInOutDurationMillis}ms ease-in-out`;
            setTimeout(() => {
                toast.style.transform = 'translateX(0%)';
                toast.style.opacity = 1;
            }, toastDelayMillis);

            document.getElementById(`close-${toastID}`).onclick = () => this._hide(toastID);
            toast.onclick = () => this._hide(toastID);

            return setTimeout(
                () => {
                    this._hide(toastID);
                },
                toastDelayMillis + toastFadeInOutDurationMillis + toastDurationMillis
            );
        },

        _hide(toastID) {
            const toast = document.getElementById(toastID);
            if (!toast) return;
            toast.style.transform = 'translateX(200%)';
            toast.style.opacity = 0;
            setTimeout(() => {
                toast.remove();
                delete existingToast[toastID];
            }, toastDelayMillis + toastFadeInOutDurationMillis);
        },

        _updateui(existing, feature) {
            const features = document.getElementById(existing[0]).getElementsByClassName('toast-feature')[0];
            const featureBadge = stringToHTML(`
                <span class="badge rounded-pill">${feature}</span>
            `);
            features.appendChild(featureBadge);

            const toast = document.getElementById(existing[0]);
            if (!toast) return true;
            const progress = toast.getElementsByClassName('toast-progress')[0];
            if (!progress) return true;

            progress.style.animation = 'none';
            progress.offsetWidth; // force re-render
            progress.style.animation = '';
            existingToast[existing[0]].id = setTimeout(() => {
                this._hide(existing[0]);
            }, toastDurationMillis + toastFadeInOutDurationMillis);
        },
    };

    class ContentFeature {
        constructor(configuration) {
            this.configuration = configuration;
            this.defaultSettings = configuration.defaultSettings;
        }

        async load(urlArg, versionInfo) {
            if (!(await isSupportedFeature(versionInfo, this.configuration.supported_version))) return;

            const url = sanitizeURL(urlArg);

            if (!(await isAuthorizedFeature(this.configuration.id, url))) return;

            this.loadFeature(url);
            this.handlePopupMessage();

            this.observeRequest();
        }

        observeRequest() {
            const onrequest = this.configuration.trigger.onrequest;
            if (!onrequest || onrequest.length < 1) return;

            Runtime.onMessage.addListener((msg) => {
                if (msg.action === MESSAGE_ACTION.TO_CONTENT.WEB_REQUEST_COMPLETE) this.onRequestCompleted(msg);
            });
        }

        async onRequestCompleted(_msg) {}

        async loadFeature(_url) {
            throw NotYetImplemented;
        }

        async handlePopupMessage() {
            if (!this.configuration.customization.popup) return;
            Runtime.onMessage.addListener((msg) => {
                if (msg.action !== MESSAGE_ACTION.TO_CONTENT.POPUP_HAS_CHANGE) return;
                this.onPopupMessage(msg);
            });
        }

        onPopupMessage(_msg) {
            if (this.configuration.customization.popup) throw NotYetImplemented;
        }

        async tryCatch(fct, fallback = undefined) {
            try {
                return await Promise.resolve(fct());
            } catch (e) {
                if (e.type === 'OdooAPIException') {
                    const error = e.error;
                    switch (error.data.name) {
                        case 'odoo.exceptions.AccessError':
                            ToastManager.warn(
                                this.configuration.id,
                                `${e.fromCache ? '[cache] ' : ''}${error.data.name}`,
                                error.data.message
                            );
                            break;
                        case 'builtins.ValueError':
                            ToastManager.warn(
                                this.configuration.id,
                                `${e.fromCache ? '[cache] ' : ''}${error.data.name}`,
                                error.data.message
                            );
                            break;
                        default:
                            ToastManager.error(
                                this.configuration.id,
                                `${e.fromCache ? '[cache] ' : ''}${error.data.name}`,
                                error.data.message
                            );
                    }
                } else {
                    ToastManager.error(this.configuration.id, `${e.name}`, e.message);
                }
            }
            return fallback;
        }
    }

    const openVersionKey = 'joorney-runbot';
    const searchVersionPath = 'runbot/r-d-1?search=';

    function getRunbotOpenUrl(version) {
        return `https://runbot.odoo.com?${openVersionKey}=${version}`;
    }

    class LimitedRunbotContentFeature extends ContentFeature {
        async load(urlArg, _versionInfo) {
            const url = sanitizeURL(urlArg);

            if (!(await isAuthorizedLimitedFeature(this.configuration.id, url))) return;

            this.loadFeature(url);
        }

        getOpenData(url) {
            if (!url.searchParams.has(openVersionKey)) return false;
            const value = url.searchParams.get(openVersionKey);
            return value ? value : false;
        }

        isRunbotPage(urlArg) {
            if (!urlArg) return false;
            const url = typeof urlArg === 'object' ? urlArg : new URL(urlArg);
            return url.host === 'runbot.odoo.com';
        }

        isRunbotPageWithAutoOpenHash(urlArg) {
            if (!urlArg) return false;
            const url = typeof urlArg === 'object' ? urlArg : new URL(urlArg);
            const openVersion = this.getOpenData(url);
            if (!openVersion) return false;
            return this.isRunbotPage(url);
        }

        isRunbotSelectorPageWithLogin(urlArg) {
            if (!urlArg) return false;
            const url = typeof urlArg === 'object' ? urlArg : new URL(urlArg);
            if (!this.getOpenData(url)) return false;
            return url.pathname === '/web/database/selector';
        }

        getAdminDebugURL(urlArg) {
            if (!urlArg) return undefined;
            const url = typeof urlArg === 'object' ? urlArg : new URL(urlArg);

            url.pathname = '/web/login';
            url.search = url.search ? `${url.search}&debug=1` : 'debug=1';
            url.search = `${url.search}&joorney-runbot=login`;
            return url.toString();
        }

        async openRunbot(href, newTab) {
            let finalURL = 'https://runbot.odoo.com/';
            if (href.includes(searchVersionPath)) {
                finalURL = href;
            } else if (href !== finalURL) {
                // Messaging flow require due to CORS on runbot
                const response = await sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.GET_FINAL_RUNBOT_URL, {
                    href: href,
                });
                if (response.error) {
                    throw RunbotException(response.error);
                }
                finalURL = this.getAdminDebugURL(response.url) ?? finalURL;
            }

            const finalLink = document.createElement('a');
            finalLink.href = finalURL;
            finalLink.target = newTab ? '_blank' : '';
            // Manage event to open tab without switching to it
            const event = new MouseEvent('click', { ctrlKey: newTab });
            finalLink.dispatchEvent(event);
        }
    }

    // https://github.com/odoo/odoo/blob/master/addons/web/static/src/core/browser/router.js#L173


    const defaultState = {
        resId: undefined,
        view_type: undefined,
        action: undefined,
        active_id: undefined,
        model: undefined,
    };

    /**
     *
     * @param {*} url: string|URL
     * @param {*} actionWindowFields: StringArray
     * @returns { resId: string|int, active_id: int, view_type: string, action: int, model: string, actionWindow: OdooActionWindow }
     */
    async function parseURL(urlArg, requireID = false) {
        const url = typeof urlArg === 'object' ? urlArg : new URL(urlArg);

        const sanitizedURL = sanitizeURL(url.href);

        const { pathname, searchParams } = sanitizedURL;

        let state = {};

        if (pathname === '/web') {
            state = parseURL_V1(searchParams);
            return state;
        }

        state = parseURL_V2(pathname);

        if (state.action === 'studio') return defaultState;
        if (requireID && !state.resId) return state;

        if (state.action && !state.model) {
            const actionWindow = await getActionWindowWithState(state.action);
            if (actionWindow) {
                state.model = actionWindow.res_model;
                state.actionWindow = actionWindow;
            } else {
                state.model = await getActionWindowModelFallback(state.action);
            }
        }
        return state;
    }

    function parseURL_V1(searchParams) {
        const state = { ...defaultState };

        if (searchParams.has('id')) {
            const id = searchParams.get('id');
            if (isNumeric(id)) state.resId = Number.parseInt(id);
            state.view_type = searchParams.get('view_type');
        } else if (searchParams.get('view_type') === 'form') {
            state.resId = 'new';
            state.view_type = 'form';
        }

        if (searchParams.has('action')) {
            const action = searchParams.get('action');
            if (isNumeric(action)) state.action = Number.parseInt(action);
        }

        if (searchParams.has('active_id')) {
            const active_id = searchParams.get('active_id');
            if (isNumeric(active_id)) state.active_id = Number.parseInt(active_id);
        }

        if (searchParams.has('model')) {
            state.model = searchParams.get('model');
        }

        return state;
    }

    function parseURL_V2(pathname) {
        const [prefix, ...splitPath] = pathname.split('/').filter(Boolean);
        if (prefix !== 'odoo') return {};

        const actionParts = [...splitPath.entries()].filter(([_, part]) => !isNumeric(part) && part !== 'new');
        let lastAction = defaultState;

        for (const [i, part] of actionParts) {
            const action = {};
            const [left, right] = [splitPath[i - 1], splitPath[i + 1]];

            if (isNumeric(left)) {
                action.active_id = Number.parseInt(left);
            }

            if (right === 'new') {
                action.resId = 'new';
                action.view_type = 'form';
            } else if (isNumeric(right)) {
                action.resId = Number.parseInt(right);
            }

            if (part.startsWith('action-')) {
                // Ignore xml_id, Odoo override it with ID
                const actionId = part.slice(7);
                if (isNumeric(actionId)) action.action = Number.parseInt(actionId);
            } else if (part.startsWith('m-')) {
                action.model = part.slice(2);
            } else if (part.includes('.')) {
                action.model = part;
            } else {
                action.action = part;
            }

            if (action.resId && action.action) {
                const act = { ...action };
                act.resId = undefined;
                lastAction = act;
            }

            if (action.action || action.resId || i === splitPath.length - 1) {
                lastAction = action;
            }
        }

        return lastAction;
    }

    //#region URL Creator
    function createRecordFormURL(url, model, id) {
        const sanitizedURL = sanitizeURL(url);
        const { pathname } = sanitizedURL;

        if (pathname === '/web') {
            return `${url.origin}${url.pathname}#id=${id}&model=${model}&view_type=form`;
        }

        return `${url.origin}${url.pathname}/${model}/${id}`;
    }
    function createActionMenuURL(url, actionID) {
        if (url.pathname.startsWith('/web')) {
            return `${url.origin}${url.pathname}#action=${actionID}`;
        }

        if (url.pathname.startsWith('/odoo')) {
            return `${url.origin}${url.pathname}/action-${actionID}${url.search}`;
        }

        return `${url.origin}/odoo/action-${actionID}`; // Not compatible before 17.2 --> 404
    }
    //#endregion

    //#region Check model new form
    async function isModelCreateView_fromURL(url, model) {
        const state = await parseURL(url);
        return state.model === model && state.view_type === 'form' && state.resId === 'new';
    }
    //#endregion

    //#region Get model ID
    async function getModelAndID_fromURL(url, modelArg = undefined, requireID = false) {
        const state = await parseURL(url, undefined);

        const { model, resId } = state;
        if (modelArg && model !== modelArg) return undefined;
        if (resId && resId !== 'new') return { model, resId };
        return undefined;
    }
    //#endregion

    async function getActionWindow_fromURL(url) {
        const state = await parseURL(url);
        if (state.actionWindow) return state.actionWindow;
        if (!state.action) return undefined;

        const actionWindow = await getActionWindowWithState(state.action);
        if (actionWindow) return actionWindow;
        return undefined;
    }

    /**
     * Entry point for content scripts.
     *
     * This file is inserted after every other content script.
     * Hence, every function / variable created by other content scripts are available here.
     */

    //#region Navigation Event

    let loadedURL = false;
    addNavigationListener();

    window.addEventListener('load', async () => {
        // ALTERNATIVE of loadSessionInfo
        // const script = document.createElement('script');
        //script.src = Runtime.getURL('inject.js');
        //script.onload = function () {
        //    onVersionLoaded();
        //    this.remove();
        //};
        //document.documentElement.appendChild(script);
        await loadSessionInfo();
        onVersionLoaded();
    });

    async function onVersionLoaded() {
        const url = window.location.href;
        if (!canContinue(url)) return;

        updateLandingPage();

        await updateTabState(url);
        const versionInfo = getOdooVersion();
        await loadFeatures(url, versionInfo, 'background');
        await loadFeatures(url, versionInfo, 'load');

        loadToast(versionInfo);

        Runtime.onMessage.addListener((message, sender, sendResponse) => {
            handleMessage(message)
                .then(async (r) => {
                    sendResponse(r);
                })
                .catch((ex) => {
                    Console.warn(ex);
                    sendResponse();
                });
            return true;
        });

        sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.TAB_LOADED);

        loadedURL = url;
    }

    async function handleMessage(message, _sender) {
        if (!message.action) return undefined;
        switch (message.action) {
            case MESSAGE_ACTION.TO_CONTENT.REQUEST_ODOO_INFO: {
                return getOdooVersion();
            }
            case MESSAGE_ACTION.TO_CONTENT.CM_OPEN_MENU: {
                openPathMenu(message.menupath);
                return {};
            }
            case MESSAGE_ACTION.TO_CONTENT.CM_OPEN_RUNBOT: {
                openRunbotWithVersion();
                return {};
            }
        }
    }

    function addNavigationListener() {
        // Experimental: This is an experimental technology - firefox not compatible
        // navigation.addEventListener('navigate', (e) => {
        //     checkTaskPage(e.destination.url);
        // });
        // Chrome & Firefox compatible
        Runtime.onMessage.addListener(async (msg) => {
            if (msg.action !== MESSAGE_ACTION.TO_CONTENT.TAB_NAVIGATION) return;
            if (!loadedURL) return;
            if (!msg.navigator) return;
            const url = msg.url;
            if (loadedURL === url) return;
            loadedURL = url;
            const versionInfo = getOdooVersion();
            loadFeatures(url, versionInfo, 'navigate');
        });
    }

    function canContinue(url) {
        if (!url || !url.startsWith('http')) return false;
        return true;
        // TODO[VERSION] Limited feature like runbot, can work without version check
        // const { isOdoo, version } = getOdooVersion();
        // return isOdoo && isSupportedOdoo(version);
    }

    async function loadFeatures(url, versionInfo, trigger) {
        const response = await sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.GET_FEATURES_LIST);
        const features = response.features.filter((f) => f.trigger[trigger]);

        let importer = async (feature) => await importFeatureContentFile(feature.id);
        if (trigger === 'background') {
            importer = async (feature) => await importFeatureBackgroundTriggerFile(feature.id);
        }

        for (const feature of features) {
            const loader = await importer(feature);
            loader.load(url, versionInfo);
        }
    }

    //#endregion

    async function updateTabState(url) {
        const offs = await getWebsiteOff();
        if (offs.has(new URL(url).origin)) {
            await sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.UPDATE_EXT_STATUS, {
                forceSwitchToOFF: true,
            });
            return true;
        }
        return false;
    }

    function updateLandingPage() {
        for (const el of document.getElementsByClassName('joorney-landing-extension-state')) {
            el.style.color = '#fca311';
        }
    }

    async function openPathMenu(menupath) {
        try {
            const result = await getMenu(menupath);

            if (result.length === 0) {
                throw new Error(`Menu '${menupath}' not found.`);
            }
            if (result.length > 1) {
                throw new Error(`Too much menu found for path ${menupath}.`);
            }
            const menu = result[0];
            const windowActionID = menu.action.split(',')[1];
            const url = window.location;

            openURL(createActionMenuURL(url, windowActionID));
        } catch (err) {
            ToastManager.warn('contextOdooMenus', 'An error occur during menu opening', err.message);
        }
    }

    function openRunbotWithVersion() {
        const { version } = getOdooVersion();
        if (!version) return;
        openURL(getRunbotOpenUrl(version));
    }

    function openURL(url) {
        window.location = url;
    }

    var adminDebugLoginConfiguration = {
        id: 'adminDebugLoginRunbot',
        display_name: '[Runbot] Admin Debug Login',
        icon: '<i class="fa-solid fa-rocket"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: false,
            option: false,
        },
        defaultSettings: {
            adminDebugLoginRunbotEnabled: false,
            adminDebugLoginRunbotLimitedOrigins: ['https://runbot.odoo.com', 'regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
        },
        limited: true,
    };

    var configuration$d = {
        id: 'ambient',
        display_name: 'Ambient',
        icon: '<i class="fa-solid fa-mountain-sun"></i>', // '<i class="fa-solid fa-panorama"></i>'
        trigger: {
            background: false,
            load: true,
            navigate: false,
        },
        customization: {
            option: false,
            popup: false,
        },
        defaultSettings: {
            ambientEnabled: false,
            ambientWhitelistMode: false,
            ambientStatus: {},
        },
        supported_version: [],
    };

    var configuration$c = {
        id: 'assignMeTask',
        display_name: 'Assign Me Task',
        icon: '<i class="fa-solid fa-user-plus"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: false,
            option: false,
        },
        defaultSettings: {
            assignMeTaskEnabled: false,
            assignMeTaskWhitelistMode: false,
        },
        supported_version: ['16.3+'],
    };

    const openRunbotWithVersionMenuItem = {
        id: 'joorney_autoOpenRunbot_open_with_version',
        title: 'Open runbot with version %version%',
        active: true,
        favorite: true,
        order: 100,
    };

    var autoOpenRunbotConfiguration = {
        id: 'autoOpenRunbot',
        display_name: '[Runbot] Auto Open',
        icon: '<i class="fa-solid fa-fighter-jet"></i>',
        trigger: {
            load: true,
            navigate: true,
            context: true,
        },
        customization: {
            popup: false,
            option: false,
        },
        defaultSettings: {
            autoOpenRunbotEnabled: false,
            autoOpenRunbotLimitedOrigins: ['https://runbot.odoo.com'],
            autoOpenRunbotContextMenu: {
                [openRunbotWithVersionMenuItem.id]: openRunbotWithVersionMenuItem,
            },
        },
        limited: true,
    };

    var configuration$b = {
        id: 'awesomeLoadingLarge',
        display_name: 'Awesome Loading Large',
        icon: '<i class="fa-solid fa-circle-notch"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: true,
            option: true,
        },
        __comment__: 'awesomeLoadingImages is shared with awesomeLoadingSmall',
        defaultSettings: {
            awesomeLoadingLargeEnabled: false,
            awesomeLoadingLargeWhitelistMode: false,
            awesomeLoadingLargeImage: 'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            awesomeLoadingImages: [
                'https://github.githubassets.com/images/mona-loading-dark.gif',
                'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
                'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
            ],
        },
        supported_version: ['16:17'],
    };

    var configuration$a = {
        id: 'awesomeLoadingSmall',
        display_name: 'Awesome Loading Small',
        icon: '<i class="fa-solid fa-spinner"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: true,
            option: true,
        },
        __comment__: 'awesomeLoadingImages is shared with awesomeLoadingLarge',
        defaultSettings: {
            awesomeLoadingSmallEnabled: false,
            awesomeLoadingSmallWhitelistMode: false,
            awesomeLoadingSmallImage: '',
            awesomeLoadingImages: [
                'https://github.githubassets.com/images/mona-loading-dark.gif',
                'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
                'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
            ],
        },
        supported_version: ['15+'],
    };

    var configuration$9 = {
        id: 'awesomeStyle',
        display_name: 'Awesome Style',
        icon: '<i class="fa-brands fa-css3-alt"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: false,
            option: true,
        },
        defaultSettings: {
            awesomeStyleEnabled: false,
            awesomeStyleWhitelistMode: false,
            awesomeStyleCSS: '',
        },
        supported_version: ['15+'],
    };

    var configuration$8 = {
        id: 'impersonateLoginRunbot',
        display_name: '[Runbot] Impersonate Login',
        icon: '<i class="fa-solid fa-masks-theater"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: false,
            option: false,
        },
        defaultSettings: {
            impersonateLoginRunbotEnabled: false,
            impersonateLoginRunbotLimitedOrigins: ['regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
        },
        limited: true,
    };

    var configuration$7 = {
        id: 'newServerActionCode',
        display_name: 'New Server Action Code',
        icon: '<i class="fa-solid fa-code"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: false,
            option: false,
        },
        defaultSettings: {
            newServerActionCodeEnabled: false,
            newServerActionCodeWhitelistMode: false,
        },
        supported_version: ['16+'],
    };

    var configuration$6 = {
        id: 'pinMessage',
        display_name: 'Pin Message',
        icon: '<i class="fa-solid fa-thumbtack"></i>',
        trigger: {
            background: false,
            load: true,
            navigate: true,
            context: false,
            onrequest: [
                'https://*/*/mail.message/toggle_message_starred',
                'https://*/mail/message/update_content',
                'https://*/mail/thread/messages',
            ],
        },
        customization: {
            option: false,
            popup: true,
        },
        defaultSettings: {
            pinMessageEnabled: false,
            pinMessageWhitelistMode: false,
            pinMessageContextMenu: {},
            pinMessageSelfAuthorEnabled: true,
            pinMessageDefaultShown: false,
        },
        supported_version: ['17+'],
    };

    var configuration$5 = {
        id: 'saveKnowledge',
        display_name: 'Save Knowledge',
        icon: '<i class="fa-solid fa-bookmark"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: false,
            option: false,
        },
        defaultSettings: {
            saveKnowledgeEnabled: false,
            saveKnowledgeWhitelistMode: false,
        },
        supported_version: ['16:17'],
    };

    var configuration$4 = {
        id: 'showMyBadge',
        display_name: 'Show My Badge',
        icon: '<i class="fa-solid fa-certificate"></i>',
        trigger: {
            background: false,
            load: true,
            navigate: true,
        },
        customization: {
            option: false,
            popup: false,
        },
        defaultSettings: {
            showMyBadgeEnabled: false,
            showMyBadgeWhitelistMode: false,
        },
        supported_version: ['17+'],
    };

    var configuration$3 = {
        id: 'starringTaskEffect',
        display_name: 'Starring Task Effect',
        icon: '<i class="fa-solid fa-star"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: false,
            option: false,
        },
        defaultSettings: {
            starringTaskEffectEnabled: false,
            starringTaskEffectWhitelistMode: false,
        },
        supported_version: ['16+'],
    };

    var configuration$2 = {
        id: 'themeSwitch',
        display_name: 'Theme Switch',
        icon: '<i class="fa-solid fa-sun"></i>',
        trigger: {
            background: true,
            load: false,
            navigate: false,
        },
        customization: {
            popup: true,
            option: true,
        },
        __comment__: "themeSwitchMode: 'system', 'autoDark', 'autoLight', 'dynamicLocation', 'dynamicTime'",
        defaultSettings: {
            themeSwitchEnabled: false,
            themeSwitchWhitelistMode: false,
            themeSwitchMode: 'system',
            themeSwitchLocationLatitude: '51.477928',
            themeSwitchLocationLongitude: '-0.001545',
            themeSwitchDarkStartTime: '20:30',
            themeSwitchDarkStopTime: '07:30',
        },
        supported_version: ['16+'],
    };

    var configuration$1 = {
        id: 'tooltipMetadata',
        display_name: 'Tooltip Metadata',
        icon: '<i class="fa-solid fa-file-lines"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: false,
            option: false,
        },
        defaultSettings: {
            tooltipMetadataEnabled: false,
            tooltipMetadataWhitelistMode: false,
        },
        supported_version: ['15+'],
    };

    var configuration = {
        id: 'unfocusApp',
        display_name: 'Unfocus App',
        icon: '<i class="fa-solid fa-ghost"></i>',
        trigger: {
            load: true,
            navigate: true,
        },
        customization: {
            popup: true,
            option: true,
        },
        defaultSettings: {
            unfocusAppEnabled: false,
            unfocusAppWhitelistMode: false,
            unfocusAppReorderEnabled: false,
            unfocusAppShareEnabled: false,
            unfocusAppLightImageURL: 'https://i.imgur.com/AkTvOga.png',
            unfocusAppDarkImageURL: 'https://i.imgur.com/YzShNtH.png',
            unfocusAppOrigins: {},
        },
        supported_version: ['15+'],
    };

    class BackgroundTriggerContentFeature extends ContentFeature {
        async loadFeature(_url) {
            sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.TRIGGER_FEATURE, {
                feature: this.configuration.id,
                args: this.getArgs(),
            });
        }

        handlePopupMessage() {
            /* No message */
        }

        getArgs() {
            return {};
        }
    }

    async function getThemeModeCookie(origin, useConfiguredCookie) {
        if (!origin.startsWith('http')) return 'light';

        if (!Cookies) return getCookiesFromDocument(useConfiguredCookie);

        const cookies = await Promise.all([
            Cookies.get({
                name: 'configured_color_scheme',
                url: origin,
            }),
            Cookies.get({
                name: 'color_scheme',
                url: origin,
            }),
        ]);
        return cookies[1]?.value || 'light';
    }

    function getCookiesFromDocument(useConfiguredCookie) {
        if (!document) return 'light';

        const decodedCookie = decodeURIComponent(document.cookie);

        const cookieName =
            decodedCookie.includes('configured_color_scheme') && useConfiguredCookie
                ? 'configured_color_scheme'
                : decodedCookie.includes('color_scheme')
                  ? 'color_scheme'
                  : null;

        if (!cookieName) return 'light';

        const cookies = decodedCookie.split(';');

        const cookie = cookies.find((c) => c.trim().indexOf(cookieName) === 0).substring(cookieName.length + 2);

        return cookie || 'light';
    }

    class ThemeSwitchContentFeature extends BackgroundTriggerContentFeature {
        constructor() {
            super(configuration$2);
        }

        getArgs() {
            const theme = getPrefersColorScheme();
            if (!theme) return {};
            const version = getOdooVersion();
            return { theme, version };
        }
    }

    var background_trigger = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: ThemeSwitchContentFeature
    });

    class AdminDebugLoginRunbotContentFeature extends LimitedRunbotContentFeature {
        constructor() {
            super(adminDebugLoginConfiguration);
        }

        async loadFeature(url) {
            if (!this.isRunbotPage(url)) return;

            this.appendRunbotAdminDebugLogin();
        }

        async appendRunbotAdminDebugLogin() {
            const btnIdentifier = 'joorney-admin-debug-login-runbot';

            for (const e of document.getElementsByClassName(btnIdentifier)) e.remove();

            const signIn = Array.from(document.getElementsByClassName('fa fa-sign-in btn btn-info'));

            for (const btn of signIn) {
                if (!btn.href.includes('static/build')) {
                    const newBtn = document.createElement('a');
                    newBtn.className = `${btnIdentifier} fa fa-rocket btn btn-warning`;
                    newBtn.style.color = '#444';
                    newBtn.onclick = (e) => this.openEventRunbot(e, false);
                    newBtn.onauxclick = (e) => this.openEventRunbot(e, true);
                    newBtn.href = btn.href;
                    newBtn.title = 'Open runbot as admin and with debug mode enabled';
                    btn.after(newBtn);
                }
            }
        }

        async openEventRunbot(e, newTab) {
            e.preventDefault();
            try {
                await this.openRunbot(e.target.href, newTab);
            } catch (error) {
                Console.warn(error);
                e.target.classList.remove('btn-warning');
                e.target.classList.add('btn-danger');
                e.target.title = error;
            }
        }
    }

    var content$e = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: AdminDebugLoginRunbotContentFeature
    });

    // Based on: https://github.com/catdad/canvas-confetti/blob/master/src/confetti.js

    const global = globalThis;

    class Confetti {
        constructor(canvas = null, globalOpts = { resize: true, disableForReducedMotion: true }) {
            this.cannon = new ConfettiCannon(canvas, globalOpts);
        }

        fire(options) {
            this.cannon.fire(options);
        }

        reset() {
            this.cannon.reset();
        }
    }

    class ConfettiCannon {
        constructor(canvas, globalOpts) {
            this.isLibCanvas = !canvas;
            this.allowResize = !!prop(globalOpts || {}, 'resize');
            this.disableForReducedMotion = prop(globalOpts, 'disableForReducedMotion', Boolean);
            this.resizer = this.isLibCanvas ? this.setCanvasWindowSize : this.setCanvasRectSize;
            this.initialized = false;
            this.preferLessMotion = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion)').matches;
            this.animationObj = undefined;
            this.canvas = canvas;

            this.animator = new ConfettiAnimator();
        }

        //#region Canvas
        loadCanvas(zIndex) {
            if (this.isLibCanvas && this.animationObj) {
                // use existing canvas from in-progress animation
                this.canvas = this.animationObj.canvas;
            } else if (this.isLibCanvas && !this.canvas) {
                // create and initialize a new canvas
                this.canvas = this.getCanvas(zIndex);
                document.body.appendChild(this.canvas);
            }

            if (this.allowResize && !this.initialized) {
                // initialize the size of a user-supplied canvas
                this.resizer(this.canvas);
            }

            return this.canvas;
        }

        getCanvas(zIndex) {
            const canvas = document.createElement('canvas');

            canvas.style.position = 'fixed';
            canvas.style.top = '0px';
            canvas.style.left = '0px';
            canvas.style.pointerEvents = 'none';
            canvas.style.zIndex = zIndex;

            return canvas;
        }

        setCanvasRectSize(canvas) {
            const rect = canvas.getBoundingClientRect();
            canvas.width = rect.width;
            canvas.height = rect.height;
        }

        setCanvasWindowSize(canvas) {
            canvas.width = document.documentElement.clientWidth;
            canvas.height = document.documentElement.clientHeight;
        }
        //#endregion

        fire(options) {
            if (this.disableForReducedMotion && this.preferLessMotion) {
                return promise((resolve) => resolve());
            }

            this.loadCanvas(prop(options, 'zIndex', Number));

            const size = {
                width: this.canvas.width,
                height: this.canvas.height,
            };

            this.initialized = true;

            function onResize() {
                // don't actually query the size here, since this
                // can execute frequently and rapidly
                size.width = size.height = null;
            }

            if (this.allowResize) global.addEventListener('resize', onResize, false);

            const fireDone = () => {
                this.animationObj = null;

                if (this.allowResize) global.removeEventListener('resize', onResize);

                if (this.isLibCanvas && this.canvas) {
                    document.body.removeChild(this.canvas);
                    this.canvas = null;
                    this.initialized = false;
                }
            };

            return this.fireLocal(options, size, fireDone);
        }

        reset() {
            if (this.animationObj) this.animationObj.reset();
        }

        fireLocal(options, size, done) {
            const particleCount = prop(options, 'particleCount', onlyPositiveInt);
            const angle = prop(options, 'angle', Number);
            const spread = prop(options, 'spread', Number);
            const startVelocity = prop(options, 'startVelocity', Number);
            const decay = prop(options, 'decay', Number);
            const gravity = prop(options, 'gravity');
            const drift = prop(options, 'drift');
            const colors = prop(options, 'colors', colorsToRgb);
            const ticks = prop(options, 'ticks', Number);
            const shapes = prop(options, 'shapes');
            const scalar = prop(options, 'scalar');
            const flat = !!prop(options, 'flat');
            const origin = getOrigin(options);
            const alpha = getAlpha(options);

            let temp = particleCount;
            const fettis = [];

            const startX = this.canvas.width * origin.x;
            const startY = this.canvas.height * origin.y;

            while (temp--) {
                fettis.push(
                    Fetti.randomPhysics({
                        x: startX,
                        y: startY,
                        angle: angle,
                        spread: spread,
                        startVelocity: startVelocity,
                        color:
                            colors.length <= particleCount
                                ? colors[temp % colors.length]
                                : colors[Math.round(randomInRange$1(0, colors.length - 1))],
                        shape: shapes[randomInt(0, shapes.length)],
                        ticks: ticks,
                        decay: decay,
                        gravity: gravity,
                        drift: drift,
                        scalar: scalar,
                        flat: flat,
                        alpha: alpha,
                    })
                );
            }

            // if we have a previous canvas already animating, add to it
            if (this.animationObj) return this.animationObj.addFettis(fettis);

            this.animationObj = this.animator.animate(this.canvas, fettis, this.resizer, size, done);
            return this.animationObj.promise;
        }
    }

    class ConfettiAnimator {
        constructor() {
            this.TIME = Math.floor(1000 / 60);
            this.frames = {};
            this.lastFrameTime = 0;

            if (typeof requestAnimationFrame === 'function' && typeof cancelAnimationFrame === 'function') {
                this.frame = (cb) => this.frameFct(cb);
                this.cancel = (id) => this.cancelFct(id);
            } else {
                this.frame = (cb) => setTimeout(cb, this.TIME);
                this.cancel = (timer) => clearTimeout(timer);
            }
        }

        onFrame(time, id, cb) {
            if (this.lastFrameTime === time || this.lastFrameTime + this.TIME - 1 < time) {
                this.lastFrameTime = time;
                delete this.frames[id];
                cb();
                return;
            }
            this.frames[id] = requestAnimationFrame((time) => this.onFrame(time, id, cb));
        }

        frameFct(cb) {
            const id = Math.random();
            this.frames[id] = requestAnimationFrame((time) => this.onFrame(time, id, cb));
            return id;
        }

        cancelFct(id) {
            if (frames[id]) cancelAnimationFrame(frames[id]);
        }

        animate(canvas, fettis, resizer, size, done) {
            let animatingFettis = fettis.slice();
            const context = canvas.getContext('2d');
            let animationFrame;
            let destroy;

            const self = this;
            function getAnimatePromise() {
                return promise((resolve) => {
                    function onDone() {
                        animationFrame = destroy = null;
                        context.clearRect(0, 0, size.width, size.height);

                        done();
                        resolve();
                    }

                    function update() {
                        if (!size.width && !size.height) {
                            resizer(canvas);
                            size.width = canvas.width;
                            size.height = canvas.height;
                        }

                        context.clearRect(0, 0, size.width, size.height);

                        animatingFettis = animatingFettis.filter((fetti) => fetti.updateFetti(context));

                        if (animatingFettis.length) {
                            animationFrame = self.frame(update);
                        } else {
                            onDone();
                        }
                    }

                    animationFrame = self.frame(update);
                    destroy = onDone;
                });
            }

            const prom = getAnimatePromise();

            return {
                canvas: canvas,
                promise: prom,
                addFettis: (fettis) => {
                    animatingFettis = animatingFettis.concat(fettis);
                    return prom;
                },
                reset: () => {
                    if (animationFrame) this.cancel(animationFrame);
                    if (destroy) destroy();
                },
            };
        }
    }

    class Fetti {
        static randomPhysics(opts) {
            const radAngle = opts.angle * (Math.PI / 180);
            const radSpread = opts.spread * (Math.PI / 180);
            let scalar = opts.scalar;
            if (typeof scalar === 'function') {
                scalar = scalar() ?? 1;
            }
            let gravity = opts.gravity;
            if (typeof gravity === 'function') {
                gravity = gravity() ?? 1;
            }
            let drift = opts.drift;
            if (typeof drift === 'function') {
                drift = drift() ?? 1;
            }

            return new Fetti(
                opts.x,
                opts.y,
                Math.random() * 10,
                Math.min(0.11, Math.random() * 0.1 + 0.05),
                opts.startVelocity * 0.5 + Math.random() * opts.startVelocity,
                -radAngle + (0.5 * radSpread - Math.random() * radSpread),
                (Math.random() * (0.75 - 0.25) + 0.25) * Math.PI,
                opts.color,
                opts.shape,
                0,
                opts.ticks,
                opts.decay,
                drift,
                Math.random() + 2,
                0,
                0,
                0,
                0,
                gravity * 3,
                0.6,
                scalar,
                opts.flat,
                opts.alpha
            );
        }

        constructor(
            x,
            y,
            wobble,
            wobbleSpeed,
            velocity,
            angle2D,
            tiltAngle,
            color,
            shape,
            tick,
            totalTicks,
            decay,
            drift,
            random,
            tiltSin,
            tiltCos,
            wobbleX,
            wobbleY,
            gravity,
            ovalScalar,
            scalar,
            flat,
            alpha
        ) {
            this.x = x;
            this.y = y;
            this.wobble = wobble;
            this.wobbleSpeed = wobbleSpeed;
            this.velocity = velocity;
            this.angle2D = angle2D;
            this.tiltAngle = tiltAngle;
            this.color = color;
            this.shape = shape;
            this.tick = tick;
            this.totalTicks = totalTicks;
            this.decay = decay;
            this.drift = drift;
            this.random = random;
            this.tiltSin = tiltSin;
            this.tiltCos = tiltCos;
            this.wobbleX = wobbleX;
            this.wobbleY = wobbleY;
            this.gravity = gravity;
            this.ovalScalar = ovalScalar;
            this.scalar = scalar;
            this.flat = flat;
            this.alpha = alpha;
        }

        ellipse(context, x, y, radiusX, radiusY, rotation, startAngle, endAngle, antiClockwise) {
            context.save();
            context.translate(x, y);
            context.rotate(rotation);
            context.scale(radiusX, radiusY);
            context.arc(0, 0, 1, startAngle, endAngle, antiClockwise);
            context.restore();
        }

        updateFettiBitmap(context, x1, x2, y1, y2, alpha) {
            const rotation = (Math.PI / 10) * this.wobble;
            const scaleX = Math.abs(x2 - x1) * 0.1;
            const scaleY = Math.abs(y2 - y1) * 0.1;
            const width = this.shape.bitmap.width * this.scalar;
            const height = this.shape.bitmap.height * this.scalar;

            const matrix = new DOMMatrix([
                Math.cos(rotation) * scaleX,
                Math.sin(rotation) * scaleX,
                -Math.sin(rotation) * scaleY,
                Math.cos(rotation) * scaleY,
                this.x,
                this.y,
            ]);

            // apply the transform matrix from the confetti shape
            matrix.multiplySelf(new DOMMatrix(this.shape.matrix));

            const pattern = context.createPattern(this.shape.bitmap, 'no-repeat');
            pattern.setTransform(matrix);

            context.globalAlpha = alpha;
            context.fillStyle = pattern;
            context.fillRect(this.x - width / 2, this.y - height / 2, width, height);
            context.globalAlpha = 1;
        }

        updateFettiCircle(context, x1, x2, y1, y2) {
            context.ellipse
                ? context.ellipse(
                      this.x,
                      this.y,
                      Math.abs(x2 - x1) * this.ovalScalar,
                      Math.abs(y2 - y1) * this.ovalScalar,
                      (Math.PI / 10) * this.wobble,
                      0,
                      2 * Math.PI
                  )
                : this.ellipse(
                      context,
                      this.x,
                      this.y,
                      Math.abs(x2 - x1) * this.ovalScalar,
                      Math.abs(y2 - y1) * this.ovalScalar,
                      (Math.PI / 10) * this.wobble,
                      0,
                      2 * Math.PI
                  );
        }

        updateFettiStar(context) {
            let rot = (Math.PI / 2) * 3;
            const innerRadius = 4 * this.scalar;
            const outerRadius = 8 * this.scalar;
            let x = this.x;
            let y = this.y;
            let spikes = 5;
            const step = Math.PI / spikes;

            while (spikes--) {
                x = this.x + Math.cos(rot) * outerRadius;
                y = this.y + Math.sin(rot) * outerRadius;
                context.lineTo(x, y);
                rot += step;

                x = this.x + Math.cos(rot) * innerRadius;
                y = this.y + Math.sin(rot) * innerRadius;
                context.lineTo(x, y);
                rot += step;
            }
        }

        updateFetti(context) {
            this.x += Math.cos(this.angle2D) * this.velocity + this.drift;
            this.y += Math.sin(this.angle2D) * this.velocity + this.gravity;
            this.velocity *= this.decay;

            if (this.flat) {
                this.wobble = 0;
                this.wobbleX = this.x + 10 * this.scalar;
                this.wobbleY = this.y + 10 * this.scalar;

                this.tiltSin = 0;
                this.tiltCos = 0;
                this.random = 1;
            } else {
                this.wobble += this.wobbleSpeed;
                this.wobbleX = this.x + 10 * this.scalar * Math.cos(this.wobble);
                this.wobbleY = this.y + 10 * this.scalar * Math.sin(this.wobble);

                this.tiltAngle += 0.1;
                this.tiltSin = Math.sin(this.tiltAngle);
                this.tiltCos = Math.cos(this.tiltAngle);
                this.random = Math.random() + 2;
            }

            const progress = this.tick++ / this.totalTicks;

            const x1 = this.x + this.random * this.tiltCos;
            const y1 = this.y + this.random * this.tiltSin;
            const x2 = this.wobbleX + this.random * this.tiltCos;
            const y2 = this.wobbleY + this.random * this.tiltSin;

            let alpha = 1 - progress;
            if (this.alpha.invert) {
                alpha = progress;
            } else if (this.alpha.double) {
                alpha = progress < 0.5 ? progress / 0.5 : progress > 0.5 ? 1 - (progress / 0.5 - 1) : 1;
            }
            if (this.alpha.max) {
                alpha *= this.alpha.max;
            }

            context.fillStyle = `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${alpha})`;
            context.beginPath();

            if (this.shape.type === 'path' && typeof this.shape.path === 'string' && Array.isArray(this.shape.matrix)) {
                context.fill(
                    this.transformPath2D(
                        this.shape.path,
                        this.shape.matrix,
                        this.x,
                        this.y,
                        Math.abs(x2 - x1) * 0.1,
                        Math.abs(y2 - y1) * 0.1,
                        (Math.PI / 10) * this.wobble
                    )
                );
            } else if (this.shape.type === 'bitmap') {
                this.updateFettiBitmap(context, x1, x2, y1, y2, alpha);
            } else if (this.shape === 'circle') {
                this.updateFettiCircle(context, x1, x2, y1, y2);
            } else if (this.shape === 'star') {
                this.updateFettiStar(context);
            } else {
                context.moveTo(Math.floor(this.x), Math.floor(this.y));
                context.lineTo(Math.floor(this.wobbleX), Math.floor(y1));
                context.lineTo(Math.floor(x2), Math.floor(y2));
                context.lineTo(Math.floor(x1), Math.floor(this.wobbleY));
            }

            context.closePath();
            context.fill();

            return this.tick < this.totalTicks;
        }

        transformPath2D(pathString, pathMatrix, x, y, scaleX, scaleY, rotation) {
            const path2d = new Path2D(pathString);

            const t1 = new Path2D();
            t1.addPath(path2d, new DOMMatrix(pathMatrix));

            const t2 = new Path2D();
            // see https://developer.mozilla.org/en-US/docs/Web/API/DOMMatrix/DOMMatrix
            t2.addPath(
                t1,
                new DOMMatrix([
                    Math.cos(rotation) * scaleX,
                    Math.sin(rotation) * scaleX,
                    -Math.sin(rotation) * scaleY,
                    Math.cos(rotation) * scaleY,
                    x,
                    y,
                ])
            );

            return t2;
        }
    }

    //#region Options
    const defaults = {
        particleCount: 50,
        angle: 90,
        spread: 45,
        startVelocity: 45,
        decay: 0.9,
        gravity: 1,
        drift: 0,
        ticks: 200,
        x: 0.5,
        y: 0.5,
        shapes: ['square', 'circle'],
        zIndex: 100,
        colors: ['#26ccff', '#a25afd', '#ff5e7e', '#88ff5a', '#fcff42', '#ffa62d', '#ff36ff'],
        // probably should be true, but back-compat
        disableForReducedMotion: false,
        scalar: 1,
    };

    function getOrigin(options) {
        const origin = prop(options, 'origin', Object);
        origin.x = prop(origin, 'x', Number);
        origin.y = prop(origin, 'y', Number);

        return origin;
    }

    function getAlpha(options) {
        const alpha = prop(options, 'alpha', Object);
        alpha.max = prop(alpha, 'max', Number);
        alpha.double = prop(alpha, 'double', Boolean);
        alpha.invert = prop(alpha, 'invert', Boolean);

        return alpha;
    }

    function convert(val, transform) {
        return transform ? transform(val) : val;
    }

    function isOk(val) {
        return !(val === null || val === undefined);
    }

    function prop(options, name, transform) {
        return convert(options && isOk(options[name]) ? options[name] : defaults[name], transform);
    }
    //#endregion

    //#region Utils
    function promise(func) {
        return new Promise(func);
    }

    function onlyPositiveInt(number) {
        return number < 0 ? 0 : Math.floor(number);
    }

    function randomInt(min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    }

    function toDecimal(str) {
        return Number.parseInt(str, 16);
    }

    function colorsToRgb(colors) {
        return colors.map(hexToRgb);
    }

    function hexToRgb(str) {
        let val = String(str).replace(/[^0-9a-f]/gi, '');

        if (val.length < 6) {
            val = val[0] + val[0] + val[1] + val[1] + val[2] + val[2];
        }

        return {
            r: toDecimal(val.substring(0, 2)),
            g: toDecimal(val.substring(2, 4)),
            b: toDecimal(val.substring(4, 6)),
        };
    }

    function shapeFromText(textData, flips = { vertical: false, horizontal: false }) {
        let text;
        let scalar = 1;
        let color = '#000000';
        let // see https://nolanlawson.com/2022/04/08/the-struggle-of-using-native-emoji-on-the-web/
            fontFamily =
                '"Twemoji Mozilla", "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "system emoji", sans-serif';

        if (typeof textData === 'string') {
            text = textData;
        } else {
            text = textData.text;
            scalar = 'scalar' in textData ? textData.scalar : scalar;
            fontFamily = 'fontFamily' in textData ? textData.fontFamily : fontFamily;
            color = 'color' in textData ? textData.color : color;
        }

        // all other confetti are 10 pixels,
        // so this pixel size is the de-facto 100% scale confetti
        const fontSize = 10 * scalar;
        const font = `${fontSize}px ${fontFamily}`;

        let canvas = new OffscreenCanvas(1, 1);
        let ctx = canvas.getContext('2d');

        ctx.font = font;
        const size = ctx.measureText(text);
        const width = Math.floor(size.width);
        const height = Math.floor(size.fontBoundingBoxAscent + size.fontBoundingBoxDescent);

        canvas = new OffscreenCanvas(width, height);
        ctx = canvas.getContext('2d');
        ctx.font = font;
        ctx.fillStyle = color;

        ctx.fillText(text, 0, fontSize);

        const scale = 1 / scalar;

        return {
            type: 'bitmap',
            // TODO these probably need to be transfered for workers
            bitmap: canvas.transferToImageBitmap(),
            matrix: [
                scale * (flips?.horizontal ? -1 : 1),
                0,
                0,
                scale * (flips?.vertical ? -1 : 1),
                (-width * scale) / 2,
                (-height * scale) / 2,
            ],
        };
    }

    //#endregion

    function randomInRange$1(min, max) {
        return Math.random() * (max - min) + min;
    }

    class AmbientLoader {
        constructor(ambientConfetti) {
            this.ambientConfetti = ambientConfetti;
            this.stopped = true;
        }

        async stop(delay) {
            this.stopped = true;
            await this.ambientConfetti.reset();
            await new Promise((r) => setTimeout(r, delay + 10));
        }

        async load(ambientData) {
            if (!ambientData) return;
            switch (ambientData.type) {
                case 'long':
                    this.loadAmbient(ambientData.load, ambientData.duration);
                    break;
                case 'count':
                    this.loadAmbientCount(ambientData.load, ambientData.count, ambientData.delay);
                    break;
                case 'onetime':
                    this.loadOneTimeAmbient(ambientData.load);
                    break;
            }
        }

        async loadAmbientCount(ambientLoader, count, delay) {
            await this.stop(0);
            this.stopped = false;
            this.loadAmbient(ambientLoader, count * delay, count);
        }

        async loadOneTimeAmbient(ambientLoader) {
            await this.stop(0);
            this.stopped = false;
            const ambients = await ambientLoader();
            this.playAmbients(ambients);
        }

        async loadAmbient(
            ambientLoader,
            duration,
            countArg = undefined,
            animationStartArg = Date.now(),
            animationEnd = animationStartArg + duration,
            delay = countArg ? duration / Number.parseFloat(countArg) : 1
        ) {
            await this.stop(delay);
            this.stopped = false;
            this._loadAmbient(ambientLoader, duration, countArg, animationStartArg, animationEnd, delay);
        }

        async _loadAmbient(ambientLoader, duration, countArg, animationStartArg, animationEnd, delay) {
            const now = Date.now();
            const timeLeft = animationEnd - now;
            const ticks = Math.max(200, 500 * (timeLeft / duration));
            const ambients = await ambientLoader(ticks);

            let count = countArg;
            let animationStart = animationStartArg;

            if (count) {
                const ellapsed = now - animationStart;

                if (ellapsed >= delay) {
                    this.playAmbients(ambients);
                    count--;
                    animationStart = now;
                }
            } else if (count === undefined) {
                this.playAmbients(ambients);
            }

            if (timeLeft > 0 && !this.stopped) {
                requestAnimationFrame(() =>
                    this._loadAmbient(ambientLoader, duration, count, animationStart, animationEnd, delay)
                );
            }
        }

        playAmbients(ambientsArg) {
            const ambients = Array.isArray(ambientsArg) ? ambientsArg : [ambientsArg];
            for (const ambient of ambients) {
                this.ambientConfetti.fire(ambient);
            }
        }
    }

    // note: you CAN only use a path for confetti.shapeFrompath(), but for
    // performance reasons it is best to use it once in development and save
    // the result to avoid the performance penalty at runtime
    // https://svg-path-visualizer.netlify.app/

    /*
    // From bubble emoji: https://images.emojiterra.com/google/noto-emoji/unicode-15.1/color/svg/1fae7.svg
    // Large
    shapeFromPath(
    	'M68.48 46.02C65.29 45.09 65.41 48.52 62.05 53.99C59.81 57.63 55.09 62.36 47.41 64.25C42.89 65.36 40.86 66.31 40.73 67.97C40.5 70.8 44.35 71.56 49.94 70.1C64.76 66.25 75.25 47.99 68.48 46.02Z M34.9902 10.2501C39.3802 11.7601 40.5402 15.6801 39.1902 19.0301C37.9502 22.1101 33.2902 23.5001 30.3702 25.0901C25.9202 27.5001 22.6902 30.6301 20.2802 35.0801C17.9502 39.3801 11.6702 41.1201 10.8102 34.8701C10.1402 29.9801 13.1802 23.0201 16.0302 19.4501C18.5502 16.3001 22.0102 13.4901 25.6302 11.6901C28.1802 10.4301 32.2202 9.30006 34.9902 10.2501Z M55.4199 12.46C57.2199 13.98 57.4299 16.77 54.9399 17.64C53.8299 17.95 52.6699 17.45 51.5199 17.37C49.1799 17.21 48.2099 18.04 46.2099 17.19C43.2299 15.91 41.9999 13.33 43.4199 11.21C44.1199 10.17 45.4499 9.63996 46.6299 9.40996C49.8299 8.78996 53.1699 10.2 55.4199 12.46Z M39.88 79.75C17.89 79.75 0 61.86 0 39.87C0 17.88 17.89 0 39.88 0C61.87 0 79.76 17.89 79.76 39.88C79.76 61.87 61.86 79.75 39.88 79.75ZM40.5 4.22C20.44 4.22 4.13 20.53 4.13 40.59C4.13 60.65 20.45 76.96 40.5 76.96C60.55 76.96 76.87 60.64 76.87 40.59C76.87 20.54 60.55 4.22 40.5 4.22Z'
    )
    // Medium
    shapeFromPath(
    	'M40.6301 28.96C38.1901 28.13 38.7701 31.89 33.9501 35.28C28.8101 38.9 25.7001 38.03 25.5201 40.08C25.3301 42.27 30.6801 42.26 36.2501 38.11C41.0801 34.53 43.1001 29.8 40.6301 28.96Z M24.2696 47.52C11.2296 47.52 0.619629 36.91 0.619629 23.87C0.619629 10.83 11.2296 0.219971 24.2696 0.219971C37.3096 0.219971 47.9196 10.83 47.9196 23.87C47.9196 36.91 37.3096 47.52 24.2696 47.52ZM24.8696 3.10997C13.3496 3.10997 3.97963 12.48 3.97963 24C3.97963 35.52 13.3496 44.89 24.8696 44.89C36.3896 44.89 45.7596 35.52 45.7596 24C45.7596 12.48 36.3896 3.10997 24.8696 3.10997Z M19.0198 7.31001C23.4198 7.01001 24.9398 10.15 23.8498 12.64C22.4498 15.84 19.1898 14.7 16.3198 17.81C14.3398 19.96 10.1098 22.29 9.51979 17.54C8.99979 13.34 13.6498 7.68001 19.0198 7.31001Z M31.7194 13C34.3694 12.99 34.6894 10.01 33.2694 8.41996C31.6294 5.96996 26.1394 6.22996 27.4394 10.27C28.0094 12.05 29.0494 13.01 31.7194 13Z'
    )
    // Small
    shapeFromPath(
    	'M31.6804 20.37C32.2604 17.3 31.5304 10.85 28.4204 12.91C27.1704 13.74 29.1404 17.29 28.5404 20.34C27.7404 24.43 26.2204 26.57 22.6404 29.12C21.8204 29.7 22.2604 30.78 23.8104 30.22C27.9004 28.75 30.6804 25.71 31.6804 20.37Z M16.5102 6.67002C17.2202 8.15002 14.9602 10.03 14.0802 11.2C11.7902 14.25 12.9802 16.62 11.2702 19.4C9.98017 21.49 5.89016 22.93 5.12016 17.82C4.64016 14.62 6.64016 11 8.00016 9.52002C12.5102 4.62002 15.9202 5.45002 16.5102 6.67002Z M18.37 36.74C8.24 36.74 0 28.5 0 18.37C0 8.24 8.24 0 18.37 0C28.5 0 36.74 8.24 36.74 18.37C36.74 28.5 28.49 36.74 18.37 36.74ZM18.02 2.6C9.32 2.6 2.24001 9.68 2.24001 18.38C2.24001 27.08 9.32 34.16 18.02 34.16C26.72 34.16 33.8 27.08 33.8 18.38C33.8 9.68 26.73 2.6 18.02 2.6Z'
    )
    */
    const bubbles = {
        large: {
            type: 'path',
            path: 'M68.48 46.02C65.29 45.09 65.41 48.52 62.05 53.99C59.81 57.63 55.09 62.36 47.41 64.25C42.89 65.36 40.86 66.31 40.73 67.97C40.5 70.8 44.35 71.56 49.94 70.1C64.76 66.25 75.25 47.99 68.48 46.02Z M34.9902 10.2501C39.3802 11.7601 40.5402 15.6801 39.1902 19.0301C37.9502 22.1101 33.2902 23.5001 30.3702 25.0901C25.9202 27.5001 22.6902 30.6301 20.2802 35.0801C17.9502 39.3801 11.6702 41.1201 10.8102 34.8701C10.1402 29.9801 13.1802 23.0201 16.0302 19.4501C18.5502 16.3001 22.0102 13.4901 25.6302 11.6901C28.1802 10.4301 32.2202 9.30006 34.9902 10.2501Z M55.4199 12.46C57.2199 13.98 57.4299 16.77 54.9399 17.64C53.8299 17.95 52.6699 17.45 51.5199 17.37C49.1799 17.21 48.2099 18.04 46.2099 17.19C43.2299 15.91 41.9999 13.33 43.4199 11.21C44.1199 10.17 45.4499 9.63996 46.6299 9.40996C49.8299 8.78996 53.1699 10.2 55.4199 12.46Z M39.88 79.75C17.89 79.75 0 61.86 0 39.87C0 17.88 17.89 0 39.88 0C61.87 0 79.76 17.89 79.76 39.88C79.76 61.87 61.86 79.75 39.88 79.75ZM40.5 4.22C20.44 4.22 4.13 20.53 4.13 40.59C4.13 60.65 20.45 76.96 40.5 76.96C60.55 76.96 76.87 60.64 76.87 40.59C76.87 20.54 60.55 4.22 40.5 4.22Z',
            matrix: [0.1282051282051282, 0, 0, 0.1282051282051282, -5, -5.128205128205128],
        },
        medium: {
            type: 'path',
            path: 'M40.6301 28.96C38.1901 28.13 38.7701 31.89 33.9501 35.28C28.8101 38.9 25.7001 38.03 25.5201 40.08C25.3301 42.27 30.6801 42.26 36.2501 38.11C41.0801 34.53 43.1001 29.8 40.6301 28.96Z M24.2696 47.52C11.2296 47.52 0.619629 36.91 0.619629 23.87C0.619629 10.83 11.2296 0.219971 24.2696 0.219971C37.3096 0.219971 47.9196 10.83 47.9196 23.87C47.9196 36.91 37.3096 47.52 24.2696 47.52ZM24.8696 3.10997C13.3496 3.10997 3.97963 12.48 3.97963 24C3.97963 35.52 13.3496 44.89 24.8696 44.89C36.3896 44.89 45.7596 35.52 45.7596 24C45.7596 12.48 36.3896 3.10997 24.8696 3.10997Z M19.0198 7.31001C23.4198 7.01001 24.9398 10.15 23.8498 12.64C22.4498 15.84 19.1898 14.7 16.3198 17.81C14.3398 19.96 10.1098 22.29 9.51979 17.54C8.99979 13.34 13.6498 7.68001 19.0198 7.31001Z M31.7194 13C34.3694 12.99 34.6894 10.01 33.2694 8.41996C31.6294 5.96996 26.1394 6.22996 27.4394 10.27C28.0094 12.05 29.0494 13.01 31.7194 13Z',
            matrix: [0.22727272727272727, 0, 0, 0.22727272727272727, -5.454545454545454, -5.454545454545454],
        },
        small: {
            type: 'path',
            path: 'M31.6804 20.37C32.2604 17.3 31.5304 10.85 28.4204 12.91C27.1704 13.74 29.1404 17.29 28.5404 20.34C27.7404 24.43 26.2204 26.57 22.6404 29.12C21.8204 29.7 22.2604 30.78 23.8104 30.22C27.9004 28.75 30.6804 25.71 31.6804 20.37Z M16.5102 6.67002C17.2202 8.15002 14.9602 10.03 14.0802 11.2C11.7902 14.25 12.9802 16.62 11.2702 19.4C9.98017 21.49 5.89016 22.93 5.12016 17.82C4.64016 14.62 6.64016 11 8.00016 9.52002C12.5102 4.62002 15.9202 5.45002 16.5102 6.67002Z M18.37 36.74C8.24 36.74 0 28.5 0 18.37C0 8.24 8.24 0 18.37 0C28.5 0 36.74 8.24 36.74 18.37C36.74 28.5 28.49 36.74 18.37 36.74ZM18.02 2.6C9.32 2.6 2.24001 9.68 2.24001 18.38C2.24001 27.08 9.32 34.16 18.02 34.16C26.72 34.16 33.8 27.08 33.8 18.38C33.8 9.68 26.73 2.6 18.02 2.6Z',
            matrix: [0.29411764705882354, 0, 0, 0.29411764705882354, -5.588235294117648, -5.588235294117648],
        },
    };

    //#region Abstract Loader
    const lockedState = ['circle', 'square', 'star'];
    const emojisLoader = ({
        emojis,
        alpha,
        size,
        gravity,
        drift,
        xRange,
        yRange,
        color = '#ffffff',
        flat = true,
        flipHorizontal = false,
        flipVertical = false,
    }) => {
        const emojisBitmap = emojis.map((emoji) =>
            lockedState.includes(emoji)
                ? emoji
                : shapeFromText(
                      { text: emoji, scalar: size?.max ?? 1, color: color },
                      { vertical: flipVertical, horizontal: flipHorizontal }
                  )
        );

        return shapesLoader({
            shapes: emojisBitmap,
            alpha,
            size,
            gravity,
            drift,
            xRange,
            yRange,
            colors: [color],
            flat,
        });
    };

    const shapesLoader = ({
        shapes,
        alpha = { max: 1, double: true },
        size = { min: 1, max: 1, dynamic: false },
        gravity = { min: 0.4, max: 0.6, dynamic: false },
        drift = { min: -0.4, max: 0.4, dynamic: false },
        xRange = { min: 0, max: 1 },
        yRange = { min: 0, max: 1 }, // Top = 0, Bottom = 1
        colors = ['#ffffff'],
        flat = true,
    }) => {
        const scalarComputed = size.dynamic ? () => Math.round(randomInRange(size.min, size.max)) : size.max;
        const gravityComputed = gravity.dynamic ? () => randomInRange(gravity.min, gravity.max) : gravity.max;
        const driftComputed = drift.dynamic ? () => randomInRange(drift.min, drift.max) : drift.max;

        return (ticks) => ({
            flat,
            particleCount: 1,
            startVelocity: 0,
            ticks,
            origin: {
                x: randomInRange(xRange.min, xRange.max),
                y: randomInRange(yRange.min, yRange.max),
            },
            colors,
            shapes,
            gravity: gravityComputed,
            scalar: scalarComputed,
            drift: driftComputed,
            alpha,
        });
    };

    const fireworkLoader = (colors, mixColor, smallAndLarge, doubleBurst) => {
        return (_ticks) => {
            const loads = [
                {
                    startVelocity: 30,
                    spread: 360,
                    ticks: 60,
                    zIndex: 0,
                    particleCount: 50,
                    origin: { x: randomInRange(0.1, 0.5), y: Math.random() - 0.2 },
                    colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
                },
                {
                    startVelocity: 30,
                    spread: 360,
                    ticks: 60,
                    zIndex: 0,
                    particleCount: 50,
                    origin: { x: randomInRange(0.5, 0.9), y: Math.random() - 0.2 },
                    colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
                },
            ];
            if (smallAndLarge) {
                loads.concat(
                    loads.map((l) => {
                        l.particleCount *= 2;
                        return l;
                    })
                );
            }

            const firework = loads[Math.round(randomInRange(0, loads.length - 1))];
            if (doubleBurst) {
                const fireworkInside = {
                    ...firework,
                    startVelocity: 15,
                    colors: mixColor ? colors : [colors[Math.round(randomInRange(0, colors.length - 1))]],
                };
                return [firework, fireworkInside];
            }
            return firework;
        };
    };
    const schoolPrideLoader = (colors) => {
        return (_ticks) => {
            return [
                {
                    particleCount: 2,
                    angle: 60,
                    spread: 55,
                    origin: { x: 0 },
                    colors: colors,
                },
                {
                    particleCount: 2,
                    angle: 120,
                    spread: 55,
                    origin: { x: 1 },
                    colors: colors,
                },
            ];
        };
    };
    const floatingLoader = (emojis) => {
        return emojisLoader({
            emojis: emojis,
            alpha: { max: 0.2, double: true },
            size: { min: 8, max: 20, dynamic: true },
            gravity: { min: -0.6, max: -0.4, dynamic: true },
            drift: { min: -0.4, max: 0.4, dynamic: true },
            yRange: { min: 0.5, max: 1 },
        });
    };

    const ambients = {
        compute: {
            name: 'Computed Events',
            ambients: [
                {
                    name: `Odoo Experience ${new Date().getFullYear()}`,
                    id: 'odoo-experience-oxp-cpt',
                    computeDates: async () => {
                        return await getOdooEventDate(['name', '=', `Odoo Experience ${new Date().getFullYear()}`]);
                    },
                    type: 'long',
                    duration: 3000,
                    load: schoolPrideLoader(['#FBB130', '#714b67', '#050a30']),
                },
                {
                    name: 'Future Community Days',
                    id: 'odoo-community-days-cpt',
                    computeDates: async () => {
                        return await getOdooEventDate(['name', '=like', '%Community Days%']);
                    },
                    type: 'long',
                    duration: 3000,
                    load: schoolPrideLoader(['#714B67', '#FFFFFF', '#017E84']),
                },
            ],
        },
        event: {
            name: 'Events',
            ambients: [
                // {
                //     name: 'Developer Test',
                //     id: 'joorney-test-ambient-evt',
                //     date: new Date().toISOString(),
                //     type: 'count',
                //     count: 20,
                //     delay: 250,
                //     load: fireworkLoader(['#FFFFFF', '#000000'], true, false, false),
                // },
                {
                    name: 'Happy Birthday Odoo!',
                    id: 'odoo-birthday-evt',
                    // date: '2005-02-22T12:00:00Z', // TinyERP
                    // date: '2009-04-14T12:00:00Z', // OpenERP
                    date: '2014-05-15T12:00:00Z',
                    type: 'count',
                    count: 20,
                    delay: 250,
                    load: fireworkLoader(['#E46E78', '#21B799', '#5B899E', '#E4A900'], true, false, false),
                },
                {
                    name: 'New Year, Countdown',
                    id: 'new-year-evt',
                    date_from: `${new Date().getFullYear()}-12-31T23:59:30`,
                    date_to: `${new Date().getFullYear() + 1}-01-01T00:00:30`,
                    type: 'count',
                    count: 480,
                    delay: 250,
                    load: fireworkLoader(
                        [
                            // Palette 1
                            '#C63347',
                            '#F28E63',
                            '#FC7F81',
                            '#FAEFC4',
                            '#F9AE9B',
                            '#792BB2',
                            '#2E42CB',
                            '#F75781',
                            '#E365E4',
                            '#FA5348',
                            // Palette 2
                            '#FFD07E',
                            '#FA9B49',
                            '#90CA80',
                            '#62ABCC',
                            '#7984DE',
                            '#DE6C90',
                        ],
                        false,
                        true,
                        true
                    ),
                },
            ],
        },
        yearly: {
            name: 'Every year, one day',
            ambients: [
                {
                    name: 'New Year',
                    id: 'new-year-yly',
                    day: 1,
                    month: 1,
                    type: 'long',
                    duration: 10000,
                    load: schoolPrideLoader(['#BF7218', '#FADE98', '#F1A738', '#f9eb82', '#180D1C', '#514414']),
                },
                {
                    name: "Valentine's Day",
                    id: 'valentine-yly',
                    day: 14,
                    month: 2,
                    type: 'count',
                    count: 30,
                    delay: 1000,
                    load: floatingLoader(['♥️', '🌹']),
                },
                {
                    name: "Lucky Day (St. Patrick's)",
                    id: 'patrick-yly',
                    day: 17,
                    month: 3,
                    type: 'onetime',
                    load: (_ticks) => {
                        const emojisBitmap = ['🍻', '🪙', '🍀', '🌈'].map((emoji) =>
                            shapeFromText({ text: emoji, scalar: 4 })
                        );
                        return [
                            {
                                shapes: emojisBitmap,
                                origin: { y: 0.7 },
                                spread: 26,
                                startVelocity: 55,
                                particleCount: 50,
                                scalar: 2,
                            },
                            {
                                shapes: emojisBitmap,
                                origin: { y: 0.7 },
                                spread: 60,
                                particleCount: 40,
                                scalar: 2,
                            },
                            {
                                shapes: emojisBitmap,
                                origin: { y: 0.7 },
                                spread: 100,
                                decay: 0.91,
                                scalar: 1.6,
                                particleCount: 70,
                            },
                            {
                                shapes: emojisBitmap,
                                origin: { y: 0.7 },
                                spread: 120,
                                startVelocity: 25,
                                decay: 0.92,
                                scalar: 2.4,
                                particleCount: 20,
                            },
                            {
                                shapes: emojisBitmap,
                                origin: { y: 0.7 },
                                spread: 120,
                                scalar: 2,
                                startVelocity: 45,
                                particleCount: 20,
                            },
                        ];
                    },
                },
                {
                    name: "April Fool's",
                    id: 'aprilfool-yly',
                    day: 1,
                    month: 4,
                    type: 'count',
                    count: 15,
                    delay: 1000,
                    load: (ticks) => {
                        const left = emojisLoader({
                            emojis: ['🐟', '🐠', '🐡'],
                            alpha: { max: 0.5, double: true },
                            size: { min: 4, max: 10, dynamic: true },
                            gravity: { min: -0.1, max: 0.1, dynamic: true },
                            drift: { min: -1, max: -0.3, dynamic: true },
                        })(ticks);
                        const right = emojisLoader({
                            emojis: ['🐟', '🐠', '🐡'],
                            alpha: { max: 0.5, double: true },
                            size: { min: 4, max: 10, dynamic: true },
                            gravity: { min: -0.1, max: 0.1, dynamic: true },
                            drift: { min: 0.3, max: 1, dynamic: true },
                            flipHorizontal: true,
                        })(ticks);
                        const bubble = shapesLoader({
                            shapes: [bubbles.large, bubbles.medium, bubbles.small],
                            alpha: { max: 0.2, double: true },
                            size: { min: 2, max: 5, dynamic: true },
                            gravity: { min: -0.4, max: -0.2, dynamic: true },
                            drift: { min: -0.4, max: 0.4, dynamic: true },
                            yRange: { min: 0.5, max: 1 },
                            colors: ['#89cff0', 'e7feff', '#a1caf1', '#39a78e'],
                        })(ticks);
                        return [left, right, bubble];
                    },
                },
                {
                    name: 'Halloween Night',
                    id: 'halloween-yly',
                    day: 31,
                    month: 10,
                    type: 'count',
                    count: 30,
                    delay: 1000,
                    load: floatingLoader(['🎃']),
                },
                {
                    name: "New Year's Eve",
                    id: 'new-year-eve-yly',
                    day: 31,
                    month: 12,
                    type: 'count',
                    count: 30,
                    delay: 1000,
                    load: floatingLoader(['🥂']),
                },
            ],
        },
        // season: {
        //     winter: {},
        //     spring: {},
        //     summer: {},
        //     fall: {},
        // },
        // weather: {
        //     rain: {},
        //     snow: {},
        //     sun: {},
        // },
    };

    // Utils
    function randomInRange(min, max) {
        return Math.random() * (max - min) + min;
    }

    async function getOdooEventDate(domainName) {
        const event = await getFutureEventWithName(domainName, 'www.odoo.com');
        if (!event) return undefined;

        return {
            event_name: event.display_name,
            event_date_from: yyyymmdd_hhmmssToDate(event.date_begin),
            event_date_to: yyyymmdd_hhmmssToDate(event.date_end),
        };
    }

    //#region SEASON
    // export const fallSeasonLoader = emojisLoader({
    //     emojis: ['🍂'],
    //     alpha: { max: 0.5 },
    //     size: { min: 1, max: 2, dynamic: true },
    //     gravity: { min: 0.4, max: 0.9, dynamic: true },
    //     drift: { min: -0.4, max: 0.4, dynamic: true },
    //     yRange: { min: 0, max: 0.75 },
    //     flat: false,
    // });

    // export const winterSeasonLoader = emojisLoader({
    //     emojis: ['❄️', 'circle'],
    //     alpha: { max: 1 },
    //     size: { min: 0.4, max: 1, dynamic: true },
    //     gravity: { min: 0.4, max: 0.6, dynamic: true },
    //     drift: { min: -0.4, max: 0.4, dynamic: true },
    //     yRange: { min: 0, max: 0.5 },
    //     color: '#ffffff',
    //     flat: false,
    // });

    // export const summerSeasonLoader = emojisLoader({
    //     emojis: ['☀️'],
    //     alpha: { max: 0.5 },
    //     size: { min: 1, max: 2, dynamic: true },
    //     gravity: { min: 0.4, max: 0.9, dynamic: true },
    //     drift: { min: -0.4, max: 0.4, dynamic: true },
    //     yRange: { min: 0, max: 0.75 },
    //     flat: false,
    // });

    // export const springSeasonLoader = emojisLoader({
    //     emojis: ['🌸'],
    //     alpha: { max: 1 },
    //     size: { min: 0.4, max: 1, dynamic: true },
    //     gravity: { min: 0.4, max: 0.6, dynamic: true },
    //     drift: { min: -0.4, max: 0.4, dynamic: true },
    //     yRange: { min: 0, max: 0.5 },
    //     color: '#ffffff',
    //     flat: false,
    // });
    //#endregion

    //#region WEATHER
    // export const rainWeatherLoader = emojisLoader({
    //     emojis: ['💧'],
    //     alpha: { max: 1 },
    //     size: { min: 0.1, max: 0.6, dynamic: true },
    //     gravity: { min: 4, max: 5, dynamic: true },
    //     drift: { min: -0.4, max: 0.4, dynamic: true },
    //     yRange: { min: -0.1, max: 0 },
    //     color: '#4a6583',
    //     flat: true,
    // });

    // export const snowWeatherLoader = emojisLoader({
    //     emojis: ['circle'],
    //     alpha: { max: 1 },
    //     size: { min: 0.1, max: 0.6, dynamic: true },
    //     gravity: { min: 0.4, max: 0.6, dynamic: true },
    //     drift: { min: -0.4, max: 0.4, dynamic: true },
    //     yRange: { min: -0.1, max: 0.5 },
    //     color: '#ffffff',
    //     flat: false,
    // });
    //#endregion

    class AmbientManager {
        static async computeEvents() {
            const ambient_dates = {};

            for (const c of ambients.compute.ambients) {
                const dates = await c.computeDates();
                if (!dates) continue;
                ambient_dates[c.id] = {
                    date_from: dates.event_date_from,
                    date_to: dates.event_date_to,
                    name: dates.event_name,
                };
            }

            await setAmbientDates(ambient_dates);
        }

        async getAmbientForDate(date) {
            let ambient = undefined;
            const { ambientStatus } = await StorageSync.get({ ambientStatus: {} });

            if (!ambient) ambient = await this.getComputedEventForDate(ambientStatus, date);
            if (!ambient) ambient = this.getEventAmbientForDate(ambientStatus, date);
            if (!ambient) ambient = this.getYearlyAmbientForDate(ambientStatus, date);
            if (!ambient) ambient = this.getSeasonAmbientForDate(ambientStatus, date);
            if (!ambient) ambient = await this.getWeatherAmbientForDate(ambientStatus, date);

            return ambient;
        }

        getEventForDate(date, events) {
            let from = undefined;
            let to = undefined;

            for (const event of events) {
                if (event.date_from && event.date_to) {
                    from = new Date(event.date_from);
                    to = new Date(event.date_to);
                    if (this.isDateBetween(date, from, to)) return event;
                    continue;
                }
                if (event.date) {
                    from = new Date(event.date);
                    if (this.isSameDay(date, from)) return event;
                }
            }

            return undefined;
        }

        getEventAmbientForDate(ambientStatus, date) {
            const activeAmbients = ambients.event.ambients.filter((a) => ambientStatus[a] ?? true);
            return this.getEventForDate(date, activeAmbients);
        }

        async getComputedEventForDate(ambientStatus, date) {
            const computes = ambients.compute.ambients.filter((a) => ambientStatus[a.id] ?? true);
            const ambient_dates = await getAmbientDates();
            for (const c of computes) {
                const dates = ambient_dates[c.id];
                if (dates) Object.assign(c, dates);
            }
            return this.getEventForDate(date, computes);
        }

        getYearlyAmbientForDate(ambientStatus, date) {
            const mm = date.getMonth() + 1; // Months start at 0!
            const dd = date.getDate();

            return ambients.event.ambients.find((a) => (ambientStatus[a] ?? true) && a.day === dd && a.month === mm);
        }

        getSeasonAmbientForDate(_ambientStatus, _date) {
            return undefined;
        }

        async getWeatherAmbientForDate(_ambientStatus, _date) {
            return undefined;
        }

        isDateBetween(targetDate, startDate, endDate) {
            return targetDate >= startDate && targetDate <= endDate;
        }

        isSameDay(date1, date2) {
            // return date1.toDateString() === date2.toDateString();
            return (
                date1.getFullYear() === date2.getFullYear() &&
                date1.getMonth() === date2.getMonth() &&
                date1.getDate() === date2.getDate()
            );
        }
    }

    let ambientConfetti = undefined;

    class AmbientContentFeature extends ContentFeature {
        constructor() {
            super(configuration$d);
            ambientConfetti = new Confetti();
            this.manager = new AmbientManager(ambientConfetti);
            this.loader = new AmbientLoader(ambientConfetti);
        }

        async loadFeature(url) {
            if (!(await isStillSameWebsite(2000, url))) return;
            if (!this.isOdooHome()) return;

            const ambientData = await this.manager.getAmbientForDate(new Date());
            this.loader.load(ambientData);
        }

        isOdooHome() {
            const container = document.getElementsByClassName('o_apps');
            return container.length > 0;
        }
    }

    var content$d = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: AmbientContentFeature
    });

    class ProjectTaskShareContentFeature extends ContentFeature {
        async loadFeature(url) {
            this.preloadFeature();
            if (!(await isStillSamePage(2500, url))) return;
            const task = await this.getProjectTask(url);
            if (task) this.loadFeatureWithTask(task);
        }

        preloadFeature() {}
        loadFeatureWithTask(_task) {}

        async getProjectTask(url) {
            const task = await this.getTask(url);
            if (!task) return undefined;
            return task;
        }

        async getTask(url) {
            const taskID = await this.tryCatch(() => this.getProjectTaskID_fromURL(url), undefined);
            if (taskID === undefined) return undefined;

            const response = await this.tryCatch(
                () => getDataset('project.task', [['id', '=', taskID]], ['id', 'project_id', 'user_ids', 'priority'], 1, 0),
                undefined
            );
            return response;
        }

        async getProjectTaskID_fromURL(url) {
            return (await getModelAndID_fromURL(url, 'project.task', true))?.resId;
        }
    }

    const ASSIGN_TYPE = Object.freeze({
        RELOAD: 'reload',
        REDIRECT: 'redirect',
    });

    class AssignMeTaskContentFeature extends ProjectTaskShareContentFeature {
        constructor() {
            super(configuration$c);
        }

        async loadFeatureWithTask(task) {
            const currentUser = await this.tryCatch(() => getSessionData(SessionKey.UID), undefined);
            if (!currentUser) return;
            const userAssigned = task.user_ids.includes(currentUser);

            const exist = document.getElementsByName('joorney_action_assign_to_me');
            // Avoid adding button if already added, remove it if user already assigned
            if (exist.length > 0) {
                if (userAssigned) for (const e of exist) e.remove();
                for (const e of exist) {
                    this.updateAssignMeTaskEvent(e, task, currentUser);
                    e.disabled = false;
                }
                return;
            }

            if (userAssigned) return;

            this.appendAssignMeTaskButtonToDom(task, currentUser);
        }

        preloadFeature() {
            const exist = document.getElementsByName('joorney_action_assign_to_me');
            for (const e of exist) e.disabled = true;
            this.removeUserInUI();
        }

        async addUserToTaskAssignees(task, userID, callback) {
            const taskID = await this.getProjectTaskID_fromURL(window.location.href);
            if (task.id !== taskID)
                throw new Error(`Button context is not the same as the url context: '${task.id}' vs '${taskID}'`);

            const newUsers = task.user_ids.concat(userID);

            try {
                const response = await writeRecord('project.task', task.id, { user_ids: newUsers });
                if (response) {
                    switch (callback) {
                        case ASSIGN_TYPE.RELOAD: {
                            for (const e of document.getElementsByName('joorney_action_assign_to_me')) e.remove();
                            const { useSimulatedUI } = await StorageSync.get({ useSimulatedUI: false });
                            if (useSimulatedUI) this.addUserInUI();
                            else window.location.reload();
                            break;
                        }
                        case ASSIGN_TYPE.REDIRECT: {
                            window.open(window.location.href);
                            break;
                        }
                    }
                }
            } catch (err) {
                ToastManager.warn(this.configuration.id, 'An error occur during task asssignation', err.message);
            }
        }

        addUserInUI() {
            const fakeDataTitle = `This element is not part of the original application; it was added artificially by Joorney.
If unsure, please reload the page!`;
            // Fake assigned element
            const fieldElement = document.getElementsByName('user_ids')?.[0];
            if (!fieldElement) return false;
            const containerElement = fieldElement
                .querySelector('.many2many_tags_avatar_field_container')
                ?.querySelector('.o_field_many2many_selection');
            if (!containerElement) return false;
            const avatarSrc = document.querySelector('.o_user_avatar, .oe_topbar_avatar')?.src;
            if (!avatarSrc || avatarSrc.length <= 0) return false;
            const userName = document.querySelector('.o_user_avatar ~ .oe_topbar_name, .oe_topbar_avatar ~ .oe_topbar_name')
                ?.firstChild?.nodeValue;
            if (!userName || userName.length <= 0) return false;
            const tagElement = generateUserAvatarTag(userName, avatarSrc);

            // Fake chat message
            const chatParent = document
                .querySelector('.o-mail-Chatter-content')
                ?.querySelector('.o-mail-Thread')?.firstChild;
            if (!chatParent) return false;
            const previousElement = chatParent.querySelector('.o-mail-Message, .o-mail-DateSection');
            if (!previousElement) return false;
            const messageElement = generateTrackingMessage(userName, userName, 'Assignees', avatarSrc, new Date());

            // Add Fake data warning
            tagElement.title = fakeDataTitle;
            messageElement.title = fakeDataTitle;

            containerElement.prepend(tagElement);
            previousElement.before(messageElement);
            return true;
        }

        removeUserInUI() {
            for (const element of document.getElementsByClassName('joorney-simulated-ui-assignme')) {
                element.remove();
            }
        }

        appendAssignMeTaskButtonToDom(task, currentUser) {
            const buttonTemplate = document.createElement('template');
            buttonTemplate.innerHTML = `
            <button class="btn btn-warning" name="joorney_action_assign_to_me" type="object" title="Page will be reloaded, use wheel click to open in another tab">
                <span>Assign to me</span>
            </button>
        `.trim();

            const assignButton = buttonTemplate.content.firstChild;
            this.updateAssignMeTaskEvent(assignButton, task, currentUser);

            const statusBarButtons = document.getElementsByClassName('o_statusbar_buttons')[0];
            if (statusBarButtons) statusBarButtons.appendChild(assignButton);
        }

        updateAssignMeTaskEvent(btn, task, currentUser) {
            btn.onclick = () => {
                this.addUserToTaskAssignees(task, currentUser, ASSIGN_TYPE.RELOAD);
            };

            btn.onauxclick = () => {
                this.addUserToTaskAssignees(task, currentUser, ASSIGN_TYPE.REDIRECT);
            };
        }
    }

    var content$c = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: AssignMeTaskContentFeature
    });

    class AutoOpenRunbotContentFeature extends LimitedRunbotContentFeature {
        constructor() {
            super(autoOpenRunbotConfiguration);
        }

        async loadFeature(url) {
            if (!this.isRunbotPageWithAutoOpenHash(url)) return;

            this.loadPath(url);
        }

        async loadPath(url, batchOffset = 0) {
            const { path, version } = await this.getRunbotPath(url, batchOffset);
            try {
                if (!path && !version) {
                    window.location = 'https://runbot.odoo.com/';
                }
                if (!path && version) {
                    const searchPath = `${searchVersionPath}${version}`;
                    const searchAndOpenPath = `${searchPath}&${openVersionKey}=${version}`;
                    // Avoid loop if version not exist and already searched
                    const finalPath = url.searchParams.has('search') ? searchPath : searchAndOpenPath;
                    window.location = `https://runbot.odoo.com/${finalPath}`;
                    return;
                }
                await this.openRunbot(`https://runbot.odoo.com/${path}`, false);
            } catch (error) {
                if (batchOffset) {
                    Console.warn(error);
                    return;
                }
                this.loadPath(url, 1);
            }
        }

        async getRunbotPath(tabURL, batchOffset = 0) {
            const urlVersion = this.getOpenData(tabURL);
            if (!urlVersion) return {};

            let openVersion = Number.parseFloat(urlVersion).toFixed(1);
            if (ValueIsNaN(openVersion)) {
                openVersion = urlVersion;
            }
            openVersion = sanitizeVersion(openVersion);

            const rows = document.getElementsByClassName('bundle_row');

            // FOR EACH VERSION ROW
            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const version = sanitizeVersion(row.querySelector('div.one_line a b').textContent);
                if (version !== openVersion) continue;

                const batches = row.querySelectorAll('div.batch_slots');

                // FOR EACH BATCH OF DATABASE OF VERSION
                for (let j = batchOffset; j < batches.length; j++) {
                    const batch = batches[j];
                    const groups = Array.from(batch.querySelectorAll('div.slot_button_group'));

                    // FOR EACH SUBGROUP BUILD OF BATCH
                    for (let k = 0; k < groups.length; k++) {
                        const group = groups[k];
                        const type = group.querySelector('a.slot_name span').textContent.toLowerCase();

                        if (!type.startsWith('enterprise')) continue;

                        const signInButtons = group.getElementsByClassName('fa fa-sign-in btn btn-info');
                        const spinGearIcons = group.getElementsByClassName('fa-cog fa-spin');
                        const refreshingIcons = group.querySelector('span i.fa-refresh');

                        // SIGN IN exist and runbot not in a refresh state
                        if (signInButtons.length > 0 && spinGearIcons.length === 0 && !refreshingIcons) {
                            return { path: signInButtons.item(0).getAttribute('href'), version: openVersion };
                        }
                    }
                }
            }

            return { version: openVersion };
        }
    }

    var content$b = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: AutoOpenRunbotContentFeature
    });

    class AwesomeLoadingShareContentFeature extends ContentFeature {
        constructor(configuration) {
            super(configuration);
            this.loadingID = null;
        }

        async loadFeature(url) {
            const exist = document.getElementsByName(this.loadingID);
            if (exist.length > 0) return;
            if (!isOdooWebsite(url)) return;

            const image = await this.getLoadingImage();
            if (image) {
                this.appendLoadingToDOM(image);
            }
        }

        getInnerStyle(_image) {
            return '';
        }

        async getLoadingImage() {
            return '';
        }

        async appendLoadingToDOM(image) {
            const styleTemplate = document.createElement('template');
            styleTemplate.innerHTML = this.getInnerStyle(image);
            document.documentElement.appendChild(styleTemplate.content.firstChild);
        }

        onPopupMessage(msg) {
            const img = this.getImageFromNavigationMessage(msg);
            if (img || img === false) {
                const exist = Array.from(document.getElementsByName(this.loadingID));
                for (const e of exist) e.remove();
                if (img && isOdooWebsite(msg.url)) this.appendLoadingToDOM(img);
            }
        }

        getImageFromNavigationMessage(_msg) {
            return '';
        }
    }

    class AwesomeLoadingLargeContentFeature extends AwesomeLoadingShareContentFeature {
        constructor() {
            super(configuration$b);
            this.loadingID = 'joorney-awesome-loading-large';
        }

        getInnerStyle(image) {
            return `
            <style name="${this.loadingID}" type="text/css">

                .o_spinner > img[src^="/web/static/img/spin."]:first-child,
                .oe_blockui_spin > img[src="/web/static/src/img/spin.png"]:first-child {

                    content: url(${image});

                    /* Resize the image automatically */
                    max-height: 46px;

                    /* Remove the spinning animation */
                    if spin {
                        animation: fa-spin 1s infinite linear !important;
                    } else {
                        animation: none !important;
                    }
                }

                /* Use same backdrop effect as Odoo 16 (slightly less blurred) */
                .o_blockUI, .blockUI.blockOverlay {
                    backdrop-filter: blur(1px);
                    background-color: rgba(0, 0, 0, 0.5) !important;
                    opacity: 1;
                }

            </style>
        `.trim();
        }

        async getLoadingImage() {
            const { awesomeLoadingLargeImage } = await StorageSync.get({
                awesomeLoadingLargeImage: false,
            });
            return awesomeLoadingLargeImage;
        }

        getImageFromNavigationMessage(msg) {
            return msg.awesomeLoadingLargeImage;
        }
    }

    var content$a = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: AwesomeLoadingLargeContentFeature
    });

    class AwesomeLoadingSmallContentFeature extends AwesomeLoadingShareContentFeature {
        constructor() {
            super(configuration$a);
            this.loadingID = 'joorney-awesome-loading-small';
        }

        getInnerStyle(image) {
            return `
            <style name="${this.loadingID}" type="text/css">

                .o_loading_indicator {

                    content: url(${image});
                    background-color: unset;

                    /* Resize the image automatically */
                    max-height: 46px;
                }
            </style>
        `.trim();
        }

        async getLoadingImage() {
            const { awesomeLoadingSmallImage } = await StorageSync.get({
                awesomeLoadingSmallImage: false,
            });
            return awesomeLoadingSmallImage;
        }

        getImageFromNavigationMessage(msg) {
            return msg.awesomeLoadingSmallImage;
        }
    }

    var content$9 = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: AwesomeLoadingSmallContentFeature
    });

    const awesomeStyleID = 'joorney-awesome-style';

    class AwesomeStyleContentFeature extends ContentFeature {
        constructor() {
            super(configuration$9);
        }

        async loadFeature(url) {
            if (!isOdooWebsite(url)) return;
            const exist = document.getElementsByName(awesomeStyleID);
            if (exist.length > 0) return;
            this.appendAwesomeStyle();
        }

        async appendAwesomeStyle() {
            const { awesomeStyleCSS } = await StorageSync.get({
                awesomeStyleCSS: this.configuration.defaultSettings.awesomeStyleCSS,
            });

            if (awesomeStyleCSS) {
                this.appendAwesomeStyleToDOM(awesomeStyleCSS);
            }
        }

        async appendAwesomeStyleToDOM(css) {
            const styleTemplate = document.createElement('template');
            styleTemplate.innerHTML = `
            <style name="${awesomeStyleID}" type="text/css">
                ${css}
            </style>
        `.trim();

            document.documentElement.appendChild(styleTemplate.content.firstChild);
        }

        onPopupMessage(msg) {
            const css = msg.enableAwesomeStyle;

            if (typeof css === 'boolean') {
                const exist = Array.from(document.getElementsByName(awesomeStyleID));
                if (exist) for (const e of exist) e.remove();
                if (css && isOdooWebsite(msg.url)) this.appendAwesomeStyle(msg.url);
            }
        }
    }

    var content$8 = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: AwesomeStyleContentFeature
    });

    class ImpersonateLoginRunbotContentFeature extends LimitedRunbotContentFeature {
        constructor() {
            super(configuration$8);
        }

        async loadFeature(url) {
            let autologin = false;
            if (
                (await isAuthorizedLimitedFeature(adminDebugLoginConfiguration.id, url)) ||
                (await isAuthorizedLimitedFeature(autoOpenRunbotConfiguration.id, url))
            ) {
                autologin = this.loginWithAdmin(url);
            }

            if (!autologin) {
                this.appendImpersonateLogin();
            }
        }

        appendImpersonateLogin() {
            const fieldLogin = document.getElementsByClassName('field-login')[0];
            if (!fieldLogin) return;

            const loginsIdentifier = 'joorney-impersonate-login-runbot';

            document.getElementById(loginsIdentifier)?.remove();

            const loginsTemplate = document.createElement('template');
            loginsTemplate.innerHTML = `
            <div id="${loginsIdentifier}" class="form-group mb-2 text-center">
                <div class="btn-group-sm d-flex justify-content-center">
                    <button type="button" class="btn btn-warning mx-1 flex-fill" data-login="admin" title="Login as admin">Admin</button>
                    <button type="button" class="btn btn-warning mx-1 flex-fill" data-login="demo" title="Login as demo">Demo</button>
                    <button type="button" class="btn btn-warning mx-1 flex-fill" data-login="portal" title="Login as portal">Portal</button>
                </div>
            </div>
        `.trim();

            const loginsElement = loginsTemplate.content.firstChild;

            for (const btn of loginsElement.getElementsByTagName('button')) {
                btn.onclick = (e) => this.loginWithForm(e.target.dataset.login);
            }

            fieldLogin.before(loginsElement);
        }

        loginWithForm(login) {
            document.getElementById('login').value = login;
            document.getElementById('password').value = login;
            const form = document.getElementsByClassName('oe_login_form')[0];
            form.action += '?debug=1';
            form.submit();
        }

        updateSelectorLink() {
            for (const e of document.querySelectorAll('div.list-group-item a')) {
                e.href = this.getAdminDebugURL(e.href);
            }
        }

        loginWithAdmin(url) {
            if (this.isRunbotSelectorPageWithLogin(url)) {
                this.updateSelectorLink();
                return true;
            }

            if (!this.getOpenData(url)) return false;

            // 16+
            let front_to_back_button = document.getElementsByClassName('o_frontend_to_backend_apps_btn');
            // < 16
            if (front_to_back_button.length === 0) front_to_back_button = document.getElementsByClassName('o_menu_toggle');
            if (front_to_back_button.length > 0) {
                window.location.href = `${window.location.origin}/web`;
                return true;
            }

            this.loginWithForm('admin');
            return true;
        }
    }

    var content$7 = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: ImpersonateLoginRunbotContentFeature
    });

    class NewServerActionCodeContentFeature extends ContentFeature {
        constructor() {
            super(configuration$7);
        }

        async loadFeature(url) {
            const isNew = await this.tryCatch(() => this.isServerActionCreateView_fromURL(url), false);
            if (!isNew) return;
            if (!(await isStillSamePage(250, url))) return;
            await this.selectServerActionModel();
            this.selectExecuteCode();
        }

        async selectServerActionModel() {
            // Odoo 17.0+ model_id_0, name_0, model_id_0_0_0
            // Odoo 16.0 model_id, name, model_id_0_0

            const inputModel = document.getElementById('model_id_0') ?? document.getElementById('model_id');
            if (!inputModel) return;
            inputModel.click();
            inputModel.value = 'ir.actions.server';

            const parent = inputModel.parentElement;
            const observer = new MutationObserver((mutations) => {
                const choiceMutations = mutations.filter((m) => m.target.id.match(/^model_id_0_(0_)?\d+$/));
                // model_id_0_0_0 for record and model_id_0_0_1 for search more (optional)
                if (choiceMutations.length !== 2 && choiceMutations.length !== 1) return;

                const serverActionItem = parent.querySelector('#model_id_0_0_0') ?? parent.querySelector('#model_id_0_0');

                observer.disconnect();
                if (serverActionItem) serverActionItem.click();

                const nameElement = document.getElementById('name_0') ?? document.getElementById('name');
                if (nameElement) nameElement.focus();
            });
            observer.disconnect();
            observer.observe(parent, { childList: true, subtree: true });
            inputModel.dispatchEvent(new InputEvent('input', { bubbles: true }));
        }

        selectExecuteCode() {
            const badge = document.querySelector(`span.o_selection_badge[value='"code"']`);
            if (badge) {
                // Odoo 16.4+
                badge.click();
                return;
            }
            // Odoo < 16.4
            const codeOption = document.querySelector(`option[value='"code"']`);
            if (!codeOption) return;
            const selector = codeOption.parentElement;
            selector.value = codeOption.value;
            selector.dispatchEvent(new Event('change'));
        }

        async isServerActionCreateView_fromURL(url) {
            return await isModelCreateView_fromURL(url, 'ir.actions.server');
        }
    }

    var content$6 = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: NewServerActionCodeContentFeature
    });

    let pinMessageChatterObserver = undefined;

    class PinMessageContentFeature extends ContentFeature {
        constructor() {
            super(configuration$6);
            this.chatter = undefined;
            this.pins = [];
            this.url = null;
            this.handleChatterMutation = this.handleChatterMutation.bind(this);
            this.onPin = this.onPin.bind(this);
            this.selfAuthor = true;
            pinMessageChatterObserver?.disconnect();
            pinMessageChatterObserver = new MutationObserver(this.handleChatterMutation);
        }

        async onRequestCompleted(msg) {
            if (msg.status !== 200) return;
            this.onPin();
        }

        async loadFeature(url) {
            if (!(await isStillSamePage(2000, url))) return;
            this.url = url;

            const { pinMessageSelfAuthorEnabled, pinMessageDefaultShown } = await StorageSync.get(this.defaultSettings);
            this.selfAuthor = pinMessageSelfAuthorEnabled;
            this.defaultShown = pinMessageDefaultShown;

            const loaded = await this.loadFormChatter();
            if (!loaded) this.loadDiscussChatter();
        }

        async loadDiscussChatter() {
            const discussChatter = document.querySelector('.o-mail-Discuss-content');
            return this.loadChatter(discussChatter, false);
        }

        async loadFormChatter() {
            const formChatter = document.querySelector('.o-mail-Form-chatter');
            const state = await this.loadChatter(formChatter, true);
            if (state && this.defaultShown) {
                this.appendPinnedSection();
            }
            return state;
        }

        async loadChatter(chatter, checkModel) {
            this.chatter = chatter;
            if (!this.chatter) return false;

            if (checkModel) {
                const model_id = await this.tryCatch(() => getModelAndID_fromURL(this.url), undefined);
                if (!model_id) return false;
            }

            this.observerChatter();

            this.appendPinButton();
            this.updatePinnedMessages();

            return true;
        }

        async updatePinnedMessages() {
            if (!this.url) {
                this.pins = [];
            } else {
                this.pins = await this.getPinnedMessages(this.url);
            }
            this.appendPinnedToggle();
        }

        appendPinButton() {
            for (const msg of this.getPinnableMessages()) {
                this.appendPinButtonToMessage(msg);
            }
        }

        appendPinButtonToMessage(messageElement) {
            const starBtnIcon = messageElement.querySelector('i.fa-star, i.fa-star-o');
            if (!starBtnIcon) return;
            starBtnIcon.parentElement.title = 'Odoo: Mark as Todo | Joorney UI override: Pin';
            starBtnIcon.classList.add('fa-thumb-tack');
        }

        async onPin() {
            if (!this.chatter) return;
            this.updatePinnedMessages();
            await sleep(100);
            this.appendPinButton();
        }

        observerChatter() {
            if (!this.chatter) return;
            const target = this.chatter.querySelector('.o-mail-Thread');
            if (!target) return;
            const observerOptions = { childList: true, subtree: false };

            pinMessageChatterObserver.disconnect();
            pinMessageChatterObserver.observe(target.firstChild, observerOptions);
        }

        handleChatterMutation(mutations) {
            for (const mutation of mutations) {
                if (mutation.type !== 'childList') return;

                for (const node of mutation.addedNodes) {
                    if (node.nodeType === 1 && node.matches('.o-mail-Message')) {
                        if (node.querySelector('.o-mail-Message-bubble.border')) return;
                        this.appendPinButtonToMessage(node);
                    }
                }
            }
        }

        getPinnableMessages() {
            const messages = Array.from(
                this.chatter.querySelectorAll(`div.o-mail-Message${this.selfAuthor ? '.o-selfAuthored' : ''}`)
            );
            return messages
                .filter((m) => !m.querySelector('.o-mail-Message-bubble.border'))
                .filter((m) => (m.querySelector('.o-mail-Message-body')?.innerHTML.trim() || '') !== '');
        }

        async getPinnedMessages(url) {
            const model_id = await this.tryCatch(() => getModelAndID_fromURL(url), undefined);
            if (!model_id) return [];

            const domain = [
                ['model', '=', model_id.model],
                ['res_id', '=', model_id.resId],
                ['body', '!=', false],
                ['body', '!=', ''],
                // Cannot be too much restrictive due to UI, hard to identify which message can be pinned
                //['message_type', 'not in', ['notification', 'auto_comment', 'user_notification']],
                //['subtype_id.internal', '=', true],
                ['starred_partner_ids', '!=', false],
            ];
            if (this.selfAuthor) {
                const uid = getSessionData(SessionKey.PARTNER_ID) || -1;
                domain.push(['starred_partner_ids', 'in', uid]);
            }

            const messages = await this.tryCatch(
                () => getDataset('mail.message', domain, ['id', 'body', 'author_id', 'create_date'], 50, 0),
                []
            );
            return messages;
        }

        appendPinnedToggle() {
            this.chatter.querySelector('#joorney-pin-message-toggle')?.remove();
            const threadOpened = this.chatter.querySelector('.joorney-pinned-mail-Thread') != null;
            this.chatter.querySelector('.joorney-pinned-mail-Thread')?.remove();
            if (this.pins.length === 0) return;
            const previous = this.chatter.querySelector('button.text-action');
            const btn = stringToHTML(`
            <button id="joorney-pin-message-toggle" class="btn btn-link text-action px-1 d-flex align-items-center my-2" aria-label="Show pinned message">
                <i class="fa fa-thumb-tack fa-lg me-1"></i>
                <sup>${this.pins.length}</sup>
            </button>
        `);
            btn.onclick = () => {
                const section = this.chatter.querySelector('.joorney-pinned-mail-Thread');
                if (section) section.remove();
                else this.appendPinnedSection();
            };
            previous.after(btn);
            if (threadOpened) this.appendPinnedSection();
        }

        appendPinnedSection() {
            const MAX_PIN = 5;
            const chatterContent = this.chatter.querySelector('div.o-mail-Chatter-content');
            if (!chatterContent) return;
            const pinsContainer = stringToHTML(`
            <div class="joorney-pinned-mail-Thread position-relative flex-grow-1 d-flex flex-column overflow-auto pb-4">
                <div class="d-flex align-items-center">
                    <hr class="flex-grow-1" />
                    <span class="p-3 fw-bold"> Pinned Messages <span class="text-muted opacity-75">[Joorney]</span></span>
                    <hr class="flex-grow-1" />
                </div>
                <div id="joorney-pinned-mail-list" class="px-3 d-flex flex-column position-relative flex-grow-1"></div>
            </div>
        `);
            const messageContainer = pinsContainer.querySelector('#joorney-pinned-mail-list');

            let pins = this.pins;
            let warning = '';
            if (pins.length > MAX_PIN) {
                warning = `...There are more than ${MAX_PIN} pinned messages! Only yours are displayed`;
                pins = this.pins.filter((pin) => pin.author_id[0] === getSessionData(SessionKey.PARTNER_ID));
                if (pins.length > MAX_PIN) {
                    warning = `...You have more than ${MAX_PIN} pinned messages!`;
                }
            }

            const messages = Array.from(this.chatter.querySelectorAll('.o-mail-Message-body'));

            for (const pin of pins.slice(0, Math.min(MAX_PIN, pins.length))) {
                const original = messages.find((m) => m.innerHTML === pin.body);

                messageContainer.appendChild(
                    generateMessage(
                        pin.author_id[1],
                        this.getAuthorAvatar(pin.author_id[0]),
                        pin.body,
                        new Date(pin.create_date),
                        original
                    )
                );
            }
            if (warning) {
                messageContainer.appendChild(
                    stringToHTML(`
                <span class="mt-2 position-sticky alert alert-warning d-flex cursor-pointer align-items-center py-2 m-0 px-4 top-0" role="button">
                    <span class="small">${warning}</span>
                </span>
            `)
                );
            }
            chatterContent.insertBefore(pinsContainer, chatterContent.querySelector('.o-mail-Thread'));
        }

        getAuthorAvatar(authorID) {
            return `${document.location.origin}/web/image?field=avatar_128&id=${authorID}&model=res.partner`;
        }
    }

    var content$5 = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: PinMessageContentFeature
    });

    class SaveKnowledgeContentFeature extends ContentFeature {
        constructor() {
            super(configuration$5);
        }

        async loadFeature(url) {
            if (!(await isStillSamePage(2500, url))) return;

            const knowledgeArticle = await this.getKnowledgeArticle(url);
            if (knowledgeArticle) {
                this.appendSaveButton(knowledgeArticle);
            }
        }

        async getKnowledgeArticle(url) {
            // Need to wait full page loaded to have access to the HTML
            // HTML not used in this method but need to return false if HTML is not "good"
            // TODO[IMP] Improve of find an way to be sure than HTML is loaded
            const saveExist = document.getElementsByName('joorney_action_save_article');
            for (const e of saveExist) e.disabled = true;

            // body_0 is the ID use when you can edit an article body
            const exist = document.getElementById('body_0') ?? document.getElementById('body');
            if (!exist) return undefined;

            const article = await this.getArticle(url);
            if (!article) return undefined;

            return article;
        }

        async getArticle(url) {
            const articleID = await this.tryCatch(() => this.getKnowledgeArticleID_fromURL(url), undefined);
            if (!articleID) return undefined;
            return { id: articleID };
        }

        async appendSaveButton(article) {
            const exist = document.getElementsByName('joorney_action_save_article');
            // Avoid adding button if already added
            if (exist.length > 0) {
                for (const e of exist) {
                    this.updateSaveEvent(e, article);
                    e.disabled = false;
                }
                return;
            }

            this.appendSaveButtonToDom(article);
        }

        async saveArticle(article) {
            const articleID = await this.tryCatch(
                () => this.getKnowledgeArticleID_fromURL(window.location.href),
                undefined
            );
            if (!articleID) return;
            if (article.id !== articleID)
                throw new Error(`Button context is not the same as the url context: '${article.id}' vs '${articleID}'`);

            const body = document.getElementById('body_0').innerHTML;
            if (!body) return;

            await writeRecord('knowledge.article', Number.parseInt(articleID), {
                body: body,
            });
        }

        updateSaveEvent(btn, article) {
            btn.onclick = () => {
                this.saveArticle(article);
            };
        }

        appendSaveButtonToDom(article) {
            const buttonTemplate = document.createElement('template');
            buttonTemplate.innerHTML = `
            <button class="btn btn-warning" name="joorney_action_save_article" type="object">
                <span>Save</span>
            </button>
        `.trim();

            const saveButton = buttonTemplate.content.firstChild;
            this.updateSaveEvent(saveButton, article);

            let statusBarButtons = document.getElementsByClassName('o_knowledge_add_buttons')[0];
            if (statusBarButtons) {
                statusBarButtons.appendChild(saveButton);
                return;
            }

            statusBarButtons = document.getElementsByClassName('o_knowledge_header')[0]?.childNodes[1];
            if (statusBarButtons) {
                statusBarButtons.prepend(saveButton);
            }
        }

        async getKnowledgeArticleID_fromURL(url) {
            return (await getModelAndID_fromURL(url, 'knowledge.article', true))?.resId;
        }
    }

    var content$4 = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: SaveKnowledgeContentFeature
    });

    let overlayShowMyBadgeObserver = undefined;

    class ShowMyBadgeContentFeature extends ContentFeature {
        constructor() {
            super(configuration$4);
            this.handleMutation = this.handleMutation.bind(this);
            overlayShowMyBadgeObserver?.disconnect();
            overlayShowMyBadgeObserver = new MutationObserver(this.handleMutation);
        }

        async loadFeature(_) {
            this.observe();
        }

        observe() {
            const overlays = document.getElementsByClassName('o-overlay-container');
            if (overlays.length !== 1) return;

            const overlayTarget = overlays[0];
            const observerOptions = { childList: true, subtree: true };
            overlayShowMyBadgeObserver.disconnect();
            overlayShowMyBadgeObserver.observe(overlayTarget, observerOptions);
        }

        handleMutation(mutations) {
            const avatarCardMutationNode = mutations
                .filter((m) => m.type === 'childList' && m.addedNodes?.length > 0)
                .flatMap((m) => Array.from(m.addedNodes))
                .find((n) => n.nodeName === 'DIV' && n.className.includes('o_avatar_card'));
            if (!avatarCardMutationNode) return;

            const emailNode = avatarCardMutationNode.querySelector('div.o_card_user_infos a[href^="mailto:"]');
            const email = emailNode.href.replace('mailto:', '');
            const name = avatarCardMutationNode.querySelector('div.o_card_user_infos span').innerText;
            if (email) this.appendBadges(avatarCardMutationNode, email, name);
        }

        async appendBadges(card, emailArg, nameArg) {
            const badges = await this.tryCatch(() => this.loadBadgesForUser(emailArg, nameArg), undefined);
            if (!badges) return;

            const infoNode = card.querySelector('div.o_card_user_infos')?.parentNode;
            if (!infoNode) return;

            const emailNode = card.querySelector('div.o_card_user_infos a[href^="mailto:"]');
            const email = emailNode.href.replace('mailto:', '');
            if (email !== emailArg) return;
            infoNode.after(this.getBadgesNode(badges));
        }

        async loadBadgesForUser(email, name) {
            const user = await getDataset(
                'res.users',
                [
                    ['email', '=', email],
                    ['name', '=', name],
                ],
                ['id', 'badge_ids'],
                1,
                60
            );
            let badgeIDs = user?.badge_ids;
            if (!badgeIDs) {
                const employee = await getDataset(
                    'hr.employee.public',
                    [
                        ['email', '=', email],
                        ['name', '=', name],
                    ],
                    ['id', 'badge_ids'],
                    1,
                    60
                );
                badgeIDs = employee?.badge_ids;
            }
            if (!badgeIDs || badgeIDs.length === 0) return undefined;

            return await this.getBadges(badgeIDs);
        }

        async getBadges(ids) {
            const badges = await getDatasetWithIDs('gamification.badge.user', ids);
            const levelMapping = {
                bronze: 1,
                silver: 2,
                gold: 3,
            };
            for (const b of badges) {
                b.lvl = levelMapping[b.level] ?? 0;
            }
            return badges.sort((a, b) => b.lvl - a.lvl);
        }

        getBadgesNode(badges) {
            if (!badges || badges.length === 0) return;

            let badgesList = badges;
            let moreBadge = false;
            if (badgesList.length >= 8) {
                badgesList = badgesList.slice(0, 8);
                moreBadge = true;
            }

            const badgesHTML = badgesList.map((b) =>
                `<a href="${createRecordFormURL(
                window.location,
                'gamification.badge',
                b.badge_id[0]
            )}"><img class="rounded" title="${b.display_name || b.badge_name}\n${
                b.comment || ''
            }" style="height: 30px" src="https://${window.location.host}/web/image?model=gamification.badge&id=${
                b.badge_id[0]
            }&field=image_128"></a>`.trim()
            );

            if (moreBadge) {
                badgesHTML.push(
                    `<i title="More..." style="height: 30px; opacity: 10%" class="d-flex align-items-center fa fa-2x fa-certificate"></i>`.trim()
                );
            }

            const template = document.createElement('template');
            template.innerHTML = `
            <div class="d-flex mt-3 mb-3 gap-2 justify-content-end flex-wrap">
                ${badgesHTML.join('\n')}
            </div>
        `.trim();

            return template.content.firstChild;
        }
    }

    var content$3 = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: ShowMyBadgeContentFeature
    });

    let starsConfetti = undefined;
    class StarringTaskEffectContentFeature extends ProjectTaskShareContentFeature {
        constructor() {
            super(configuration$3);
            starsConfetti = new Confetti();
            this.defaultsStar = {
                spread: 360,
                ticks: 50,
                gravity: 0,
                decay: 0.94,
                startVelocity: 5,
                shapes: ['star'],
                colors: ['FFE400', 'FFBD00', 'E89400', 'FFCA6C', 'FDFFB8'],
            };
            this.generateStars = this.generateStars.bind(this);
            this.addStarsGenerator = this.addStarsGenerator.bind(this);
        }

        async loadFeatureWithTask(task) {
            const starred = Number.parseInt(`${task.priority}`) === 1;
            for (const el of document.getElementsByClassName('o_priority_star')) {
                // No way to detect starred state dynamically due to hover effect on the star
                if (starred) el.addEventListener('click', this.addStarsGenerator);
                else el.addEventListener('click', this.generateStars);
            }
        }

        preloadFeature() {
            const exist = Array.from(document.getElementsByClassName('o_priority_star'));
            for (const el of exist) {
                el.removeEventListener('click', this.addStarsGenerator);
                el.removeEventListener('click', this.generateStars);
            }
        }

        addStarsGenerator(event) {
            event.target.removeEventListener('click', this.addStarsGenerator);
            event.target.addEventListener('click', this.generateStars);
        }

        generateStars(event) {
            const element = event.target;
            const rect = element.getBoundingClientRect();
            const sizeX = rect.right - rect.left;
            const sizeY = rect.bottom - rect.top;

            const x = (rect.left + sizeX / 2) / window.innerWidth;
            const y = (rect.top + sizeY / 2) / window.innerHeight;
            starsConfetti.reset();
            setTimeout(() => this.shoot(x, y), 0);
            setTimeout(() => this.shoot(x, y), 100);
            setTimeout(() => this.shoot(x, y), 200);

            element.removeEventListener('click', this.generateStars);
            element.addEventListener('click', this.addStarsGenerator);
        }

        async shoot(x, y) {
            starsConfetti.fire({
                ...this.defaultsStar,
                particleCount: 1,
                scalar: 0.8,
                shapes: ['star'],
                origin: { x: x, y: y },
            });

            starsConfetti.fire({
                ...this.defaultsStar,
                particleCount: 2,
                scalar: 0.75,
                shapes: ['circle'],
                origin: { x: x, y: y },
            });
        }
    }

    var content$2 = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: StarringTaskEffectContentFeature
    });

    class TooltipMetadataContentFeature extends ContentFeature {
        constructor() {
            super(configuration$1);
        }

        async loadFeature(url) {
            if (!(await isStillSamePage(1000, url))) return;

            this.appendTooltipMetadata(url);
        }

        async appendTooltipMetadata(url) {
            const metadataContainer = document.getElementById('joorney-tooltip-metadata');
            if (metadataContainer) metadataContainer.remove();

            if (!isDebugSession()) return;

            await this.tryCatch(async () => {
                const model_id = await getModelAndID_fromURL(url);
                if (!model_id) {
                    const actionWindow = await getActionWindow_fromURL(url);
                    if (!actionWindow) return;
                    this.appendModelToBreadcrumb(actionWindow.res_model);
                    this.appendActionWindowTooltip(actionWindow);
                    return;
                }

                this.appendModelToBreadcrumb(model_id.model);
                this.loadRecordMetadata(model_id);
            });
        }

        appendModelToBreadcrumb(model) {
            const spanID = 'joorney-technical-model';
            document.getElementById(spanID)?.remove();
            if (!model) return;

            const breadcrumbList = document.querySelector('ol.breadcrumb');
            const lastItem = document.querySelector('.o_last_breadcrumb_item');
            const container =
                (breadcrumbList ? lastItem?.parentElement ?? breadcrumbList : breadcrumbList) ??
                document.querySelector('.o_breadcrumb'); // ?? document.querySelector('.o_control_panel_navigation') no breadcrumb?
            if (!container) return;

            const element = stringToHTML(
                `<span id="${spanID}" style="align-content: center; margin-left: 4px; line-height: initial; font-style: italic; color: darkgoldenrod; cursor: copy" title="[Joorney] Copy technical name to clipboard" >(${model})</span>`
            );
            element.onclick = () => navigator.clipboard.writeText(model);
            container.appendChild(element);
        }

        async loadRecordMetadata(model_id) {
            const { resId, model } = model_id;
            if (!model || !resId) return;
            const metadata = await getMetadata(model, resId);
            this.appendRecordMetadataTooltip(metadata);
        }

        appendActionWindowTooltip(actionWindow) {
            this.appendTooltip([
                { label: 'Window Action ID', value: actionWindow.id },
                { label: 'XML ID', value: actionWindow.xmlid },
                { label: 'Name', value: actionWindow.name },
                { label: 'Model', value: actionWindow.res_model },
                {
                    label: '[Filters] Domain',
                    value: actionWindow.domain ? actionWindow.domain.trim() : false,
                },
                { label: '[Filters] Context', value: actionWindow.context?.trim() },
                { label: '[Filters] Limit', value: actionWindow.limit },
                { label: '[Filters] Filter', value: actionWindow.filter },
            ]);
        }

        appendRecordMetadataTooltip(metadata) {
            this.appendTooltip([
                { label: 'ID', value: metadata.id },
                { label: 'XML ID', value: metadata.xmlid },
                { label: 'No Update', value: metadata.noupdate },
                { label: 'Creation User', value: metadata.create_uid },
                { label: 'Creation Date', value: metadata.create_date },
                { label: 'Latest Modification by', value: metadata.write_uid },
                { label: 'Latest Modification Date', value: metadata.write_date },
            ]);
        }

        appendTooltip(datas) {
            if (!datas || datas.length === 0) return;

            const metadataContainer = document.getElementById('joorney-tooltip-metadata');
            if (metadataContainer) metadataContainer.remove();

            const debugManager = document.querySelector('.o_debug_manager');
            if (!debugManager) return;

            const rows = datas.map((d) => `<tr><th>${d.label}:</th><td>${d.value}</td></tr>`.trim());

            const template = document.createElement('template');
            template.innerHTML = `
            <div id="joorney-tooltip-metadata">
                <style>
                    #joorney-tooltip-metadata {
                        display: none;
                        position: absolute;
                        top: 100%;
                        z-index: 10;
                        background-color: #f9f9f9;
                        color: #374151;
                        width: max-content;
                        padding: 8px;
                        border: 1px solid rgba(252, 163, 17, 0.2);
                        border-radius: 0.5rem;
                        box-shadow: 0 0.125rem 0.25rem rgba(252, 163, 17, 0.075);
                        transform: translateX(-90%);
                    }
                    #joorney-tooltip-metadata th, #joorney-tooltip-metadata td {
                        padding-right: 50px;
                    }
                    #joorney-tooltip-metadata th:first-child {
                        width: 1%;
                        white-space: nowrap;
                    }

                    #joorney-tooltip-metadata td:last-child {
                        width: 100%;
                    }
                    .o_debug_manager:hover #joorney-tooltip-metadata {
                        display: flex;
                    }
                    .o_debug_manager:hover button {
                        border-color: rgba(252, 163, 17, 1) !important
                    }
                </style>
                <table class="table table-sm table-striped" style="max-width: 600px; width: 100%">
                    ${rows.join('\n')}
                </table>
            </div>
        `.trim();
            debugManager.appendChild(template.content.firstChild);
            debugManager.style.position = 'relative';
        }
    }

    var content$1 = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: TooltipMetadataContentFeature
    });

    const UNFOCUS_STATE = Object.freeze({
        UNFOCUS: 0,
        DEFAULT: 1,
        SUPER: 2,
        MAX: 2,
    });

    const FOCUS_OPACITY = 1;
    const UNFOCUS_OPACITY = 0.1;
    const STAR_ELEMENT_CLASS = 'joorney-focus-app';
    const FOCUS_ICON = 'fa-star';
    const UNFOCUS_ICON = 'fa-star-o';
    const SHARED_ORIGIN = 'unfocus_app_shared';

    class UnfocusApp extends ContentFeature {
        constructor() {
            super(configuration);
            this.clickCount = 0;
        }

        async loadFeature(url) {
            if (!(await isStillSameWebsite(0, url))) return;

            this.appendUnfocusApp(url);
        }

        async appendUnfocusApp(urlArg, count = 0) {
            const url = sanitizeURL(urlArg);

            const {
                unfocusAppReorderEnabled,
                unfocusAppShareEnabled,
                unfocusAppLightImageURL,
                unfocusAppDarkImageURL,
                unfocusAppOrigins,
            } = await StorageSync.get(this.defaultSettings);

            const elements = document.getElementsByClassName('o_app');
            if (elements.length === 0 && count === 0) {
                await sleep(2500);
                return this.appendUnfocusApp(url, count + 1);
            }

            const origin = unfocusAppShareEnabled ? SHARED_ORIGIN : url.origin;
            const unfocusAppList = unfocusAppOrigins[origin] || {};

            this.appendStar(elements, unfocusAppList, {
                unfocusAppLightImageURL,
                unfocusAppDarkImageURL,
            });
            this.handleStar(unfocusAppReorderEnabled);
        }

        appendStar(elements, unfocusAppList, configuration) {
            for (const element of elements) {
                const app = element.getAttribute('data-menu-xmlid');
                let state = unfocusAppList[app];
                if (state === undefined) state = UNFOCUS_STATE.DEFAULT;
                if (state === true) state = UNFOCUS_STATE.UNFOCUS;
                this.updateAppElement(element, state, null, configuration);

                const divElement = element.getElementsByClassName('o_caption')[0];
                for (const star of divElement.getElementsByClassName(STAR_ELEMENT_CLASS)) {
                    star.remove();
                }

                const isUnfocus = state === UNFOCUS_STATE.UNFOCUS;
                divElement.innerHTML = `<i title="Change focus state" class="joorney-focus-app fa
                ${isUnfocus ? UNFOCUS_ICON : FOCUS_ICON} me-1" data-joorney-state="${state}">
            </i>${divElement.innerHTML}`.trim();
            }
        }

        handleStar(reorderEnabled) {
            const container = document.getElementsByClassName('o_apps')[0];
            const apps = Array.from(document.getElementsByClassName(STAR_ELEMENT_CLASS));
            const defaultApps = [];
            const unfocusApps = [];

            for (const app of apps) {
                app.onclick = (e) => this.onStarClick(app, e);

                if (reorderEnabled) {
                    let parent = app.parentElement.parentElement;
                    // 16.4+ introduce draggable feature, a new parent has been added
                    if (parent.parentElement.classList.contains('o_draggable')) {
                        parent = parent.parentElement;
                    }

                    const state = app.getAttribute('data-joorney-state');

                    switch (state) {
                        case `${UNFOCUS_STATE.DEFAULT}`: {
                            // TODO[IMP] Why not: defaultApps.push(parent);
                            break;
                        }
                        case `${UNFOCUS_STATE.UNFOCUS}`: {
                            unfocusApps.push(parent);
                            break;
                        }
                    }
                }
            }
            for (const p of defaultApps) container.appendChild(p);
            for (const p of unfocusApps) container.appendChild(p);
        }

        async onStarClick(element, event) {
            event.preventDefault();
            event.stopPropagation();
            event.stopImmediatePropagation();

            // debounce
            this.clickCount += 1;
            const currentClickCount = this.clickCount;
            await sleep(200);
            if (this.clickCount !== currentClickCount || this.clickCount === 0) return;

            let origin = window.location.origin;
            const parent = event.target.parentElement.parentElement;
            const app = parent.getAttribute('data-menu-xmlid');

            const { unfocusAppOrigins, unfocusAppShareEnabled, unfocusAppLightImageURL, unfocusAppDarkImageURL } =
                await StorageSync.get(this.defaultSettings);

            if (unfocusAppShareEnabled) {
                origin = SHARED_ORIGIN;
            }

            unfocusAppOrigins[origin] = unfocusAppOrigins[origin] || {};

            let currentState = unfocusAppOrigins[origin][app];
            if (currentState === undefined) currentState = UNFOCUS_STATE.DEFAULT;
            if (currentState === true) currentState = UNFOCUS_STATE.UNFOCUS; // true was the previous version logic

            const newState = this.clickCount > UNFOCUS_STATE.MAX ? UNFOCUS_STATE.MAX : this.clickCount;

            if (
                currentState === UNFOCUS_STATE.UNFOCUS ||
                (currentState !== newState && currentState > UNFOCUS_STATE.UNFOCUS)
            ) {
                unfocusAppOrigins[origin][app] = this.clickCount > UNFOCUS_STATE.MAX ? UNFOCUS_STATE.MAX : this.clickCount;
            } else {
                unfocusAppOrigins[origin][app] = UNFOCUS_STATE.UNFOCUS;
            }

            await StorageSync.set({ unfocusAppOrigins: unfocusAppOrigins });

            this.updateAppElement(parent, unfocusAppOrigins[origin][app], element, {
                unfocusAppLightImageURL,
                unfocusAppDarkImageURL,
            });

            this.clickCount = 0;
        }

        async updateAppElement(element, state, starElement, configuration) {
            const superfocusImageURL =
                (await getThemeModeCookie(origin)) === 'light'
                    ? configuration.unfocusAppLightImageURL
                    : configuration.unfocusAppDarkImageURL;

            const isUnfocus = state === UNFOCUS_STATE.UNFOCUS;
            if (starElement) {
                starElement.classList.remove(isUnfocus ? FOCUS_ICON : UNFOCUS_ICON);
                starElement.classList.add(isUnfocus ? UNFOCUS_ICON : FOCUS_ICON);
            }
            element.style.opacity = isUnfocus ? UNFOCUS_OPACITY : FOCUS_OPACITY;

            const isSuperfocus = state === UNFOCUS_STATE.SUPER;
            const parent = element.parentElement.classList.contains('o_draggable') ? element.parentElement : element;
            parent.style.backgroundImage = isSuperfocus ? `url("${superfocusImageURL}")` : null;
            parent.style.backgroundSize = isSuperfocus ? 'contain' : null;
            parent.style.backgroundRepeat = isSuperfocus ? 'no-repeat' : null;
            parent.style.backgroundPosition = 'center top';
        }

        onPopupMessage(msg) {
            const checked = msg.enableUnfocusApp;

            if (typeof checked === 'boolean') {
                const exist = Array.from(document.getElementsByClassName(STAR_ELEMENT_CLASS));
                if (exist)
                    for (const e of exist) {
                        e.parentElement.parentElement.style.opacity = FOCUS_OPACITY;
                        e.parentElement.parentElement.parentElement.style.backgroundImage = null;
                        e.remove();
                    }
                if (checked && isOdooWebsite(msg.url)) this.appendUnfocusApp(msg.url);
            }
        }
    }

    var content = /*#__PURE__*/Object.freeze({
        __proto__: null,
        default: UnfocusApp
    });

    exports.updateTabState = updateTabState;

    return exports;

})({});
