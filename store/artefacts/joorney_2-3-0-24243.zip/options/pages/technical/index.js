// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
let getRandomValues;
const rnds8 = new Uint8Array(16);
function rng() {
  // lazy load so that environments that need to polyfill have a chance to do so
  if (!getRandomValues) {
    // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation.
    getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);

    if (!getRandomValues) {
      throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
    }
  }

  return getRandomValues(rnds8);
}

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */

const byteToHex = [];

for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).slice(1));
}

function unsafeStringify(arr, offset = 0) {
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];
}

const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
var native = {
  randomUUID
};

function v4(options, buf, offset) {
  if (native.randomUUID && !buf && !options) {
    return native.randomUUID();
  }

  options = options || {};
  const rnds = options.random || (options.rng || rng)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  return unsafeStringify(rnds);
}

var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringTaskEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var pinMessage = true;
var ambient = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringTaskEffect: starringTaskEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus,
	pinMessage: pinMessage,
	ambient: ambient
};

function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
isFirefox() ? browser.tabs : chrome.tabs;
isFirefox() ? browser.contextMenus : chrome.contextMenus;
isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
const StorageLocal = isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
isFirefox() ? browser.webNavigation : chrome.webNavigation;
isFirefox() ? browser.cookies : chrome.cookies;
isFirefox() ? browser.action : chrome.action;
isFirefox() ? browser.commands : chrome.commands;
isFirefox() ? browser.windows : chrome.windows;
const Management = isFirefox() ? browser.management : chrome.management;
isFirefox() ? browser.omnibox : chrome.omnibox;
isFirefox() ? browser.webRequest : chrome.webRequest;

const baseSettings = {
    configurationVersion: 1,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['17.0'],

    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
};

const extensionFeatureState = FeaturesState;
Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

// https://github.com/callumlocke/json-formatter

function handleExpanderClick() {
    for (const element of document.getElementsByClassName('expander')) {
        element.onclick = onClickExpander;
    }
}

function onClickExpander(event) {
    event.preventDefault();
    const parent = event.target.parentNode;

    // Expand or collapse
    if (parent.classList.contains('json-collapsed')) {
        // EXPAND
        if (event.metaKey || event.ctrlKey) {
            const gp = parent.parentNode;
            expand(gp.children, event.shiftKey);
            return;
        }
        expand([parent], event.shiftKey);
        return;
    }

    // COLLAPSE
    if (event.metaKey || event.ctrlKey) {
        const gp = parent.parentNode;
        collapse(gp.children, event.shiftKey);
        return;
    }
    collapse([parent], event.shiftKey);
}

// (CSS shows/hides the contents and hides/shows an ellipsis.)
function collapse(elements, recursive = false) {
    for (const el of elements) {
        el.classList.add('json-collapsed');
        if (recursive) {
            for (const sel of el.getElementsByClassName('jsonEntry')) {
                sel.classList.add('json-collapsed');
            }
        }
    }
}

function expand(elements, recursive = false) {
    for (const el of elements) {
        el.classList.remove('json-collapsed');
        if (recursive) {
            for (const sel of el.getElementsByClassName('jsonEntry')) {
                sel.classList.remove('json-collapsed');
            }
        }
    }
}

// https://github.com/callumlocke/json-formatter

const baseSpan = document.createElement('span');

const createBlankSpan = () => baseSpan.cloneNode(false);

const getSpanWithClass = (className) => {
    const span = createBlankSpan();
    span.className = className;
    return span;
};

const getSpanWithBoth = (innerText, className) => {
    const span = createBlankSpan();
    span.className = className;
    span.innerText = innerText;
    return span;
};

const templates = {
    t_entry: getSpanWithClass('jsonEntry'),
    t_exp: getSpanWithClass('expander'),
    t_key: getSpanWithClass('key'),
    t_string: getSpanWithClass('stringValue'),
    t_number: getSpanWithClass('numberValue'),

    t_null: getSpanWithBoth('null', 'nullValue'),
    t_true: getSpanWithBoth('true', 'boolValue'),
    t_false: getSpanWithBoth('false', 'boolValue'),

    t_oBrace: getSpanWithBoth('{', 'brace_bracket'),
    t_cBrace: getSpanWithBoth('}', 'brace_bracket'),
    t_oBracket: getSpanWithBoth('[', 'brace_bracket'),
    t_cBracket: getSpanWithBoth(']', 'brace_bracket'),

    t_sizeComment: getSpanWithClass('comment'),

    t_ellipsis: getSpanWithClass('collectionEllipsis'),
    t_blockInner: getSpanWithClass('innerJSON'),

    t_colonAndSpace: document.createTextNode(':\u00A0'),
    t_commaText: document.createTextNode(','),
    t_dblqText: document.createTextNode('"'),
};

// https://github.com/callumlocke/json-formatter

const getValueType = (value) => {
    if (typeof value === 'string') return TYPE_STRING;
    if (typeof value === 'number') return TYPE_NUMBER;
    if (value === false || value === true) return TYPE_BOOL;
    if (value === null) return TYPE_NULL;
    if (Array.isArray(value)) return TYPE_ARRAY;

    return TYPE_OBJECT;
};

const TYPE_STRING = 1;
const TYPE_NUMBER = 2;
const TYPE_OBJECT = 3;
const TYPE_ARRAY = 4;
const TYPE_BOOL = 5;
const TYPE_NULL = 6;

// https://github.com/callumlocke/json-formatter


function buildDom(value, keyName = false, collapse = false) {
    const type = getValueType(value);

    const entry = templates.t_entry.cloneNode(false);
    if (collapse) entry.classList.add('json-collapsed');

    let collectionSize = 0;
    if (type === TYPE_OBJECT) {
        collectionSize = Object.keys(value).length;
        //entry.classList.add('objProp');
    } else if (type === TYPE_ARRAY) {
        collectionSize = value.length;
        //entry.classList.add('arrElem');
    }

    const nonZeroSize = collectionSize > 0;
    if (nonZeroSize) entry.appendChild(templates.t_exp.cloneNode(false));

    // NB: "" is a legal keyname in JSON
    if (keyName !== false) {
        const keySpan = templates.t_key.cloneNode(false);
        keySpan.textContent = JSON.stringify(keyName).slice(1, -1); // remove quotes

        entry.appendChild(templates.t_dblqText.cloneNode(false));
        entry.appendChild(keySpan);
        entry.appendChild(templates.t_dblqText.cloneNode(false));

        entry.appendChild(templates.t_colonAndSpace.cloneNode(false));
    }

    let blockInner = undefined;
    let childEntry = undefined;

    switch (type) {
        case TYPE_STRING: {
            const innerStringEl = createBlankSpan();

            const escapedString = JSON.stringify(value).slice(1, -1); // remove outer quotes

            if (value.substring(0, 8) === 'https://' || value.substring(0, 7) === 'http://') {
                const innerStringA = document.createElement('a');
                innerStringA.href = value;
                innerStringA.innerText = escapedString;
                innerStringEl.appendChild(innerStringA);
            } else {
                innerStringEl.innerText = escapedString;
            }
            const valueElement = templates.t_string.cloneNode(false);
            valueElement.appendChild(templates.t_dblqText.cloneNode(false));
            valueElement.appendChild(innerStringEl);
            valueElement.appendChild(templates.t_dblqText.cloneNode(false));
            entry.appendChild(valueElement);
            break;
        }

        case TYPE_NUMBER: {
            const valueElement = templates.t_number.cloneNode(false);
            valueElement.innerText = String(value);
            entry.appendChild(valueElement);
            break;
        }

        case TYPE_OBJECT: {
            entry.appendChild(templates.t_oBrace.cloneNode(true));

            if (nonZeroSize) {
                entry.appendChild(templates.t_ellipsis.cloneNode(false));
                blockInner = templates.t_blockInner.cloneNode(false);

                let lastComma;
                for (const k in value) {
                    childEntry = buildDom(value[k], k, collapse);

                    const comma = templates.t_commaText.cloneNode();

                    childEntry.appendChild(comma);

                    blockInner.appendChild(childEntry);

                    lastComma = comma;
                }

                if (childEntry && lastComma) {
                    childEntry.removeChild(lastComma);
                }

                entry.appendChild(blockInner);
            }

            entry.appendChild(templates.t_cBrace.cloneNode(true));

            entry.dataset.size = ` // ${collectionSize} ${collectionSize === 1 ? 'item' : 'items'}`;

            break;
        }

        case TYPE_ARRAY: {
            entry.appendChild(templates.t_oBracket.cloneNode(true));

            if (nonZeroSize) {
                entry.appendChild(templates.t_ellipsis.cloneNode(false));

                blockInner = templates.t_blockInner.cloneNode(false);

                for (let i = 0, length = value.length, lastIndex = length - 1; i < length; i++) {
                    childEntry = buildDom(value[i], false, collapse);

                    if (i < lastIndex) {
                        const comma = templates.t_commaText.cloneNode();
                        childEntry.appendChild(comma);
                    }

                    blockInner.appendChild(childEntry);
                }
                entry.appendChild(blockInner);
            }
            entry.appendChild(templates.t_cBracket.cloneNode(true));

            entry.dataset.size = ` // ${collectionSize} ${collectionSize === 1 ? 'item' : 'items'}`;

            break;
        }

        case TYPE_BOOL: {
            if (value) entry.appendChild(templates.t_true.cloneNode(true));
            else entry.appendChild(templates.t_false.cloneNode(true));
            break;
        }

        case TYPE_NULL: {
            entry.appendChild(templates.t_null.cloneNode(true));
            break;
        }
    }

    return entry;
}

async function sleep(timeMS) {
    return await new Promise((r) => setTimeout(r, timeMS));
}

// Private
const LOCAL_DEFAULT = {
    journey_announces: {},
    offs: [],
    ambient_dates: {},
    joorney_sunrise: 0,
    joorney_sunset: 23 * 60 + 59,
    joorney_date: '',
    joorneyLocalCacheCall: {},
};

// Developer
async function getStorageUsage(...keysArg) {
    const keys = Array.from(keysArg);
    const usage = await StorageLocal.getBytesInUse(keys && keys.length > 0 ? keys : undefined);
    return usage;
}
async function clearLocal() {
    await StorageLocal.clear();
}
async function getLocal() {
    return await StorageLocal.get(LOCAL_DEFAULT);
}

const store$4 = {
    tour_hostControls: false,
    tour_hostControls_version: 1,
    step_hostControls_moveFeature: false,
    step_hostControls_addHost: false,
    step_hostControls_configureHost: false,
    step_hostControls_deleteHost: false,
};

const steps$4 = {
    step_hostControls_moveFeature: {
        id: 'step_hostControls_moveFeature',
        tour: 'joorney_tour_hostControls',
        name: 'Manage Features',
        description: 'Drag and drop to enable or disable a feature for optimal control.',
        trigger: [{ selector: '#joorney_showMyBadge_feature', run: 'dragend' }],
        next: 'step_hostControls_addHost',
        progression: 30,
    },
    step_hostControls_addHost: {
        id: 'step_hostControls_addHost',
        tour: 'joorney_tour_hostControls',
        name: 'Add your own origin',
        description: "Add a new origin by saving your changes or pressing 'Enter'.",
        trigger: [
            { selector: '#joorney_origins_filter_new_origin_save', run: 'click' },
            { selector: '#joorney_origins_filter_new_origin', run: 'onkeydown', conditional: (e) => e.key === 'Enter' },
        ],
        next: 'step_hostControls_configureHost',
        progression: 20,
    },
    step_hostControls_configureHost: {
        id: 'step_hostControls_configureHost',
        tour: 'joorney_tour_hostControls',
        name: 'Configure your origin',
        description: 'Adjust the settings for each origin by enabling or disabling features using the checkboxes.',
        trigger: [{ selector: '.joorney_origins_filter_origin_0_showMyBadge', run: 'click' }],
        next: 'step_hostControls_deleteHost',
        progression: 30,
    },
    step_hostControls_deleteHost: {
        id: 'step_hostControls_deleteHost',
        tour: 'joorney_tour_hostControls',
        name: 'Remove your origin',
        description: 'Initiate and confirm origin deletion in the prompt.',
        trigger: [{ selector: '.joorney_origins_filter_origin_delete_0', run: 'click' }],
        progression: 20,
    },
};

const store$3 = {
    tour_preferences: false,
    tour_preferences_version: 1,
    step_preferences_awesomeLoading: false,
    step_preferences_awesomeStyle: false,
    step_preferences_unfocusApp: false,
    step_preferences_themeSwitchLocation: false,
    step_preferences_themeSwitchTime: false,
    step_preferences_contextOdooMenus: false,
};

const steps$3 = {
    step_preferences_awesomeLoading: {
        id: 'step_preferences_awesomeLoading',
        tour: 'tour_preferences',
        name: 'Custom Loading',
        description: 'Upload and set a custom loading GIF for a personalized Odoo loading.',
        trigger: [{ selector: '#joorney_awe_loading_new_image_save', run: 'click', align: 'nearest' }],
        next: 'step_preferences_awesomeStyle',
        progression: 20,
    },
    step_preferences_awesomeStyle: {
        id: 'step_preferences_awesomeStyle',
        tour: 'tour_preferences',
        name: 'Stylus Like',
        description: 'Adjust and customize the visual style to match your preferences.',
        trigger: [{ selector: '#joorney_awe_style_css', run: 'click' }],
        next: 'step_preferences_unfocusApp',
        progression: 15,
    },
    step_preferences_unfocusApp: {
        id: 'step_preferences_unfocusApp',
        tour: 'tour_preferences',
        name: 'App Icon Background',
        description: 'Personalize the app icon background, used for superfocused apps.',
        trigger: [{ selector: '#joorney_unfocus_app_light_image_input', run: 'click' }],
        next: 'step_preferences_themeSwitchLocation',
        progression: 20,
    },
    step_preferences_themeSwitchLocation: {
        id: 'step_preferences_themeSwitchLocation',
        tour: 'tour_preferences',
        name: 'Sunlight Theme Mode',
        description: 'Enable automatic theme switching based on sunrise and sunset times.',
        trigger: [{ selector: '#joorney_theme_switch_get_location_button', run: 'click' }],
        next: 'step_preferences_themeSwitchTime',
        progression: 15,
    },
    step_preferences_themeSwitchTime: {
        id: 'step_preferences_themeSwitchTime',
        tour: 'tour_preferences',
        name: 'Scheduled Theme Mode',
        description: 'Set a schedule time range for automatic theme switching.',
        trigger: [
            { selector: '#joorney_theme_switch_dark_start', run: 'click' },
            { selector: '#joorney_theme_switch_dark_stop', run: 'click' },
        ],
        next: 'step_preferences_contextOdooMenus',
        progression: 15,
    },
    step_preferences_contextOdooMenus: {
        id: 'step_preferences_contextOdooMenus',
        tour: 'tour_preferences',
        name: 'Context Menus',
        description: "Setup some Odoo's menus to use in Joorney context menu.",
        trigger: [{ selector: '#joorney_contextOdooMenus_new_save', run: 'click' }],
        progression: 15,
    },
};

const store$2 = {
    tour_technical: true,
    tour_technical_version: 1,
    step_technical_experimentalOption: false,
    step_technical_addWAFallback: false,
    step_technical_removeWAFallback: false,
    step_technical_extensionState: false,
    step_technical_onboardingProgress: false,
    step_technical_extensionFeaturesConfiguration: false,
    step_technical_extensionConfiguration: false,
};

const steps$2 = {
    step_technical_experimentalOption: {
        id: 'step_technical_experimentalOption',
        tour: 'tour_technical',
        name: 'Experimental / Advanced',
        description: 'Advanced options for informed user.',
        next: 'step_technical_addWAFallback',
        progression: 20,
    },
    step_technical_addWAFallback: {
        id: 'step_technical_addWAFallback',
        tour: 'tour_technical',
        name: 'Window Actions - No access',
        description: "You don't have the access to see 'Window Action' records? Add model fallback here",
        trigger: [{ selector: '#joorney_window_action_fallback_new_path_save', run: 'click' }],
        next: 'step_technical_removeWAFallback',
        progression: 20,
    },
    step_technical_removeWAFallback: {
        id: 'step_technical_removeWAFallback',
        tour: 'tour_technical',
        name: 'Window Actions - Removal',
        description: "Revoke or adjust the fallback for 'Window Action' records as needed.",
        trigger: [{ selector: '[class^="joorney_window_action_fallback_origin_delete"]', run: 'click' }],
        next: 'step_technical_extensionState',
        progression: 20,
    },
    step_technical_extensionState: {
        id: 'step_technical_extensionState',
        tour: 'tour_technical',
        name: 'Extension State',
        description: '', // 'Review the list of enabled features in the current version/build.',
        trigger: [{ selector: '#joorney-extension-state .expander', run: 'click' }],
        next: 'step_technical_onboardingProgress',
        progression: 15,
    },
    step_technical_onboardingProgress: {
        id: 'step_technical_onboardingProgress',
        tour: 'tour_technical',
        name: 'Onboarding progression',
        description: '', // "Check your onboarding progression stored in Chrome's local storage.",
        trigger: [{ selector: '#joorney-onboarding-progression .expander', run: 'click' }],
        next: 'step_technical_extensionFeaturesConfiguration',
        progression: 15,
    },
    step_technical_extensionFeaturesConfiguration: {
        id: 'step_technical_extensionFeaturesConfiguration',
        tour: 'tour_technical',
        name: 'Feature Setup',
        description: '', // 'Explore configurations for all features.',
        trigger: [{ selector: '#joorney-extension-features .expander', run: 'click' }],
        next: 'step_technical_extensionConfiguration',
        progression: 15,
    },
    step_technical_extensionConfiguration: {
        id: 'step_technical_extensionConfiguration',
        tour: 'tour_technical',
        name: 'User Configuration',
        description: '', // "Check your user configuration stored in Chrome's sync storage.",
        trigger: [{ selector: '#joorney-storage-configuration .expander', run: 'click' }],
        progression: 15,
    },
};

const store$1 = {
    tour_versions: false,
    tour_versions_version: 1,
    step_versions_addLTSVersion: false,
    step_versions_addSubVersion: false,
    step_versions_checkCompatibility: false,
    step_versions_removeSubVersion: false,
};

const steps$1 = {
    step_versions_addLTSVersion: {
        id: 'step_versions_addLTSVersion',
        tour: 'joorney_tour_versions',
        name: 'Enable LTS version',
        description: 'Select and enable a new Long-Term Support (LTS) version.',
        trigger: [{ selector: 'label[for="joorney_16_0_version"]', run: 'click' }],
        next: 'step_versions_addSubVersion',
        progression: 30,
    },
    step_versions_addSubVersion: {
        id: 'step_versions_addSubVersion',
        tour: 'joorney_tour_versions',
        name: 'Enable Version',
        description: 'Enable a version to explore new features.',
        trigger: [{ selector: 'label[for="joorney_15_2_version"]', run: 'click' }],
        next: 'step_versions_checkCompatibility',
        progression: 30,
    },
    step_versions_checkCompatibility: {
        id: 'step_versions_checkCompatibility',
        tour: 'joorney_tour_versions',
        name: 'Compatibility Table',
        description: 'Review compatibility between features and versions.',
        next: 'step_versions_removeSubVersion',
        progression: 10,
    },
    step_versions_removeSubVersion: {
        id: 'step_versions_removeSubVersion',
        tour: 'joorney_tour_versions',
        name: 'Disable Version',
        description: 'Disable the previously enabled version.',
        trigger: [{ selector: 'label[for="joorney_15_2_version"]', run: 'click' }],
        progression: 30,
    },
};

async function getOnboardingProgressData() {
    const progress = await StorageLocal.get({
        ...store$4,
        ...store$3,
        ...store$1,
        ...store$2,
    });
    return progress;
}

const store = {
    tour_toasts: false,
    tour_toasts_version: 1,
    step_toast_showMe_1: false,
    step_toast_switchMode: false,
    step_toast_disableType: false,
    step_toast_showMe_2: false,
};

const steps = {
    step_toast_showMe_1: {
        id: 'step_toast_showMe_1',
        tour: 'tour_toasts',
        name: 'Notification Look',
        description: 'Display some notifications with your current configuration!',
        trigger: [{ selector: '#joorney-toast-mode-showme', run: 'click' }],
        next: 'step_toast_switchMode',
        progression: 25,
    },
    step_toast_switchMode: {
        id: 'step_toast_switchMode',
        tour: 'tour_toasts',
        name: 'Switch Mode',
        description: 'Change the display of notification, larger or hide in console!',
        trigger: [
            { selector: 'label[for="joorney-toast-mode-log"]', run: 'click' },
            { selector: 'label[for="joorney-toast-mode-small"]', run: 'click' },
            { selector: 'label[for="joorney-toast-mode-large"]', run: 'click' },
        ],
        next: 'step_toast_disableType',
        progression: 25,
    },
    step_toast_disableType: {
        id: 'step_toast_disableType',
        tour: 'tour_toasts',
        name: 'Disable Type',
        description: 'Choose your prefered notifications types!',
        trigger: [
            { selector: 'label[for="joorney-toast-mode-info"]', run: 'click' },
            { selector: 'label[for="joorney-toast-mode-warn"]', run: 'click' },
            { selector: 'label[for="joorney-toast-mode-error"]', run: 'click' },
            { selector: 'label[for="joorney-toast-mode-succss"]', run: 'click' },
        ],
        next: 'step_toast_showMe_2',
        progression: 25,
    },
    step_toast_showMe_2: {
        id: 'step_toast_showMe_2',
        tour: 'tour_toasts',
        name: 'Notification Look',
        description: 'Display some notifications with your current configuration!',
        progression: 25,
    },
};

const tours = {
    tour_hostControls: {
        id: 'tour_hostControls',
        version: 1,
        title: 'Hosts control',
        description: 'Manage feature by host!',
        steps: steps$4,
        store: store$4,
    },
    tour_preferences: {
        id: 'tour_preferences',
        version: 1,
        title: 'Preferences',
        description: 'Setup your preferences for many features.',
        steps: steps$3,
        store: store$3,
    },
    tour_versions: {
        id: 'tour_versions',
        version: 1,
        title: 'Versions',
        description: 'Choose in which version you want to use Joorney!',
        steps: steps$1,
        store: store$1,
    },
    tour_toasts: {
        id: 'tour_toasts',
        version: 1,
        title: 'Notifications',
        description: 'Setup your notification preferences!',
        steps: steps,
        store: store,
    },
    tour_technical: {
        id: 'tour_technical',
        version: 1,
        title: 'Technical / Developers',
        description: 'Welcome to the dark side, we have cookies!',
        steps: steps$2,
        store: store$2,
    },
};

function stringToHTML(str) {
    const template = document.createElement('template');
    template.innerHTML = str.trim();
    return template.content.firstChild;
}

async function getInstallType() {
    const extension = await Management.getSelf();
    return extension.installType;
}

async function isDevMode() {
    const installType = await getInstallType();
    return installType === 'development';
}

const colors = [
    'red',
    'blue',
    'green',
    'yellow',
    'orange',
    'purple',
    'pink',
    'brown',
    'cyan',
    'magenta',
    'lime',
    'indigo',
    'violet',
    'turquoise',
    'maroon',
    'olive',
    'teal',
    'coral',
    'gold',
];

class DoubleProgressBar {
    constructor(progressName, labelID, switcherID, totalBarID, partialBarID, maximum, total, sections) {
        this.label = document.getElementById(labelID);
        this.switcher = document.getElementById(switcherID);
        this.totalBar = document.getElementById(totalBarID);
        this.partialBar = document.getElementById(partialBarID);

        this.maximum = maximum;
        this.total = total;
        this.sections = sections;

        this.loadTotal();
        this.loadPartial();

        this.switcher.onclick = () => this.switch();
        this.label.innerHTML = `${progressName}: ${this.total} / ${this.maximum} bytes`;
    }

    switch() {
        this.totalBar.classList.toggle('d-none');
        this.partialBar.classList.toggle('d-none');
    }

    loadTotal() {
        this.totalBar.innerHTML = '';
        this.totalBar.title = `${this.maximum}`;
        const usageElement = this.getSectionElement(
            `${this.total} / ${this.maximum}`,
            (this.total / this.maximum) * 100,
            'var(--joorney-secondary)'
        );
        usageElement.onclick = () => this.switch();
        this.totalBar.appendChild(usageElement);
    }

    loadPartial() {
        this.partialBar.innerHTML = '';
        this.partialBar.title = `${this.total}`;
        let usageElement = undefined;
        let i = 0;
        for (const section of this.sections) {
            usageElement = this.getSectionElement(
                `${section.label}: ${section.usage} / ${this.total}`,
                (section.usage / this.total) * 100,
                colors[i % colors.length]
            );
            this.partialBar.appendChild(usageElement);
            i++;
        }
    }

    getSectionElement(label, value, color) {
        return stringToHTML(
            `<div title="${label}" class="progress-bar" style="width: ${value}%; background-color: ${color}"></div>`
        );
    }
}

async function loadPage(features, currentSettings) {
    loadExperimental(currentSettings);

    handleWindowActionFallback(currentSettings.windowActionFallbacks);

    loadStorage(features, currentSettings);

    await loadChaos();
}

function loadExperimental(currentSettings) {
    const { useSimulatedUI, omniboxFocusCurrentTab } = currentSettings;

    const useSimulatedUIElement = document.getElementById('joorney_experimentalSimulatedUI');
    useSimulatedUIElement.checked = useSimulatedUI;
    useSimulatedUIElement.onchange = (e) => {
        StorageSync.set({ useSimulatedUI: e.target.checked });
    };

    const omniboxElement = document.getElementById('joorney_experimentalOmniboxFocusCurrentTab');
    omniboxElement.checked = omniboxFocusCurrentTab;
    omniboxElement.onchange = (e) => {
        StorageSync.set({ omniboxFocusCurrentTab: e.target.checked });
    };
}

//#region Storage
async function loadStorage(features, currentSettings) {
    loadFeaturesPreview(features);
    loadConfigurationPreview(currentSettings);
    await loadLocalDataPreview();
    await loadOnboardingProgression();
    handleExpanderClick();

    let sections = [];
    for (const feature of features) {
        sections.push({
            label: feature.display_name,
            usage: await StorageSync.getBytesInUse(Object.keys(feature.defaultSettings)),
        });
    }
    sections.push({
        label: 'Base',
        usage: await StorageSync.getBytesInUse(Object.keys(baseSettings)),
    });

    new DoubleProgressBar(
        'Sync Storage',
        'joorney-sync-storage-progress-label',
        'joorney-sync-storage-progress-switch',
        'joorney-sync-storage-byteUsageTotal',
        'joorney-sync-storage-byteUsageFeature',
        StorageSync.QUOTA_BYTES,
        await StorageSync.getBytesInUse(undefined),
        sections
    );

    sections = [];
    for (const tour of Object.values(tours)) {
        sections.push({
            label: `[Onboard] ${tour.title}`,
            usage: await getStorageUsage(...Object.keys(tour.store)),
        });
    }
    sections.push({
        label: 'Cache',
        usage: await getStorageUsage('joorneyLocalCacheCall'),
    });
    sections.push({
        label: 'Extension Off',
        usage: await getStorageUsage('offs'),
    });
    sections.push({
        label: 'Extension Announcement',
        usage: await getStorageUsage('journey_announces'),
    });
    sections.push({
        label: 'Ambient computed events',
        usage: await getStorageUsage('ambient_dates'),
    });
    sections.push({
        label: 'Sunrise / Sunset ',
        usage: await getStorageUsage('joorney_sunrise', 'joorney_sunset', 'joorney_date'),
    });

    new DoubleProgressBar(
        'Local Storage',
        'joorney-local-storage-progress-label',
        'joorney-local-storage-progress-switch',
        'joorney-local-storage-byteUsageTotal',
        'joorney-local-storage-byteUsageFeature',
        StorageLocal.QUOTA_BYTES,
        await getStorageUsage(),
        sections
    );
}

function loadFeaturesPreview(features) {
    let preview = document.getElementById('joorney-extension-state');
    preview.innerHTML = '';
    preview.appendChild(buildDom(extensionFeatureState, false, true));
    //preview.innerHTML = JSON.stringify(extensionFeatureState, null, 4);
    preview = document.getElementById('joorney-extension-features');
    preview.innerHTML = '';
    preview.appendChild(buildDom(features, false, true));
    //preview.innerHTML = JSON.stringify(features, null, 4);
}

function loadConfigurationPreview(currentSettings) {
    const preview = document.getElementById('joorney-storage-configuration');
    preview.innerHTML = '';
    preview.appendChild(buildDom(currentSettings, false, true));
    //debug.innerHTML = JSON.stringify(currentSettings, null, 4);
}

async function loadLocalDataPreview() {
    const cache = await getLocal();
    const preview = document.getElementById('joorney-storage-local');
    preview.innerHTML = '';
    preview.appendChild(buildDom(cache, false, true));
}

async function loadOnboardingProgression() {
    const progress = await getOnboardingProgressData();
    const preview = document.getElementById('joorney-onboarding-progression');
    preview.innerHTML = '';
    preview.appendChild(buildDom(progress, false, true));
    //debug.innerHTML = JSON.stringify(progress, null, 4);
}
//#endregion

//#region Window Action Fallback
function handleWindowActionFallback(windowActionFallbacks) {
    loadWindowActionFallback(windowActionFallbacks);
    document.getElementById('joorney_window_action_fallback_new_path_save').onclick = createFallback;
}

async function createFallback() {
    const originString = document.getElementById('joorney_window_action_fallback_new_origin')?.value?.trim();
    const path = document.getElementById('joorney_window_action_fallback_new_action_path')?.value?.trim();
    const model = document.getElementById('joorney_window_action_fallback_new_action_model')?.value?.trim();

    if (!originString) {
        renderFallbackError('Missing origin');
        return;
    }

    if (!path) {
        renderFallbackError('Missing path');
        return;
    }

    if (!model) {
        renderFallbackError('Missing model');
        return;
    }

    try {
        const origin = new URL(originString).origin;
        const windowActionFallbacks = await readFallbacks();

        const originsFallbacks = windowActionFallbacks[origin] ?? {};
        originsFallbacks[path] = model;

        windowActionFallbacks[origin] = originsFallbacks;
        await StorageSync.set({ windowActionFallbacks });

        loadWindowActionFallback(windowActionFallbacks);
    } catch (ex) {
        renderFallbackError(ex);
    }
}

function renderFallbackError(errorMessage) {
    const container = document.getElementById('joorney_window_action_fallback_error_footer');
    container.textContent = errorMessage;
    container.style.display = errorMessage ? 'table-cell' : 'none';
}

function loadWindowActionFallback(windowActionFallbacks) {
    const container = document.getElementById('joorney_window_action_fallback_table_body');
    container.innerHTML = '';
    renderFallbackError();

    for (const [k, v] of Object.entries(windowActionFallbacks)) {
        renderOriginFallback(k, v, container);
    }
}

function renderOriginFallback(origin, values, container) {
    if (Object.keys(values).length === 0) return;

    const idx = v4();
    const originID = `joorney_window_action_fallback_origin_delete_${idx}`;
    const originRow = stringToHTML(`
        <tr>
            <td colspan="3" class="text-center fw-bold joorney-valign-middle">${origin}</td>
            <td class="joorney-valign-middle">
                <button
                    class="${originID} btn btn-outline-danger border-0 btn-floating"
                    title="Delete all fallbacks"
                >
                    <i class="joorney-font-icon-size fa fa-trash"></i>
                </button>
            </td>
        </tr>
    `);
    const deleteButton = originRow.getElementsByClassName(originID)[0];
    deleteButton.onclick = () => deleteOriginsFallback(origin);
    container.appendChild(originRow);

    for (const [k, v] of Object.entries(values)) {
        renderFallback(origin, k, v, container);
    }
}

function renderFallback(origin, actionPath, actionModel, container) {
    const idx = v4();
    const originID = `joorney_window_action_fallback_delete_${idx}`;
    const fallbackRow = stringToHTML(`
        <tr>
            <td class="joorney-valign-middle">${origin}</td>
            <td class="joorney-valign-middle">${actionPath}</td>
            <td class="joorney-valign-middle">${actionModel}</td>
            <td class="joorney-valign-middle">
                <button
                    class="${originID} btn btn-outline-danger border-0 btn-floating"
                    title="Delete fallback"
                >
                    <i class="joorney-font-icon-size fa fa-trash"></i>
                </button>
            </td>
        </tr>
    `);
    const deleteButton = fallbackRow.getElementsByClassName(originID)[0];
    deleteButton.onclick = () => deleteFallbackPath(origin, actionPath);
    container.appendChild(fallbackRow);
}

async function readFallbacks() {
    const { windowActionFallbacks } = await StorageSync.get(baseSettings);
    return windowActionFallbacks;
}

async function deleteOriginsFallback(origin) {
    if (confirm(`Are you sure you want to remove origin: ${origin}?`)) {
        const windowActionFallbacks = await readFallbacks();
        delete windowActionFallbacks[origin];
        StorageSync.set({ windowActionFallbacks });

        loadWindowActionFallback(windowActionFallbacks);
    }
}

async function deleteFallbackPath(origin, actionPath) {
    if (confirm(`Are you sure you want to remove path "${actionPath}" for origin "${origin}"?`)) {
        const windowActionFallbacks = await readFallbacks();
        delete windowActionFallbacks[origin]?.[actionPath];
        if (Object.keys(windowActionFallbacks[origin]).length === 0) {
            delete windowActionFallbacks[origin];
        }
        StorageSync.set({ windowActionFallbacks });

        loadWindowActionFallback(windowActionFallbacks);
    }
}
//#endregion

//#region Developer Mode
async function loadChaos() {
    const isdev = await isDevMode();
    const ischaos = new URL(window.location.href).searchParams.get('chaos');
    if (!isdev || !ischaos) return;
    await sleep(5000);
    const chaos = document.getElementById('joorney_chaos_mode');
    if (!chaos) return;
    const actions = [
        { id: 'joorney_chaos_destroy_local_storage', action: () => clearLocal() },
        { id: 'joorney_chaos_destroy_sync_storage', action: () => StorageSync.clear() },
    ];
    for (const action of actions) {
        const actionElement = document.getElementById(action.id);
        actionElement.onclick = (e) => {
            confirmChaos(e.target.innerText, action.action);
        };
        actionElement.classList.remove('d-none');
    }
    chaos.classList.remove('d-none');
}

async function confirmChaos(name, action) {
    if (confirm(`Confirm "${name}". This page will be reloaded!!!`)) {
        const isdev = await isDevMode();
        const ischaos = new URL(window.location.href).searchParams.get('chaos');
        if (isdev && ischaos) {
            action();
            window.location.reload();
        } else {
            alert('DEVELOPMENT MODE NOT ACTIVE');
        }
    }
}
//#endregion

export { loadPage };
