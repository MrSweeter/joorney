var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringPriorityEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var pinMessage = true;
var ambient = true;
var followUnfollow = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringPriorityEffect: starringPriorityEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus,
	pinMessage: pinMessage,
	ambient: ambient,
	followUnfollow: followUnfollow
};

function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
isFirefox() ? browser.tabs : chrome.tabs;
isFirefox() ? browser.contextMenus : chrome.contextMenus;
isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
isFirefox() ? browser.webNavigation : chrome.webNavigation;
isFirefox() ? browser.cookies : chrome.cookies;
isFirefox() ? browser.action : chrome.action;
isFirefox() ? browser.commands : chrome.commands;
isFirefox() ? browser.windows : chrome.windows;
isFirefox() ? browser.management : chrome.management;
isFirefox() ? browser.omnibox : chrome.omnibox;
isFirefox() ? browser.webRequest : chrome.webRequest;

const Console = {
    info(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
    },
    log(obj) {
        console.log(obj);
    },
    error(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
    },
    warn(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
    },
    success(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
    },
    trace(label, obj) {
        console.trace(label, obj);
    },
    critical(obj) {
        console.error(obj);
    },

    _getFormatOperator(obj) {
        switch (typeof obj) {
            case 'string':
                return '%s';
            case 'number':
                return '%s';
            case 'object':
                return '%O';
            default:
                return '%s';
        }
    },
};

const baseSettings = {
    configurationVersion: 2,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['19.0'],
    supportedDevVersions: [],

    // Experimental
    developerMode: false,
    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
    cacheEncodingBase64: true,
};
Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

function stringToHTML(str) {
    const template = document.createElement('template');
    template.innerHTML = str.trim();
    return template.content.firstChild;
}

function ValueIsNaN(value) {
    return isNaN(value) || Number.isNaN(value);
}

let SUPPORTED_VERSION = ['16.0']; // Minimal supported version for extension versioning
let SUPPORTED_DEV_VERSION = [];

function sanitizeVersion(version) {
    return `${version}`.replaceAll(/saas[~|-]/g, '');
}

function includeVersion(versions, version, empty = false) {
    const supportedVersions = Array.isArray(versions) ? versions : [versions];
    if (supportedVersions.length === 0) return empty;
    if (supportedVersions.includes(version)) return true;

    const versionNum = sanitizeVersion(version);
    if (ValueIsNaN(versionNum)) return false;

    const uniqueOperator = versions.length === 1;

    for (const supportedVersion of supportedVersions) {
        const sanitizedVersion = sanitizeVersion(supportedVersion);
        if (!sanitizedVersion) continue;
        if (isVersionSupported(sanitizedVersion, versionNum, uniqueOperator)) return true;
    }

    return false;
}

function isVersionSupported(supportedVersion, version, uniqueOperator) {
    const supportedVersionNum = Number.parseFloat(supportedVersion);
    if (ValueIsNaN(supportedVersionNum)) return false;

    const versionNum = Number.parseFloat(version);
    if (ValueIsNaN(versionNum)) return false;

    if (supportedVersion.endsWith('+')) {
        if (uniqueOperator) return versionNum >= supportedVersionNum;
        Console.warn('Version operator "+" cannot be used with other values, with ":" for range');
        return false;
    }

    if (supportedVersion.endsWith('-')) {
        if (uniqueOperator) return versionNum < supportedVersionNum;
        Console.warn('Version operator "-" cannot be used with other values, with ":" for range');
        return false;
    }

    if (supportedVersion.includes(':')) {
        const fromTo = supportedVersion.split(':');
        const minimum = Number.parseFloat(fromTo[0]);
        const maximum = Number.parseFloat(fromTo[1]);
        if (ValueIsNaN(minimum) || ValueIsNaN(maximum)) {
            Console.warn(`Invalid range for operator ":" --> ${supportedVersion}`);
            return false;
        }
        return versionNum >= minimum && versionNum < maximum;
    }
    return versionNum === supportedVersionNum;
}

async function loadPage(features, currentSettings) {
    loadSupportedOdoo(currentSettings, features);
    loadSupportedOdoo(currentSettings, features, true);
    loadSupportedFeature(features, currentSettings.supportedVersions);
}

function loadSupportedOdoo(currentSettings, features, isdev = false) {
    let containerID = 'joorney-odoo-versions';
    let settingKey = 'supportedVersions';
    let toggleClass = 'odoo-version-wrapper';
    let ALL = SUPPORTED_VERSION;

    if (isdev) {
        containerID = 'joorney-odoo-dev-versions';
        settingKey = 'supportedDevVersions';
        toggleClass = 'dev odoo-version-wrapper';
        ALL = SUPPORTED_DEV_VERSION;
    }
    const supported = currentSettings[settingKey];
    const versionContainer = document.getElementById(containerID);

    for (const version of ALL) {
        const versionID = sanitizeVersionID(version);
        const versionElement = stringToHTML(`
			<label
				title="[Odoo Version] ${version}"
				for="joorney_${versionID}_version"
				style="width: 200px"
			>
				<input id="joorney_${versionID}_version" class="input-hide" type="checkbox" />
				<div class="${toggleClass} d-flex align-items-center justify-content-center">
					<i class="joorney-font-icon-size fa-regular me-2"></i>
					<p>${version}</p>
				</div>
			</label>
		`);
        versionContainer.appendChild(versionElement);

        const versionInput = document.getElementById(`joorney_${versionID}_version`);
        versionInput.checked = supported.includes(version);
        versionInput.onchange = async (e) => {
            const settings = await StorageSync.get(baseSettings);
            let versions = new Set(settings[settingKey]);
            e.target.checked ? versions.add(version) : versions.delete(version);
            versions = Array.from(versions);
            await StorageSync.set({ [settingKey]: versions });
            if (!isdev) await loadSupportedFeature(features, versions);
        };
    }
}

async function loadSupportedFeature(features, supportedVersions) {
    const versionContainerHead = document.getElementById('joorney-feature-versions-head');
    versionContainerHead.innerHTML = '';

    const header = stringToHTML(`
        <tr>
            <th class="text-end opacity-50">Compatibility</th>
            <th class="text-center" style="width: 32px"><i class="fa-solid fa-icons"></i></th>
            ${SUPPORTED_VERSION.map((v) => `<th class="text-center">${v}</th>`).join('')}
        </tr>
    `);
    versionContainerHead.appendChild(header);

    const versionContainerBody = document.getElementById('joorney-feature-versions-body');
    versionContainerBody.innerHTML = '';

    for (const feature of features.filter((f) => !f.limited)) {
        const versions = SUPPORTED_VERSION.map((v) => {
            return {
                odoo: includeVersion(supportedVersions, v),
                feature: includeVersion(feature.supported_version, v, true),
            };
        });
        const versionRow = stringToHTML(`
            <tr>
                <th class="text-end">
                    <span>${feature.display_name ?? feature.id}</span>
                </th>
                <th>
                    <div class="icon-wrapper">
                        ${feature.icon}
                    </div>
                </th>
                ${versions
                    .map(
                        (v) =>
                            `<td class="text-center table-${v.feature ? (v.odoo ? 'success' : 'warning') : 'danger'}">
                                <span class="opacity-25">${v.feature ? (v.odoo ? 'YES' : 'OFF') : 'NO'}</span>
                            </td>`
                    )
                    .join('')}
            </tr>
		`);
        versionContainerBody.appendChild(versionRow);
    }
}

function sanitizeVersionID(version) {
    return version.replace('.', '_');
}

export { loadPage };
