function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
const Tabs = isFirefox() ? browser.tabs : chrome.tabs;
const ContextMenus = isFirefox() ? browser.contextMenus : chrome.contextMenus;
const Runtime = isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
const StorageLocal = isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
const WebNavigation = isFirefox() ? browser.webNavigation : chrome.webNavigation;
const Cookies = isFirefox() ? browser.cookies : chrome.cookies;
const Action = isFirefox() ? browser.action : chrome.action;
const Commands = isFirefox() ? browser.commands : chrome.commands;
const Windows = isFirefox() ? browser.windows : chrome.windows;
const Management = isFirefox() ? browser.management : chrome.management;
const OmniBox = isFirefox() ? browser.omnibox : chrome.omnibox;

async function sendTabMessage(tabID, action, message = {}) {
    try {
        return await Tabs.sendMessage(tabID, { action: action, ...message });
    } catch (err) {
        Console.trace('catch tabs', err);
    }
}

const Console = {
    info(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
    },
    log(obj) {
        console.log(obj);
    },
    error(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
    },
    warn(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
    },
    success(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
    },
    trace(label, obj) {
        console.trace(label, obj);
    },
    critical(obj) {
        console.error(obj);
    },

    _getFormatOperator(obj) {
        switch (typeof obj) {
            case 'string':
                return '%s';
            case 'number':
                return '%s';
            case 'object':
                return '%O';
            default:
                return '%s';
        }
    },
};

var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringTaskEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringTaskEffect: starringTaskEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus
};

const MESSAGE_ACTION = {
    TO_BACKGROUND: {
        GET_FEATURES_LIST: 'GET_FEATURES_LIST',
        GET_FINAL_RUNBOT_URL: 'GET_FINAL_RUNBOT_URL',
        UPDATE_EXT_STATUS: 'UPDATE_EXT_STATUS',
        TRIGGER_FEATURE: 'TRIGGER_FEATURE',
        RECREATE_MENU: 'RECREATE_MENU',
        TAB_LOADED: 'TAB_LOADED',
    },
    TO_CONTENT: {
        TAB_NAVIGATION: 'TAB_NAVIGATION',
        POPUP_HAS_CHANGE: 'POPU¨_HAS_CHANGE',
        REQUEST_ODOO_INFO: 'REQUEST_ODOO_INFO',
        CM_OPEN_MENU: 'CM_OPEN_MENU',
        CM_OPEN_RUNBOT: 'CM_OPEN_RUNBOT',
    },
};

// import { getVersionInfo } from '../api/odoo.js';
function sanitizeVersion(version) {
    return `${version}`.replaceAll(/saas[~|-]/g, '');
}

function __variableDynamicImportRuntime3__(path) {
  switch (path) {
    case './src/features/themeSwitch/background.js': return Promise.resolve().then(function () { return background; });
    default: return new Promise(function(resolve, reject) {
      (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
        reject.bind(null, new Error("Unknown variable dynamic import: " + path))
      );
    })
   }
 }

function __variableDynamicImportRuntime0__(path) {
  switch (path) {
    case './src/features/adminDebugLoginRunbot/configuration.js': return Promise.resolve().then(function () { return configuration$q; });
    case './src/features/assignMeTask/configuration.js': return Promise.resolve().then(function () { return configuration$p; });
    case './src/features/autoOpenRunbot/configuration.js': return Promise.resolve().then(function () { return configuration$r; });
    case './src/features/awesomeLoadingLarge/configuration.js': return Promise.resolve().then(function () { return configuration$n; });
    case './src/features/awesomeLoadingSmall/configuration.js': return Promise.resolve().then(function () { return configuration$l; });
    case './src/features/awesomeStyle/configuration.js': return Promise.resolve().then(function () { return configuration$j; });
    case './src/features/contextOdooMenus/configuration.js': return Promise.resolve().then(function () { return configuration$h; });
    case './src/features/impersonateLoginRunbot/configuration.js': return Promise.resolve().then(function () { return configuration$f; });
    case './src/features/newServerActionCode/configuration.js': return Promise.resolve().then(function () { return configuration$d; });
    case './src/features/saveKnowledge/configuration.js': return Promise.resolve().then(function () { return configuration$b; });
    case './src/features/showMyBadge/configuration.js': return Promise.resolve().then(function () { return configuration$9; });
    case './src/features/starringTaskEffect/configuration.js': return Promise.resolve().then(function () { return configuration$7; });
    case './src/features/themeSwitch/configuration.js': return Promise.resolve().then(function () { return configuration$5; });
    case './src/features/tooltipMetadata/configuration.js': return Promise.resolve().then(function () { return configuration$3; });
    case './src/features/unfocusApp/configuration.js': return Promise.resolve().then(function () { return configuration$1; });
    default: return new Promise(function(resolve, reject) {
      (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
        reject.bind(null, new Error("Unknown variable dynamic import: " + path))
      );
    })
   }
 }

const SUPPORTED_VERSION = [
    '15.0',
    'saas-15.2',
    '16.0',
    'saas-16.1',
    'saas-16.2',
    'saas-16.3',
    'saas-16.4',
    '17.0',
    'saas-17.1',
    'saas-17.2',
    'saas-17.3',
    'saas-17.4',
    //'18.0' master
].map((v) => sanitizeVersion(v));

const baseSettings = {
    configurationVersion: 1,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['17.0'],

    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
};
const activeFeaturesList = Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

let features = [];
async function loadFeaturesConfiguration() {
    features = await Promise.all(activeFeaturesList.map((f) => importFeatureConfigurationFile(f)));
    Console.info(features);
}

function importFeatureConfigurationFile(featureID) {
    return __variableDynamicImportRuntime0__(`./src/features/${featureID}/configuration.js`).then((f) => f.default);
}

function importFeatureBackgroundFile(featureID) {
    return __variableDynamicImportRuntime3__(`./src/features/${featureID}/background.js`).then((f) => new f.default());
}

async function getCurrentSettings(features) {
    const defaultSettings = features.reduce((acc, obj) => {
        return Object.assign(acc, obj.defaultSettings);
    }, {});

    const settings = await StorageSync.get({
        ...baseSettings,
        ...defaultSettings,
    });
    return settings;
}

async function getCache() {
    const { joorneyLocalCacheCall } = await StorageLocal.get('joorneyLocalCacheCall');
    return joorneyLocalCacheCall ?? {};
}

async function setCache(cache) {
    await StorageLocal.set({ joorneyLocalCacheCall: cache ?? {} });
}

// Clear host if last change is 12h hours old
async function _checkHostsExpiration(cache, now) {
    let hasChange = false;
    for (const [k, v] of Object.entries(cache)) {
        if (now - (v.lastChange ?? 0) > 12 * 60 * 60 * 1000) {
            delete cache[k];
            hasChange = true;
        }
    }
    return { changed: hasChange, cache: cache };
}

async function checkHostsExpiration() {
    let cache = await getCache();
    cache = await _checkHostsExpiration(cache, Date.now());
    if (cache.changed) setCache(cache.cache);
}

async function clearHost(host) {
    const cache = await getCache();
    delete cache[host];
    await setCache(cache);
}

const openRunbotWithVersionMenuItem = {
    id: 'joorney_autoOpenRunbot_open_with_version',
    title: 'Open runbot with version %version%',
    active: true,
    favorite: true,
    order: 100,
};

var autoOpenRunbotConfiguration = {
    id: 'autoOpenRunbot',
    display_name: '[Runbot] Auto Open',
    icon: [
        '<!--<i class="fa-solid fa-door-open"></i>-->',
        '<!--<i class="fa-solid fa-dungeon"></i>-->',
        '<i class="fa-solid fa-fighter-jet"></i>',
    ],
    trigger: {
        load: true,
        navigate: true,
        context: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        autoOpenRunbotEnabled: false,
        autoOpenRunbotLimitedOrigins: ['https://runbot.odoo.com'],
        autoOpenRunbotContextMenu: {
            [openRunbotWithVersionMenuItem.id]: openRunbotWithVersionMenuItem,
        },
    },
    limited: true,
};

var configuration$r = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: autoOpenRunbotConfiguration,
    openRunbotWithVersionMenuItem: openRunbotWithVersionMenuItem
});

function sanitizeURL(url) {
    return sanitizedHrefToUrl(url);
}

function sanitizedHrefToUrl(hrefArg) {
    const href = typeof hrefArg === 'object' ? hrefArg.href : hrefArg;
    const url = new URL(href.replace(/#/g, href.includes('?') ? '&' : '?'));
    return url;
}

async function sleep(timeMS) {
    return await new Promise((r) => setTimeout(r, timeMS));
}

const regexSchemePrefix = 'regex://';

async function isAuthorizedFeature(feature, url) {
    const key = `${feature}Enabled`;
    const configuration = await StorageSync.get({
        [key]: false,
    });
    if (!configuration[key]) return false;

    const authorizedFeature = await authorizeFeature(feature, url.origin);
    return authorizedFeature;
}

async function isAuthorizedLimitedFeature(featureName, url) {
    const key = `${featureName}Enabled`;
    const configKey = `${featureName}LimitedOrigins`;
    const configuration = await StorageSync.get({
        [key]: false,
        [configKey]: [],
    });
    if (!configuration[key]) return false;
    const origin = url.origin;

    const { offs } = await StorageLocal.get({ offs: [] });
    if (offs.includes(origin)) {
        return false;
    }

    // Check URL
    if (configuration[configKey].includes(origin)) {
        return true;
    }

    // Check Regex
    const activeRegex = configuration[configKey]
        .filter((o) => o.startsWith(regexSchemePrefix))
        .map((o) => new RegExp(o.replace(regexSchemePrefix, '')));
    const validRegex = activeRegex.some((r) => r.test(origin));

    return validRegex;
}

async function authorizeFeature(featureName, origin) {
    const { offs } = await StorageLocal.get({ offs: [] });
    if (offs.includes(origin)) {
        return false;
    }

    const configuration = await StorageSync.get({
        originsFilterOrigins: {},
        [`${featureName}Enabled`]: false,
        [`${featureName}WhitelistMode`]: true,
    });

    if (!configuration[`${featureName}Enabled`]) return false;

    const activeOrigins = getActiveFeatureOrigins(configuration.originsFilterOrigins, featureName);
    const activeRegex = activeOrigins
        .filter((o) => o.startsWith(regexSchemePrefix))
        .map((o) => new RegExp(o.replace(regexSchemePrefix, '')));

    const originExist = activeOrigins.includes(origin) || activeRegex.some((r) => r.test(origin));

    const isWhitelistMode = configuration[`${featureName}WhitelistMode`];
    if (isWhitelistMode) {
        return originExist;
    }

    if (!isWhitelistMode) {
        return !originExist;
    }

    return false;
}

function getActiveFeatureOrigins(originsFilterOrigins, featureName) {
    const enabledOrigins = Object.entries(originsFilterOrigins)
        .filter((origin) => origin[1][featureName] === true)
        .map((origin) => origin[0]);
    return enabledOrigins;
}

const separatorMenuItem = {
    id: 'joorney_cm_separator_options',
    contexts: ['all'],
    type: 'separator',
};

const optionMenuItem = {
    id: 'joorney_cm_open_options',
    title: 'Open options',
    contexts: ['all'],
};

const clearLocalCacheMenuItem = {
    id: 'joorney_cm_clear_cache_host',
    title: 'Clear cache for this host',
    contexts: ['all'],
};

const CONTEXT_MENU_DYNAMIC_ITEM_IDS = [];

async function disableDynamicItems() {
    return Promise.all(CONTEXT_MENU_DYNAMIC_ITEM_IDS.map((id) => ContextMenus.update(id, { visible: false })));
}

async function createContextMenu() {
    await ContextMenus.removeAll();
    CONTEXT_MENU_DYNAMIC_ITEM_IDS.length = 0;

    const items = [];
    const dynamicItems = await getItems();

    for (const item of dynamicItems.filter((i) => !i.parentId)) {
        items.push(
            createContextMenuItem({
                id: item.id,
                title: item.title ?? item.path ?? 'Unknown item',
                contexts: item.contexts ?? ['all'],
                visible: false,
            })
        );
        CONTEXT_MENU_DYNAMIC_ITEM_IDS.push(item.id);
    }

    for (const item of dynamicItems.filter((i) => i.parentId)) {
        items.push(
            createContextMenuItem({
                id: item.id,
                title: item.title ?? item.path ?? 'Unknown item',
                contexts: item.contexts ?? ['all'],
                visible: false,
                parentId: item.parentId,
            })
        );
        CONTEXT_MENU_DYNAMIC_ITEM_IDS.push(item.id);
    }

    if (dynamicItems.length > 0) items.push(createContextMenuItem(separatorMenuItem));
    items.push(createContextMenuItem(clearLocalCacheMenuItem));
    items.push(createContextMenuItem(optionMenuItem));

    await Promise.all(items);
}

async function updateContext(tabId) {
    disableDynamicItems();

    try {
        const tab = await Tabs.get(tabId);
        if (!tab.active) return;
        if (!tab.url.startsWith('http')) return;
        const odooInfo = await sendTabMessage(tab.id, MESSAGE_ACTION.TO_CONTENT.REQUEST_ODOO_INFO);
        if (!odooInfo || !odooInfo.isOdoo) return;
        updateContextMenu(tab, odooInfo.isOdoo, odooInfo.version);
    } catch (error) {
        // Error: No tab with id (from Tabs.get) is expected
        if (`${error}`.includes(tabId)) Console.log(`background.js - updateContext: ${error}`);
        else Console.error(error);
    }
}

async function updateContextMenu(tab, isOdoo, version) {
    const dynamicItems = await getItems(tab);

    const itemsUpdate = [];
    for (const item of dynamicItems) {
        itemsUpdate.push(
            ContextMenus.update(item.id, {
                visible: isOdoo === true && item.active,
                title: formatTitle(item.title ?? item.path ?? 'Unknown item', { version }),
                parentId: null,
            })
        );
    }
    await Promise.all(itemsUpdate);
}

async function onContextMenuItemClick(info, tab) {
    const itemId = info.menuItemId;

    switch (itemId) {
        case optionMenuItem.id: {
            Runtime.openOptionsPage();
            return;
        }
        case clearLocalCacheMenuItem.id: {
            clearHost(new URL(tab.url).host);
            return;
        }
        case openRunbotWithVersionMenuItem.id: {
            sendTabMessage(tab.id, MESSAGE_ACTION.TO_CONTENT.CM_OPEN_RUNBOT);
            return;
        }
    }

    const items = await getItems(tab, false);
    const item = items[itemId];
    if (item?.path) {
        sendTabMessage(tab.id, MESSAGE_ACTION.TO_CONTENT.CM_OPEN_MENU, { menupath: item.path });
    }
}

function formatTitle(title, args) {
    const placeholders = ['%version%'];
    let finalTitle = title;
    for (const p of placeholders) {
        finalTitle = finalTitle.replaceAll(p, args[p.replaceAll('%', '')]);
    }
    return finalTitle;
}

async function createContextMenuItem(createProperties) {
    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/menus/create
    // https://developer.chrome.com/docs/extensions/reference/api/contextMenus#method-create
    // TODO switch to await when Promise flow is release
    return new Promise((resolve) => {
        ContextMenus.create(createProperties, resolve);
    }).catch(() => {});
}

async function getItems(tab = undefined, toArray = true) {
    const featureItems = await getFeaturesItems(tab);

    if (!toArray) return featureItems;

    const items = Object.values(featureItems).sort((a, b) => {
        if (a.parentId && !b.parentId) return 1;
        if (!a.parentId && b.parentId) return -1;
        return a.order - b.order;
    });
    return items;
}

async function getFeaturesItems(tab) {
    let url = undefined;
    if (tab) {
        if (!tab.url) return {};
        url = sanitizeURL(tab.url);
        if (!url.origin || !url.origin.startsWith('http')) return;
    }

    const contextFeatures = features.filter((f) => f.trigger.context);
    const allFavorite = contextFeatures.length === 1;

    const result = {};
    for (const feature of contextFeatures) {
        // If more limited feature, maybe need to rethink this part
        const isActive = feature.limited
            ? await isAuthorizedLimitedFeature(
                  feature.id,
                  new URL(feature.defaultSettings[`${feature.id}LimitedOrigins`][0])
              )
            : url !== undefined && (await isAuthorizedFeature(feature.id, url));

        const defaultSettings = await StorageSync.get(feature.defaultSettings);

        const id = `joorney_cm_${feature.id}`;
        const menus = defaultSettings[`${feature.id}ContextMenu`];
        if (!menus) continue;

        if (Object.keys(menus).length <= 0) continue;
        const menusArray = Object.values(menus);
        const activeMenuCount = menusArray.filter((m) => m.active).length;
        const activeFavoriteCount = menusArray.filter((m) => m.favorite).length;

        const parentActive = !allFavorite && activeFavoriteCount !== activeMenuCount && activeMenuCount > 1;
        result[id] = {
            id: id,
            title: feature.display_name,
            contexts: ['all'],
            order: Number.MAX_SAFE_INTEGER,
            active: isActive && parentActive,
        };

        for (const menu of menusArray) {
            result[menu.id] = {
                ...menu,
                parentId: parentActive ? (menu.favorite ? undefined : id) : undefined,
                active: isActive && menu.active,
            };
        }
    }
    return result;
}

const fetchVersion = 'https://raw.githubusercontent.com/MrSweeter/joorney/master/manifest.json';

async function getInstallType() {
    const extension = await Management.getSelf();
    return extension.installType;
}

async function checkVersion() {
    const installType = await getInstallType();
    if (!['development', 'other'].includes(installType)) return;
    const res = await fetch(fetchVersion);
    const manifest = await res.json();
    const remoteVersion = removeBuildFromVersion(manifest.version);
    const currentVersion = removeBuildFromVersion(Runtime.getManifest().version);

    let badgeText = { text: '' };

    if (
        remoteVersion.localeCompare(currentVersion, undefined, {
            numeric: true,
            sensitivity: 'base',
        }) > 0
    ) {
        badgeText = { text: remoteVersion };
    }

    await Action.setBadgeText(badgeText);
    await Action.setBadgeBackgroundColor({
        color: '#FF0000',
    });
}

function removeBuildFromVersion(version) {
    return version.split('.').slice(0, 3).join('.');
}

const openOption4Version = ['2.1.0'];
function openOption(force = false) {
    const currentVersion = removeBuildFromVersion(Runtime.getManifest().version);
    if (force || openOption4Version.includes(currentVersion)) {
        Runtime.openOptionsPage();
    }
}

// Only use this function during the initial install phase. After
// installation the user may have intentionally unassigned commands.
function checkCommandShortcuts() {
    Commands.getAll((commands) => {

        for (const { name, shortcut } of commands) {
        }
    });
}

function handleCommands() {
    Commands.onCommand.addListener((command, tab) => {
        switch (command) {
            case 'enable-disable-temporary':
                if (!tab) return;
                enableDisableTabExtension(tab);
                break;
        }
    });
}

async function updateTabState(request) {
    const tabs = await Tabs.query({ active: true, currentWindow: true });
    if (!tabs) return;
    const tab = tabs[0];
    enableDisableTabExtension(tab, request.forceSwitchToOFF);
}

async function enableDisableTabExtension(tab, forceOff = undefined) {
    const tabId = tab.id;
    const origin = new URL(tab.url).origin;

    let isOFF = (await Action.getBadgeText({ tabId: tabId })) === 'OFF';
    if (forceOff) {
        isOFF = false;
    }

    let { offs } = await StorageLocal.get({ offs: [] });
    offs = new Set(offs);

    const badgeText = { tabId: tabId, text: isOFF ? '' : 'OFF' };

    if (isOFF) {
        Action.enable(tabId);
        offs = offs.delete(origin);
    } else {
        Action.disable(tabId);
        offs.add(origin);
    }

    await Action.setBadgeText(badgeText);
    await Action.setBadgeBackgroundColor({
        tabId: tabId,
        color: '#FF0000',
    });

    await StorageLocal.set({ offs: Array.from(offs) });

    if (forceOff === undefined) {
        Tabs.reload(tabId);
    }
}

async function getFinalRunbotURL(request) {
    try {
        const response = await fetch(request.href, {
            method: 'HEAD',
        });
        return { url: response.url };
    } catch (ex) {
        Console.warn(ex);
        return { url: null, error: ex.toString() };
    }
}

async function handleMessage(message, sender) {
    if (message.action) return handleAction(message, sender);
    return undefined;
}

async function handleAction(message, sender) {
    let callback = undefined;

    switch (message.action) {
        case MESSAGE_ACTION.TO_BACKGROUND.GET_FEATURES_LIST: {
            callback = Promise.resolve({ features: features });
            break;
        }
        case MESSAGE_ACTION.TO_BACKGROUND.GET_FINAL_RUNBOT_URL: {
            callback = getFinalRunbotURL(message);
            break;
        }
        case MESSAGE_ACTION.TO_BACKGROUND.UPDATE_EXT_STATUS: {
            callback = updateTabState(message);
            break;
        }
        case MESSAGE_ACTION.TO_BACKGROUND.RECREATE_MENU: {
            callback = createContextMenu();
            break;
        }
        case MESSAGE_ACTION.TO_BACKGROUND.TRIGGER_FEATURE: {
            if (!message.feature) return undefined;
            callback = handleFeature(message.feature, sender.tab, message.args);
            break;
        }
        case MESSAGE_ACTION.TO_BACKGROUND.TAB_LOADED: {
            callback = updateContext(sender.tab.id);
            break;
        }
    }

    return callback;
}

async function handleFeature(feature, tab, args) {
    if (!features.some((f) => f.id === feature)) return undefined;

    return importFeatureBackgroundFile(feature).then((featureModule) => {
        featureModule.load(tab, args);
    });
}

const html = String.raw;
const css = String.raw;

const toastFadeInOutDurationMillis = 500;
const toastDelayMillis = 100;
const toastDurationMillis = 3000;

const ToastContainerElementID = 'joorney-toast-container';
const ToastItemElementClass = 'joorney-toasty';

const ToastStyle = css`
    #${ToastContainerElementID} {
        display: flex;
        flex-direction: column;
        padding: 16px;
        position: fixed;
        top: 32px;
        width: 100%;
        z-index: 9999;
        pointer-events: none;
        font-family: Roboto, sans-serif;
    }

    .${ToastItemElementClass} {
        display: none;
        opacity: 0;
        align-self: end;
        padding: 16px;
        margin-bottom: 10px;
        border-radius: 4px;
        min-width: 300px;
        max-width: 600px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        position: relative;
        overflow: hidden;
        pointer-events: auto;
    }

    .${ToastItemElementClass}-success .toast-progress {
        background-color: #4caf50;
    }

    .${ToastItemElementClass}-danger .toast-progress {
        background-color: #f44336;
    }

    .${ToastItemElementClass}-info .toast-progress {
        background-color: #2196f3;
    }

    .${ToastItemElementClass}-warning .toast-progress {
        background-color: #ff9800;
    }

    .toast-icon {
        margin-right: 10px;
        font-size: 24px;
    }

    .toast-content {
        flex-grow: 1;
        align-content: center;
    }

    .toast-title {
        font-weight: bold;
        margin-bottom: 5px;
    }

    .toast-text {
        max-width: 500px;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .toast-feature span {
        background-color: rgba(128, 128, 128, .25);
    }

    .toast-close {
        cursor: pointer;
        position: absolute;
        top: 8px;
        right: 8px;
        font-size: 16px;
        background: transparent;
        border: none;
    }

    .toast-progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 5px;
        animation: progressBar ${toastDurationMillis}ms linear forwards;
        animation-delay: ${toastDelayMillis + toastFadeInOutDurationMillis}ms;
    }

    @keyframes progressBar {
        from { width: 100%; }
        to { width: 0%; }
    }
  `.trim();

html`
    <div id="${ToastContainerElementID}">
        <style>${ToastStyle}</style>
    </div>
`.trim();

const openVersionKey = 'joorney-runbot';

function getRunbotOpenUrl(version) {
    return `https://runbot.odoo.com?${openVersionKey}=${version}`;
}

function initOmni() {
    OmniBox.onInputStarted.removeListener(onStarted);
    OmniBox.onInputStarted.addListener(onStarted);
}

async function onStarted() {
    const { autoOpenRunbotEnabled } = await StorageSync.get({ autoOpenRunbotEnabled: false });
    if (!autoOpenRunbotEnabled) {
        await OmniBox.setDefaultSuggestion({
            description:
                'The functionality to open a runbot from URL is currently disabled. Open options to enabled "Auto Open Runbot"!',
        });
    } else {
        await OmniBox.setDefaultSuggestion({ description: 'Open <match>%s</match> <dim>(if found)</dim>' });
        OmniBox.onInputChanged.removeListener(onChange);
        OmniBox.onInputChanged.addListener(onChange);

        OmniBox.onInputEntered.removeListener(onEntered);
        OmniBox.onInputEntered.addListener(onEntered);
    }
}

function onChange(text, suggest) {
    const suggestions = getSuggestions(text);
    suggest(suggestions);
}

function onEntered(text) {
    const url = getURLFromKeyword(text);
    if (url) {
        openURL(url);
    }
}

async function openURL(url) {
    const { omniboxFocusCurrentTab } = await StorageSync.get({ omniboxFocusCurrentTab: false });
    if (omniboxFocusCurrentTab) {
        Tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs.length > 0) {
                Tabs.update(tabs[0].id, { url });
            }
        });
    } else {
        Tabs.create({ url });
    }
}

function getSuggestions(keyword) {
    const prefix = 'rb';
    if (!keyword.startsWith(prefix)) return [];

    const suggestions = SUPPORTED_VERSION.map((v) => ({ value: v, keyword: `${prefix}:${v}` }))
        .filter((v) => v.keyword.startsWith(keyword))
        .map((version) => ({
            content: version.keyword,
            description: `Open Runbot for version '${version.value}'`,
        }));
    suggestions.push({
        content: 'rb:master',
        description: `Open Runbot for version 'master'`,
    });
    return suggestions;
}

function getURLFromKeyword(keyword) {
    const pattern = /^rb:(.+)$/;
    const match = keyword.match(pattern);

    if (match) {
        const version = match[1];
        return getRunbotOpenUrl(version);
    }

    return null;
}

// On page # path change, pre 17.2
WebNavigation.onReferenceFragmentUpdated.addListener((e) => {
    if (e.url.startsWith('http')) {
        sendTabMessage(e.tabId, MESSAGE_ACTION.TO_CONTENT.TAB_NAVIGATION, {
            url: e.url,
            navigator: true,
            fragment: true,
        });
    }
});

// 17.2
WebNavigation.onHistoryStateUpdated.addListener((e) => {
    if (e.url.startsWith('http')) {
        sendTabMessage(e.tabId, MESSAGE_ACTION.TO_CONTENT.TAB_NAVIGATION, {
            url: e.url,
            navigator: true,
            history: true,
        });
    }
});

Runtime.onInstalled.addListener(async (details) => {
    const isInstall = details.reason === Runtime.OnInstalledReason.INSTALL;
    if (isInstall) {
        const settingsOrDefault = getCurrentSettings(features);
        await StorageSync.set(settingsOrDefault);
        checkCommandShortcuts();
    }
    await sleep(1000);
    openOption(isInstall);
});

Tabs.onActivated.addListener((activeInfo) => {
    updateContext(activeInfo.tabId);
});

// Handled by message "TAB_LOADED"
// Tabs.onUpdated.addListener((tabId, changeInfo, _tab) => {
//     if (changeInfo.status === 'complete') {
//         updateContext(tabId);
//     }
// });

Windows.onFocusChanged.addListener(async (windowId) => {
    const tabs = await Tabs.query({ active: true, windowId: windowId });
    if (tabs.length > 0) updateContext(tabs[0].id);
});

// Triggers when a message is received (from the content script)
Runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleMessage(message, sender)
        .then(async (r) => {
            sendResponse(r);
        })
        .catch((ex) => {
            Console.warn(ex);
            sendResponse();
        });
    return true;
});

ContextMenus.onClicked.addListener(onContextMenuItemClick);

async function main() {
    // Add some delay to avoid initialization side effect
    await sleep(1000);

    checkVersion();
    handleCommands();
    checkHostsExpiration();

    loadFeaturesConfiguration();

    initOmni();

    createContextMenu();
}

main();

var adminDebugLoginConfiguration = {
    id: 'adminDebugLoginRunbot',
    display_name: '[Runbot] Admin Debug Login',
    icon: ['<i class="fa-solid fa-rocket"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        adminDebugLoginRunbotEnabled: false,
        adminDebugLoginRunbotLimitedOrigins: ['https://runbot.odoo.com', 'regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
    },
    limited: true,
};

var configuration$q = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: adminDebugLoginConfiguration
});

var configuration$o = {
    id: 'assignMeTask',
    display_name: 'Assign Me Task',
    icon: ['<i class="fa-solid fa-user-plus"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        assignMeTaskEnabled: false,
        assignMeTaskWhitelistMode: false,
    },
    supported_version: ['16.3+'],
};

var configuration$p = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$o
});

var configuration$m = {
    id: 'awesomeLoadingLarge',
    display_name: 'Awesome Loading Large',
    icon: ['<i class="fa-solid fa-circle-notch"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingSmall',
    defaultSettings: {
        awesomeLoadingLargeEnabled: false,
        awesomeLoadingLargeWhitelistMode: false,
        awesomeLoadingLargeImage: 'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['16:17'],
};

var configuration$n = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$m
});

var configuration$k = {
    id: 'awesomeLoadingSmall',
    display_name: 'Awesome Loading Small',
    icon: ['<i class="fa-solid fa-spinner"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingLarge',
    defaultSettings: {
        awesomeLoadingSmallEnabled: false,
        awesomeLoadingSmallWhitelistMode: false,
        awesomeLoadingSmallImage: '',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['15+'],
};

var configuration$l = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$k
});

var configuration$i = {
    id: 'awesomeStyle',
    display_name: 'Awesome Style',
    icon: ['<i class="fa-brands fa-css3-alt"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: true,
    },
    defaultSettings: {
        awesomeStyleEnabled: false,
        awesomeStyleWhitelistMode: false,
        awesomeStyleCSS: '',
    },
    supported_version: ['15+'],
};

var configuration$j = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$i
});

var configuration$g = {
    id: 'contextOdooMenus',
    display_name: 'Context OdooMenus',
    icon: ['<i class="fa-solid fa-location-arrow"></i>'],
    trigger: {
        background: false,
        load: false,
        navigate: false,
        context: true,
    },
    customization: {
        option: true,
        popup: false,
    },
    defaultSettings: {
        contextOdooMenusEnabled: false,
        contextOdooMenusWhitelistMode: false,
        contextOdooMenusContextMenu: {},
    },
    supported_version: ['15+'],
};

var configuration$h = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$g
});

var configuration$e = {
    id: 'impersonateLoginRunbot',
    display_name: '[Runbot] Impersonate Login',
    icon: ['<!--<i class="fa-solid fa-people-arrows"></i>-->', '<i class="fa-solid fa-masks-theater"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        impersonateLoginRunbotEnabled: false,
        impersonateLoginRunbotLimitedOrigins: ['regex://.*\\.runbot\\d{3}\\.odoo\\.com'],
    },
    limited: true,
};

var configuration$f = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$e
});

var configuration$c = {
    id: 'newServerActionCode',
    display_name: 'New Server Action Code',
    icon: ['<i class="fa-solid fa-code"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        newServerActionCodeEnabled: false,
        newServerActionCodeWhitelistMode: false,
    },
    supported_version: ['15+'],
};

var configuration$d = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$c
});

var configuration$a = {
    id: 'saveKnowledge',
    display_name: 'Save Knowledge',
    icon: ['<i class="fa-regular fa-bookmark"></i>', '<i class="fa-solid fa-floppy-disk double-fa"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        saveKnowledgeEnabled: false,
        saveKnowledgeWhitelistMode: false,
    },
    supported_version: ['16:17'],
};

var configuration$b = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$a
});

var configuration$8 = {
    id: 'showMyBadge',
    display_name: 'Show My Badge',
    icon: ['<i class="fa-solid fa-certificate"></i>'],
    trigger: {
        background: false,
        load: true,
        navigate: true,
    },
    customization: {
        option: false,
        popup: false,
    },
    defaultSettings: {
        showMyBadgeEnabled: false,
        showMyBadgeWhitelistMode: false,
    },
    supported_version: ['17+'],
};

var configuration$9 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$8
});

var configuration$6 = {
    id: 'starringTaskEffect',
    display_name: 'Starring Task Effect',
    icon: ['<i class="fa-solid fa-star"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        starringTaskEffectEnabled: false,
        starringTaskEffectWhitelistMode: false,
    },
    supported_version: ['16+'],
};

var configuration$7 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$6
});

var configuration$4 = {
    id: 'themeSwitch',
    display_name: 'Theme Switch',
    icon: [
        '<i class="fa-solid fa-sun"></i>',
        '<i class="fa-solid fa-circle double-fa-mask double-fa-bicolor"></i>',
        '<i class="fa-solid fa-moon double-fa"></i>',
    ],
    trigger: {
        background: true,
        load: false,
        navigate: false,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: "themeSwitchMode: 'system', 'autoDark', 'autoLight', 'dynamicLocation', 'dynamicTime'",
    defaultSettings: {
        themeSwitchEnabled: false,
        themeSwitchWhitelistMode: false,
        themeSwitchMode: 'system',
        themeSwitchLocationLatitude: '51.477928',
        themeSwitchLocationLongitude: '-0.001545',
        themeSwitchDarkStartTime: '20:30',
        themeSwitchDarkStopTime: '07:30',
    },
    supported_version: ['16+'],
};

var configuration$5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$4
});

var configuration$2 = {
    id: 'tooltipMetadata',
    display_name: 'Tooltip Metadata',
    icon: ['<i class="fa-solid fa-file-lines"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: false,
    },
    defaultSettings: {
        tooltipMetadataEnabled: false,
        tooltipMetadataWhitelistMode: false,
    },
    supported_version: ['15+'],
};

var configuration$3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration$2
});

var configuration = {
    id: 'unfocusApp',
    display_name: 'Unfocus App',
    icon: ['<i class="fa-solid fa-ghost"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    defaultSettings: {
        unfocusAppEnabled: false,
        unfocusAppWhitelistMode: false,
        unfocusAppReorderEnabled: false,
        unfocusAppShareEnabled: false,
        unfocusAppLightImageURL: 'https://i.imgur.com/AkTvOga.png',
        unfocusAppDarkImageURL: 'https://i.imgur.com/YzShNtH.png',
        unfocusAppOrigins: {},
    },
    supported_version: ['15+'],
};

var configuration$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: configuration
});

class BackgroundFeature {
    constructor(configuration) {
        this.configuration = configuration;
        this.defaultSettings = configuration.defaultSettings;
    }

    async load(tab, args = undefined) {
        // TODO[IMP] Maybe useless as background trigger has been moved to content script side, cf themeSwitch
        if (!tab.url) return;
        const url = sanitizeURL(tab.url);
        const origin = url.origin;
        if (!origin || !origin.startsWith('http')) return;

        if (!(await isAuthorizedFeature(this.configuration.id, url))) return;

        this.loadFeature(tab, url, args);
    }

    async loadFeature(_tab, _url, _args) {}
}

async function setThemeModeCookie(expectedMode, origin, useConfiguredCookie) {
    if (!origin.startsWith('http')) return;
    await Cookies.set({
        name: 'color_scheme',
        value: expectedMode,
        url: origin,
    });
    if (useConfiguredCookie) {
        await Cookies.set({
            name: 'configured_color_scheme',
            value: expectedMode,
            url: origin,
        });
    }
}

async function getThemeModeCookie(origin, useConfiguredCookie) {
    if (!origin.startsWith('http')) return 'light';

    if (!Cookies) return getCookiesFromDocument(useConfiguredCookie);

    const cookies = await Promise.all([
        Cookies.get({
            name: 'configured_color_scheme',
            url: origin,
        }),
        Cookies.get({
            name: 'color_scheme',
            url: origin,
        }),
    ]);
    if (useConfiguredCookie) return cookies[0]?.value || cookies[1]?.value || 'light';
    return cookies[1]?.value || 'light';
}

function getCookiesFromDocument(useConfiguredCookie) {
    if (!document) return 'light';

    const decodedCookie = decodeURIComponent(document.cookie);

    const cookieName =
        decodedCookie.includes('configured_color_scheme') && useConfiguredCookie
            ? 'configured_color_scheme'
            : decodedCookie.includes('color_scheme')
              ? 'color_scheme'
              : null;

    if (!cookieName) return 'light';

    const cookies = decodedCookie.split(';');

    const cookie = cookies.find((c) => c.trim().indexOf(cookieName) === 0).substring(cookieName.length + 2);

    return cookie || 'light';
}

class ThemeSwitchBackgroundFeature extends BackgroundFeature {
    constructor() {
        super(configuration$4);
    }

    async loadFeature(tab, url, args) {
        const {
            themeSwitchMode /* "system", "autoDark", "autoLight", "dynamicLocation", "dynamicTime" */,
            themeSwitchLocationLatitude,
            themeSwitchLocationLongitude,
            themeSwitchDarkStartTime,
            themeSwitchDarkStopTime,
        } = await StorageSync.get(this.configuration.defaultSettings);

        let expectedMode = false;
        const today = new Date();
        const time = today.getHours() * 60 + today.getMinutes();

        switch (themeSwitchMode) {
            case 'system': {
                if (!args.theme) break;
                if (!['dark', 'light'].includes(args.theme)) {
                    console.debug(
                        `Invalid theme provided: ${args.theme}\nYou can open a bug report on https://github.com/MrSweeter/joorney/issues/new/choose`
                    );
                    return;
                }
                expectedMode = args.theme;
                break;
            }
            case 'autoDark':
                expectedMode = 'dark';
                break;
            case 'autoLight':
                expectedMode = 'light';
                break;
            case 'dynamicLocation': {
                const sunData = await this.getSunRiseSunSet(themeSwitchLocationLatitude, themeSwitchLocationLongitude);

                expectedMode = time > sunData.joorney_sunrise && time < sunData.joorney_sunset ? 'light' : 'dark';
                break;
            }
            case 'dynamicTime': {
                let start = themeSwitchDarkStartTime.split(':');
                start = Number.parseInt(start[0]) * 60 + Number.parseInt(start[1]);
                let stop = themeSwitchDarkStopTime.split(':');
                stop = Number.parseInt(stop[0]) * 60 + Number.parseInt(stop[1]);

                expectedMode = time > start && time < stop ? 'dark' : 'light';
            }
        }

        if (!expectedMode) return;

        const useConfiguredCookie = args.version < 17.4;
        const origin = url.origin;
        const currentMode = await getThemeModeCookie(origin, useConfiguredCookie);
        console.log(currentMode);

        if (currentMode !== expectedMode) {
            await setThemeModeCookie(expectedMode, origin, useConfiguredCookie);
            Tabs.reload(tab.id);
        }
    }

    async getSunRiseSunSet(latitude, longitude) {
        let today = new Date();
        today = `${today.getMonth() + 1}-${today.getDate()}-${today.getFullYear()}`;
        const cached = await StorageLocal.get({
            joorney_sunrise: 0,
            joorney_sunset: 23 * 60 + 59,
            joorney_date: '',
        });

        if (cached.joorney_sunrise && cached.joorney_sunset && cached.joorney_date === today) {
            return cached;
        }

        const response = await fetch(`https://api.sunrisesunset.io/json?lat=${latitude}&lng=${longitude}`);

        const json = await response.json();

        let sunrise = json.results.sunrise.split(':');
        sunrise =
            Number.parseInt(sunrise[0]) * 60 + Number.parseInt(sunrise[1]) + (sunrise[2].endsWith('PM') ? 12 * 60 : 0);

        let sunset = json.results.sunset.split(':');
        sunset =
            Number.parseInt(sunset[0]) * 60 + Number.parseInt(sunset[1]) + (sunset[2].endsWith('PM') ? 12 * 60 : 0);

        const data = {
            joorney_sunrise: sunrise,
            joorney_sunset: sunset,
            joorney_date: today,
        };

        await StorageLocal.set(data);
        return data;
    }
}

var background = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ThemeSwitchBackgroundFeature
});
