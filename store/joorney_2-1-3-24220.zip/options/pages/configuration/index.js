var awesomeLoadingLarge = true;
var awesomeLoadingSmall = true;
var assignMeTask = true;
var starringTaskEffect = true;
var saveKnowledge = true;
var themeSwitch = true;
var awesomeStyle = true;
var unfocusApp = true;
var newServerActionCode = true;
var tooltipMetadata = true;
var impersonateLoginRunbot = true;
var adminDebugLoginRunbot = true;
var autoOpenRunbot = true;
var showMyBadge = true;
var contextOdooMenus = true;
var FeaturesState = {
	awesomeLoadingLarge: awesomeLoadingLarge,
	awesomeLoadingSmall: awesomeLoadingSmall,
	assignMeTask: assignMeTask,
	starringTaskEffect: starringTaskEffect,
	saveKnowledge: saveKnowledge,
	themeSwitch: themeSwitch,
	awesomeStyle: awesomeStyle,
	unfocusApp: unfocusApp,
	newServerActionCode: newServerActionCode,
	tooltipMetadata: tooltipMetadata,
	impersonateLoginRunbot: impersonateLoginRunbot,
	adminDebugLoginRunbot: adminDebugLoginRunbot,
	autoOpenRunbot: autoOpenRunbot,
	showMyBadge: showMyBadge,
	contextOdooMenus: contextOdooMenus
};

function isFirefox() {
    return typeof chrome !== 'undefined' && typeof browser !== 'undefined';
}

//export const BrowserAction = isFirefox() ? browser?.browserAction : chrome.action;
isFirefox() ? browser.tabs : chrome.tabs;
isFirefox() ? browser.contextMenus : chrome.contextMenus;
const Runtime = isFirefox() ? browser.runtime : chrome.runtime;
const StorageSync = isFirefox() ? browser.storage.sync : chrome.storage.sync;
isFirefox() ? browser.storage.local : chrome.storage.local;
//export const Scripting = isFirefox() ? browser.scripting : chrome.scripting;
isFirefox() ? browser.webNavigation : chrome.webNavigation;
isFirefox() ? browser.cookies : chrome.cookies;
isFirefox() ? browser.action : chrome.action;
isFirefox() ? browser.commands : chrome.commands;
isFirefox() ? browser.windows : chrome.windows;
isFirefox() ? browser.management : chrome.management;
isFirefox() ? browser.omnibox : chrome.omnibox;

async function sendRuntimeMessage(action, message = {}) {
    try {
        return await Runtime.sendMessage({ action: action, ...message });
    } catch (err) {
        Console.trace('catch runtime', err);
    }
}

const Console = {
    info(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid cyan; padding-left: 8px;', obj);
    },
    log(obj) {
        console.log(obj);
    },
    error(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid red; padding-left: 8px;', obj);
    },
    warn(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid goldenrod; padding-left: 8px;', obj);
    },
    success(obj) {
        console.info(`%c${this._getFormatOperator(obj)}`, 'border-left: 2px solid green; padding-left: 8px;', obj);
    },
    trace(label, obj) {
        console.trace(label, obj);
    },
    critical(obj) {
        console.error(obj);
    },

    _getFormatOperator(obj) {
        switch (typeof obj) {
            case 'string':
                return '%s';
            case 'number':
                return '%s';
            case 'object':
                return '%O';
            default:
                return '%s';
        }
    },
};

const MESSAGE_ACTION = {
    TO_BACKGROUND: {
        GET_FEATURES_LIST: 'GET_FEATURES_LIST',
        GET_FINAL_RUNBOT_URL: 'GET_FINAL_RUNBOT_URL',
        UPDATE_EXT_STATUS: 'UPDATE_EXT_STATUS',
        TRIGGER_FEATURE: 'TRIGGER_FEATURE',
        RECREATE_MENU: 'RECREATE_MENU',
        TAB_LOADED: 'TAB_LOADED',
    },
    TO_CONTENT: {
        TAB_NAVIGATION: 'TAB_NAVIGATION',
        POPUP_HAS_CHANGE: 'POPU¨_HAS_CHANGE',
        REQUEST_ODOO_INFO: 'REQUEST_ODOO_INFO',
        CM_OPEN_MENU: 'CM_OPEN_MENU',
        CM_OPEN_RUNBOT: 'CM_OPEN_RUNBOT',
    },
};

function __variableDynamicImportRuntime5__(path) {
  switch (path) {
    case './src/features/awesomeLoadingLarge/option_customization.js': return Promise.resolve().then(function () { return option_customization$5; });
    case './src/features/awesomeLoadingSmall/option_customization.js': return Promise.resolve().then(function () { return option_customization$4; });
    case './src/features/awesomeStyle/option_customization.js': return Promise.resolve().then(function () { return option_customization$3; });
    case './src/features/contextOdooMenus/option_customization.js': return Promise.resolve().then(function () { return option_customization$2; });
    case './src/features/themeSwitch/option_customization.js': return Promise.resolve().then(function () { return option_customization$1; });
    case './src/features/unfocusApp/option_customization.js': return Promise.resolve().then(function () { return option_customization; });
    default: return new Promise(function(resolve, reject) {
      (typeof queueMicrotask === 'function' ? queueMicrotask : setTimeout)(
        reject.bind(null, new Error("Unknown variable dynamic import: " + path))
      );
    })
   }
 }

({
    configurationVersion: 1,
    toastMode: 'ui',
    toastType: JSON.stringify({
        info: false,
        warning: true,
        danger: true,
        success: false,
    }),

    // [LIMITATION] Object is loaded by default even if values exists - 'https://www.odoo.com': {},
    originsFilterOrigins: {},
    windowActionFallbacks: {
        // 'https://www.odoo.com': {
        //     'my-tasks': 'project.task',
        //     'all-tasks': 'project.task',
        // },
    },

    supportedVersions: ['17.0'],

    useSimulatedUI: false,
    omniboxFocusCurrentTab: false,
});
Object.keys(FeaturesState).filter((k) => FeaturesState[k]);

function importFeatureCustomizationFile(featureID) {
    return __variableDynamicImportRuntime5__(`./src/features/${featureID}/option_customization.js`).then((f) => new f.default());
}

async function loadPage(features, _currentSettings) {
    loadFeatures(features);
}

async function loadFeatures(features) {
    for (const feature of features.filter((f) => f.customization.option)) {
        importFeatureCustomizationFile(feature.id).then((featureModule) => featureModule.load());
    }
}

var configuration$5 = {
    id: 'awesomeLoadingLarge',
    display_name: 'Awesome Loading Large',
    icon: ['<i class="fa-solid fa-circle-notch"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingSmall',
    defaultSettings: {
        awesomeLoadingLargeEnabled: false,
        awesomeLoadingLargeWhitelistMode: false,
        awesomeLoadingLargeImage: 'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['16:17'],
};

var configuration$4 = {
    id: 'awesomeLoadingSmall',
    display_name: 'Awesome Loading Small',
    icon: ['<i class="fa-solid fa-spinner"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: 'awesomeLoadingImages is shared with awesomeLoadingLarge',
    defaultSettings: {
        awesomeLoadingSmallEnabled: false,
        awesomeLoadingSmallWhitelistMode: false,
        awesomeLoadingSmallImage: '',
        awesomeLoadingImages: [
            'https://github.githubassets.com/images/mona-loading-dark.gif',
            'https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif',
            'https://static.wikia.nocookie.net/fbbc7304-c0ac-44dc-9ccd-a839ee627a9a/scale-to-width/370',
        ],
    },
    supported_version: ['15+'],
};

var configuration$3 = {
    id: 'awesomeStyle',
    display_name: 'Awesome Style',
    icon: ['<i class="fa-brands fa-css3-alt"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: false,
        option: true,
    },
    defaultSettings: {
        awesomeStyleEnabled: false,
        awesomeStyleWhitelistMode: false,
        awesomeStyleCSS: '',
    },
    supported_version: ['15+'],
};

var configuration$2 = {
    id: 'contextOdooMenus',
    display_name: 'Context OdooMenus',
    icon: ['<i class="fa-solid fa-location-arrow"></i>'],
    trigger: {
        background: false,
        load: false,
        navigate: false,
        context: true,
    },
    customization: {
        option: true,
        popup: false,
    },
    defaultSettings: {
        contextOdooMenusEnabled: false,
        contextOdooMenusWhitelistMode: false,
        contextOdooMenusContextMenu: {},
    },
    supported_version: ['15+'],
};

var configuration$1 = {
    id: 'themeSwitch',
    display_name: 'Theme Switch',
    icon: [
        '<i class="fa-solid fa-sun"></i>',
        '<i class="fa-solid fa-circle double-fa-mask double-fa-bicolor"></i>',
        '<i class="fa-solid fa-moon double-fa"></i>',
    ],
    trigger: {
        background: true,
        load: false,
        navigate: false,
    },
    customization: {
        popup: true,
        option: true,
    },
    __comment__: "themeSwitchMode: 'system', 'autoDark', 'autoLight', 'dynamicLocation', 'dynamicTime'",
    defaultSettings: {
        themeSwitchEnabled: false,
        themeSwitchWhitelistMode: false,
        themeSwitchMode: 'system',
        themeSwitchLocationLatitude: '51.477928',
        themeSwitchLocationLongitude: '-0.001545',
        themeSwitchDarkStartTime: '20:30',
        themeSwitchDarkStopTime: '07:30',
    },
    supported_version: ['16+'],
};

var configuration = {
    id: 'unfocusApp',
    display_name: 'Unfocus App',
    icon: ['<i class="fa-solid fa-ghost"></i>'],
    trigger: {
        load: true,
        navigate: true,
    },
    customization: {
        popup: true,
        option: true,
    },
    defaultSettings: {
        unfocusAppEnabled: false,
        unfocusAppWhitelistMode: false,
        unfocusAppReorderEnabled: false,
        unfocusAppShareEnabled: false,
        unfocusAppLightImageURL: 'https://i.imgur.com/AkTvOga.png',
        unfocusAppDarkImageURL: 'https://i.imgur.com/YzShNtH.png',
        unfocusAppOrigins: {},
    },
    supported_version: ['15+'],
};

class OptionCustomizationFeature {
    constructor(configuration) {
        this.configuration = configuration;
        this.defaultSettings = configuration.defaultSettings;
        if (!configuration.customization.option) throw new Error(`Invalid state for feature: ${this.configuration.id}`);
    }

    async load() {
        const container = document.querySelector(`div[data-feature-customization="${this.configuration.id}"]`);
        if (!container) throw new Error(`Invalid state for feature: ${this.configuration.id}`);
        container.classList.remove('d-none');

        await this.setupCollapse(container);
    }

    async setupCollapse(container) {
        const toggleElement = container.getElementsByClassName('feature-collapse-toggle')[0];
        const contentElements = container.getElementsByClassName('feature-collapse-content');
        const indicatorElement = container.getElementsByClassName('feature-collapse-indicator')[0];

        function toggle() {
            if (indicatorElement.classList.contains('feature-opened')) {
                for (const el of contentElements) el.style.maxHeight = 0;
                indicatorElement.classList.remove('feature-opened');
            } else {
                for (const el of contentElements) el.style.maxHeight = '100%';
                indicatorElement.classList.add('feature-opened');
            }
        }

        toggleElement.onclick = () => toggle();
        for (const el of contentElements) el.style.maxHeight = 0;
    }
}

class AwesomeLoadingShareOptionCustomizationFeature extends OptionCustomizationFeature {
    async load() {
        const container = document.querySelector(`div[data-feature-customization="awesomeLoading"]`);
        if (!container) throw new Error(`Invalid state for feature: ${this.configuration.id}`);
        container.classList.remove('d-none');

        const awesomeLoadingNewImage = document.getElementById('joorney_awe_loading_new_image');
        awesomeLoadingNewImage.onkeydown = (e) => this.onKeydownHost(e);
        awesomeLoadingNewImage.oninput = (e) => this.onImageChange(e);

        document.getElementById('joorney_awe_loading_new_image_save').onclick = () => this.createAwesomeLoadingImage();

        const configuration = await StorageSync.get(this.configuration.defaultSettings);

        this.renderImagesList(configuration.awesomeLoadingImages);

        this.setupCollapse(container);
    }

    //#region CRUD
    async createAwesomeLoadingImage() {
        const imageInput = document.getElementById('joorney_awe_loading_new_image');
        let imageUrl = imageInput.value;
        if (!imageUrl) {
            this.renderAwesomeLoadingError('Missing url');
            return;
        }

        const images = await this.readAwesomeLoadingImages();

        imageUrl = imageUrl.trim().replace(/\s/g, '');

        try {
            imageUrl = new URL(imageUrl).href;
            images.push(imageUrl);
            await this.renderImagesList(images);
            imageInput.value = '';
        } catch (ex) {
            this.renderAwesomeLoadingError(ex);
        }
    }

    async readAwesomeLoadingImages() {
        const { awesomeLoadingImages } = await StorageSync.get({
            awesomeLoadingImages: '',
        });
        return awesomeLoadingImages;
    }

    async deleteAwesomeLoadingImage(imageUrl) {
        if (confirm(`Are you sure you want to remove image: ${imageUrl}?`)) {
            const images = await this.readAwesomeLoadingImages();
            await this.renderImagesList(images.filter((img) => img !== imageUrl));
        }
    }
    //#endregion

    //#region Event
    onKeydownHost(event) {
        if (event.key === 'Enter') this.createAwesomeLoadingImage();
    }
    onImageChange(event) {
        let imageUrl = event.target.value;
        if (!imageUrl) return;

        imageUrl = imageUrl.trim().replace(/\s/g, '');

        try {
            imageUrl = new URL(imageUrl).href;
            const imagePreview = document.getElementById('joorney_awe_loading_new_image_preview');
            imagePreview.src = imageUrl;
        } catch (ex) {
            Console.warn(ex);
        }
    }
    //#endregion

    //#region UI
    renderAwesomeLoadingError(errorMessage) {
        const container = document.getElementById('joorney_awe_loading_error_footer');
        container.textContent = errorMessage;
        container.style.display = errorMessage ? 'table-cell' : 'none';
    }

    async renderImagesList(imagesArg) {
        const images = Array.from(new Set(imagesArg)).sort();
        await StorageSync.set({ awesomeLoadingImages: images });

        const container = document.getElementById('joorney_awe_loading_images_table_body');
        container.innerHTML = '';
        for (const [id, image] of images.entries()) container.appendChild(this.renderImage(id, image));
        this.renderAwesomeLoadingError();
    }

    renderImage(idx, image) {
        const imageTemplate = document.createElement('template');
        imageTemplate.innerHTML = `
            <tr>
                <td class="p-1 joorney-valign-middle">
                    <img class="joorney-awe-loading-preview" loading="lazy" src="${image}" />
                </td>
                <td class="p-1 joorney-valign-middle">
                    <input
                        id="joorney_awe_loading_image_key_${idx}"
                        class="joorney-bg-white form-control border border-0"
                        type="text"
                        disabled
                        value="${image}"
                    />
                </td>
                <td class="p-1 joorney-valign-middle">
                    <button
                        class="joorney_awe_loading_image_delete_${idx} btn btn-outline-danger border-0 btn-floating"
                        title="Delete image"
                    >
                        <i class="joorney-font-icon-size fa fa-trash"></i>
                    </button>
                </td>
            </tr>
        `.trim();

        const imageElement = imageTemplate.content.firstChild;
        const deleteButton = imageElement.getElementsByClassName(`joorney_awe_loading_image_delete_${idx}`)[0];
        deleteButton.onclick = () => this.deleteAwesomeLoadingImage(image);

        return imageElement;
    }
    //#endregion
}

class AwesomeLoadingLargeOptionCustomizationFeature extends AwesomeLoadingShareOptionCustomizationFeature {
    constructor() {
        super(configuration$5);
    }
}

var option_customization$5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeLoadingLargeOptionCustomizationFeature
});

class AwesomeLoadingSmallOptionCustomizationFeature extends AwesomeLoadingShareOptionCustomizationFeature {
    constructor() {
        super(configuration$4);
    }
}

var option_customization$4 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeLoadingSmallOptionCustomizationFeature
});

class AwesomeStyleOptionCustomizationFeature extends OptionCustomizationFeature {
    constructor() {
        super(configuration$3);
    }

    async load() {
        super.load();
        document.getElementById('joorney_awe_style_save').onclick = this.saveAwesomeStyle;

        const configuration = await StorageSync.get(this.configuration.defaultSettings);

        const textareaInput = document.getElementById('joorney_awe_style_css');
        textareaInput.value = configuration.awesomeStyleCSS;
        const linesCount = configuration.awesomeStyleCSS.split(/\r\n|\r|\n/).length;
        textareaInput.setAttribute('rows', Math.max(linesCount + 2, 10));

        textareaInput.onkeydown = (e) => {
            if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                this.saveAwesomeStyle();
            }
        };
    }

    async saveAwesomeStyle() {
        const textareaInput = document.getElementById('joorney_awe_style_css');

        textareaInput.disabled = true;
        await StorageSync.set({ awesomeStyleCSS: textareaInput.value });
        textareaInput.disabled = false;
    }
}

var option_customization$3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: AwesomeStyleOptionCustomizationFeature
});

class ContextOdooMenusOptionCustomizationFeature extends OptionCustomizationFeature {
    constructor() {
        super(configuration$2);
        this.menusKey = 'contextOdooMenusContextMenu';
    }

    async load() {
        super.load();
        const menus = await this.getItems();
        this.setup(menus);
    }

    async getItems() {
        const settings = await StorageSync.get(this.defaultSettings);
        return settings[this.menusKey];
    }

    async setItems(menus) {
        await StorageSync.set({ [this.menusKey]: menus });
    }

    //#region CRUD
    async create() {
        const pathInput = document.getElementById('joorney_contextOdooMenus_new_path');

        try {
            const menus = await this.updateOrCreate(crypto.randomUUID(), pathInput.value, false);
            await this.saveAndRender(menus, true);
            pathInput.value = '';
        } catch (error) {
            this.displayError(error.message);
        }
    }

    async toggle(id, active) {
        const menus = await this.getItems();
        menus[id].active = active;
        await this.saveAndRender(menus, false);
    }

    async favorite(id, favorite) {
        const menus = await this.getItems();
        menus[id].favorite = favorite;
        await this.saveAndRender(menus, true);
    }

    async updatePath(id, path) {
        try {
            const menus = await this.updateOrCreate(id, path, false);
            await this.saveAndRender(menus, false);
        } catch (error) {
            this.displayError(error.message);
        }
    }

    async reorder(id, moveUp) {
        const menus = await this.getItems();

        const sortedRecordIds = Object.keys(menus).sort((k1, k2) => menus[k1].order - menus[k2].order);

        const curPos = sortedRecordIds.indexOf(id);
        const newPos = Math.min(Math.max(curPos + (moveUp ? -1 : 1), 0), sortedRecordIds.length - 1); // Keep newPos in bounds (0 <= newPos <= maxPos)

        [sortedRecordIds[curPos], sortedRecordIds[newPos]] = [sortedRecordIds[newPos], sortedRecordIds[curPos]]; // ES6 Swap

        sortedRecordIds.forEach((k, i) => {
            menus[k].order = i;
        }); // Rewrite order

        await this.saveAndRender(menus, true);
    }

    async remove(id, path) {
        if (confirm(`Are you sure you want to remove the menu: ${path}?`)) {
            const menus = await this.getItems();
            delete menus[id];
            await this.saveAndRender(menus, true);
        }
    }

    async removeAll() {
        if (confirm('Are you sure you want to delete all menus?')) {
            await this.saveAndRender({}, true);
        }
    }

    async updateOrCreate(id, pathArg, overwrite) {
        if (!pathArg) throw new Error('Missing path');

        const menus = await this.getItems();

        const path = pathArg.trim();
        const existingRecord = menus[id];
        let nextPosition = existingRecord?.order ?? Number.MAX_SAFE_INTEGER;

        if (!overwrite) {
            const ids = Object.keys(menus);
            if (ids.includes(id)) {
                throw new Error(`This id is already registered (should not happen): ${id}`);
            }
            const items = Object.values(menus);
            if (items.some((s) => s.path === path)) {
                throw new Error(`This path is already registered: ${path}`);
            }
            nextPosition = Math.max(...items.map((s) => s.order)) + 1;
        }

        menus[id] = {
            id: id,
            path: path,
            order: Math.max(0, nextPosition),
            active: existingRecord?.active ?? true,
            favorite: existingRecord?.favorite ?? false,
        };
        return menus;
    }
    //#endregion

    //#region UI
    displayError(errorMessage) {
        const container = document.getElementById('joorney_contextOdooMenus_new_error');
        container.textContent = errorMessage;
        container.style.display = errorMessage ? 'table-cell' : 'none';
    }

    async saveAndRender(menus, recreate) {
        await this.setItems(menus);
        if (recreate) await sendRuntimeMessage(MESSAGE_ACTION.TO_BACKGROUND.RECREATE_MENU);
        this.render(menus);
    }

    render(menus) {
        const container = document.getElementById('joorney_contextOdooMenus_table_body');
        container.innerHTML = '';

        const menusArray = Object.values(menus).sort((a, b) => a.order - b.order);
        menusArray.forEach((menu, index) =>
            this.renderOne(menu, index === 0, index === menusArray.length - 1, container)
        );

        this.displayError();
    }

    renderOne(menu, isFirst, isLast, container) {
        const template = document.createElement('template');

        template.innerHTML = `
        <tr style="opacity: ${menu.active ? '1' : '0.5'}" ${!menu.active ? 'disabled' : ''}>
            <td class="p-1 ps-3" title="${menu.order}" style="vertical-align: middle">
                <button class="btn p-2 order-up-button-${menu.id}" ${isFirst ? 'disabled style="opacity: 0"' : 0}>
                    <i class="fa fa-caret-up text-success"></i>
                </button>
                <button class="btn p-2 order-down-button-${menu.id}" ${isLast ? 'disabled style="opacity: 0"' : 0}>
                    <i class="fa fa-caret-down text-danger"></i>
                </button>
            </td>
            <td class="p-1" style="vertical-align: middle">
                <input
                    class="joorney_contextOdooMenus_record_path_${menu.id} form-control border border-0 ${
                        menu.active ? '' : 'text-muted'
                    }"
                    placeholder="General Ledger"
                    value="${menu.path}"
                    type="text"
                    ${!menu.active ? 'disabled' : ''}
                    style="background-color: rgba(0,0,0,0)">
            </td>
            <td class="p-1" style="vertical-align: middle">
                <button
                    class="joorney_contextOdooMenus_record_favorite_${menu.id} btn btn-outline-warning ${
                        menu.active ? '' : 'text-muted'
                    } border-0 btn-floating"
                    title="${menu.favorite ? 'Favorite' : 'Not favorite'}">
                    <i style="font-size: 1.2em" class="fa fa-${menu.favorite ? 'solid' : 'regular'} fa-star"></i>
                </button>
                <button
                    class="joorney_contextOdooMenus_record_toggle_${menu.id} btn btn-outline-success ${
                        menu.active ? '' : 'text-muted'
                    } border-0 btn-floating"
                    title="${menu.active ? 'Disable' : 'Enable'} quick menu">
                    <i style="font-size: 1.2em" class="fa fa-toggle-${menu.active ? 'on' : 'off'}"></i>
                </button>
                <button
                    class="joorney_contextOdooMenus_record_update_button_${menu.id} btn btn-outline-success border-0 btn-floating"
                    title="Save modification"
                    disabled>
                    ${menu.active ? '<i class="fa fa-save" style="font-size: 1.2em"></i>' : ''}
                </button>
                <button
                    class="joorney_contextOdooMenus_record_remove_button_${menu.id} btn btn-outline-danger border-0 btn-floating"
                    title="Delete quick menu">
                    <i style="font-size: 1.2em" class="fa fa-trash"></i>
                </button>
            </td>
        </tr>
    `.trim();

        const menuElement = template.content.firstChild;

        const downButton = menuElement.getElementsByClassName(`order-down-button-${menu.id}`)[0];
        const upButton = menuElement.getElementsByClassName(`order-up-button-${menu.id}`)[0];
        const favoriteButton = menuElement.getElementsByClassName(
            `joorney_contextOdooMenus_record_favorite_${menu.id}`
        )[0];
        const stateButton = menuElement.getElementsByClassName(`joorney_contextOdooMenus_record_toggle_${menu.id}`)[0];
        const updateButton = menuElement.getElementsByClassName(
            `joorney_contextOdooMenus_record_update_button_${menu.id}`
        )[0];
        const removeButton = menuElement.getElementsByClassName(
            `joorney_contextOdooMenus_record_remove_button_${menu.id}`
        )[0];
        const pathInput = menuElement.getElementsByClassName(`joorney_contextOdooMenus_record_path_${menu.id}`)[0];

        downButton.addEventListener('click', () => this.reorder(menu.id, false));
        upButton.addEventListener('click', () => this.reorder(menu.id, true));

        favoriteButton.addEventListener('click', () => this.favorite(menu.id, !menu.favorite));
        stateButton.addEventListener('click', () => this.toggle(menu.id, !menu.active));
        updateButton.addEventListener('click', () => this.updatePath(menu.id, pathInput.value));
        removeButton.addEventListener('click', () => this.remove(menu.id, menu.path));

        pathInput.addEventListener('input', (event) => {
            event.target.parentElement.style.backgroundColor = 'rgba(255, 204, 0, 0.25)';
            updateButton.removeAttribute('disabled');
        });

        container.appendChild(menuElement);
    }

    async setup(menus) {
        const newPathInput = document.getElementById('joorney_contextOdooMenus_new_path');
        newPathInput.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                this.create();
            }
        });

        document.getElementById('joorney_contextOdooMenus_new_save').addEventListener('click', () => this.create());
        document
            .getElementById('joorney_contextOdooMenus_delete_all')
            .addEventListener('click', () => this.removeAll());

        this.render(menus);
    }
    //#endregion
}

var option_customization$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ContextOdooMenusOptionCustomizationFeature
});

class ThemeSwitchOptionCustomizationFeature extends OptionCustomizationFeature {
    constructor() {
        super(configuration$1);
        this.updateLocation = this.updateLocation.bind(this);
    }

    async load() {
        super.load();
        const configuration = await StorageSync.get(this.configuration.defaultSettings);

        const latitudeElement = document.getElementById('joorney_theme_switch_latitude');
        latitudeElement.value = configuration.themeSwitchLocationLatitude;
        latitudeElement.onchange = async (e) => await StorageSync.set({ themeSwitchLocationLatitude: e.target.value });

        const longitudeElement = document.getElementById('joorney_theme_switch_longitude');
        longitudeElement.value = configuration.themeSwitchLocationLongitude;
        longitudeElement.onchange = async (e) =>
            await StorageSync.set({ themeSwitchLocationLongitude: e.target.value });

        const getLocationElement = document.getElementById('joorney_theme_switch_get_location_button');
        getLocationElement.onclick = this.updateLocation;

        const darkStartTime = document.getElementById('joorney_theme_switch_dark_start');
        darkStartTime.value = configuration.themeSwitchDarkStartTime;
        darkStartTime.onchange = async (e) => await StorageSync.set({ themeSwitchDarkStartTime: e.target.value });

        const darkStopTime = document.getElementById('joorney_theme_switch_dark_stop');
        darkStopTime.value = configuration.themeSwitchDarkStopTime;
        darkStopTime.onchange = async (e) => await StorageSync.set({ themeSwitchDarkStopTime: e.target.value });
    }

    async updateLocation() {
        const coords = await this.getUserLocation();
        document.getElementById('joorney_theme_switch_latitude').value = coords.latitude;
        document.getElementById('joorney_theme_switch_longitude').value = coords.longitude;

        await StorageSync.set({
            themeSwitchLocationLatitude: coords.latitude,
            themeSwitchLocationLongitude: coords.longitude,
        });
    }

    async getUserLocation() {
        return await new Promise((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(
                (loc) => resolve(loc.coords),
                (error) => reject(error)
            );
        });
    }
}

var option_customization$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: ThemeSwitchOptionCustomizationFeature
});

class UnfocusAppOptionCustomizationFeature extends OptionCustomizationFeature {
    constructor() {
        super(configuration);
    }

    async load() {
        super.load();
        const origins = await this.readUnfocusAppOrigins();

        await this.restoreImage();
        await this.renderOriginsObject(origins);
    }

    //#region CRUD
    async readUnfocusAppOrigins() {
        const { unfocusAppOrigins } = await StorageSync.get({
            unfocusAppOrigins: this.defaultSettings.unfocusAppOrigins,
        });
        return unfocusAppOrigins;
    }

    async deleteUnfocusAppOrigin(origin) {
        if (confirm(`Are you sure you want to remove origin: ${origin}?`)) {
            const origins = await this.readUnfocusAppOrigins();
            delete origins[origin];
            await this.renderOriginsObject(origins);
        }
    }
    //#endregion

    //#region UI
    async renderOriginsObject(origins) {
        await StorageSync.set({ unfocusAppOrigins: origins });

        const container = document.getElementById('joorney_unfocus_app_table_body');
        container.innerHTML = '';
        for (const [id, o] of Object.keys(origins).entries()) {
            const values = Object.values(origins[o]);
            container.appendChild(
                this.renderOrigin(
                    id,
                    o,
                    values.filter((v) => v === 2).length,
                    values.filter((v) => v === true || v === 0).length
                )
            );
        }
    }

    renderOrigin(idx, origin, superfocusCount, unfocusCount) {
        const originTemplate = document.createElement('template');

        originTemplate.innerHTML = `
		<tr>
			<td class="p-1 joorney-valign-middle">
				<input
					id="joorney_unfocus_app_origin_${idx}"
					class="joorney-bg-white form-control border border-0 joorney_unfocus_app_origin_input"
					type="text"
					disabled
					value="${origin}"
				/>
			</td>
			<td>${superfocusCount}</td>
            <td>${unfocusCount}</td>
			<td class="p-1 joorney-valign-middle">
				<button
					class="joorney_unfocus_app_origin_delete_${idx} btn btn-outline-danger border-0 btn-floating"
					title="Delete origin"
				>
					<i class="joorney-font-icon-size fa fa-trash"></i>
				</button>
			</td>
		</tr>
	`.trim();

        const originElement = originTemplate.content.firstChild;

        const deleteButton = originElement.getElementsByClassName(`joorney_unfocus_app_origin_delete_${idx}`)[0];
        deleteButton.onclick = () => this.deleteUnfocusAppOrigin(origin);

        return originElement;
    }
    //#endregion

    //#region Image
    async restoreImage() {
        const { unfocusAppLightImageURL, unfocusAppDarkImageURL } = await StorageSync.get({
            unfocusAppLightImageURL: this.defaultSettings.unfocusAppLightImageURL,
            unfocusAppDarkImageURL: this.defaultSettings.unfocusAppDarkImageURL,
        });

        document.getElementById('joorney_unfocus_app_light_image').src = unfocusAppLightImageURL;
        document.getElementById('joorney_unfocus_app_dark_image').src = unfocusAppDarkImageURL;

        this.loadImageInput(
            'joorney_unfocus_app_light_image_input',
            'joorney_unfocus_app_light_image',
            'unfocusAppLightImageURL',
            unfocusAppLightImageURL
        );

        this.loadImageInput(
            'joorney_unfocus_app_dark_image_input',
            'joorney_unfocus_app_dark_image',
            'unfocusAppDarkImageURL',
            unfocusAppDarkImageURL
        );
    }

    loadImageInput(inputKey, imageKey, configKey, value) {
        const imageInput = document.getElementById(inputKey);
        imageInput.value = value;

        imageInput.oninput = async (e) => {
            let imageUrl = e.target.value.trim().replace(/\s/g, '');
            if (imageUrl.length === 0) {
                await StorageSync.set({ [configKey]: '' });
                return;
            }

            try {
                imageUrl = new URL(imageUrl);
                if (!this.isImageUrlPath(imageUrl.pathname)) throw new Error('Invalid image extension in the url path');

                await StorageSync.set({ [configKey]: `${imageUrl}` });
                imageInput.value = imageUrl;
                document.getElementById(imageKey).src = imageUrl;
            } catch (ex) {
                Console.warn(ex);
            }
        };
    }

    isImageUrlPath(path) {
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg']; // Add more extensions if needed
        const lowercaseUrl = path.toLowerCase();

        return imageExtensions.some((extension) => lowercaseUrl.endsWith(extension));
    }
    //#endregion
}

var option_customization = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: UnfocusAppOptionCustomizationFeature
});

export { loadPage };
